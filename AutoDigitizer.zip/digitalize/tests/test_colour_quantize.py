import unittest, warnings

from ..colour_quantize import *


class TestReduceBits(unittest.TestCase):
    def test_reduce_bits(self):
        in_val = np.array([0b11111111])
        expected = np.array([0b11111100])
        assert reduce_bits(in_val) == expected

    def test_dtype(self):
        in_val = np.array([0b11111111]).astype("uint8")
        expected = np.array([0b11111100]).astype("uint8")

        ret_val = reduce_bits(in_val)

        assert ret_val == expected
        assert ret_val.dtype == expected.dtype

    def test_shape(self):
        in_val = np.array(
            [
                [0b00000011, 0b00000111, 0b00001011, 0b00010011],
                [0b00100011, 0b00100111, 0b00101011, 0b00110011],
                [0b01000011, 0b01000111, 0b01001011, 0b01010011],
            ]
        ).astype("uint8")
        expected = np.array(
            [
                [0b00000000, 0b00000100, 0b00001000, 0b00010000],
                [0b00100000, 0b00100100, 0b00101000, 0b00110000],
                [0b01000000, 0b01000100, 0b01001000, 0b01010000],
            ]
        ).astype("uint8")

        ret_val = reduce_bits(in_val)

        assert (ret_val == expected).all()
        assert ret_val.shape == expected.shape

    def test_n_bits(self):
        in_val = np.array([0b11111111])
        expected = np.array([0b11000000])
        assert reduce_bits(in_val, 6) == expected

    def test_out_of_bounds(self):
        in_val = np.array([0b11111111]).astype("uint8")
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            ret_val = reduce_bits(in_val, -1)
            assert ret_val == in_val
            assert len(w) == 1
            assert "outside of range" in str(w[-1].message)

            ret_val = reduce_bits(in_val, 10)
            assert ret_val == np.array([0b00000000]).astype("uint8")
            assert len(w) == 2
            assert "outside of range" in str(w[-1].message)


class TestPackUnpackPixel(unittest.TestCase):
    def test_pack(self):
        in_val = np.array([0xBA, 0xDB, 0xED]).astype("uint8")
        expected = np.array([0xBADBED])

        assert pack_pixel_channels(in_val) == expected

    def test_unpack(self):
        in_val = np.array([0xBADBED])
        expected = np.array([0xBA, 0xDB, 0xED]).astype("uint8")

        assert (unpack_pixel_channels(in_val) == expected).all()

    def test_pack_unpack(self):
        in_val = expected = np.array([0xBA, 0xDB, 0xED]).astype("uint8")

        assert (unpack_pixel_channels(pack_pixel_channels(in_val)) == expected).all()

    def test_pack_unpack_metadata(self):
        in_val = expected_unpacked = np.array(
            [
                [0x11AA, 0x12BB, 0x13CC, 0x14DD],
                [0x21AA, 0x22BB, 0x23CC, 0x24DD],
                [0x31AA, 0x32BB, 0x33CC, 0x34DD],
            ]
        ).astype("uint16")
        expected_packed = np.array(
            [
                0x11AA12BB13CC14DD,
                0x21AA22BB23CC24DD,
                0x31AA32BB33CC34DD,
            ]
        )

        packed, metadata = pack_pixel_channels(in_val, True)
        assert (packed == expected_packed).all()

        ret_val = unpack_pixel_channels(packed, **metadata)
        assert (ret_val == expected_unpacked).all()


class TestSamplePixels(unittest.TestCase):
    def test_sample_pixels(self):
        in_val = np.array([[1], [2], [3], [4], [5], [6], [7], [8], [9], [0]])
        ret_val = sample_pixels(in_val, 0.3)

        assert len(ret_val) == 3


class TestSortPixelFreq(unittest.TestCase):
    def test_sort_pixel_frequency(self):
        in_val = np.array(
            [
                [0xA5, 0xB5, 0xC5],
                [0xA5, 0xB5, 0xC5],
                [0xA5, 0xB5, 0xC5],
                [0xA5, 0xB5, 0xC5],
                [0xA5, 0xB5, 0xC5],
                [0xA2, 0xB2, 0xC2],
                [0xA2, 0xB2, 0xC2],
                [0xA1, 0xB1, 0xC1],
            ]
        ).astype("uint8")
        expected = [
            (np.array([0xA5, 0xB5, 0xC5]).astype("uint8"), 5),
            (np.array([0xA2, 0xB2, 0xC2]).astype("uint8"), 2),
            (np.array([0xA1, 0xB1, 0xC1]).astype("uint8"), 1),
        ]
        assert all(
            [
                (y[0] == y[1]).all()
                for x in zip(sort_pixel_frequency(in_val, True), expected)
                for y in zip(*x)
            ]
        )


class TestReorderChannels(unittest.TestCase):
    def test_reverse(self):
        in_val = np.array([1, 2, 3, 4, 5])
        expected = np.array([5, 4, 3, 2, 1])

        assert (reorder_channels(in_val) == expected).all()

    def test_retain_shape(self):
        in_val = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [1, 2, 3]]])

        assert reorder_channels(in_val).shape == in_val.shape

    def test_specific_order(self):
        in_val = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [1, 2, 3]]])
        expected = np.array(
            [[[2, 1, 3, 2], [5, 4, 6, 5]], [[8, 7, 9, 8], [2, 1, 3, 2]]]
        )

        assert (reorder_channels(in_val, [1, 0, 2, 1]) == expected).all()

    def test_out_of_bounds(self):
        in_val = np.array([1, 2, 3])
        with self.assertRaises(IndexError) as cm:
            reorder_channels(in_val, [9, 9, 9])


class TestPixelRangeMask(unittest.TestCase):
    def test_pixel_range_mask(self):
        image = np.array(
            [
                [[255, 255, 255], [255, 255, 255], [255, 255, 255]],
                [[0, 0, 255], [0, 0, 255], [0, 0, 255]],
                [[0, 255, 0], [0, 255, 0], [0, 255, 0]],
                [[255, 0, 0], [255, 0, 0], [255, 0, 0]],
            ]
        )
        reference = np.array([255, 255, 255])
        thresh_range = np.array([25, 25, 25])
        expected = np.array(
            [
                [True, True, True],
                [False, False, False],
                [False, False, False],
                [False, False, False],
            ]
        )
        assert (pixel_range_mask(image, reference, thresh_range) == expected).all()


if __name__ == "__main__":
    unittest.main()
