#!/usr/bin/env python

"""
_summary_

Adapted from https://github.com/mzucker/noteshrink
"""

import functools
import operator
import warnings
from typing import List, Optional, Tuple, Union

import cv2
import numpy as np
import numpy.typing as npt
from scipy.cluster.vq import kmeans, vq, whiten


def reduce_bits(image: npt.NDArray, bits_to_reduce: int = 2) -> npt.NDArray:
    """
    Reduces the number of bits per channel in the given image.

    :param image: numpy.ndarray of image, assumes last axis is the image channels
    :param bits_to_reduce: Number of bits to reduce from each channel, assumes to
    be in range [0, bits per channel], defaults to 2

    :return: numpy.ndarray of image with `bits_to_reduce` least significant bits set to 0
    """
    img_type = image.dtype
    bits_per_channel = img_type.itemsize * 8

    if (bits_to_reduce < 0) or (bits_per_channel < bits_to_reduce):
        warnings.warn(
            f"{bits_to_reduce=} outside of range [0, {bits_per_channel=}], modified to be within range"
        )
        bits_to_reduce = max(0, min(bits_to_reduce, bits_per_channel))

    ret = (image.astype(int) >> bits_to_reduce) << bits_to_reduce
    return ret.astype(img_type)


def pack_pixel_channels(
    image: npt.NDArray, return_metadata: bool = False
) -> Union[npt.NDArray, Tuple[npt.NDArray, dict]]:
    """
    Bit packs all channels into a single integer

    :param image: `m * n * c` numpy.ndarray of image
    :param return_metadata: Includes number of channels, bits per channel, and data
    type, defaults to False

    :return: `m * n` numpy.ndarray of image
    """
    img_shape = image.shape[:-1]
    metadata = {
        "num_channels": image.shape[-1],
        "bits_per_channel": image.dtype.itemsize * 8,
        "dtype": image.dtype,
    }

    # Resize as list of pixels
    image = image.astype(int).reshape((-1, metadata["num_channels"]))

    # Bitshift each channel
    # For 3-channel 8-bit RGB image, shifts will be as follows:
    # Red << 16, Green << 8, Blue << 0
    # eg. Red = 0xBA, Green = 0xDB, Blue = 0xED
    # => Red = 0xBA0000, Green = 0x00DB00, Blue = 0x0000ED
    bitshift_channels = [
        image[:, i]
        << (metadata["bits_per_channel"] * (metadata["num_channels"] - i - 1))
        for i in range(metadata["num_channels"])
    ]
    # Pack all channels together
    # For 3-channel 8-bit RGB image, channels will be packed as follow:
    # Red|Green|Blue
    # eg. Red = 0xBA0000, Green = 0x00DB00, Blue = 0x0000ED
    # => Packed = 0xBADBED
    packed_img: npt.NDArray = functools.reduce(operator.or_, bitshift_channels)

    if not return_metadata:
        return packed_img.reshape(img_shape)
    else:
        return packed_img.reshape(img_shape), metadata


def unpack_pixel_channels(
    image: npt.NDArray,
    num_channels: int = 3,
    bits_per_channel: int = 8,
    dtype: np.number = np.uint8,
) -> npt.NDArray:
    """
    Unpacks a `m * n` array of integers into multiple channels values.

    :param image: `m * n` numpy.ndarray of image
    :param num_channels: Number of image channels, defaults to 3
    :param bits_per_channel: Number of bits per channel, defaults to 8
    :param dtype: Return dtype, defaults to np.uint8

    :return: `m * n * c` numpy.ndarray of image
    """
    img_shape = image.shape
    image = image.reshape((-1, 1))

    # Unpack by bitshifting and masking
    # For 24-bit integer to 3-channel 8-bit RGB:
    # eg. 0xBADBED
    # Red   => (0xBADBED >> (8 * 2)) & (2**8 -1) = (0xBADBED >> 16) & 0xFF =     0xBA & 0xFF = 0xBA
    # Green => (0xBADBED >> (8 * 1)) & (2**8 -1) = (0xBADBED >>  8) & 0xFF =   0xBADB & 0xFF = 0xDB
    # Blue  => (0xBADBED >> (8 * 0)) & (2**8 -1) = (0xBADBED >>  0) & 0xFF = 0xBADBED & 0xFF = 0xED
    unpacked_img = [
        (image >> (bits_per_channel * i)) & (2**bits_per_channel - 1)
        for i in reversed(range(num_channels))
    ]

    # Reshape to m * n * c
    unpacked_img = np.hstack(unpacked_img).reshape(img_shape + (num_channels,))
    return unpacked_img.astype(dtype)


def sample_pixels(image: npt.NDArray, sample_fraction: float = 0.1) -> npt.NDArray:
    """
    Pick a fixed percentage of pixels in the image, returned in random order.

    :param image: `m * n * c` numpy.ndarray of image
    :param sample_fraction: Percentage of pixels to sample, defaults to 0.1

    :return: `s * c` numpy.ndarray of random selection of pixels
    """
    img_channels = image.shape[-1]

    # Flatten image
    pixels = image.reshape((-1, img_channels))

    num_pixels = pixels.shape[0]
    num_samples = int(num_pixels * sample_fraction)

    # Faster to shuffle on index
    idx = np.arange(num_pixels)
    np.random.shuffle(idx)

    return pixels[idx[:num_samples]]


def sort_pixel_frequency(
    pixels: npt.NDArray, return_counts: bool = False, sort_asc: bool = False
) -> Union[npt.NDArray, List[Tuple[npt.NDArray, int]]]:
    """
    Sorts pixel by decreasing frequency

    **Performs bitpacking, do not use with float type**

    :param pixels: Array of pixels or image
    :param return_counts: Include counts in return, defaults to False
    :param sort_asc: Sort by ascending order, defaults to False

    :return: Array of pixels sorted by frequency or list of (pixel, frequency) tuples
    """
    # Bit-pack pixels
    packed, metadata = pack_pixel_channels(pixels, True)

    # Get unique pixels and counts
    unique, counts = np.unique(packed, return_counts=True)

    # Sort unpacked pixels by counts in decreasing order
    unpacked = unpack_pixel_channels(unique, **metadata)
    frequencies = sorted(
        zip(unpacked, counts),
        key=lambda x: x[1],
        reverse=not sort_asc,
    )

    if return_counts:
        return frequencies
    else:
        return np.array(list(zip(*frequencies))[0])


def reorder_channels(
    image: npt.NDArray, order: Union[str, list] = "reverse"
) -> npt.NDArray:
    """
    Reorders image channels.

    :param image: numpy.ndarray of image, assumes last axis is the image channels
    :param order: Specific order of channels or "reverse", defaults to "reverse"

    :raises IndexError: If index in `order` is out of bounds

    :return: numpy.ndarray of image
    """
    num_channels = image.shape[-1]

    if order == "reverse":
        order = list(range(num_channels))
        order.reverse()

    idx = (slice(None),) * (len(image.shape) - 1) + (order,)

    try:
        return image[idx]
    except IndexError:
        raise IndexError(
            f"{order=} for {num_channels=} should be within range [0, {num_channels-1}]"
        )


def pixel_range_mask(
    image: npt.NDArray,
    reference: npt.NDArray,
    threshold_range: npt.NDArray,
    negate: bool = False,
    broadcast_to_image: bool = False,
    channel_max: Optional[npt.NDArray] = None,
) -> npt.NDArray:
    """
    Get `m * n` boolean mask of `m * n * c` image where pixel colours are **within**
    `reference` +/- `threshold_range`. If `broadcast_to_image` is `True`, convert
    `m * n` mask to `m * n * c` image with `True` portion as `channel_max` and
    `False` as `0`. Set `negate` to `True` to create mask to filter our reference
    colour (eg. remove background colour).

    :param image: numpy.ndarray of image, assumes last axis is the image channels
    :param reference: Reference colour
    :param threshold_range: +/- range within reference colour
    :param negate: Negate output, defaults to False
    :param broadcast_to_image: Convert boolean mask to image by matching original
    image dtype and number of channels, and, replaces `True` portion with `channel_max`
    and `False` with `0`, defaults to False
    :param channel_max: Colour to use for `True`, if `None`, uses image dtype max
    value. Suggested values - RGB/BGR: `np.array([255, 255, 255])`, HSV: `np.array([0.0, 0.0, 1.0])`,
    defaults to None

    :raises ValueError: If number of channels between image, reference colour, and
    threshold range does not match

    :return: `m * n` numpy.ndarray boolean mask or `m * n * c` numpy.ndarray image
    """
    shape = image.shape
    num_channels = shape[-1]
    dtype = image.dtype

    # Check number of channels
    if (reference.shape[-1] != num_channels) or (
        threshold_range.shape[-1] != num_channels
    ):
        raise ValueError(
            f"Mismatched number of channels, {num_channels=}, {reference.shape=}, {threshold_range.shape=}"
        )

    # Identify if each channel component falls within threshold range
    # eg. 3-channel image
    # image = [
    #     [[255, 255, 255], [255, 255, 255], [255, 255, 255]],
    #     [[  0,   0, 255], [  0,   0, 255], [  0,   0, 255]],
    #     [[  0, 255,   0], [  0, 255,   0], [  0, 255,   0]],
    #     [[255,   0,   0], [255,   0,   0], [255,   0,   0]],
    # ]
    # reference = [255, 255, 255] +/- [25, 25, 25]
    # channel_component_mask = [
    #     [[ True,  True,  True], [ True,  True,  True], [ True,  True,  True]],
    #     [[False, False,  True], [False, False,  True], [False, False,  True]],
    #     [[False,  True, False], [False,  True, False], [False,  True, False]],
    #     [[ True, False, False], [ True, False, False], [ True, False, False]],
    # ]
    pixel_component_mask = np.abs(image - reference) <= threshold_range

    # Aggregate channel components to determine if each pixel is within threshold range
    # eg. continuing from above
    # pixel_mask = [
    #     [ True,  True,  True],
    #     [False, False, False],
    #     [False, False, False],
    #     [False, False, False],
    # ]
    pixel_mask = np.apply_along_axis(all, len(shape) - 1, pixel_component_mask)

    # Negate pixel mask
    if negate:
        pixel_mask = ~pixel_mask

    # Expand pixel mask to image with same number of channels as original image
    if broadcast_to_image:
        # Use dtype max value if channel_max not provided
        if channel_max is None:
            channel_max: npt.NDArray = (
                np.iinfo(dtype).max
                if isinstance(dtype, np.integer)
                else np.finfo(dtype).max
            )
        # Expand mask by number of channels
        # eg. continuing from above
        # pixel_mask = [
        #     [[ True,  True,  True], [ True,  True,  True], [ True,  True,  True]],
        #     [[False, False, False], [False, False, False], [False, False, False]],
        #     [[False, False, False], [False, False, False], [False, False, False]],
        #     [[False, False, False], [False, False, False], [False, False, False]],
        # ]
        pixel_mask = np.stack((pixel_mask,) * num_channels, axis=len(shape) - 1)
        # Convert boolean mask to dtype mask with False => 0, True => channel_max
        # eg. assuming dtype uint8
        # pixel_mask = [
        #     [[255, 255, 255], [255, 255, 255], [255, 255, 255]],
        #     [[  0,   0,   0], [  0,   0,   0], [  0,   0,   0]],
        #     [[  0,   0,   0], [  0,   0,   0], [  0,   0,   0]],
        #     [[  0,   0,   0], [  0,   0,   0], [  0,   0,   0]],
        # ]
        pixel_mask = (pixel_mask.astype(channel_max.dtype) * channel_max).astype(dtype)

    return pixel_mask


def get_clusters(
    obs: npt.NDArray,
    k_or_guess: Union[int, npt.NDArray],
    iter: int = 20,
    thresh: float = 0.00001,
    check_finite: bool = True,
    rng: Union[int, np.random.Generator, None] = None,
) -> Union[npt.NDArray, float]:
    """
    Wrapper for scipy.cluster.vq.kmeans() with whitening.

    Performs k-means on a set of observation vectors forming k clusters.

    :param obs: M by N array of observations
    :param k_or_guess: The number of centroids to generate or k by N array of initial k centroids
    :param iter: The number of times to run k-means returning best centroid group, defaults to 20
    :param thresh: Terminates the k-means algorithm if the change in distortion <= thresh, defaults to 0.00001
    :param check_finite: Whether to check that the input matrices contain only finite numbers, defaults to True
    :param rng: RNG seed or generator for initializing centroids, defaults to None

    :return: k by N array of k centroids; and distortions as calculated as the
    mean (non-squared) Euclidean distance between obs and centroids
    """
    dtype = obs.dtype
    s = obs.astype("float32")
    whitened = whiten(s, check_finite)
    centroid, distortion = kmeans(
        whitened, k_or_guess, iter, thresh, check_finite, rng=rng
    )
    centroid = centroid * np.std(s, 0)
    return centroid.astype(dtype), distortion


def assign_clusters(
    obs: npt.NDArray, centroids: npt.NDArray, check_finite: bool = True
) -> Tuple[npt.NDArray, npt.NDArray]:
    """
    Wrapper for scipy.cluster.vq.vq()

    Assign codes from a code book to observations.

    :param obs: M by N array of observations
    :param centroids: k by N array of k centroids
    :param check_finite: Whether to check that the input matrices contain only
    finite numbers, defaults to True

    :return: A length M array holding the centroid index for each observation;
    and the distortion (distance) between the observation and its nearest centroid.
    """
    return vq(obs, centroids, check_finite)
