# Creating Plugins
Refer to QGIS docs

# Plugin XML
Minimum XML requirement seems to be:
```xml
<?xml version = '1.0' encoding = 'UTF-8'?>
<plugins>
    <pyqgis_plugin name="Test Plugin AGIS" version="0.1" plugin_id="1">
        <description><![CDATA[Test Description]]></description>
        <version>0.1</version>
        <download_url>file:C:\Users\hchen\Documents\VMShare\General Software\AutoDigitizer\Example plugin\agis.zip</download_url>
        <qgis_minimum_version>3.0.0</qgis_minimum_version>
    </pyqgis_plugin>
</plugins>
```

# Add File Based Plugin Repository
QGIS > Plugins > Manage and Install Plugins... > Settings > Add

Set URL to: `file:[path to plugins xml]`
eg. `file:C:\Users\hchen\Documents\VMShare\General Software\AutoDigitizer\Example plugin\qgis_plugin.xml`

Use "Reload all Repositories" to reload XML
