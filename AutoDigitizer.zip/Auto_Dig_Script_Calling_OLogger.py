import os
import datetime
import cv2
import numpy as np
import rasterio
from rasterio.transform import from_origin
from rasterio.enums import Resampling
from qgis.core import (
    QgsFeature,
    QgsGeometry,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsField,
    QgsFields,
    QgsPoint,
    QgsVectorFileWriter,
    QgsProject,
)
from PyQt5.QtCore import QVariant, QTimer
from PyQt5.QtWidgets import (
    QFileDialog,
    QInputDialog,
    QMessageBox,
    QWidget,
    QProgressBar,
    QApplication,
    QDialog,
    QVBoxLayout,
    QPushButton,
    QComboBox,
    QSpinBox,
    QLabel,
)


log_directory = r"C:\Users\jcarvajal\OneDrive - Orix GeoScience\QGIS_Plugin_Development\Log Files_Script"
log_file= os.path.join(log_directory, "Autodigitizing_Script_Log.txt")

def setup_progress_bar(max_value):
    progress_widget=QWidget()
    progress_widget.setWindowTitle("Processing Progress")
    progress_widget.resize(300,100)

    progress_bar=QProgressBar(progress_widget)
    progress_bar.setGeometry(50,30,200,30)
    progress_bar.setMaximum(max_value)
    progress_bar.setValue(0)

    progress_widget.show()
    QApplication.processEvents()

    return progress_widget, progress_bar

def update_progress_bar(progress_bar,value):
    progress_bar.setValue(value)
    QApplication.processEvents()
    

def initialize_log():
    if not os.path.exists(log_directory):
        os.makedirs(log_directory)
    with open(log_file, "a") as log_file_handle:
        log_file_handle.write(f"\nProcess Log - {datetime.datetime.now()}\n")
        log_file_handle.write("-"*50+"\n")

def write_log(message):
    if os.path.exists(log_file):
        with open(log_file, "r") as log_file_handle:
            existing_log = log_file_handle.read()
    else:
        existing_log =""
    
    with open(log_file, "a") as log_file_handle:
        log_file_handle.write(message + "\n")

class InputDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Input Parameters")
        self.setGeometry(100, 100, 400, 300)

        layout = QVBoxLayout()

        self.raster_path_label = QLabel("Select Raster File:")
        self.raster_path_button = QPushButton("Browse")
        self.raster_path_button.clicked.connect(self.browse_raster_file)
        layout.addWidget(self.raster_path_label)
        layout.addWidget(self.raster_path_button)

        self.output_folder_label=QLabel("Select Output Folder:")
        self.output_folder_button=QPushButton("Browse")
        self.output_folder_button.clicked.connect(self.browse_output_folder)
        layout.addWidget(self.output_folder_label)
        layout.addWidget(self.output_folder_button)

     
        self.operation_label = QLabel("Select Operation (Erosion, Dilation, or None):")
        self.operation_combo = QComboBox()
        self.operation_combo.addItems(["Dilation", "Erosion", "None"])
        layout.addWidget(self.operation_label)
        layout.addWidget(self.operation_combo)

      
        self.kernel_size_label = QLabel("Kernel Size (1-10):")
        self.kernel_size_spin = QSpinBox()
        self.kernel_size_spin.setRange(1, 10)
        self.kernel_size_spin.setValue(3)
        layout.addWidget(self.kernel_size_label)
        layout.addWidget(self.kernel_size_spin)

       
        self.iterations_label = QLabel("Iterations (1-5):")
        self.iterations_spin = QSpinBox()
        self.iterations_spin.setRange(1, 5)
        self.iterations_spin.setValue(1)
        layout.addWidget(self.iterations_label)
        layout.addWidget(self.iterations_spin)

       
        self.num_thresholds_label = QLabel("Number of Thresholds (1-10):")
        self.num_thresholds_spin = QSpinBox()
        self.num_thresholds_spin.setRange(1, 10)
        self.num_thresholds_spin.setValue(1)
        self.num_thresholds_spin.valueChanged.connect(self.update_threshold_inputs)
        layout.addWidget(self.num_thresholds_label)
        layout.addWidget(self.num_thresholds_spin)

        self.threshold_inputs_layout=QVBoxLayout()
        self.num_thresholds_layout=QVBoxLayout()
        self.threshold_inputs_widget = QWidget()
        self.threshold_inputs_widget.setLayout(self.threshold_inputs_layout)
        layout.addWidget(self.threshold_inputs_widget)

     
        self.submit_button = QPushButton("Submit")
        self.submit_button.clicked.connect(self.submit_inputs)
        layout.addWidget(self.submit_button)

        self.setLayout(layout)
        self.result = None
        self.update_threshold_inputs()

    def browse_raster_file(self):
        file_types = "GeoTIFF Files (*.tif *.tiff);;JPEG Files (*.jpg *.jpeg);;PNG Files (*.png)"
        raster_path, _ = QFileDialog.getOpenFileName(None, "Select Raster File", "", file_types)
        self.raster_path_label.setText(raster_path)

    def browse_output_folder(self):
        output_folder = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        self.output_folder_label.setText(output_folder)

    def update_threshold_inputs(self):
        num_thresholds=self.num_thresholds_spin.value()
        for i in reversed(range(self.threshold_inputs_layout.count())):
            widget = self.threshold_inputs_layout.itemAt(i).widget()
            if widget is not None:
                widget.deleteLater()
            
        self.threshold_inputs = []
        for i in range(num_thresholds):
            threshold_label = QLabel(f"Threshold {i+1}:")
            threshold_spin=QSpinBox()
            threshold_spin.setRange(0,255)
            threshold_spin.setValue(255 // num_thresholds * (i+1))
            
            self.threshold_inputs_layout.addWidget(threshold_label)
            self.threshold_inputs_layout.addWidget(threshold_spin)

            self.threshold_inputs.append(threshold_spin)

    def submit_inputs(self):
        thresholds = [spin.value() for spin in self.threshold_inputs]
        self.result = {
            "raster_path": self.raster_path_label.text(),
            "operation": self.operation_combo.currentText(),
            "kernel_size": self.kernel_size_spin.value(),
            "iterations": self.iterations_spin.value(),
            "num_thresholds": self.num_thresholds_spin.value(),
            "thresholds": thresholds,
            "output_folder":self.output_folder_label.text(),
        }
        self.accept()

def save_binary_geotiff(binary_image,threshold_value, output_dir, transform, crs):
    output_path=os.path.join(output_dir, f"binary_image_{threshold_value}.tif")
    with rasterio.open(
        output_path, 'w', driver='GTiff', height=binary_image.shape[0],
        width=binary_image.shape[1], count=1, dtype=binary_image.dtype,
        crs=crs, transform=transform
    ) as dst:
        dst.write(binary_image,1)
    write_log(f"Binary image saved to {output_path}")
    return output_path

    

initialize_log()
start_time=datetime.datetime.now()

input_dialog = InputDialog()
if input_dialog.exec_() == QDialog.Accepted:
    inputs = input_dialog.result
    raster_path = inputs['raster_path']
    operation = inputs['operation']
    kernel_size = inputs['kernel_size']
    iterations = inputs['iterations']
    num_thresholds = inputs['num_thresholds']
    output_folder=inputs['output_folder']

    if not raster_path:
        print("File selection canceled.")
        write_log("File selection canceled.")
    else:
        layer = QgsRasterLayer(raster_path, "Raster Layer", "gdal")
        if not layer.isValid():
            print("Error: Could not load raster layer.")
            write_log("Error: Could not load raster layer.")
        else:
            threshold_values = [int(i * (255 / num_thresholds)) for i in range(1, num_thresholds + 1)]
            all_contours = []
            fields = QgsFields()
            fields.append(QgsField("ID", QVariant.Int))
            fields.append(QgsField("Threshold", QVariant.Int))
            fields.append(QgsField("Length_Km", QVariant.Double))
            memory_layer = QgsVectorLayer(
                "LineString?crs=" + layer.crs().authid(),
                "combined_contours",
                "memory",
            )
            memory_layer.dataProvider().addAttributes(fields)
            memory_layer.updateFields()
            x_pixel_size = layer.rasterUnitsPerPixelX()
            y_pixel_size = layer.rasterUnitsPerPixelY()
            xmin, ymax = layer.extent().xMinimum(), layer.extent().yMaximum()

            block = layer.dataProvider().block(
                    1, layer.extent(), layer.width(), layer.height()
            )
            raster_data = np.frombuffer(block.data(), dtype=np.uint8).reshape(
                    (block.height(), block.width())
            )

            transform = from_origin(
                layer.extent().xMinimum(),
                layer.extent().yMaximum(),
                layer.rasterUnitsPerPixelX(),
                layer.rasterUnitsPerPixelY()
            )
            crs=layer.crs().authid()

            progress_widget, progress_bar = setup_progress_bar(len(threshold_values))

            binary_image_dir = os.path.join(log_directory, "Binary Images")
            if not os.path.exists(binary_image_dir):
                os.makedirs(binary_image_dir)

            for idx, threshold_value in enumerate(threshold_values):
                try:
                    write_log(f"Applying threshold value {threshold_value}, converting raster to binary image.")
                    _, binary_image = cv2.threshold(raster_data, threshold_value, 255, cv2.THRESH_BINARY)
                    binary_image = binary_image.astype(np.uint8)
                    write_log(f"Binary image dtype before operation: {binary_image.dtype}")
                    write_log(f"Unique values in binary image before operation: {np.unique(binary_image)}")
                    output_path=save_binary_geotiff(binary_image, threshold_value, binary_image_dir, transform, crs)
                    write_log(f"Binary image saved to {output_path}")
                except Exception as e:
                    write_log(f"error during binary image conversion for threshold {threshold_value}: {e}")
                    continue

                if operation.lower() != "none":
                    try:
                        write_log(f"Applying {operation} operation with kernel size {kernel_size} and iterations {iterations}")
                        kernel = np.ones((kernel_size, kernel_size), np.uint8)
                        write_log(f"Kernel used: {kernel}")

                        if operation == "Dilation":
                            binary_image = cv2.dilate(binary_image, kernel, iterations=iterations)
                            write_log("Dilation operation completed.")
                        elif operation == "Erosion":
                            binary_image = cv2.erode(binary_image, kernel, iterations=iterations)
                            write_log("Erosion operation completed.")

                        write_log(f"Binary image dtype after operation: {binary_image.dtype}")
                        write_log(f"Unique values in binary image after operation: {np.unique(binary_image)}")
                    except Exception as e:
                        write_log(f"Error during {operation} operation: {e}")
                        continue
                
                    try:
                        output_path=save_binary_geotiff(binary_image, threshold_value, binary_image_dir, transform, crs)
                        write_log(f"Binary image saved to {output_path}")
                    except Exception as e:
                        write_log(f"Error saving binary image for threshold {threshold_value}: {e}")

                    try:
                        update_progress_bar(progress_bar,idx+1)
                    except RuntimeError as e:
                        write_log(f"RuntimeError: {e}")
                        break


                    try:
                            
                        contours, _ = cv2.findContours(
                            binary_image, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE
                        )
                        write_log(f"Found {len(contours)} contours for threshold value {threshold_value}")
                        all_contours.extend(contours)
                        for idx, contour in enumerate(contours):
                            feature = QgsFeature()
                            map_coordinates = [
                                (
                                    xmin + pt[0][0] * x_pixel_size,
                                    ymax - pt[0][1] * y_pixel_size,
                                )
                                for pt in contour
                            ]
                            feature.setGeometry(
                                QgsGeometry.fromPolyline(
                                    [QgsPoint(pt[0], pt[1]) for pt in map_coordinates]
                                )
                            )
                            feature.setAttributes(
                                [
                                    idx + 1,
                                    threshold_value,
                                    len(contour) * (x_pixel_size + y_pixel_size) / 2000,
                                ]
                            )
                            
                            memory_layer.dataProvider().addFeature(feature)
                        
                        try:
                            update_progress_bar(progress_bar,idx+1)
                        except RuntimeError as e:
                            write_log(f"RuntimeError: {e}")
                            break

                    except Exception as e:
                        write_log(f"Error during contour extraction for threshold {threshold_value}: {e}")
                QgsProject.instance().addMapLayer(memory_layer)
                input_basename = os.path.splitext(os.path.basename(raster_path))[0]
                threshold_values_str = "_".join(map(str, threshold_values))
                output_name = f"{input_basename}_combined_{threshold_values_str}_{operation}_{kernel_size}_iterations_{iterations}.shp"
                output_folder = inputs['output_folder']
                if not output_folder:
                    print("Output folder selection canceled.")
                    write_log("Output folder selection canceled.")
                else:
                    output_path = os.path.join(output_folder, output_name)
                    QgsVectorFileWriter.writeAsVectorFormat(
                        memory_layer,
                        output_path,
                        "utf-8",
                        layer.crs(),
                        "ESRI Shapefile",
                    )
                if not output_folder:
                    print("Output folder selection canceled.")
                    write_log("Output folder selection canceled.")
                else:
                    output_path = os.path.join(output_folder, output_name)
                    QgsVectorFileWriter.writeAsVectorFormat(
                        memory_layer,
                        output_path,
                        "utf-8",
                        layer.crs(),
                        "ESRI Shapefile",
                    )
                    progress_bar.setValue(progress_bar.maximum())
                    progress_widget.close()
                    end_time=datetime.datetime.now()
                    processing_time=end_time-start_time
                    print(f"Contours exported to: {output_path}")
                    write_log(f"Contours exported to: {output_path} \n Total processing time: {processing_time}")
