"""
Boilerplate for logging script execution

MUST ADD THE FOLLOWING TO ANY SCRIPT THAT USES THIS MODULE

from pathlib import Path
from OO.OCore.OLogger import get_logger
logger = get_logger(Path(__file__).stem)

"""

import sys
import logging
import datetime
from pathlib import Path
from logging.handlers import TimedRotatingFileHandler


FORMATTER = logging.Formatter(u"%(asctime)s — %(levelname)s — %(funcName)s — %(message)s")
LOG_FILE = f"logs/{datetime.datetime.now().strftime('%Y_%m_%d_%H_%M')}_{{}}.log"


def get_console_handler():
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(FORMATTER)
    return console_handler


def get_file_handler(logger_name):
    logger_path = Path(logger_name).resolve()
    if not logger_path.parent.exists():
        logger_path.parent.mkdir(parents=True, exist_ok=True)
    file_handler = TimedRotatingFileHandler(logger_name, when='midnight')
    file_handler.namer = lambda name: f"{name.replace('.log', '')}.log"
    file_handler.setFormatter(FORMATTER)
    return file_handler


def get_logger(logger_name):
    logger_name = LOG_FILE.format(logger_name)
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)  # better to have too much log than not enough
    logger.addHandler(get_console_handler())
    logger.addHandler(get_file_handler(logger_name))
    # with this pattern, it's rarely necessary to propagate the error up to parent
    logger.propagate = False
    return logger
