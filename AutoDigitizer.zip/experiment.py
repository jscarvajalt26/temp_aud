import os
from pathlib import Path

from nicegui import ui
from PIL import Image
from PyQt6.QtCore import QLibraryInfo

from digitalize import *

# os.environ["QT_QPA_PLATFORM"] = "wayland-egl"
# os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = QLibraryInfo.path(
#     QLibraryInfo.LibraryPath.PluginsPath
# )

IMAGE_ROOT = Path(
    "/media/sf_VMShare/General Software/AutoDigitizer/digitalize/tests/images"
)

img_cv2 = cv2.imread(
    (
        IMAGE_ROOT
        / "222_Western_Pacific_Minerals_Phillipines_Project_Lampaki_geology_map_2.JPG"
    ).as_posix(),
    cv2.IMREAD_COLOR_BGR,
)
threshold_range = np.array([360.0, 0.3, 0.5])
sample_size = 0.05
pallet_size = 20

# img_cv2 = cv2.imread(
#     (
#         IMAGE_ROOT
#         / "222_Western_Pacific_Minerals_Vietnam_Project_CentralVietnam_geochemistry_map_3.JPG"
#     ).as_posix(),
#     cv2.IMREAD_COLOR_BGR,
# )
# threshold_range = np.array([360.0, 0.1, 0.5])
# sample_size = 0.1
# pallet_size = 10


class x:
    quiet = False
    sample_fraction = 0.25
    num_colors = 12
    value_threshold = 0.25
    sat_threshold = 0.20


options = x()


def show_img(img, delay=15000):
    # cv2.imshow("image", img)
    # cv2.waitKey(delay)
    # cv2.destroyAllWindows()
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    im_pil = Image.fromarray(img)
    ui.image(im_pil)


def get_pallet(img, k_or_guess=15):
    s = img.astype("float32")

    # centroid, labels = kmeans2(s, k_or_guess, iter=40)

    whitened = whiten(s)
    trials = []
    for _ in range(1):
        c, d = kmeans(whitened, k_or_guess)
        trials.append((c, d))
        # print(f"{c}, {d}")
    centroid, _ = min(trials, key=lambda x: x[1])
    labels, _ = vq(whitened, centroid)
    centroid = centroid * np.std(s, 0)
    return centroid.astype("uint8"), labels


def broadcast_pallet(pallet):
    pallet = np.array((np.vstack(np.array([(p,) * 50 for p in pallet])),) * 50)
    return pallet


img_hsv = cv2.cvtColor(img_cv2, cv2.COLOR_BGR2HSV)
img_hsv_6 = reduce_bits(img_hsv, 5)
img_hsv_6[:, :, 0] = img_hsv[:, :, 0]
# show_img(cv2.cvtColor(img_hsv_6, cv2.COLOR_HSV2BGR))


def plt_demo():
    import matplotlib.pyplot as plt
    import numpy as np

    # Fixing random state for reproducibility
    np.random.seed(19680801)

    def randrange(n, vmin, vmax):
        """
        Helper function to make an array of random numbers having shape (n, )
        with each number distributed Uniform(vmin, vmax).
        """
        return (vmax - vmin) * np.random.rand(n) + vmin

    fig = plt.figure()
    ax = fig.add_subplot(projection="3d")

    n = 100

    # For each set of style and range settings, plot n random points in the box
    # defined by x in [23, 32], y in [0, 100], z in [zlow, zhigh].
    for m, zlow, zhigh in [("o", -50, -25), ("^", -30, -5)]:
        xs = randrange(n, 23, 32)
        ys = randrange(n, 0, 100)
        zs = randrange(n, zlow, zhigh)
        ax.scatter(xs, ys, zs, marker=m)

    ax.set_xlabel("X Label")
    ax.set_ylabel("Y Label")
    ax.set_zlabel("Z Label")

    plt.show()


def plt(data, centroid=None, matches=None):
    import matplotlib.colors as colors
    import matplotlib.markers as marker
    import matplotlib.pyplot as plt

    fig = plt.figure()
    # fig = plt.figure(layout="tight")
    with ui.matplotlib().figure as fig:
        ax = fig.add_subplot(projection="3d")

        # if matches is None:
        ax.scatter(
            data[:, 0], data[:, 1], data[:, 2], c=data / 255.0, marker="1", alpha=0.5
        )
        if centroid is not None:

            ax.scatter(
                centroid[:, 0],
                centroid[:, 1],
                centroid[:, 2],
                ec="#000",
                # fc=np.array([1, 1, 1]) - (centroid / 255.0),
                # marker=marker.MarkerStyle("D").scaled(3.0, 3.0),
                fc=centroid / 255.0,
                # fc="#fff",
                marker=marker.MarkerStyle("D").scaled(2.0, 2.0),
                alpha=1,
            )

            if matches is not None:
                matches = [centroid[idx] for idx in matches]
                zipped = list(
                    map(
                        lambda x: list(zip(*x)),
                        zip(
                            zip(*data), zip(*matches), zip(*np.full(data.shape, np.nan))
                        ),
                    )
                )
                ax.plot(
                    list(sum(zipped[0], ())),
                    list(sum(zipped[1], ())),
                    list(sum(zipped[2], ())),
                    marker=None,
                    alpha=0.5,
                    linewidth=0.5,
                )

        ax.set_xlabel("Red")
        ax.set_xlim(0, 255)
        ax.set_ylabel("Green")
        ax.set_ylim(0, 255)
        ax.set_zlabel("Blue")
        ax.set_zlim(0, 255)

    # plt.show()


# plt(
#     sort_pixel_frequency(reorder_channels(reduce_bits(sample_pixels(img_cv2, 0.02), 2)))
# )

# s = sort_pixel_frequency(
#     # reorder_channels(
#     sample_pixels(
#         # reduce_bits(
#         cv2.cvtColor(img_cv2.astype(np.float32) / 255.0, cv2.COLOR_BGR2HSV),
#         # ),
#         0.02,
#     )
#     # )
# )
# bg_colour = s[0]
# filtered = filter_pixels(s, bg_colour, np.array([0, 0.2, 0.25]))
# plt(reorder_channels(cv2.cvtColor(np.array([filtered]), cv2.COLOR_HSV2BGR)[0]))


def BGR2HSV(pixels):
    # pixels = cv2.cvtColor(
    #     np.array([pixels.astype(np.float32) / 255.0]), cv2.COLOR_BGR2HSV
    # )
    # pixels = pixels.reshape((-1, 3))
    pixels = cv2.cvtColor(pixels.astype(np.float32) / 255, cv2.COLOR_BGR2HSV)
    return pixels


def HSV2BGR(pixels):
    # pixels = cv2.cvtColor(np.array([pixels]), cv2.COLOR_HSV2BGR)[0] * 255
    pixels = cv2.cvtColor(pixels, cv2.COLOR_HSV2BGR) * 255
    return pixels.astype(np.uint8)


# # show_img(img_cv2)
# img_smooth = cv2.bilateralFilter(img_cv2, 0, 30, 20)
# # show_img(img_smooth)
# s = sample_pixels(reduce_bits(img_smooth), 0.02)
# # plt(reorder_channels(s))
# s_hsv = BGR2HSV(s)
# bg_colour = BGR2HSV(np.array([sort_pixel_frequency(s)[0]]))
# filtered = filter_out_pixels(s_hsv, bg_colour, np.array([360.0, 0.3, 0.5]), False)
# filtered_rgb = HSV2BGR(filtered)
# plt(reorder_channels(filtered_rgb))
# show_img(get_pallet(filtered_rgb, 8))
# # show_img(get_pallet(s[[np.any(np.all(x == filtered_rgb, axis=1)) for x in s.astype(np.float32)]], 8))


def trial1():
    img_smooth = cv2.bilateralFilter(img_cv2, 0, 30, 20)
    s = sample_pixels(reduce_bits(img_smooth), sample_size)

    bg_colour = BGR2HSV(np.array([[sort_pixel_frequency(s)[0]]])).reshape(3)
    img_smooth_hsv = BGR2HSV(img_smooth)

    mask_smooth_hsv = pixel_range_mask(
        img_smooth_hsv,
        bg_colour,
        threshold_range,
        True,
        True,
        np.array([0.0, 0.0, 1.0]),
    )

    mask_smooth = HSV2BGR(mask_smooth_hsv)

    # show_img(img_smooth & mask_smooth)

    filtered = img_smooth[
        pixel_range_mask(img_smooth_hsv, bg_colour, threshold_range, True)
    ]
    s_filtered = sample_pixels(filtered, sample_size)
    s_filtered = sort_pixel_frequency(s_filtered)
    s_pallet, labels = get_pallet(s_filtered, pallet_size)
    show_img(broadcast_pallet(s_pallet))
    plt(reorder_channels(s_filtered), reorder_channels(s_pallet), labels)


def trial2():
    img_smooth = cv2.bilateralFilter(img_cv2, 0, 35, 20)
    show_img(img_smooth)

    colours_distinct = sort_pixel_frequency(img_smooth)
    colours_sample = sample_pixels(colours_distinct, sample_size)

    pallet, labels = get_pallet(colours_sample, pallet_size)
    show_img(broadcast_pallet(pallet))

    # plt(reorder_channels(colours_sample), reorder_channels(pallet))
    plt(reorder_channels(colours_sample), reorder_channels(pallet), labels)


if __name__ in {"__main__", "__mp_main__"}:
    trial2()
    ui.run()
