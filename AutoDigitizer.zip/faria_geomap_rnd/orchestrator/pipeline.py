﻿from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from faria_geomap_rnd.models.model_prediction import ModelPrediction
from faria_geomap_rnd.orchestrator.contracts import (
    ExpertResult,
    PipelineResult,
    RefinementRequest,
)
from faria_geomap_rnd.orchestrator.fusion_engine import (
    fuse_semantic_predictions,
    fusion_summary,
)
from faria_geomap_rnd.orchestrator.uncertainty import (
    build_refinement_mask,
)


@dataclass
class PipelineConfig:
    """
    Runtime configuration for the multi-expert orchestration layer.
    """

    uncertainty_threshold: float = 0.55
    disagreement_threshold: float = 0.25

    expert_weights: dict[str, float] = field(
        default_factory=dict
    )

    continue_on_expert_error: bool = True


class MultiExpertPipeline:
    """
    Core GeoMap multi-expert orchestration pipeline.

    This class does not assume how individual neural networks are loaded.
    Expert adapters/runners provide ExpertResult objects, which are then
    combined here.
    """

    def __init__(
        self,
        config: PipelineConfig | None = None,
    ) -> None:
        self.config = (
            config
            if config is not None
            else PipelineConfig()
        )

    @staticmethod
    def collect_semantic_predictions(
        expert_results: dict[str, ExpertResult],
    ) -> list[ModelPrediction]:
        """
        Collect only successful experts that produced semantic
        ModelPrediction objects.

        Structural/specialist experts remain available in expert_results
        but are not blindly averaged into semantic fusion.
        """

        predictions: list[
            ModelPrediction
        ] = []

        for result in expert_results.values():

            if not result.success:
                continue

            if result.prediction is None:
                continue

            if (
                result.prediction.prediction_type
                not in {"semantic", "semantic_segmentation"}
            ):
                continue

            result.prediction.validate()

            predictions.append(
                result.prediction
            )

        return predictions

    def build_refinement_request(
        self,
        *,
        source_path: Path,
        uncertainty_map: np.ndarray,
        disagreement_map: np.ndarray,
    ) -> RefinementRequest:
        """
        Convert fusion uncertainty/disagreement into a request that
        specialists such as SAM2 can consume later.
        """

        refinement_mask = (
            build_refinement_mask(
                uncertainty_map=uncertainty_map,
                disagreement_map=disagreement_map,
                uncertainty_threshold=(
                    self.config
                    .uncertainty_threshold
                ),
                disagreement_threshold=(
                    self.config
                    .disagreement_threshold
                ),
            )
        )

        request = RefinementRequest(
            uncertainty_mask=refinement_mask,
            disagreement_mask=(
                disagreement_map.astype(
                    np.float32
                )
            ),
            source_path=source_path,
            metadata={
                "uncertainty_threshold": (
                    self.config
                    .uncertainty_threshold
                ),
                "disagreement_threshold": (
                    self.config
                    .disagreement_threshold
                ),
                "selected_pixel_count": int(
                    refinement_mask.sum()
                ),
            },
        )

        request.validate()

        return request

    def run_from_results(
        self,
        *,
        source_path: Path,
        expert_results: dict[
            str,
            ExpertResult,
        ],
    ) -> PipelineResult:
        """
        Run orchestration from already-computed expert results.

        Current V0 flow:
            expert results
                -> semantic collection
                -> semantic fusion
                -> uncertainty/disagreement
                -> refinement request

        Later:
            -> SAM2 specialist execution
            -> affinity reasoning
            -> topology
            -> visibility
            -> vectorization
        """

        source_path = Path(
            source_path
        )

        for name, result in (
            expert_results.items()
        ):
            try:
                result.validate()
            except Exception:
                if (
                    not self.config
                    .continue_on_expert_error
                ):
                    raise

        semantic_predictions = (
            self.collect_semantic_predictions(
                expert_results
            )
        )

        if not semantic_predictions:
            return PipelineResult(
                source_path=source_path,
                expert_results=expert_results,
                fusion=None,
                metadata={
                    "status": (
                        "no_semantic_predictions"
                    ),
                    "semantic_expert_count": 0,
                },
            )

        weights = (
            self.config.expert_weights
            if self.config.expert_weights
            else None
        )

        fusion = fuse_semantic_predictions(
            semantic_predictions,
            weights=weights,
        )

        refinement_request = (
            self.build_refinement_request(
                source_path=source_path,
                uncertainty_map=(
                    fusion.uncertainty_map
                ),
                disagreement_map=(
                    fusion.disagreement_map
                ),
            )
        )

        summary = fusion_summary(
            fusion
        )

        successful = [
            name
            for name, result
            in expert_results.items()
            if result.success
        ]

        failed = [
            name
            for name, result
            in expert_results.items()
            if not result.success
        ]

        return PipelineResult(
            source_path=source_path,
            expert_results=expert_results,
            fusion=fusion,
            metadata={
                "status": "fusion_complete",
                "semantic_expert_count": len(
                    semantic_predictions
                ),
                "successful_experts": successful,
                "failed_experts": failed,
                "fusion_summary": summary,
                "refinement_request": (
                    refinement_request
                ),
            },
        )

