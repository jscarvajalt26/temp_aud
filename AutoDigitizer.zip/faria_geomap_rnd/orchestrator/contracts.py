﻿from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from faria_geomap_rnd.models.model_prediction import ModelPrediction


@dataclass
class ExpertResult:
    """
    Standard result returned by one expert.

    A raster segmentation expert should populate `prediction`.
    Specialist/refinement experts may instead populate artifacts and metadata.
    """

    expert_name: str
    role: str

    prediction: ModelPrediction | None = None

    artifacts: dict[str, Path] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    success: bool = True
    error: str | None = None

    def validate(self) -> None:
        if self.prediction is not None:
            self.prediction.validate()

        if not self.expert_name:
            raise ValueError("expert_name cannot be empty.")

        if not self.role:
            raise ValueError("role cannot be empty.")


@dataclass
class FusionResult:
    """
    Consensus produced from multiple raster experts.
    """

    predicted_classes: np.ndarray
    class_probabilities: np.ndarray

    confidence_map: np.ndarray
    uncertainty_map: np.ndarray
    disagreement_map: np.ndarray

    contributing_experts: list[str] = field(default_factory=list)
    expert_weights: dict[str, float] = field(default_factory=dict)

    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        if self.predicted_classes.ndim != 2:
            raise ValueError(
                "predicted_classes must have shape [H, W]."
            )

        if self.class_probabilities.ndim != 3:
            raise ValueError(
                "class_probabilities must have shape [C, H, W]."
            )

        class_count, height, width = self.class_probabilities.shape

        expected_shape = (height, width)

        if self.predicted_classes.shape != expected_shape:
            raise ValueError(
                "Prediction dimensions do not match probability dimensions."
            )

        for name, array in (
            ("confidence_map", self.confidence_map),
            ("uncertainty_map", self.uncertainty_map),
            ("disagreement_map", self.disagreement_map),
        ):
            if array.shape != expected_shape:
                raise ValueError(
                    f"{name} must have shape {expected_shape}."
                )

        if class_count < 2:
            raise ValueError("At least two classes are required.")


@dataclass
class RefinementRequest:
    """
    Describes regions where the main expert ensemble wants help from
    a specialist such as SAM2.
    """

    uncertainty_mask: np.ndarray
    disagreement_mask: np.ndarray

    source_path: Path | None = None

    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        if self.uncertainty_mask.ndim != 2:
            raise ValueError(
                "uncertainty_mask must have shape [H, W]."
            )

        if self.disagreement_mask.shape != self.uncertainty_mask.shape:
            raise ValueError(
                "disagreement_mask and uncertainty_mask must match."
            )


@dataclass
class PipelineResult:
    """
    Final result of the complete GeoMap multi-expert pipeline.
    """

    source_path: Path

    expert_results: dict[str, ExpertResult]

    fusion: FusionResult | None = None

    refinement_artifacts: dict[str, Path] = field(default_factory=dict)
    vector_artifacts: dict[str, Path] = field(default_factory=dict)

    metadata: dict[str, Any] = field(default_factory=dict)

    def successful_experts(self) -> list[str]:
        return [
            name
            for name, result in self.expert_results.items()
            if result.success
        ]

    def failed_experts(self) -> list[str]:
        return [
            name
            for name, result in self.expert_results.items()
            if not result.success
        ]
