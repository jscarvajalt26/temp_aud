﻿from __future__ import annotations

import numpy as np

from faria_geomap_rnd.models.model_prediction import ModelPrediction
from faria_geomap_rnd.orchestrator.contracts import FusionResult
from faria_geomap_rnd.orchestrator.uncertainty import (
    validate_compatible_predictions,
    probability_disagreement_map,
    vote_disagreement_map,
    consensus_entropy,
)


def normalize_weights(
    predictions: list[ModelPrediction],
    weights: dict[str, float] | None = None,
) -> dict[str, float]:
    """
    Produce normalized expert weights.

    For architecture V0 all experts default to equal weight.
    Later these can be learned/calibrated from validation performance.
    """

    if not predictions:
        raise ValueError(
            "At least one prediction is required."
        )

    if weights is None:
        raw = {
            prediction.model_name: 1.0
            for prediction in predictions
        }
    else:
        raw = {}

        for prediction in predictions:
            value = float(
                weights.get(
                    prediction.model_name,
                    1.0,
                )
            )

            if value < 0:
                raise ValueError(
                    "Expert weights cannot be negative."
                )

            raw[prediction.model_name] = value

    total = float(
        sum(raw.values())
    )

    if total <= 0:
        raise ValueError(
            "At least one expert must have positive weight."
        )

    return {
        name: value / total
        for name, value in raw.items()
    }


def weighted_probability_fusion(
    predictions: list[ModelPrediction],
    weights: dict[str, float],
) -> np.ndarray:
    """
    Fuse semantic probabilities.

    Input per expert:
        [C,H,W]

    Output:
        [C,H,W]
    """

    classes, height, width = (
        validate_compatible_predictions(
            predictions
        )
    )

    fused = np.zeros(
        (classes, height, width),
        dtype=np.float32,
    )

    for prediction in predictions:
        weight = weights[
            prediction.model_name
        ]

        fused += (
            prediction.class_probabilities.astype(
                np.float32
            )
            * weight
        )

    # Numerical safety.
    denominator = np.sum(
        fused,
        axis=0,
        keepdims=True,
    )

    denominator = np.maximum(
        denominator,
        1e-8,
    )

    fused /= denominator

    return fused


def combine_disagreement(
    predictions: list[ModelPrediction],
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    """
    Combine hard-class disagreement and probability disagreement.

    We keep both diagnostics so later experiments can determine
    which signal is most useful for specialist routing.
    """

    vote_map = vote_disagreement_map(
        predictions
    )

    probability_map = (
        probability_disagreement_map(
            predictions
        )
    )

    combined = np.maximum(
        vote_map,
        probability_map,
    ).astype(
        np.float32
    )

    return combined, {
        "vote_disagreement": vote_map,
        "probability_disagreement": probability_map,
    }


def fuse_semantic_predictions(
    predictions: list[ModelPrediction],
    *,
    weights: dict[str, float] | None = None,
) -> FusionResult:
    """
    Produce the semantic consensus of compatible raster experts.

    Examples of future compatible experts:
      SE-UNet
      HybridGeoMapNet
      RS3Mamba
      Mask2Former semantic adapter

    Structural specialists such as affinity networks and SAM2 are
    deliberately NOT fused here.
    """

    validate_compatible_predictions(
        predictions
    )

    normalized_weights = normalize_weights(
        predictions,
        weights,
    )

    fused_probabilities = (
        weighted_probability_fusion(
            predictions,
            normalized_weights,
        )
    )

    predicted_classes = np.argmax(
        fused_probabilities,
        axis=0,
    ).astype(
        np.int32
    )

    confidence_map = np.max(
        fused_probabilities,
        axis=0,
    ).astype(
        np.float32
    )

    uncertainty_map = consensus_entropy(
        fused_probabilities
    )

    (
        disagreement_map,
        disagreement_components,
    ) = combine_disagreement(
        predictions
    )

    result = FusionResult(
        predicted_classes=predicted_classes,
        class_probabilities=(
            fused_probabilities
        ),
        confidence_map=confidence_map,
        uncertainty_map=uncertainty_map,
        disagreement_map=disagreement_map,
        contributing_experts=[
            prediction.model_name
            for prediction in predictions
        ],
        expert_weights=normalized_weights,
        metadata={
            "fusion_method": (
                "weighted_probability_average"
            ),
            "disagreement_method": (
                "maximum_of_vote_and_probability"
            ),
            "vote_disagreement_map": (
                disagreement_components[
                    "vote_disagreement"
                ]
            ),
            "probability_disagreement_map": (
                disagreement_components[
                    "probability_disagreement"
                ]
            ),
        },
    )

    result.validate()

    return result


def fusion_summary(
    fusion: FusionResult,
) -> dict[str, float | int]:
    """
    Compact diagnostics for logging and experiment reports.
    """

    return {
        "expert_count": len(
            fusion.contributing_experts
        ),
        "mean_confidence": float(
            np.mean(
                fusion.confidence_map
            )
        ),
        "mean_uncertainty": float(
            np.mean(
                fusion.uncertainty_map
            )
        ),
        "mean_disagreement": float(
            np.mean(
                fusion.disagreement_map
            )
        ),
        "max_disagreement": float(
            np.max(
                fusion.disagreement_map
            )
        ),
    }
