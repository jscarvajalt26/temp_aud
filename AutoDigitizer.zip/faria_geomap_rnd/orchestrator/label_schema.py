﻿from enum import IntEnum


class GeoMapClass(IntEnum):
    BACKGROUND = 0
    CONTACT = 1
    STRUCTURAL_FEATURE = 2
    CLUTTER = 3


CLASS_NAMES = {
    GeoMapClass.BACKGROUND: "background_or_ignore",
    GeoMapClass.CONTACT: "geological_contact",
    GeoMapClass.STRUCTURAL_FEATURE: "fault_vein_or_major_structure",
    GeoMapClass.CLUTTER: "text_label_or_printed_clutter",
}


NUM_CANONICAL_CLASSES = len(GeoMapClass)


def validate_class_count(class_count: int) -> None:
    if class_count != NUM_CANONICAL_CLASSES:
        raise ValueError(
            f"Expected {NUM_CANONICAL_CLASSES} canonical classes, "
            f"received {class_count}."
        )


def get_class_name(class_id: int) -> str:
    try:
        return CLASS_NAMES[GeoMapClass(class_id)]
    except ValueError as exc:
        raise ValueError(
            f"Unknown GeoMap class id: {class_id}"
        ) from exc
