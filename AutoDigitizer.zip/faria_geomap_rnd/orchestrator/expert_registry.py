﻿from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ExpertKind(str, Enum):
    """
    High-level expert categories used by the orchestrator.
    """

    SEGMENTATION = "segmentation"
    CONTEXT = "context"
    MULTITASK = "multitask"
    AFFINITY = "affinity"
    REFINEMENT = "refinement"
    TOPOLOGY = "topology"
    VISIBILITY = "visibility"
    VECTORIZATION = "vectorization"


class ExpertStatus(str, Enum):
    """
    Integration state of an expert.
    """

    AVAILABLE = "available"
    EXPERIMENTAL = "experimental"
    PLANNED = "planned"
    DISABLED = "disabled"


@dataclass(frozen=True)
class ExpertSpec:
    """
    Registry description for one GeoMap expert.
    """

    name: str
    kind: ExpertKind
    status: ExpertStatus

    module: str | None = None
    description: str = ""

    tasks: tuple[str, ...] = ()
    requires_checkpoint: bool = False

    default_weight: float = 1.0

    metadata: dict[str, Any] = field(default_factory=dict)


EXPERT_REGISTRY: dict[str, ExpertSpec] = {

    # ---------------------------------------------------------
    # PRIMARY LEARNED EXPERTS
    # ---------------------------------------------------------

    "se_unet": ExpertSpec(
        name="se_unet",
        kind=ExpertKind.SEGMENTATION,
        status=ExpertStatus.AVAILABLE,
        module="faria_geomap_rnd.models.se_unet",
        description=(
            "SE-U-Net dense segmentation expert."
        ),
        tasks=(
            "semantic_segmentation",
            "local_boundary_detection",
        ),
        requires_checkpoint=True,
        default_weight=1.0,
    ),

    "hybrid_geomap": ExpertSpec(
        name="hybrid_geomap",
        kind=ExpertKind.CONTEXT,
        status=ExpertStatus.EXPERIMENTAL,
        module=(
            "faria_geomap_rnd.models.hybrid."
            "hybrid_geomap_net"
        ),
        description=(
            "Hybrid GeoMap expert combining local and "
            "contextual representations."
        ),
        tasks=(
            "semantic_segmentation",
            "context_reasoning",
        ),
        requires_checkpoint=True,
        default_weight=1.0,
    ),

    "supervisor_multihead": ExpertSpec(
        name="supervisor_multihead",
        kind=ExpertKind.MULTITASK,
        status=ExpertStatus.EXPERIMENTAL,
        module=(
            "faria_geomap_rnd.models.hybrid."
            "multihead_geomap_net"
        ),
        description=(
            "Multi-head GeoMap network for multiple "
            "geological prediction targets."
        ),
        tasks=(
            "multitask_prediction",
            "geological_features",
        ),
        requires_checkpoint=True,
        default_weight=1.0,
    ),

    "georegion_affinity": ExpertSpec(
        name="georegion_affinity",
        kind=ExpertKind.AFFINITY,
        status=ExpertStatus.EXPERIMENTAL,
        module=(
            "faria_geomap_rnd.models.hybrid."
            "georegion_affinity_net"
        ),
        description=(
            "GeoRegion affinity expert for relationships "
            "between geological regions."
        ),
        tasks=(
            "region_affinity",
            "boundary_reasoning",
        ),
        requires_checkpoint=True,
        default_weight=1.0,
    ),

    # ---------------------------------------------------------
    # FUTURE / EXTERNAL LEARNED EXPERTS
    # ---------------------------------------------------------

    "transunet": ExpertSpec(
        name="transunet",
        kind=ExpertKind.MULTITASK,
        status=ExpertStatus.EXPERIMENTAL,
        module=(
            "faria_geomap_rnd.models.hybrid."
            "transunet_geomap"
        ),
        description=(
            "TransUNet line expert: CNN detail plus a ViT over the "
            "tile, for thin contacts and faults that must stay "
            "continuous. Same heads as supervisor_multihead."
        ),
        tasks=(
            "contact_detection",
            "fault_detection",
            "clutter_detection",
        ),
        requires_checkpoint=True,
        default_weight=1.0,
        metadata={
            "checkpoint": "transunet_geomap_best.pth",
            "train": (
                "python -m faria_geomap_rnd.pipelines."
                "train_supervisor_multihead --architecture transunet"
            ),
        },
    ),

    "rs3mamba": ExpertSpec(
        name="rs3mamba",
        kind=ExpertKind.CONTEXT,
        status=ExpertStatus.EXPERIMENTAL,
        module=(
            "faria_geomap_rnd.models.hybrid."
            "rs3mamba_geomap"
        ),
        description=(
            "RS3Mamba-style dual-branch (ResNet + visual state "
            "space) expert for long-range continuity of long "
            "faults and contacts. Same heads as supervisor_multihead."
        ),
        tasks=(
            "long_range_context",
            "contact_detection",
            "fault_detection",
        ),
        requires_checkpoint=True,
        default_weight=1.0,
        metadata={
            "checkpoint": "rs3mamba_geomap_best.pth",
            "train": (
                "python -m faria_geomap_rnd.pipelines."
                "train_supervisor_multihead --architecture rs3mamba"
            ),
            "fast_kernel": "pip install mamba-ssm (CUDA only)",
        },
    ),

    "mask2former": ExpertSpec(
        name="mask2former",
        kind=ExpertKind.SEGMENTATION,
        status=ExpertStatus.EXPERIMENTAL,
        module="faria_geomap_rnd.models.mask2former_regions",
        description=(
            "Mask2Former area expert: one mask per map area, "
            "class-agnostic, to separate neighbouring areas with "
            "similar colours or faint boundaries."
        ),
        tasks=(
            "area_segmentation",
            "area_boundary",
        ),
        requires_checkpoint=True,
        default_weight=1.0,
        metadata={
            "checkpoint": "mask2former_regions_best.pth",
            "train": (
                "python -m faria_geomap_rnd.versions.v3_mask2former."
                "training.train_mask2former"
            ),
        },
    ),

    "digmapper": ExpertSpec(
        name="digmapper",
        kind=ExpertKind.SEGMENTATION,
        status=ExpertStatus.DISABLED,
        module=None,
        description=(
            "DIGMAPPER (DARPA CriticalMAAS, 2025) end-to-end map "
            "digitization system. Its code and weights were not "
            "public as of 2026-10-18 (arXiv 2506.16006); the slot "
            "is kept so it can be added if they are released."
        ),
        tasks=(
            "area_segmentation",
            "line_extraction",
            "point_extraction",
            "legend_extraction",
            "georeferencing",
        ),
        requires_checkpoint=True,
        default_weight=1.0,
    ),

    "sam2_refiner": ExpertSpec(
        name="sam2_refiner",
        kind=ExpertKind.REFINEMENT,
        status=ExpertStatus.AVAILABLE,
        module=(
            "faria_geomap_rnd.models.refinement."
            "mapsam2_refiner"
        ),
        description=(
            "SAM2 specialist for targeted geological-body "
            "mask refinement. In the runner it settles uncertain "
            "area boundaries using public SAM2.1 weights."
        ),
        tasks=(
            "mask_refinement",
            "uncertain_region_refinement",
        ),
        requires_checkpoint=False,
        default_weight=1.0,
    ),

    "sam2_geobody_proposer": ExpertSpec(
        name="sam2_geobody_proposer",
        kind=ExpertKind.REFINEMENT,
        status=ExpertStatus.AVAILABLE,
        module=(
            "faria_geomap_rnd.models.refinement."
            "sam2_geobody_proposer"
        ),
        description=(
            "SAM2-based geological-body proposal specialist."
        ),
        tasks=(
            "object_proposal",
            "geobody_proposal",
        ),
        requires_checkpoint=False,
        default_weight=1.0,
    ),

    "sam2_mask_validator": ExpertSpec(
        name="sam2_mask_validator",
        kind=ExpertKind.REFINEMENT,
        status=ExpertStatus.AVAILABLE,
        module=(
            "faria_geomap_rnd.models.refinement."
            "sam2_mask_validator"
        ),
        description=(
            "SAM2 candidate-mask validation specialist."
        ),
        tasks=(
            "mask_validation",
        ),
        requires_checkpoint=False,
        default_weight=1.0,
    ),

    # ---------------------------------------------------------
    # DETERMINISTIC REASONING EXPERTS
    # ---------------------------------------------------------

    "topology_vectorizer": ExpertSpec(
        name="topology_vectorizer",
        kind=ExpertKind.TOPOLOGY,
        status=ExpertStatus.AVAILABLE,
        module=(
            "faria_geomap_rnd.models.refinement."
            "georegion_topology_vectorizer"
        ),
        description=(
            "Topology-preserving geological-region "
            "boundary/vector reconstruction."
        ),
        tasks=(
            "topology",
            "shared_boundaries",
            "junctions",
        ),
        requires_checkpoint=False,
    ),

    "visibility_occlusion": ExpertSpec(
        name="visibility_occlusion",
        kind=ExpertKind.VISIBILITY,
        status=ExpertStatus.EXPERIMENTAL,
        module=(
            "faria_geomap_rnd.models.refinement."
            "visibility_occlusion"
        ),
        description=(
            "Visible-versus-inferred geological geometry "
            "reasoning."
        ),
        tasks=(
            "visibility",
            "occlusion",
        ),
        requires_checkpoint=False,
    ),

    "geojson_export": ExpertSpec(
        name="geojson_export",
        kind=ExpertKind.VECTORIZATION,
        status=ExpertStatus.AVAILABLE,
        module=(
            "faria_geomap_rnd.pipelines."
            "prediction_to_geojson"
        ),
        description=(
            "GIS GeoJSON export stage."
        ),
        tasks=(
            "vectorization",
            "gis_export",
        ),
        requires_checkpoint=False,
    ),
}


def get_expert(name: str) -> ExpertSpec:
    try:
        return EXPERT_REGISTRY[name]
    except KeyError as exc:
        available = ", ".join(
            sorted(EXPERT_REGISTRY)
        )
        raise KeyError(
            f"Unknown expert '{name}'. "
            f"Registered experts: {available}"
        ) from exc


def list_experts(
    *,
    status: ExpertStatus | None = None,
    kind: ExpertKind | None = None,
) -> list[ExpertSpec]:

    experts = list(
        EXPERT_REGISTRY.values()
    )

    if status is not None:
        experts = [
            expert
            for expert in experts
            if expert.status == status
        ]

    if kind is not None:
        experts = [
            expert
            for expert in experts
            if expert.kind == kind
        ]

    return experts


def available_experts() -> list[ExpertSpec]:
    return list_experts(
        status=ExpertStatus.AVAILABLE
    )
