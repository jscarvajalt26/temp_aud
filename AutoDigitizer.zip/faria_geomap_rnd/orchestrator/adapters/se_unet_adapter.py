﻿from __future__ import annotations

from pathlib import Path
from typing import Callable

import cv2
import torch

from faria_geomap_rnd.models.se_unet import SEUNet
from faria_geomap_rnd.orchestrator.contracts import ExpertResult
from faria_geomap_rnd.pipelines.inference_core import predict_tiled_map


class SEUNetAdapter:
    """
    Orchestrator adapter for the existing GeoMap SE-U-Net.

    Responsibilities:
      1. Load the existing checkpoint.
      2. Reconstruct SEUNet using checkpoint metadata.
      3. Load one geological map.
      4. Reuse the existing tiled-inference pipeline.
      5. Return a standard ExpertResult.
    """

    expert_name = "se_unet"
    role = "semantic_segmentation"

    def __init__(
        self,
        checkpoint_path: str | Path,
        *,
        device: str | torch.device = "auto",
        tile_size: int = 512,
        tile_overlap: int = 128,
        confidence_alpha: float = 0.5,
    ) -> None:

        self.checkpoint_path = Path(
            checkpoint_path
        )

        if not self.checkpoint_path.exists():
            raise FileNotFoundError(
                f"SE-U-Net checkpoint not found: "
                f"{self.checkpoint_path}"
            )

        if device == "auto":
            self.device = torch.device(
                "cuda"
                if torch.cuda.is_available()
                else "cpu"
            )
        else:
            self.device = torch.device(
                device
            )

        self.tile_size = int(
            tile_size
        )
        self.tile_overlap = int(
            tile_overlap
        )
        self.confidence_alpha = float(
            confidence_alpha
        )

        self.model: SEUNet | None = None
        self.checkpoint: dict | None = None

    def load(self) -> None:
        checkpoint = torch.load(
            self.checkpoint_path,
            map_location=self.device,
            weights_only=False,
        )

        if not isinstance(
            checkpoint,
            dict,
        ):
            raise TypeError(
                "Expected SE-U-Net checkpoint "
                "to be a dictionary."
            )

        if "model_state_dict" not in checkpoint:
            raise KeyError(
                "SE-U-Net checkpoint does not contain "
                "'model_state_dict'."
            )

        num_classes = int(
            checkpoint.get(
                "num_classes",
                4,
            )
        )

        base_channels = int(
            checkpoint.get(
                "base_channels",
                32,
            )
        )

        model = SEUNet(
            in_channels=3,
            num_classes=num_classes,
            base_channels=base_channels,
            use_se=True,
        )

        model.load_state_dict(
            checkpoint[
                "model_state_dict"
            ]
        )

        model = model.to(
            self.device
        )

        model.eval()

        self.model = model
        self.checkpoint = checkpoint

    def run(
        self,
        source_path: str | Path,
        *,
        progress_callback: (
            Callable[[int, int], None]
            | None
        ) = None,
    ) -> ExpertResult:

        source_path = Path(
            source_path
        )

        if not source_path.exists():
            raise FileNotFoundError(
                f"Input map not found: "
                f"{source_path}"
            )

        if self.model is None:
            self.load()

        image_bgr = cv2.imread(
            str(source_path),
            cv2.IMREAD_COLOR,
        )

        if image_bgr is None:
            raise RuntimeError(
                f"OpenCV could not read map: "
                f"{source_path}"
            )

        prediction = predict_tiled_map(
            model=self.model,
            image_bgr=image_bgr,
            model_name=self.expert_name,
            device=self.device,
            tile_size=self.tile_size,
            tile_overlap=self.tile_overlap,
            confidence_alpha=(
                self.confidence_alpha
            ),
            source_path=source_path,
            checkpoint_path=(
                self.checkpoint_path
            ),
            progress_callback=(
                progress_callback
            ),
        )

        result = ExpertResult(
            expert_name=self.expert_name,
            role=self.role,
            prediction=prediction,
            metadata={
                "adapter": (
                    self.__class__.__name__
                ),
                "device": str(
                    self.device
                ),
                "checkpoint_epoch": (
                    self.checkpoint.get(
                        "epoch"
                    )
                    if self.checkpoint
                    else None
                ),
                "validation_loss": (
                    self.checkpoint.get(
                        "validation_loss",
                        self.checkpoint.get(
                            "val_loss"
                        ),
                    )
                    if self.checkpoint
                    else None
                ),
                "tile_size": (
                    self.tile_size
                ),
                "tile_overlap": (
                    self.tile_overlap
                ),
            },
        )

        result.validate()

        return result
