﻿from __future__ import annotations

import numpy as np

from faria_geomap_rnd.models.model_prediction import ModelPrediction


def validate_compatible_predictions(
    predictions: list[ModelPrediction],
) -> tuple[int, int, int]:
    """
    Verify that predictions can participate in semantic fusion.

    Returns:
        (number_of_classes, height, width)
    """

    if not predictions:
        raise ValueError(
            "At least one prediction is required."
        )

    for prediction in predictions:
        prediction.validate()

    reference = predictions[0]
    classes, height, width = (
        reference.class_probabilities.shape
    )

    for prediction in predictions[1:]:
        shape = prediction.class_probabilities.shape

        if shape != (classes, height, width):
            raise ValueError(
                "Semantic experts must have matching probability "
                "shapes before fusion. "
                f"Expected {(classes, height, width)}, "
                f"received {shape} from "
                f"'{prediction.model_name}'."
            )

    return classes, height, width


def prediction_stack(
    predictions: list[ModelPrediction],
) -> np.ndarray:
    """
    Stack expert probability maps as:

        [E, C, H, W]

    where E = number of experts.
    """

    validate_compatible_predictions(
        predictions
    )

    return np.stack(
        [
            prediction.class_probabilities
            for prediction in predictions
        ],
        axis=0,
    ).astype(
        np.float32
    )


def class_vote_stack(
    predictions: list[ModelPrediction],
) -> np.ndarray:
    """
    Stack predicted class maps as:

        [E, H, W]
    """

    validate_compatible_predictions(
        predictions
    )

    return np.stack(
        [
            prediction.predicted_classes
            for prediction in predictions
        ],
        axis=0,
    )


def vote_disagreement_map(
    predictions: list[ModelPrediction],
) -> np.ndarray:
    """
    Fraction of experts that disagree with the modal class.

    0.0 = complete agreement
    approaching 1.0 = strong disagreement
    """

    votes = class_vote_stack(
        predictions
    )

    expert_count, height, width = (
        votes.shape
    )

    disagreement = np.zeros(
        (height, width),
        dtype=np.float32,
    )

    if expert_count == 1:
        return disagreement

    for y in range(height):
        for x in range(width):
            values, counts = np.unique(
                votes[:, y, x],
                return_counts=True,
            )

            modal_count = int(
                counts.max()
            )

            disagreement[y, x] = (
                1.0
                - modal_count / expert_count
            )

    return disagreement


def probability_disagreement_map(
    predictions: list[ModelPrediction],
) -> np.ndarray:
    """
    Measure disagreement between complete probability distributions.

    Uses mean per-class variance across experts.
    """

    probabilities = prediction_stack(
        predictions
    )

    variance = np.var(
        probabilities,
        axis=0,
    )

    disagreement = np.mean(
        variance,
        axis=0,
    )

    # Probability variance is bounded, but normalize dynamically
    # for a convenient [0,1] diagnostic map.
    maximum = float(
        disagreement.max()
    )

    if maximum > 1e-12:
        disagreement = (
            disagreement / maximum
        )

    return np.clip(
        disagreement,
        0.0,
        1.0,
    ).astype(
        np.float32
    )


def consensus_entropy(
    probabilities: np.ndarray,
) -> np.ndarray:
    """
    Normalized entropy of a consensus probability tensor [C,H,W].

    0 = confident
    1 = maximally uncertain
    """

    if probabilities.ndim != 3:
        raise ValueError(
            "probabilities must have shape [C,H,W]."
        )

    class_count = probabilities.shape[0]

    if class_count < 2:
        raise ValueError(
            "At least two classes are required."
        )

    eps = 1e-8

    entropy = -np.sum(
        probabilities
        * np.log(
            probabilities + eps
        ),
        axis=0,
    )

    maximum_entropy = np.log(
        float(class_count)
    )

    return np.clip(
        entropy / maximum_entropy,
        0.0,
        1.0,
    ).astype(
        np.float32
    )


def build_refinement_mask(
    *,
    uncertainty_map: np.ndarray,
    disagreement_map: np.ndarray,
    uncertainty_threshold: float = 0.55,
    disagreement_threshold: float = 0.25,
) -> np.ndarray:
    """
    Identify regions that should be considered for specialist refinement.

    A pixel is selected when either:
      - consensus uncertainty is high, OR
      - expert disagreement is high.
    """

    if (
        uncertainty_map.shape
        != disagreement_map.shape
    ):
        raise ValueError(
            "uncertainty and disagreement maps must match."
        )

    mask = (
        (uncertainty_map >= uncertainty_threshold)
        |
        (disagreement_map >= disagreement_threshold)
    )

    return mask.astype(
        np.uint8
    )
