﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

from faria_geomap_rnd.models.model_prediction import ModelPrediction
from faria_geomap_rnd.orchestrator.contracts import ExpertResult


@dataclass
class RawExpertOutput:
    """
    Raw normalized output from a PyTorch expert before it is converted
    into the higher-level orchestration contract.
    """

    expert_name: str
    outputs: dict[str, torch.Tensor]
    metadata: dict[str, Any]


def _extract_tensor_outputs(
    output: torch.Tensor | dict[str, torch.Tensor],
) -> dict[str, torch.Tensor]:
    """
    Normalize model.forward() output into a dictionary.

    Supported:
      Tensor -> {"logits": tensor}
      dict[str, Tensor] -> unchanged
    """

    if isinstance(output, torch.Tensor):
        return {
            "logits": output,
        }

    if isinstance(output, dict):
        tensor_outputs = {
            str(name): value
            for name, value in output.items()
            if isinstance(value, torch.Tensor)
        }

        if not tensor_outputs:
            raise ValueError(
                "Model returned a dictionary containing "
                "no tensor outputs."
            )

        return tensor_outputs

    raise TypeError(
        "Unsupported model output type: "
        f"{type(output).__name__}"
    )


def run_torch_expert(
    *,
    expert_name: str,
    model: torch.nn.Module,
    input_tensor: torch.Tensor,
    device: torch.device,
) -> RawExpertOutput:
    """
    Execute one PyTorch expert safely and normalize its raw outputs.
    """

    model = model.to(device)
    model.eval()

    x = input_tensor.to(device)

    with torch.inference_mode():
        output = model(x)

    outputs = _extract_tensor_outputs(
        output
    )

    detached_outputs = {
        name: tensor.detach().cpu()
        for name, tensor in outputs.items()
    }

    return RawExpertOutput(
        expert_name=expert_name,
        outputs=detached_outputs,
        metadata={
            "device": str(device),
            "input_shape": list(
                input_tensor.shape
            ),
            "output_shapes": {
                name: list(tensor.shape)
                for name, tensor
                in detached_outputs.items()
            },
        },
    )


def logits_to_model_prediction(
    *,
    expert_name: str,
    logits: torch.Tensor,
    source_path: Path | None = None,
    checkpoint_path: Path | None = None,
    metadata: dict[str, Any] | None = None,
) -> ModelPrediction:
    """
    Convert semantic logits [B,C,H,W] into ModelPrediction.

    Current orchestration inference supports batch size 1.
    """

    if logits.ndim != 4:
        raise ValueError(
            "Semantic logits must have shape [B,C,H,W]. "
            f"Received {tuple(logits.shape)}."
        )

    if logits.shape[0] != 1:
        raise ValueError(
            "ModelPrediction currently expects one map at a time. "
            f"Received batch size {logits.shape[0]}."
        )

    if logits.shape[1] < 2:
        raise ValueError(
            "Semantic prediction requires at least two classes."
        )

    probabilities = F.softmax(
        logits.float(),
        dim=1,
    )[0]

    confidence, predicted = torch.max(
        probabilities,
        dim=0,
    )

    eps = 1e-8

    entropy = -torch.sum(
        probabilities
        * torch.log(
            probabilities + eps
        ),
        dim=0,
    )

    maximum_entropy = float(
        np.log(
            probabilities.shape[0]
        )
    )

    uncertainty = (
        entropy / maximum_entropy
    ).clamp(
        0.0,
        1.0,
    )

    prediction = ModelPrediction(
        model_name=expert_name,
        prediction_type="semantic_segmentation",
        confidence_type="maximum_softmax_probability",
        predicted_classes=(
            predicted.numpy().astype(
                np.int32
            )
        ),
        class_probabilities=(
            probabilities.numpy().astype(
                np.float32
            )
        ),
        confidence_map=(
            confidence.numpy().astype(
                np.float32
            )
        ),
        uncertainty_map=(
            uncertainty.numpy().astype(
                np.float32
            )
        ),
        source_path=source_path,
        checkpoint_path=checkpoint_path,
        metadata=metadata or {},
    )

    prediction.validate()

    return prediction


def semantic_expert_result(
    *,
    expert_name: str,
    raw_output: RawExpertOutput,
    source_path: Path | None = None,
    checkpoint_path: Path | None = None,
    logits_key: str = "logits",
) -> ExpertResult:
    """
    Convert an ordinary semantic segmentation expert into ExpertResult.

    Intended for:
      - SE-UNet
      - HybridGeoMapNetV1
      - future RS3Mamba semantic adapter
      - compatible Mask2Former semantic adapter
    """

    if logits_key not in raw_output.outputs:
        available = ", ".join(
            sorted(
                raw_output.outputs
            )
        )

        raise KeyError(
            f"Expert '{expert_name}' has no "
            f"'{logits_key}' output. "
            f"Available outputs: {available}"
        )

    prediction = logits_to_model_prediction(
        expert_name=expert_name,
        logits=raw_output.outputs[
            logits_key
        ],
        source_path=source_path,
        checkpoint_path=checkpoint_path,
        metadata={
            **raw_output.metadata,
            "logits_key": logits_key,
        },
    )

    result = ExpertResult(
        expert_name=expert_name,
        role="semantic_segmentation",
        prediction=prediction,
        metadata={
            "raw_output_keys": list(
                raw_output.outputs.keys()
            ),
        },
    )

    result.validate()

    return result


def split_multihead_output(
    raw_output: RawExpertOutput,
) -> dict[str, torch.Tensor]:
    """
    Preserve every MultiHeadGeoMapNet output as a separate task.

    We deliberately do NOT pretend these heads are one semantic
    segmentation prediction.
    """

    return dict(
        raw_output.outputs
    )


def affinity_expert_result(
    *,
    expert_name: str,
    raw_output: RawExpertOutput,
) -> ExpertResult:
    """
    Package GeoRegionAffinityNet output without converting it into
    semantic class probabilities.

    Expected structural outputs:
      affinity_h
      affinity_v
      boundary

    Exact names are checked at runtime rather than invented here.
    """

    output_keys = set(
        raw_output.outputs
    )

    result = ExpertResult(
        expert_name=expert_name,
        role="region_affinity",
        prediction=None,
        metadata={
            **raw_output.metadata,
            "output_keys": sorted(
                output_keys
            ),
            "raw_tensors": raw_output.outputs,
        },
    )

    result.validate()

    return result


def safe_run(
    *,
    expert_name: str,
    callable_fn,
    role: str,
) -> ExpertResult:
    """
    Boundary used by the orchestrator so one failed expert does not
    necessarily terminate the entire multi-expert pipeline.
    """

    try:
        result = callable_fn()

        if not isinstance(
            result,
            ExpertResult,
        ):
            raise TypeError(
                "Expert callable must return ExpertResult."
            )

        result.validate()

        return result

    except Exception as exc:
        return ExpertResult(
            expert_name=expert_name,
            role=role,
            prediction=None,
            success=False,
            error=(
                f"{type(exc).__name__}: {exc}"
            ),
        )
