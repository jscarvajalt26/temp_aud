﻿from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

# ============================================================
# PROJECT IMPORTS
# ============================================================
from faria_geomap_rnd.datasets.georegion_dataset import (
    DEFAULT_AFFINITY_TARGET_ROOT,
    DEFAULT_DATASET_ROOT,
    DEFAULT_SPLIT_PATH,
    DEFAULT_SUPERVISOR_TARGET_ROOT,
    GeoRegionDataset,
    load_split_map_ids,
)
from faria_geomap_rnd.models.hybrid.georegion_affinity_net import (
    GeoRegionAffinityNet,
)

BASE_DIR = Path(__file__).resolve().parents[1]

# ============================================================
# DEFAULTS
# ============================================================

DEFAULT_OUTPUT_DIR = BASE_DIR / "outputs" / "checkpoints_georegion_affinity"

SEED = 42


# ============================================================
# REPRODUCIBILITY
# ============================================================


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# ============================================================
# DEVICE
# ============================================================


def resolve_device(name: str) -> torch.device:

    if name == "cpu":
        return torch.device("cpu")

    if name == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but torch.cuda.is_available() is False.")

        return torch.device("cuda")

    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    raise ValueError(f"Unsupported device: {name}")


# ============================================================
# MASKED LOSSES
# ============================================================


def masked_weighted_bce(
    logits: torch.Tensor,
    target: torch.Tensor,
    valid: torch.Tensor,
    zero_class_weight: float,
) -> torch.Tensor:
    """
    Affinity target semantics:

        1 = neighboring pixels belong to SAME geological region
        0 = neighboring pixels belong to DIFFERENT geological regions

    Because ~99% of valid pairs are SAME, target=0 is the rare
    and important class.

    BCEWithLogitsLoss(pos_weight=...) cannot directly upweight
    negative targets, so we calculate elementwise BCE and assign
    a larger weight to target=0.
    """

    loss = nn.functional.binary_cross_entropy_with_logits(
        logits,
        target,
        reduction="none",
    )

    class_weight = torch.where(
        target < 0.5,
        torch.full_like(
            target,
            float(zero_class_weight),
        ),
        torch.ones_like(target),
    )

    weighted = loss * class_weight * valid

    denominator = torch.clamp(
        valid.sum(),
        min=1.0,
    )

    return weighted.sum() / denominator


def masked_boundary_bce(
    logits: torch.Tensor,
    target: torch.Tensor,
    valid: torch.Tensor,
    positive_weight: float,
) -> torch.Tensor:

    loss = nn.functional.binary_cross_entropy_with_logits(
        logits,
        target,
        reduction="none",
    )

    class_weight = torch.where(
        target > 0.5,
        torch.full_like(
            target,
            float(positive_weight),
        ),
        torch.ones_like(target),
    )

    weighted = loss * class_weight * valid

    denominator = torch.clamp(
        valid.sum(),
        min=1.0,
    )

    return weighted.sum() / denominator


def masked_dice_loss(
    logits: torch.Tensor,
    target: torch.Tensor,
    valid: torch.Tensor,
    eps: float = 1e-6,
) -> torch.Tensor:

    probability = torch.sigmoid(logits)

    probability = probability * valid

    target = target * valid

    intersection = (probability * target).sum(dim=(1, 2, 3))

    denominator = probability.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3))

    dice = (2.0 * intersection + eps) / (denominator + eps)

    return 1.0 - dice.mean()


# ============================================================
# COMPLETE LOSS
# ============================================================


class GeoRegionLoss(nn.Module):

    def __init__(
        self,
        affinity_different_weight: float = 12.0,
        boundary_positive_weight: float = 15.0,
        affinity_loss_weight: float = 0.40,
        boundary_bce_weight: float = 0.30,
        boundary_dice_weight: float = 0.30,
    ) -> None:

        super().__init__()

        self.affinity_different_weight = float(affinity_different_weight)

        self.boundary_positive_weight = float(boundary_positive_weight)

        self.affinity_loss_weight = float(affinity_loss_weight)

        self.boundary_bce_weight = float(boundary_bce_weight)

        self.boundary_dice_weight = float(boundary_dice_weight)

    def forward(
        self,
        outputs: dict[str, torch.Tensor],
        batch: dict,
    ) -> tuple[torch.Tensor, dict]:

        h_loss = masked_weighted_bce(
            logits=outputs["affinity_h"],
            target=batch["affinity_h"],
            valid=batch["affinity_h_valid"],
            zero_class_weight=(self.affinity_different_weight),
        )

        v_loss = masked_weighted_bce(
            logits=outputs["affinity_v"],
            target=batch["affinity_v"],
            valid=batch["affinity_v_valid"],
            zero_class_weight=(self.affinity_different_weight),
        )

        affinity_loss = 0.5 * h_loss + 0.5 * v_loss

        boundary_bce = masked_boundary_bce(
            logits=outputs["boundary"],
            target=batch["boundary"],
            valid=batch["boundary_valid"],
            positive_weight=(self.boundary_positive_weight),
        )

        boundary_dice = masked_dice_loss(
            logits=outputs["boundary"],
            target=batch["boundary"],
            valid=batch["boundary_valid"],
        )

        total = (
            self.affinity_loss_weight * affinity_loss
            + self.boundary_bce_weight * boundary_bce
            + self.boundary_dice_weight * boundary_dice
        )

        details = {
            "affinity_h": float(h_loss.detach().cpu()),
            "affinity_v": float(v_loss.detach().cpu()),
            "boundary_bce": float(boundary_bce.detach().cpu()),
            "boundary_dice": float(boundary_dice.detach().cpu()),
            "total": float(total.detach().cpu()),
        }

        return total, details


# ============================================================
# METRICS
# ============================================================


def binary_counts(
    prediction: torch.Tensor,
    target: torch.Tensor,
    valid: torch.Tensor,
) -> tuple[int, int, int]:

    prediction = prediction > 0.5

    target = target > 0.5

    valid = valid > 0.5

    tp = int((prediction & target & valid).sum().item())

    fp = int((prediction & (~target) & valid).sum().item())

    fn = int(((~prediction) & target & valid).sum().item())

    return tp, fp, fn


def safe_metrics(
    tp: int,
    fp: int,
    fn: int,
) -> dict[str, float]:

    precision = tp / max(tp + fp, 1)

    recall = tp / max(tp + fn, 1)

    iou = tp / max(
        tp + fp + fn,
        1,
    )

    f1 = (
        2.0
        * precision
        * recall
        / max(
            precision + recall,
            1e-12,
        )
    )

    return {
        "precision": float(precision),
        "recall": float(recall),
        "iou": float(iou),
        "f1": float(f1),
    }


# ============================================================
# AFFINITY-DIFFERENT METRICS
# ============================================================


def affinity_difference_counts(
    logits: torch.Tensor,
    same_target: torch.Tensor,
    valid: torch.Tensor,
    same_threshold: float = 0.5,
) -> tuple[int, int, int]:
    """
    Metrics are calculated on DIFFERENT-region edges.

    Network output:
        sigmoid(logit) = probability of SAME region

    Therefore:
        predicted different = same_probability < threshold
    """

    same_probability = torch.sigmoid(logits)

    predicted_different = same_probability < same_threshold

    target_different = same_target < 0.5

    valid_bool = valid > 0.5

    tp = int((predicted_different & target_different & valid_bool).sum().item())

    fp = int((predicted_different & (~target_different) & valid_bool).sum().item())

    fn = int(((~predicted_different) & target_different & valid_bool).sum().item())

    return tp, fp, fn


# ============================================================
# MOVE BATCH
# ============================================================

TENSOR_KEYS = (
    "image",
    "valid_pixel",
    "affinity_h",
    "affinity_h_valid",
    "affinity_v",
    "affinity_v_valid",
    "boundary",
    "boundary_valid",
)


def move_batch(
    batch: dict,
    device: torch.device,
) -> dict:

    result = dict(batch)

    for key in TENSOR_KEYS:

        result[key] = batch[key].to(
            device,
            non_blocking=True,
        )

    return result


# ============================================================
# TRAIN ONE EPOCH
# ============================================================


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    criterion: GeoRegionLoss,
    device: torch.device,
) -> dict:

    model.train()

    total_loss = 0.0
    total_batches = 0

    component_sums = {
        "affinity_h": 0.0,
        "affinity_v": 0.0,
        "boundary_bce": 0.0,
        "boundary_dice": 0.0,
    }

    mode_counts = {}

    for batch_index, raw_batch in enumerate(
        loader,
        start=1,
    ):

        batch = move_batch(
            raw_batch,
            device,
        )

        optimizer.zero_grad(set_to_none=True)

        outputs = model(batch["image"])

        loss, details = criterion(
            outputs,
            batch,
        )

        loss.backward()

        torch.nn.utils.clip_grad_norm_(
            model.parameters(),
            max_norm=5.0,
        )

        optimizer.step()

        total_loss += float(loss.detach().cpu())

        total_batches += 1

        for key in component_sums:

            component_sums[key] += details[key]

        for crop_mode in raw_batch["crop_mode"]:

            mode_counts[crop_mode] = (
                mode_counts.get(
                    crop_mode,
                    0,
                )
                + 1
            )

        if batch_index % 100 == 0 or batch_index == len(loader):

            print(f"  train: " f"{batch_index}/" f"{len(loader)}")

    result = {
        "loss": (total_loss / max(total_batches, 1)),
        "sample_modes": (mode_counts),
    }

    for key, value in component_sums.items():

        result[key] = value / max(
            total_batches,
            1,
        )

    return result


# ============================================================
# VALIDATION
# ============================================================


@torch.inference_mode()
def validate(
    model: nn.Module,
    loader: DataLoader,
    criterion: GeoRegionLoss,
    device: torch.device,
) -> dict:

    model.eval()

    total_loss = 0.0
    total_batches = 0

    boundary_counts = [
        0,
        0,
        0,
    ]

    h_diff_counts = [
        0,
        0,
        0,
    ]

    v_diff_counts = [
        0,
        0,
        0,
    ]

    for batch_index, raw_batch in enumerate(
        loader,
        start=1,
    ):

        batch = move_batch(
            raw_batch,
            device,
        )

        outputs = model(batch["image"])

        loss, _ = criterion(
            outputs,
            batch,
        )

        total_loss += float(loss.detach().cpu())

        total_batches += 1

        # ----------------------------------------------------
        # Boundary metrics
        # ----------------------------------------------------

        boundary_probability = torch.sigmoid(outputs["boundary"])

        counts = binary_counts(
            prediction=boundary_probability,
            target=batch["boundary"],
            valid=batch["boundary_valid"],
        )

        for i in range(3):
            boundary_counts[i] += counts[i]

        # ----------------------------------------------------
        # Horizontal DIFFERENT edge metrics
        # ----------------------------------------------------

        counts = affinity_difference_counts(
            logits=outputs["affinity_h"],
            same_target=batch["affinity_h"],
            valid=batch["affinity_h_valid"],
        )

        for i in range(3):
            h_diff_counts[i] += counts[i]

        # ----------------------------------------------------
        # Vertical DIFFERENT edge metrics
        # ----------------------------------------------------

        counts = affinity_difference_counts(
            logits=outputs["affinity_v"],
            same_target=batch["affinity_v"],
            valid=batch["affinity_v_valid"],
        )

        for i in range(3):
            v_diff_counts[i] += counts[i]

        if batch_index % 100 == 0 or batch_index == len(loader):

            print(f"  validation: " f"{batch_index}/" f"{len(loader)}")

    boundary_metrics = safe_metrics(*boundary_counts)

    h_metrics = safe_metrics(*h_diff_counts)

    v_metrics = safe_metrics(*v_diff_counts)

    affinity_mean_iou = (h_metrics["iou"] + v_metrics["iou"]) / 2.0

    # Main checkpoint score:
    #
    # boundary is weighted more heavily because the final
    # polygonization depends directly on accurate contacts.
    validation_score = (
        0.60 * boundary_metrics["iou"]
        + 0.20 * h_metrics["iou"]
        + 0.20 * v_metrics["iou"]
    )

    return {
        "loss": (
            total_loss
            / max(
                total_batches,
                1,
            )
        ),
        "boundary": (boundary_metrics),
        "horizontal_difference": (h_metrics),
        "vertical_difference": (v_metrics),
        "affinity_mean_iou": float(affinity_mean_iou),
        "validation_score": float(validation_score),
    }


# ============================================================
# CHECKPOINT
# ============================================================


def save_checkpoint(
    path: Path,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    args,
    train_metrics: dict,
    validation_metrics: dict,
) -> None:

    checkpoint = {
        "schema_version": 1,
        "model_name": ("GeoRegionAffinityNet"),
        "model_state_dict": (model.state_dict()),
        "optimizer_state_dict": (optimizer.state_dict()),
        "epoch": int(epoch),
        "validation_score": float(validation_metrics["validation_score"]),
        "validation_metrics": (validation_metrics),
        "training_metrics": (train_metrics),
        "base_channels": int(args.base_channels),
        "crop_size": int(args.crop_size),
        "samples_per_map": int(args.samples_per_map),
        "affinity_different_weight": float(args.affinity_different_weight),
        "boundary_positive_weight": float(args.boundary_positive_weight),
        "palette_probability": float(args.palette_probability),
    }

    torch.save(
        checkpoint,
        path,
    )


# ============================================================
# ARGUMENTS
# ============================================================


def parse_args():

    parser = argparse.ArgumentParser(
        description=(
            "Train palette-independent geological "
            "region affinity and boundary model."
        )
    )

    parser.add_argument(
        "--dataset-root",
        type=Path,
        default=DEFAULT_DATASET_ROOT,
    )

    parser.add_argument(
        "--resume",
        type=Path,
        default=None,
    )

    parser.add_argument(
        "--supervisor-target-root",
        type=Path,
        default=DEFAULT_SUPERVISOR_TARGET_ROOT,
    )

    parser.add_argument(
        "--affinity-target-root",
        type=Path,
        default=DEFAULT_AFFINITY_TARGET_ROOT,
    )

    parser.add_argument(
        "--split-path",
        type=Path,
        default=DEFAULT_SPLIT_PATH,
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
    )

    parser.add_argument(
        "--device",
        choices=[
            "auto",
            "cpu",
            "cuda",
        ],
        default="auto",
    )

    parser.add_argument(
        "--crop-size",
        type=int,
        default=256,
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=1,
    )

    parser.add_argument(
        "--epochs",
        type=int,
        default=10,
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=3e-4,
    )

    parser.add_argument(
        "--weight-decay",
        type=float,
        default=1e-4,
    )

    parser.add_argument(
        "--base-channels",
        type=int,
        default=16,
    )

    parser.add_argument(
        "--samples-per-map",
        type=int,
        default=8,
    )

    parser.add_argument(
        "--palette-probability",
        type=float,
        default=0.35,
    )

    parser.add_argument(
        "--affinity-different-weight",
        type=float,
        default=12.0,
    )

    parser.add_argument(
        "--boundary-positive-weight",
        type=float,
        default=15.0,
    )

    parser.add_argument(
        "--patience",
        type=int,
        default=5,
    )

    parser.add_argument(
        "--num-workers",
        type=int,
        default=0,
    )

    return parser.parse_args()


# ============================================================
# MAIN
# ============================================================


def main():

    args = parse_args()

    seed_everything(SEED)

    device = resolve_device(args.device)

    args.output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    train_map_ids = load_split_map_ids(
        args.split_path,
        "train",
    )

    validation_map_ids = load_split_map_ids(
        args.split_path,
        "validation",
    )

    train_dataset = GeoRegionDataset(
        map_ids=train_map_ids,
        dataset_root=args.dataset_root,
        supervisor_target_root=(args.supervisor_target_root),
        affinity_target_root=(args.affinity_target_root),
        crop_size=args.crop_size,
        samples_per_map=(args.samples_per_map),
        boundary_crop_probability=0.65,
        random_crop_probability=0.25,
        interior_crop_probability=0.10,
        augment=True,
        palette_randomization_probability=(args.palette_probability),
        seed=SEED,
    )

    validation_dataset = GeoRegionDataset(
        map_ids=validation_map_ids,
        dataset_root=args.dataset_root,
        supervisor_target_root=(args.supervisor_target_root),
        affinity_target_root=(args.affinity_target_root),
        crop_size=args.crop_size,
        # More coverage than one centre crop per map,
        # but still cheap on CPU.
        samples_per_map=4,
        boundary_crop_probability=0.70,
        random_crop_probability=0.20,
        interior_crop_probability=0.10,
        augment=False,
        palette_randomization_probability=0.0,
        seed=SEED + 1000,
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=(device.type == "cuda"),
    )

    validation_loader = DataLoader(
        validation_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=(device.type == "cuda"),
    )

    print(
        "Device:",
        device,
    )

    print(
        "Dataset root:",
        args.dataset_root,
    )

    print(
        "Supervisor target root:",
        args.supervisor_target_root,
    )

    print(
        "Affinity target root:",
        args.affinity_target_root,
    )

    print(
        "Split path:",
        args.split_path,
    )

    print(
        "Train maps:",
        len(train_map_ids),
    )

    print(
        "Train samples/epoch:",
        len(train_dataset),
    )

    print(
        "Validation maps:",
        len(validation_map_ids),
    )

    print(
        "Validation samples:",
        len(validation_dataset),
    )

    print(
        "Affinity DIFFERENT weight:",
        args.affinity_different_weight,
    )

    print(
        "Boundary positive weight:",
        args.boundary_positive_weight,
    )

    print(
        "Palette probability:",
        args.palette_probability,
    )

    # --------------------------------------------------------
    # MODEL
    # --------------------------------------------------------

    model = GeoRegionAffinityNet(base_channels=(args.base_channels)).to(device)

    criterion = GeoRegionLoss(
        affinity_different_weight=(args.affinity_different_weight),
        boundary_positive_weight=(args.boundary_positive_weight),
    )

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
    )

    start_epoch = 1

    if args.resume is not None:
        print()
        print("Loading checkpoint:", args.resume)

    checkpoint = torch.load(
        args.resume,
        map_location=device,
        weights_only=False,
    )

    model.load_state_dict(checkpoint["model_state_dict"])

    if "optimizer_state_dict" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

    start_epoch = int(checkpoint.get("epoch", 0)) + 1

    best_score = float(
        checkpoint.get(
            "validation_score",
            -1.0,
        )
    )

    print(
        "Resuming after epoch:",
        checkpoint.get("epoch", 0),
    )

    print(
        "Previous best score:",
        best_score,
    )

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=2,
    )

    best_score = -1.0
    epochs_without_improvement = 0

    best_checkpoint = args.output_dir / "georegion_affinity_best.pth"

    history = []

    # --------------------------------------------------------
    # TRAINING LOOP
    # --------------------------------------------------------

    for epoch in range(
        start_epoch,
        args.epochs + 1,
    ):

        print()
        print("=" * 72)

        print(f"Epoch " f"{epoch:03d}/" f"{args.epochs}")

        start_time = time.time()

        train_metrics = train_one_epoch(
            model=model,
            loader=train_loader,
            optimizer=optimizer,
            criterion=criterion,
            device=device,
        )

        validation_metrics = validate(
            model=model,
            loader=validation_loader,
            criterion=criterion,
            device=device,
        )

        runtime = time.time() - start_time

        validation_score = float(validation_metrics["validation_score"])

        scheduler.step(validation_score)

        print(f"Train loss: " f"{train_metrics['loss']:.5f}")

        print(f"Validation loss: " f"{validation_metrics['loss']:.5f}")

        print()

        b = validation_metrics["boundary"]

        h = validation_metrics["horizontal_difference"]

        v = validation_metrics["vertical_difference"]

        print("Boundary:")

        print(
            f"  IoU={b['iou']:.4f} "
            f"F1={b['f1']:.4f} "
            f"P={b['precision']:.4f} "
            f"R={b['recall']:.4f}"
        )

        print("Horizontal DIFFERENT affinity:")

        print(
            f"  IoU={h['iou']:.4f} "
            f"F1={h['f1']:.4f} "
            f"P={h['precision']:.4f} "
            f"R={h['recall']:.4f}"
        )

        print("Vertical DIFFERENT affinity:")

        print(
            f"  IoU={v['iou']:.4f} "
            f"F1={v['f1']:.4f} "
            f"P={v['precision']:.4f} "
            f"R={v['recall']:.4f}"
        )

        print()

        print("GeoRegion validation score:", f"{validation_score:.5f}")

        print(
            "Train sample modes:",
            train_metrics["sample_modes"],
        )

        print("Epoch runtime:", f"{runtime:.1f}s")

        epoch_record = {
            "epoch": epoch,
            "runtime_seconds": runtime,
            "train": train_metrics,
            "validation": (validation_metrics),
        }

        history.append(epoch_record)

        (args.output_dir / "training_history.json").write_text(
            json.dumps(
                history,
                indent=2,
            ),
            encoding="utf-8",
        )

        if validation_score > best_score:

            best_score = validation_score

            epochs_without_improvement = 0

            save_checkpoint(
                path=best_checkpoint,
                model=model,
                optimizer=optimizer,
                epoch=epoch,
                args=args,
                train_metrics=train_metrics,
                validation_metrics=(validation_metrics),
            )

            print(
                "Saved best checkpoint:",
                best_checkpoint,
            )

        else:

            epochs_without_improvement += 1

            print(
                "No improvement:",
                epochs_without_improvement,
                "epoch(s)",
            )

        if epochs_without_improvement >= args.patience:

            print()
            print("Early stopping.")

            break

    print()
    print("=" * 72)
    print("Training complete.")

    print(
        "Best checkpoint:",
        best_checkpoint,
    )

    print(
        "Best validation score:",
        best_score,
    )

    print("=" * 72)


if __name__ == "__main__":
    main()
