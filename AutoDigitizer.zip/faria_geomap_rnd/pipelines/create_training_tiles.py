from pathlib import Path

import cv2

BASE_DIR = Path(__file__).resolve().parents[1]

RAW_MAP_DIR = BASE_DIR / "data" / "raw_maps"

TRAINING_DIR = BASE_DIR / "data" / "training"
COLOR_IMAGE_DIR = TRAINING_DIR / "color" / "images"
GRAYSCALE_IMAGE_DIR = TRAINING_DIR / "grayscale" / "images"

COLOR_IMAGE_DIR.mkdir(parents=True, exist_ok=True)
GRAYSCALE_IMAGE_DIR.mkdir(parents=True, exist_ok=True)

TILE_SIZE = 512
OVERLAP = 128


def is_grayscale_like(image_bgr):
    hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]

    valid = (value > 40) & (value < 245)

    if valid.sum() == 0:
        return True

    mean_saturation = saturation[valid].mean()
    high_saturation_ratio = (saturation[valid] > 45).mean()

    return not (mean_saturation > 25 and high_saturation_ratio > 0.08)


def save_tiles(image_path: Path):
    image_bgr = cv2.imread(str(image_path))

    if image_bgr is None:
        print("Skipping unreadable file:", image_path)
        return

    map_type = "grayscale" if is_grayscale_like(image_bgr) else "color"

    output_dir = GRAYSCALE_IMAGE_DIR if map_type == "grayscale" else COLOR_IMAGE_DIR

    h, w = image_bgr.shape[:2]

    step = TILE_SIZE - OVERLAP

    tile_count = 0

    for y in range(0, max(h - TILE_SIZE + 1, 1), step):
        for x in range(0, max(w - TILE_SIZE + 1, 1), step):
            tile = image_bgr[y : y + TILE_SIZE, x : x + TILE_SIZE]

            if tile.shape[0] != TILE_SIZE or tile.shape[1] != TILE_SIZE:
                continue

            tile_name = f"{image_path.stem}_{map_type}_y{y}_x{x}.png"
            tile_path = output_dir / tile_name

            cv2.imwrite(str(tile_path), tile)
            tile_count += 1

    print(f"{image_path.name}: {tile_count} {map_type} tiles saved")


def main():
    image_extensions = ["*.png", "*.jpg", "*.jpeg", "*.tif", "*.tiff"]

    image_paths = []

    for ext in image_extensions:
        image_paths.extend(RAW_MAP_DIR.glob(ext))

    if not image_paths:
        print("No raw maps found in:", RAW_MAP_DIR)
        return

    for image_path in image_paths:
        save_tiles(image_path)


if __name__ == "__main__":
    main()
