﻿from __future__ import annotations

from pathlib import Path
from typing import Callable

import cv2
import numpy as np
import torch
import torch.nn.functional as F

from faria_geomap_rnd.models.model_prediction import ModelPrediction


def generate_positions(
    length: int,
    tile_size: int,
    step: int,
) -> list[int]:
    if tile_size <= 0:
        raise ValueError("tile_size must be positive.")

    if step <= 0:
        raise ValueError("step must be positive.")

    if length <= tile_size:
        return [0]

    positions = list(
        range(
            0,
            length - tile_size + 1,
            step,
        )
    )

    final_position = length - tile_size

    if not positions or positions[-1] != final_position:
        positions.append(final_position)

    return positions


def pad_image(
    image_bgr: np.ndarray,
    minimum_height: int,
    minimum_width: int,
) -> tuple[np.ndarray, int, int]:
    if image_bgr is None or image_bgr.size == 0:
        raise ValueError("Input image is empty.")

    original_height, original_width = image_bgr.shape[:2]

    pad_bottom = max(
        minimum_height - original_height,
        0,
    )

    pad_right = max(
        minimum_width - original_width,
        0,
    )

    if pad_bottom == 0 and pad_right == 0:
        return (
            image_bgr,
            original_height,
            original_width,
        )

    padded = cv2.copyMakeBorder(
        image_bgr,
        top=0,
        bottom=pad_bottom,
        left=0,
        right=pad_right,
        borderType=cv2.BORDER_REFLECT_101,
    )

    return (
        padded,
        original_height,
        original_width,
    )


def prepare_tile(
    tile_bgr: np.ndarray,
    device: torch.device,
) -> torch.Tensor:
    tile_rgb = cv2.cvtColor(
        tile_bgr,
        cv2.COLOR_BGR2RGB,
    )

    tile_float = tile_rgb.astype(np.float32) / 255.0

    tile_chw = np.transpose(
        tile_float,
        (2, 0, 1),
    )

    tensor = torch.from_numpy(tile_chw).unsqueeze(0)

    return tensor.to(
        device=device,
        dtype=torch.float32,
    )


def calculate_normalized_entropy(
    probabilities: np.ndarray,
) -> np.ndarray:
    class_count = probabilities.shape[0]

    clipped = np.clip(
        probabilities,
        1e-8,
        1.0,
    )

    entropy = -np.sum(
        clipped * np.log(clipped),
        axis=0,
    )

    maximum_entropy = np.log(max(class_count, 2))

    return (entropy / maximum_entropy).astype(np.float32)


def predict_tiled_map(
    model: torch.nn.Module,
    image_bgr: np.ndarray,
    model_name: str,
    device: torch.device,
    tile_size: int = 512,
    tile_overlap: int = 128,
    confidence_alpha: float = 0.5,
    source_path: Path | None = None,
    checkpoint_path: Path | None = None,
    progress_callback: (
        Callable[
            [int, int],
            None,
        ]
        | None
    ) = None,
) -> ModelPrediction:
    if tile_overlap < 0:
        raise ValueError("tile_overlap cannot be negative.")

    if tile_overlap >= tile_size:
        raise ValueError("tile_overlap must be smaller than tile_size.")

    if not 0.0 <= confidence_alpha <= 1.0:
        raise ValueError("confidence_alpha must be between 0 and 1.")

    tile_step = tile_size - tile_overlap

    padded_bgr, original_height, original_width = pad_image(
        image_bgr,
        minimum_height=tile_size,
        minimum_width=tile_size,
    )

    height, width = padded_bgr.shape[:2]

    y_positions = generate_positions(
        height,
        tile_size,
        tile_step,
    )

    x_positions = generate_positions(
        width,
        tile_size,
        tile_step,
    )

    probability_sum: np.ndarray | None = None

    count_map = np.zeros(
        (height, width),
        dtype=np.float32,
    )

    total_tiles = len(y_positions) * len(x_positions)

    completed_tiles = 0

    model.eval()

    with torch.inference_mode():
        for y in y_positions:
            for x in x_positions:
                tile_bgr = padded_bgr[
                    y : y + tile_size,
                    x : x + tile_size,
                ]

                tile_tensor = prepare_tile(
                    tile_bgr,
                    device,
                )

                logits = model(tile_tensor)

                if logits.ndim != 4:
                    raise RuntimeError("Model output must have shape [B, C, H, W].")

                if logits.shape[0] != 1:
                    raise RuntimeError(
                        "Tiled inference currently expects batch size 1."
                    )

                probabilities = (
                    F.softmax(
                        logits,
                        dim=1,
                    )[0]
                    .detach()
                    .cpu()
                    .numpy()
                )

                class_count = probabilities.shape[0]

                if probability_sum is None:
                    probability_sum = np.zeros(
                        (
                            class_count,
                            height,
                            width,
                        ),
                        dtype=np.float32,
                    )

                if probability_sum.shape[0] != class_count:
                    raise RuntimeError("Model class count changed during inference.")

                probability_sum[
                    :,
                    y : y + tile_size,
                    x : x + tile_size,
                ] += probabilities

                count_map[
                    y : y + tile_size,
                    x : x + tile_size,
                ] += 1.0

                completed_tiles += 1

                if progress_callback is not None:
                    progress_callback(
                        completed_tiles,
                        total_tiles,
                    )

    if probability_sum is None:
        raise RuntimeError("No tiles were processed.")

    count_map = np.maximum(
        count_map,
        1.0,
    )

    averaged_probabilities = probability_sum / count_map[None, :, :]

    averaged_probabilities = averaged_probabilities[
        :,
        :original_height,
        :original_width,
    ]

    predicted_classes = np.argmax(
        averaged_probabilities,
        axis=0,
    ).astype(np.uint8)

    maximum_probability = np.max(
        averaged_probabilities,
        axis=0,
    ).astype(np.float32)

    normalized_entropy = calculate_normalized_entropy(averaged_probabilities)

    normalized_confidence = (
        confidence_alpha * maximum_probability
        + (1.0 - confidence_alpha) * (1.0 - normalized_entropy)
    ).astype(np.float32)

    uncertainty_map = (1.0 - normalized_confidence).astype(np.float32)

    result = ModelPrediction(
        model_name=model_name,
        prediction_type="semantic",
        confidence_type="pixel_probability",
        predicted_classes=predicted_classes,
        class_probabilities=averaged_probabilities,
        confidence_map=normalized_confidence,
        uncertainty_map=uncertainty_map,
        source_path=source_path,
        checkpoint_path=checkpoint_path,
        metadata={
            "tile_size": tile_size,
            "tile_overlap": tile_overlap,
            "tile_count": total_tiles,
            "class_count": int(averaged_probabilities.shape[0]),
            "confidence_alpha": confidence_alpha,
            "maximum_probability_mean": float(maximum_probability.mean()),
            "normalized_entropy_mean": float(normalized_entropy.mean()),
            "normalized_confidence_mean": float(normalized_confidence.mean()),
        },
    )

    result.validate()

    return result
