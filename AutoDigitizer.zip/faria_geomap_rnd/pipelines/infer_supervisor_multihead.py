﻿from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np
import torch

# ============================================================
# PROJECT PATH
# ============================================================
# ============================================================
# PROJECT IMPORTS
# ============================================================
from faria_geomap_rnd.models.hybrid.line_models import build_line_model
from faria_geomap_rnd.models.hybrid.multihead_geomap_net import (
    HEAD_NAMES,
    MultiHeadGeoMapNet,
)

BASE_DIR = Path(__file__).resolve().parents[1]

# ============================================================
# DEFAULTS
# ============================================================

DEFAULT_CHECKPOINT = (
    BASE_DIR
    / "outputs"
    / "checkpoints_supervisor_multihead"
    / "multihead_geomap_best.pth"
)

DEFAULT_OUTPUT_ROOT = BASE_DIR / "outputs" / "supervisor_multihead_inference"

SUPPORTED_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".tif",
    ".tiff",
}

# BGR overlay colours.
HEAD_COLORS_BGR = {
    "contact": (0, 0, 255),  # red
    "fault": (255, 0, 255),  # magenta
    "road": (0, 165, 255),  # orange
    "river": (255, 255, 0),  # cyan
    "lake": (255, 0, 0),  # blue
    "strike_dip": (0, 255, 255),  # yellow
    "clutter": (128, 128, 128),  # gray
}


# ============================================================
# HELPERS
# ============================================================


def choose_device(requested: str) -> torch.device:
    requested = requested.lower().strip()

    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    if requested == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but no CUDA device is available.")
        return torch.device("cuda")

    if requested == "cpu":
        return torch.device("cpu")

    raise ValueError("device must be one of: auto, cpu, cuda")


def collect_inputs(
    input_path: Path,
    recursive: bool,
) -> list[Path]:
    input_path = input_path.resolve()

    if not input_path.exists():
        raise FileNotFoundError(f"Input does not exist: {input_path}")

    if input_path.is_file():
        if input_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file type: {input_path.suffix}")
        return [input_path]

    iterator = input_path.rglob("*") if recursive else input_path.glob("*")

    files = sorted(
        p.resolve()
        for p in iterator
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS
    )

    if not files:
        raise RuntimeError(f"No supported images found in: {input_path}")

    return files


def load_model(
    checkpoint_path: Path,
    device: torch.device,
) -> tuple[
    MultiHeadGeoMapNet,
    dict,
]:
    checkpoint_path = checkpoint_path.resolve()

    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    checkpoint = torch.load(
        checkpoint_path,
        map_location=device,
        weights_only=False,
    )

    base_channels = int(
        checkpoint.get(
            "base_channels",
            16,
        )
    )

    head_names = tuple(
        checkpoint.get(
            "head_names",
            list(HEAD_NAMES),
        )
    )

    model = build_line_model(
        architecture=checkpoint.get("architecture", "multihead"),
        base_channels=base_channels,
        head_names=head_names,
    ).to(device)

    model.load_state_dict(checkpoint["model_state_dict"])

    model.eval()

    return model, checkpoint


def generate_positions(
    length: int,
    tile_size: int,
    step: int,
) -> list[int]:
    if length <= tile_size:
        return [0]

    positions = list(
        range(
            0,
            max(
                length - tile_size + 1,
                1,
            ),
            step,
        )
    )

    last = length - tile_size

    if positions[-1] != last:
        positions.append(last)

    return positions


def pad_tile(
    tile: np.ndarray,
    tile_size: int,
) -> tuple[
    np.ndarray,
    int,
    int,
]:
    h, w = tile.shape[:2]

    if h == tile_size and w == tile_size:
        return tile, h, w

    padded = cv2.copyMakeBorder(
        tile,
        0,
        tile_size - h,
        0,
        tile_size - w,
        borderType=cv2.BORDER_REFLECT_101,
    )

    return padded, h, w


def tile_to_tensor(
    tile_bgr: np.ndarray,
    device: torch.device,
) -> torch.Tensor:
    rgb = cv2.cvtColor(
        tile_bgr,
        cv2.COLOR_BGR2RGB,
    )

    array = rgb.astype(np.float32) / 255.0

    tensor = torch.from_numpy(array.transpose(2, 0, 1)).unsqueeze(0)

    return tensor.to(device)


@torch.no_grad()
def predict_tiled(
    model: MultiHeadGeoMapNet,
    image_bgr: np.ndarray,
    device: torch.device,
    tile_size: int,
    overlap: int,
) -> tuple[
    dict[str, np.ndarray],
    int,
]:
    if overlap < 0:
        raise ValueError("overlap cannot be negative")

    if overlap >= tile_size:
        raise ValueError("overlap must be smaller than tile_size")

    h, w = image_bgr.shape[:2]

    step = tile_size - overlap

    ys = generate_positions(
        h,
        tile_size,
        step,
    )

    xs = generate_positions(
        w,
        tile_size,
        step,
    )

    probability_sums = {
        head: np.zeros(
            (h, w),
            dtype=np.float32,
        )
        for head in model.head_names
    }

    weight_sum = np.zeros(
        (h, w),
        dtype=np.float32,
    )

    total_tiles = len(ys) * len(xs)
    tile_index = 0

    for y in ys:
        for x in xs:
            tile_index += 1

            y2 = min(
                y + tile_size,
                h,
            )

            x2 = min(
                x + tile_size,
                w,
            )

            tile = image_bgr[
                y:y2,
                x:x2,
            ]

            padded, valid_h, valid_w = pad_tile(
                tile,
                tile_size,
            )

            tensor = tile_to_tensor(
                padded,
                device,
            )

            outputs = model(tensor)

            for head, logits in outputs.items():
                probabilities = (
                    torch.sigmoid(logits).squeeze(0).squeeze(0).detach().cpu().numpy()
                )

                probability_sums[head][
                    y : y + valid_h,
                    x : x + valid_w,
                ] += probabilities[
                    :valid_h,
                    :valid_w,
                ]

            weight_sum[
                y : y + valid_h,
                x : x + valid_w,
            ] += 1.0

            if tile_index == total_tiles or tile_index % 10 == 0:
                print(f"Tiles: {tile_index}/{total_tiles}")

    safe_weights = np.maximum(
        weight_sum,
        1.0,
    )

    probabilities = {
        head: values / safe_weights for head, values in probability_sums.items()
    }

    return probabilities, total_tiles


def save_probability_map(
    path: Path,
    probability: np.ndarray,
) -> None:
    image = np.clip(
        probability * 255.0,
        0,
        255,
    ).astype(np.uint8)

    if not cv2.imwrite(
        str(path),
        image,
    ):
        raise RuntimeError(f"Could not save: {path}")


def save_binary_mask(
    path: Path,
    probability: np.ndarray,
    threshold: float,
) -> np.ndarray:
    mask = (probability >= threshold).astype(np.uint8) * 255

    if not cv2.imwrite(
        str(path),
        mask,
    ):
        raise RuntimeError(f"Could not save: {path}")

    return mask


def create_overlay(
    original_bgr: np.ndarray,
    binary_masks: dict[str, np.ndarray],
    alpha: float = 0.55,
) -> np.ndarray:
    color_layer = original_bgr.copy()

    for head in HEAD_NAMES:
        if head not in binary_masks:
            continue

        mask = binary_masks[head] > 0

        color_layer[mask] = HEAD_COLORS_BGR[head]

    return cv2.addWeighted(
        original_bgr,
        alpha,
        color_layer,
        1.0 - alpha,
        0.0,
    )


def process_image(
    image_path: Path,
    model: MultiHeadGeoMapNet,
    checkpoint: dict,
    device: torch.device,
    output_root: Path,
    overlap: int,
    threshold: float,
) -> None:
    image_bgr = cv2.imread(
        str(image_path),
        cv2.IMREAD_COLOR,
    )

    if image_bgr is None:
        raise RuntimeError(f"Could not read image: {image_path}")

    tile_size = int(
        checkpoint.get(
            "crop_size",
            256,
        )
    )

    output_dir = output_root / image_path.stem

    probabilities_dir = output_dir / "probabilities"

    masks_dir = output_dir / "masks"

    probabilities_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    masks_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    print()
    print("=" * 72)
    print("Processing:", image_path.name)
    print("Shape:", image_bgr.shape)
    print("Tile size:", tile_size)
    print("Overlap:", overlap)
    print("Threshold:", threshold)
    print("Output:", output_dir)
    print("=" * 72)

    start = time.perf_counter()

    probabilities, tile_count = predict_tiled(
        model=model,
        image_bgr=image_bgr,
        device=device,
        tile_size=tile_size,
        overlap=overlap,
    )

    binary_masks: dict[
        str,
        np.ndarray,
    ] = {}

    statistics = {}

    total_pixels = image_bgr.shape[0] * image_bgr.shape[1]

    for head, probability in probabilities.items():
        probability_path = probabilities_dir / f"{head}_probability.png"

        mask_path = masks_dir / f"{head}_mask.png"

        save_probability_map(
            probability_path,
            probability,
        )

        mask = save_binary_mask(
            mask_path,
            probability,
            threshold,
        )

        binary_masks[head] = mask

        foreground_pixels = int(np.count_nonzero(mask))

        statistics[head] = {
            "mean_probability": float(probability.mean()),
            "maximum_probability": float(probability.max()),
            "foreground_pixels": foreground_pixels,
            "foreground_fraction": float(
                foreground_pixels
                / max(
                    total_pixels,
                    1,
                )
            ),
        }

    overlay = create_overlay(
        image_bgr,
        binary_masks,
    )

    overlay_path = output_dir / "combined_overlay.png"

    if not cv2.imwrite(
        str(overlay_path),
        overlay,
    ):
        raise RuntimeError(f"Could not save overlay: {overlay_path}")

    elapsed = time.perf_counter() - start

    report = {
        "schema_version": "1.0.0",
        "image": str(image_path),
        "checkpoint_epoch": checkpoint.get("epoch"),
        "checkpoint_validation_mean_head_iou": checkpoint.get(
            "validation_mean_head_iou"
        ),
        "base_channels": checkpoint.get("base_channels"),
        "tile_size": tile_size,
        "overlap": overlap,
        "threshold": threshold,
        "tile_count": tile_count,
        "elapsed_seconds": elapsed,
        "statistics": statistics,
        "overlay": str(overlay_path),
    }

    report_path = output_dir / "run_report.json"

    report_path.write_text(
        json.dumps(
            report,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(f"Completed in {elapsed:.1f}s")

    for head in HEAD_NAMES:
        if head not in statistics:
            continue

        print(
            f"{head:12s} "
            f"fraction="
            f"{statistics[head]['foreground_fraction']:.3%} "
            f"mean_p="
            f"{statistics[head]['mean_probability']:.3f}"
        )

    print("Overlay:", overlay_path)
    print("Report:", report_path)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run tiled inference with the Supervisor150 "
            "multi-head geological map model."
        )
    )

    parser.add_argument(
        "--input",
        required=True,
        type=Path,
        help=("Path to one image or a folder of images."),
    )

    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=DEFAULT_CHECKPOINT,
    )

    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT_ROOT,
    )

    parser.add_argument(
        "--device",
        choices=[
            "auto",
            "cpu",
            "cuda",
        ],
        default="auto",
    )

    parser.add_argument(
        "--overlap",
        type=int,
        default=64,
    )

    parser.add_argument(
        "--threshold",
        type=float,
        default=0.5,
    )

    parser.add_argument(
        "--recursive",
        action="store_true",
    )

    return parser


def main() -> None:
    args = build_parser().parse_args()

    if not (0.0 < args.threshold < 1.0):
        raise ValueError("threshold must be between 0 and 1")

    device = choose_device(args.device)

    checkpoint_path = args.checkpoint.resolve()

    output_root = args.output.resolve()

    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    images = collect_inputs(
        args.input,
        args.recursive,
    )

    print(
        "Device:",
        device,
    )

    print(
        "Checkpoint:",
        checkpoint_path,
    )

    model, checkpoint = load_model(
        checkpoint_path,
        device,
    )

    print(
        "Checkpoint epoch:",
        checkpoint.get(
            "epoch",
            "unknown",
        ),
    )

    print(
        "Checkpoint mean head IoU:",
        checkpoint.get(
            "validation_mean_head_iou",
            "unknown",
        ),
    )

    print(
        "Base channels:",
        checkpoint.get(
            "base_channels",
            "unknown",
        ),
    )

    print(
        "Training crop size:",
        checkpoint.get(
            "crop_size",
            "unknown",
        ),
    )

    print(
        "Images found:",
        len(images),
    )

    for index, image_path in enumerate(
        images,
        start=1,
    ):
        print()
        print(f"[{index}/{len(images)}] " f"{image_path.name}")

        process_image(
            image_path=image_path,
            model=model,
            checkpoint=checkpoint,
            device=device,
            output_root=output_root,
            overlap=args.overlap,
            threshold=args.threshold,
        )


if __name__ == "__main__":
    main()
