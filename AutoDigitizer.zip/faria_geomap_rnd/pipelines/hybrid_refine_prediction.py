﻿import json
from pathlib import Path

import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.morphology import skeletonize, thin

from faria_geomap_rnd.pipelines.ood_sanity_guard import (
    annotate_run_report,
    check_out_of_distribution,
)

BASE_DIR = Path(__file__).resolve().parents[1]

INPUT_MAP_PATH = BASE_DIR / "data" / "validation" / "map004.jpg"

PREDICTION_DIR = BASE_DIR / "outputs" / "predictions"

PREDICTED_CLASSES_PATH = PREDICTION_DIR / "map004_predicted_classes.npy"

CONFIDENCE_PATH = PREDICTION_DIR / "map004_confidence.png"

OUTPUT_DIR = BASE_DIR / "outputs" / "hybrid_refined"

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

REFINED_CLASSES_PATH = OUTPUT_DIR / "map004_refined_classes.npy"

CONTACTS_ONLY_PATH = OUTPUT_DIR / "map004_refined_contacts.png"

VEINS_ONLY_PATH = OUTPUT_DIR / "map004_refined_veins.png"

CLUTTER_ONLY_PATH = OUTPUT_DIR / "map004_refined_clutter.png"

COMBINED_FEATURES_PATH = OUTPUT_DIR / "map004_refined_features.png"

OVERLAY_PATH = OUTPUT_DIR / "map004_refined_overlay.png"

PREVIEW_PATH = OUTPUT_DIR / "map004_refined_preview.png"

UNCERTAIN_PATH = OUTPUT_DIR / "map004_uncertain_regions.png"

RUN_REPORT_PATH = OUTPUT_DIR / "run_report.json"


BACKGROUND_CLASS = 0
CONTACT_CLASS = 1
VEIN_CLASS = 2
CLUTTER_CLASS = 3


MIN_CONTACT_COMPONENT_AREA = 12
MIN_VEIN_COMPONENT_AREA = 8
MIN_CLUTTER_COMPONENT_AREA = 20

MAX_CONTACT_GAP = 1
MAX_VEIN_GAP = 2

CONTACT_CLOSE_ITERATIONS = 1

CONTACT_MIN_SKELETON_LENGTH = 12
VEIN_MIN_SKELETON_LENGTH = 8

MAX_VEIN_THICKNESS = 6.0

MIN_VEIN_ELONGATION = 2.2
MIN_VEIN_ASPECT_RATIO = 2.0

CONTACT_CLUTTER_EXCLUSION_RADIUS = 0
VEIN_CONTACT_EXCLUSION_RADIUS = 1

CONFIDENCE_THRESHOLD = 0.60

OOD_STRONG_CONFIDENCE_THRESHOLD = 0.75
OOD_WEAK_CONFIDENCE_THRESHOLD = 0.50

OVERLAY_ALPHA = 0.70


def load_data() -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray | None,
]:
    original_bgr = cv2.imread(
        str(INPUT_MAP_PATH),
        cv2.IMREAD_COLOR,
    )

    if original_bgr is None:
        raise FileNotFoundError(f"Could not load original map: {INPUT_MAP_PATH}")

    if not PREDICTED_CLASSES_PATH.exists():
        raise FileNotFoundError(f"Could not find prediction: {PREDICTED_CLASSES_PATH}")

    predicted_classes = np.load(PREDICTED_CLASSES_PATH).astype(np.uint8)

    if predicted_classes.shape != original_bgr.shape[:2]:
        raise RuntimeError("Prediction dimensions do not match the original map.")

    confidence = None

    if CONFIDENCE_PATH.exists():
        confidence_image = cv2.imread(
            str(CONFIDENCE_PATH),
            cv2.IMREAD_GRAYSCALE,
        )

        if (
            confidence_image is not None
            and confidence_image.shape == predicted_classes.shape
        ):
            confidence = confidence_image.astype(np.float32) / 255.0

    return (
        original_bgr,
        predicted_classes,
        confidence,
    )


def remove_small_components(
    binary_mask: np.ndarray,
    minimum_area: int,
) -> np.ndarray:
    binary = (binary_mask > 0).astype(np.uint8)

    component_count, component_labels, stats, _ = cv2.connectedComponentsWithStats(
        binary,
        connectivity=8,
    )

    result = np.zeros_like(
        binary,
        dtype=np.uint8,
    )

    for component_id in range(
        1,
        component_count,
    ):
        area = int(
            stats[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        if area >= minimum_area:
            result[component_labels == component_id] = 255

    return result


def remove_short_skeleton_components(
    binary_mask: np.ndarray,
    minimum_length: int,
) -> np.ndarray:
    skeleton = skeletonize(binary_mask > 0)

    component_labels, component_count = ndi.label(
        skeleton,
        structure=np.ones(
            (3, 3),
            dtype=np.uint8,
        ),
    )

    result = np.zeros_like(
        binary_mask,
        dtype=np.uint8,
    )

    for component_id in range(
        1,
        component_count + 1,
    ):
        region = component_labels == component_id

        length = int(region.sum())

        if length >= minimum_length:
            result[region] = 255

    return result


def directional_gap_closing(
    binary_mask: np.ndarray,
    maximum_gap: int,
) -> np.ndarray:
    result = (binary_mask > 0).astype(np.uint8) * 255

    kernel_size = maximum_gap * 2 + 1

    kernels = [
        cv2.getStructuringElement(
            cv2.MORPH_RECT,
            (
                kernel_size,
                1,
            ),
        ),
        cv2.getStructuringElement(
            cv2.MORPH_RECT,
            (
                1,
                kernel_size,
            ),
        ),
        np.eye(
            kernel_size,
            dtype=np.uint8,
        ),
        np.fliplr(
            np.eye(
                kernel_size,
                dtype=np.uint8,
            )
        ).copy(),
    ]

    for kernel in kernels:
        closed = cv2.morphologyEx(
            result,
            cv2.MORPH_CLOSE,
            kernel,
            iterations=1,
        )

        result = np.maximum(
            result,
            closed,
        )

    return result


def recover_contact_junctions(
    original_bgr: np.ndarray,
    contacts: np.ndarray,
    original_contact_prediction: np.ndarray,
) -> np.ndarray:
    gray = cv2.cvtColor(
        original_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    blurred = cv2.GaussianBlur(
        gray,
        (3, 3),
        sigmaX=0.5,
    )

    image_edges = cv2.Canny(
        blurred,
        30,
        100,
    )

    original_contact_neighborhood = cv2.dilate(
        original_contact_prediction,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (5, 5),
        ),
        iterations=1,
    )

    existing_contact_neighborhood = cv2.dilate(
        contacts,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (3, 3),
        ),
        iterations=1,
    )

    candidate_recovery = (
        (image_edges > 0)
        & (original_contact_neighborhood > 0)
        & (existing_contact_neighborhood > 0)
    )

    candidate_recovery = candidate_recovery.astype(np.uint8) * 255

    candidate_recovery = remove_small_components(
        candidate_recovery,
        minimum_area=12,
    )

    candidate_recovery = thin(candidate_recovery > 0).astype(np.uint8) * 255

    recovered = cv2.bitwise_or(
        contacts,
        candidate_recovery,
    )

    cross_kernel = np.array(
        [
            [0, 1, 0],
            [1, 1, 1],
            [0, 1, 0],
        ],
        dtype=np.uint8,
    )

    recovered = cv2.morphologyEx(
        recovered,
        cv2.MORPH_CLOSE,
        cross_kernel,
        iterations=1,
    )

    recovered = thin(recovered > 0).astype(np.uint8) * 255

    return recovered


def refine_contacts(
    original_bgr: np.ndarray,
    contact_prediction: np.ndarray,
    clutter_prediction: np.ndarray,
) -> np.ndarray:
    original_contacts = (contact_prediction > 0).astype(np.uint8) * 255

    contacts = original_contacts.copy()

    clutter_binary = (clutter_prediction > 0).astype(np.uint8) * 255

    clutter_buffer = cv2.dilate(
        clutter_binary,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (
                CONTACT_CLUTTER_EXCLUSION_RADIUS * 2 + 1,
                CONTACT_CLUTTER_EXCLUSION_RADIUS * 2 + 1,
            ),
        ),
        iterations=1,
    )

    contact_density = cv2.boxFilter(
        (original_contacts > 0).astype(np.uint8),
        ddepth=cv2.CV_32F,
        ksize=(
            9,
            9,
        ),
        normalize=False,
        borderType=cv2.BORDER_REPLICATE,
    )

    likely_junction = contact_density >= 4

    original_contact_buffer = (
        cv2.dilate(
            original_contacts,
            cv2.getStructuringElement(
                cv2.MORPH_ELLIPSE,
                (
                    5,
                    5,
                ),
            ),
            iterations=1,
        )
        > 0
    )

    removable_overlap = (
        (clutter_buffer > 0) & (~likely_junction) & (~original_contact_buffer)
    )

    # Retained for clutter-aware refinement experiments.
    _ = removable_overlap

    contacts = remove_small_components(
        contacts,
        minimum_area=MIN_CONTACT_COMPONENT_AREA,
    )

    contacts = remove_short_skeleton_components(
        contacts,
        minimum_length=CONTACT_MIN_SKELETON_LENGTH,
    )

    contacts = directional_gap_closing(
        contacts,
        maximum_gap=2,
    )

    contacts = thin(contacts > 0).astype(np.uint8) * 255

    return contacts


def refine_veins(
    vein_prediction: np.ndarray,
    contacts: np.ndarray,
) -> np.ndarray:
    veins = (vein_prediction > 0).astype(np.uint8) * 255

    contact_buffer = cv2.dilate(
        contacts,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (
                VEIN_CONTACT_EXCLUSION_RADIUS * 2 + 1,
                VEIN_CONTACT_EXCLUSION_RADIUS * 2 + 1,
            ),
        ),
        iterations=1,
    )

    veins[contact_buffer > 0] = 0

    veins = remove_small_components(
        veins,
        minimum_area=MIN_VEIN_COMPONENT_AREA,
    )

    veins = directional_gap_closing(
        veins,
        maximum_gap=MAX_VEIN_GAP,
    )

    component_count, component_labels, stats, _ = cv2.connectedComponentsWithStats(
        (veins > 0).astype(np.uint8),
        connectivity=8,
    )

    retained = np.zeros_like(
        veins,
        dtype=bool,
    )

    for component_id in range(
        1,
        component_count,
    ):
        region = component_labels == component_id

        area = int(
            stats[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        width = int(
            stats[
                component_id,
                cv2.CC_STAT_WIDTH,
            ]
        )

        height = int(
            stats[
                component_id,
                cv2.CC_STAT_HEIGHT,
            ]
        )

        component_skeleton = skeletonize(region)

        skeleton_length = int(component_skeleton.sum())

        if skeleton_length < VEIN_MIN_SKELETON_LENGTH:
            continue

        average_thickness = area / max(
            skeleton_length,
            1,
        )

        if average_thickness > MAX_VEIN_THICKNESS:
            continue

        ys, xs = np.where(region)

        if len(xs) < 3:
            continue

        coordinates = np.column_stack(
            [
                xs,
                ys,
            ]
        ).astype(np.float32)

        centered = coordinates - coordinates.mean(
            axis=0,
            keepdims=True,
        )

        covariance = np.cov(
            centered,
            rowvar=False,
        )

        if covariance.shape != (
            2,
            2,
        ):
            continue

        eigenvalues = np.linalg.eigvalsh(covariance)

        elongation = (float(eigenvalues[-1]) + 1e-6) / (float(eigenvalues[0]) + 1e-6)

        aspect_ratio = max(
            width / max(height, 1),
            height / max(width, 1),
        )

        if elongation >= MIN_VEIN_ELONGATION or aspect_ratio >= MIN_VEIN_ASPECT_RATIO:
            retained |= region

    veins = skeletonize(retained).astype(np.uint8) * 255

    return veins


def refine_clutter(
    clutter_prediction: np.ndarray,
    contacts: np.ndarray,
    veins: np.ndarray,
) -> np.ndarray:
    clutter = (clutter_prediction > 0).astype(np.uint8) * 255

    protected_features = np.maximum(
        contacts,
        veins,
    )

    feature_buffer = cv2.dilate(
        protected_features,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (
                3,
                3,
            ),
        ),
        iterations=1,
    )

    clutter[feature_buffer > 0] = 0

    clutter = remove_small_components(
        clutter,
        minimum_area=MIN_CLUTTER_COMPONENT_AREA,
    )

    clutter = cv2.morphologyEx(
        clutter,
        cv2.MORPH_CLOSE,
        np.ones(
            (
                3,
                3,
            ),
            dtype=np.uint8,
        ),
        iterations=1,
    )

    return clutter


def build_refined_classes(
    contacts: np.ndarray,
    veins: np.ndarray,
    clutter: np.ndarray,
) -> np.ndarray:
    refined = np.zeros(
        contacts.shape,
        dtype=np.uint8,
    )

    refined[clutter > 0] = CLUTTER_CLASS

    refined[veins > 0] = VEIN_CLASS

    refined[contacts > 0] = CONTACT_CLASS

    return refined


def create_binary_output(
    mask: np.ndarray,
) -> np.ndarray:
    output = np.full(
        (
            mask.shape[0],
            mask.shape[1],
            3,
        ),
        255,
        dtype=np.uint8,
    )

    output[mask > 0] = [
        0,
        0,
        0,
    ]

    return output


def create_preview(
    refined_classes: np.ndarray,
) -> np.ndarray:
    preview = np.zeros(
        (
            refined_classes.shape[0],
            refined_classes.shape[1],
            3,
        ),
        dtype=np.uint8,
    )

    preview[refined_classes == CONTACT_CLASS] = [
        255,
        255,
        255,
    ]

    preview[refined_classes == VEIN_CLASS] = [
        0,
        0,
        255,
    ]

    preview[refined_classes == CLUTTER_CLASS] = [
        255,
        0,
        0,
    ]

    return preview


def create_overlay(
    original_bgr: np.ndarray,
    refined_classes: np.ndarray,
) -> np.ndarray:
    overlay = original_bgr.copy()

    overlay[refined_classes == CONTACT_CLASS] = [
        0,
        255,
        255,
    ]

    overlay[refined_classes == VEIN_CLASS] = [
        0,
        0,
        255,
    ]

    overlay[refined_classes == CLUTTER_CLASS] = [
        255,
        0,
        0,
    ]

    blended = cv2.addWeighted(
        original_bgr,
        OVERLAY_ALPHA,
        overlay,
        1.0 - OVERLAY_ALPHA,
        0,
    )

    return blended


def create_uncertainty_output(
    confidence: np.ndarray | None,
    shape: tuple[int, int],
) -> np.ndarray:
    if confidence is None:
        return np.full(
            shape,
            255,
            dtype=np.uint8,
        )

    uncertain = (confidence < CONFIDENCE_THRESHOLD).astype(np.uint8) * 255

    uncertain = cv2.dilate(
        uncertain,
        np.ones(
            (
                3,
                3,
            ),
            dtype=np.uint8,
        ),
        iterations=1,
    )

    return uncertain


def save_bgr(
    path: Path,
    image: np.ndarray,
) -> None:
    success = cv2.imwrite(
        str(path),
        image,
    )

    if not success:
        raise RuntimeError(f"Could not save output: {path}")


def main() -> None:
    (
        original_bgr,
        predicted_classes,
        confidence,
    ) = load_data()

    print(
        "Original image shape:",
        original_bgr.shape,
    )

    contact_prediction = (predicted_classes == CONTACT_CLASS).astype(np.uint8) * 255

    vein_prediction = (predicted_classes == VEIN_CLASS).astype(np.uint8) * 255

    clutter_prediction = (predicted_classes == CLUTTER_CLASS).astype(np.uint8) * 255

    # ============================================================
    # Prediction sanity / OOD guard
    # ============================================================

    if confidence is not None:
        strong_mask = (
            (contact_prediction > 0) & (confidence >= OOD_STRONG_CONFIDENCE_THRESHOLD)
        ).astype(np.uint8) * 255

        weak_mask = (
            (contact_prediction > 0) & (confidence >= OOD_WEAK_CONFIDENCE_THRESHOLD)
        ).astype(np.uint8) * 255

    else:
        # Fallback when no confidence image exists.
        # We can still detect catastrophic contact overprediction,
        # although strong/weak become identical.
        strong_mask = contact_prediction.copy()
        weak_mask = contact_prediction.copy()

    ood_result = check_out_of_distribution(
        strong_mask=strong_mask,
        weak_mask=weak_mask,
    )

    print("\nPrediction sanity check:")

    print(f"Strong contact fraction: " f"{ood_result.strong_fraction:.2%}")

    print(f"Weak contact fraction: " f"{ood_result.weak_fraction:.2%}")

    if ood_result.is_suspect:
        print("\n" + "!" * 70)

        print("WARNING: CONTACT PREDICTION FAILED SANITY CHECK")

        for reason in ood_result.reasons:
            print(
                " -",
                reason,
            )

        print(
            "Refinement will continue, but this output "
            "should NOT be trusted without inspection."
        )

        print("!" * 70 + "\n")

    else:
        print("OOD sanity check: OK")

    print("Refining contacts...")

    contacts = refine_contacts(
        original_bgr,
        contact_prediction,
        clutter_prediction,
    )

    print("Refining veins...")

    veins = refine_veins(
        vein_prediction,
        contacts,
    )

    print("Refining clutter...")

    clutter = refine_clutter(
        clutter_prediction,
        contacts,
        veins,
    )

    refined_classes = build_refined_classes(
        contacts,
        veins,
        clutter,
    )

    combined_features = np.maximum(
        contacts,
        veins,
    )

    contacts_output = create_binary_output(contacts)

    veins_output = create_binary_output(veins)

    clutter_output = create_binary_output(clutter)

    combined_output = create_binary_output(combined_features)

    preview = create_preview(refined_classes)

    overlay = create_overlay(
        original_bgr,
        refined_classes,
    )

    uncertainty = create_uncertainty_output(
        confidence,
        predicted_classes.shape,
    )

    np.save(
        REFINED_CLASSES_PATH,
        refined_classes,
    )

    save_bgr(
        CONTACTS_ONLY_PATH,
        contacts_output,
    )

    save_bgr(
        VEINS_ONLY_PATH,
        veins_output,
    )

    save_bgr(
        CLUTTER_ONLY_PATH,
        clutter_output,
    )

    save_bgr(
        COMBINED_FEATURES_PATH,
        combined_output,
    )

    save_bgr(
        PREVIEW_PATH,
        preview,
    )

    save_bgr(
        OVERLAY_PATH,
        overlay,
    )

    save_bgr(
        UNCERTAIN_PATH,
        uncertainty,
    )

    unique_classes, counts = np.unique(
        refined_classes,
        return_counts=True,
    )

    class_counts = {
        str(int(class_id)): int(count)
        for class_id, count in zip(
            unique_classes,
            counts,
        )
    }

    report = {
        "schema_version": "1.0.0",
        "module": "hybrid_contact_refinement",
        "input_map": str(INPUT_MAP_PATH),
        "prediction_path": str(PREDICTED_CLASSES_PATH),
        "status": ("suspect" if ood_result.is_suspect else "ok"),
        "refined_class_counts": class_counts,
    }

    report = annotate_run_report(
        report,
        ood_result,
    )

    with open(
        RUN_REPORT_PATH,
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            report,
            file,
            indent=2,
        )

    print("\nRefined class counts:")

    for class_id, count in zip(
        unique_classes,
        counts,
    ):
        print(f"Class {class_id}: " f"{int(count)} pixels")

    print(
        "\nSaved refined classes:",
        REFINED_CLASSES_PATH,
    )

    print(
        "Saved contacts:",
        CONTACTS_ONLY_PATH,
    )

    print(
        "Saved veins:",
        VEINS_ONLY_PATH,
    )

    print(
        "Saved clutter:",
        CLUTTER_ONLY_PATH,
    )

    print(
        "Saved combined features:",
        COMBINED_FEATURES_PATH,
    )

    print(
        "Saved preview:",
        PREVIEW_PATH,
    )

    print(
        "Saved overlay:",
        OVERLAY_PATH,
    )

    print(
        "Saved uncertain regions:",
        UNCERTAIN_PATH,
    )

    print(
        "Saved run report:",
        RUN_REPORT_PATH,
    )


if __name__ == "__main__":
    main()
