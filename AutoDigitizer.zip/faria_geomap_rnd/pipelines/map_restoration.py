from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np


# ---------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------


def read_color(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return image


def save_image(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ok = cv2.imwrite(str(path), image)
    if not ok:
        raise IOError(f"Could not write image: {path}")


# ---------------------------------------------------------------------
# BASIC METRICS
# ---------------------------------------------------------------------


def robust_percentile_range(
    gray: np.ndarray,
    lo: float = 2.0,
    hi: float = 98.0,
) -> tuple[float, float]:
    return float(np.percentile(gray, lo)), float(np.percentile(gray, hi))


def edge_density(gray: np.ndarray) -> float:
    edges = cv2.Canny(gray, 50, 150)
    return float((edges > 0).mean())


def local_contrast_score(gray: np.ndarray) -> float:
    blur = cv2.GaussianBlur(gray, (0, 0), sigmaX=5.0)
    diff = cv2.absdiff(gray, blur)
    return float(diff.mean())


def chroma_spread(image_bgr: np.ndarray) -> float:
    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB)
    a = lab[:, :, 1].astype(np.float32) - 128.0
    b = lab[:, :, 2].astype(np.float32) - 128.0
    chroma = np.sqrt(a * a + b * b)
    return float(np.percentile(chroma, 90) - np.percentile(chroma, 10))


def estimate_quality(image_bgr: np.ndarray) -> dict:
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB)

    a = lab[:, :, 1].astype(np.float32) - 128.0
    b = lab[:, :, 2].astype(np.float32) - 128.0

    p02, p98 = robust_percentile_range(gray)
    contrast_span = max(0.0, p98 - p02)

    lap = cv2.Laplacian(gray, cv2.CV_32F)
    sharpness = float(lap.var())

    mean_b = float(b.mean())
    mean_a = float(a.mean())
    mean_gray = float(gray.mean())
    std_gray = float(gray.std())
    loc_contrast = local_contrast_score(gray)
    e_density = edge_density(gray)
    c_spread = chroma_spread(image_bgr)

    yellow_cast_score = max(0.0, mean_b)

    # Important: we no longer equate global grayscale contrast with "worn".
    # Geological maps often contain broad pastel regions that naturally reduce
    # global contrast while remaining perfectly healthy.
    yellowed = yellow_cast_score > 7.0
    low_local_contrast = loc_contrast < 9.0
    soft_edges = sharpness < 900.0
    weak_chroma = c_spread < 10.0

    # "degraded" is now a composite indicator, not a single threshold.
    degraded_score = 0
    degraded_score += 1 if yellowed else 0
    degraded_score += 1 if low_local_contrast else 0
    degraded_score += 1 if soft_edges else 0
    degraded_score += 1 if weak_chroma else 0

    if c_spread >= 18.0:
        map_mode = "color"
    elif c_spread >= 7.0:
        map_mode = "limited_color_or_aged"
    else:
        map_mode = "grayscale_or_bw"

    return {
        "shape": [
            int(image_bgr.shape[0]),
            int(image_bgr.shape[1]),
            int(image_bgr.shape[2]),
        ],
        "mean_gray": mean_gray,
        "std_gray": std_gray,
        "p02_gray": p02,
        "p98_gray": p98,
        "robust_contrast_span": contrast_span,
        "laplacian_variance": sharpness,
        "local_contrast_score": loc_contrast,
        "edge_density": e_density,
        "chroma_spread": c_spread,
        "mean_lab_a_centered": mean_a,
        "mean_lab_b_centered": mean_b,
        "yellow_cast_score": yellow_cast_score,
        "map_mode": map_mode,
        "degradation_score_0_to_4": int(degraded_score),
        "flags": {
            "yellowed": bool(yellowed),
            "low_local_contrast": bool(low_local_contrast),
            "soft_edges": bool(soft_edges),
            "weak_chroma": bool(weak_chroma),
            "degraded_candidate": bool(degraded_score >= 2),
        },
    }


# ---------------------------------------------------------------------
# CORE RESTORATION VIEWS
# ---------------------------------------------------------------------


def gray_world_white_balance(
    image_bgr: np.ndarray,
    strength: float = 0.75,
) -> np.ndarray:
    """
    Conservative gray-world correction.

    strength=0 leaves the image unchanged.
    strength=1 applies the full gray-world correction.
    """
    img = image_bgr.astype(np.float32)
    means = img.reshape(-1, 3).mean(axis=0)
    global_mean = float(means.mean())

    scales = global_mean / np.maximum(means, 1e-6)
    scales = 1.0 + float(np.clip(strength, 0.0, 1.0)) * (scales - 1.0)

    balanced = img * scales.reshape(1, 1, 3)
    return np.clip(balanced, 0, 255).astype(np.uint8)


def lab_luminance_clahe(
    image_bgr: np.ndarray,
    clip_limit: float = 2.0,
    tile_grid_size: int = 8,
) -> np.ndarray:
    """
    Enhance only luminance in LAB so colour identities remain stable.
    """
    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)

    clahe = cv2.createCLAHE(
        clipLimit=float(clip_limit),
        tileGridSize=(int(tile_grid_size), int(tile_grid_size)),
    )
    l2 = clahe.apply(l)

    return cv2.cvtColor(cv2.merge([l2, a, b]), cv2.COLOR_LAB2BGR)


def grayscale_clahe(
    image_bgr: np.ndarray,
    clip_limit: float = 2.0,
    tile_grid_size: int = 8,
) -> np.ndarray:
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(
        clipLimit=float(clip_limit),
        tileGridSize=(int(tile_grid_size), int(tile_grid_size)),
    )
    return clahe.apply(gray)


def normalize_u8(image: np.ndarray) -> np.ndarray:
    arr = image.astype(np.float32)
    lo = float(np.percentile(arr, 1.0))
    hi = float(np.percentile(arr, 99.5))

    if hi <= lo + 1e-6:
        return np.zeros(arr.shape, dtype=np.uint8)

    out = (arr - lo) * (255.0 / (hi - lo))
    return np.clip(out, 0, 255).astype(np.uint8)


# ---------------------------------------------------------------------
# COLOR FEATURE ENHANCEMENT
# ---------------------------------------------------------------------


def enhance_color_separation(
    image_bgr: np.ndarray,
    chroma_gain: float = 1.22,
    max_gain: float = 1.40,
) -> np.ndarray:
    """
    Increase separation between geological unit colours without changing
    luminance geometry.

    Chroma is expanded around LAB neutral (a=b=128), not around arbitrary RGB.
    This makes similar unit fills more separable while preserving spatial
    boundaries and avoiding hue invention.
    """
    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)

    l = lab[:, :, 0]
    a = lab[:, :, 1] - 128.0
    b = lab[:, :, 2] - 128.0

    gain = float(np.clip(chroma_gain, 1.0, max_gain))
    a *= gain
    b *= gain

    out = np.stack(
        [
            l,
            np.clip(a + 128.0, 0, 255),
            np.clip(b + 128.0, 0, 255),
        ],
        axis=2,
    ).astype(np.uint8)

    return cv2.cvtColor(out, cv2.COLOR_LAB2BGR)


def color_edge_support(image_bgr: np.ndarray) -> np.ndarray:
    """
    Palette-independent colour-boundary evidence.

    Computes LAB gradients and returns a normalized single-channel response.
    Useful for geological contacts where neighbouring regions differ in colour
    even if the contact line itself is faint or absent.
    """
    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)

    responses = []
    for c in range(3):
        channel = lab[:, :, c]
        gx = cv2.Sobel(channel, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(channel, cv2.CV_32F, 0, 1, ksize=3)
        responses.append(np.sqrt(gx * gx + gy * gy))

    response = np.maximum.reduce(responses)
    response = cv2.GaussianBlur(response, (0, 0), sigmaX=0.8)
    return normalize_u8(response)


# ---------------------------------------------------------------------
# LINE / STRUCTURAL FEATURE ENHANCEMENT
# ---------------------------------------------------------------------


def multiscale_dark_line_response(
    gray: np.ndarray,
    kernel_sizes: tuple[int, ...] = (5, 9, 15, 23),
) -> np.ndarray:
    """
    Multi-scale black-hat response for faint dark linework.

    This is evidence, not semantic classification. It can respond to contacts,
    veins, faults, roads, text, symbols, borders, or other dark marks.
    """
    responses = []

    for size in kernel_sizes:
        size = int(size)
        if size < 3:
            continue
        if size % 2 == 0:
            size += 1

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (size, size))
        response = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, kernel)
        responses.append(response.astype(np.float32))

    if not responses:
        return np.zeros_like(gray)

    return normalize_u8(np.stack(responses, axis=0).max(axis=0))


def multiscale_tophat_line_response(
    gray: np.ndarray,
    kernel_sizes: tuple[int, ...] = (5, 9, 15),
) -> np.ndarray:
    """
    Light-line evidence, useful on darkened or unevenly aged paper.
    """
    responses = []

    for size in kernel_sizes:
        size = int(size)
        if size % 2 == 0:
            size += 1

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (size, size))
        response = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, kernel)
        responses.append(response.astype(np.float32))

    if not responses:
        return np.zeros_like(gray)

    return normalize_u8(np.stack(responses, axis=0).max(axis=0))


def oriented_line_response(gray: np.ndarray) -> np.ndarray:
    """
    Multi-orientation elongated black-hat detector.

    Improves long weak veins/faults/linear structures while remaining
    independent of the exact line direction.
    """
    responses = []

    lengths = (9, 17, 29)
    thickness = 3
    angles = (0, 30, 60, 90, 120, 150)

    for length in lengths:
        base = np.zeros((length, length), dtype=np.uint8)
        center = length // 2

        for angle in angles:
            kernel = base.copy()
            theta = np.deg2rad(angle)
            dx = int(round((length - 1) * 0.45 * np.cos(theta)))
            dy = int(round((length - 1) * 0.45 * np.sin(theta)))

            p1 = (center - dx, center - dy)
            p2 = (center + dx, center + dy)

            cv2.line(kernel, p1, p2, 1, thickness=thickness)
            response = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, kernel)
            responses.append(response.astype(np.float32))

    return normalize_u8(np.stack(responses, axis=0).max(axis=0))


def combine_line_evidence(
    gray: np.ndarray,
    color_edges: np.ndarray,
) -> tuple[np.ndarray, dict]:
    dark = multiscale_dark_line_response(gray)
    oriented = oriented_line_response(gray)

    # Colour edges are intentionally weakly weighted so they support contact
    # localization without turning every unit edge into a "vein".
    combined = (
        0.55 * dark.astype(np.float32)
        + 0.35 * oriented.astype(np.float32)
        + 0.10 * color_edges.astype(np.float32)
    )

    combined = normalize_u8(combined)

    return combined, {
        "dark_blackhat_weight": 0.55,
        "oriented_line_weight": 0.35,
        "color_edge_support_weight": 0.10,
    }


# ---------------------------------------------------------------------
# B/W STRUCTURAL VIEW
# ---------------------------------------------------------------------


def structural_bw_view(image_bgr: np.ndarray) -> np.ndarray:
    """
    Produce a high-detail grayscale structural representation suitable for
    faded yellow or black/white maps without hard thresholding away faint lines.
    """
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)

    # Remove slow illumination/paper variation.
    background = cv2.GaussianBlur(gray, (0, 0), sigmaX=18.0)
    flat = cv2.divide(gray, np.maximum(background, 1), scale=128)

    clahe = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8))
    flat = clahe.apply(flat)

    # Mild unsharp mask; conservative enough to avoid ringing.
    blur = cv2.GaussianBlur(flat, (0, 0), sigmaX=1.2)
    sharp = cv2.addWeighted(flat, 1.35, blur, -0.35, 0)

    return sharp


# ---------------------------------------------------------------------
# ADAPTIVE POLICY
# ---------------------------------------------------------------------


def choose_adaptive_parameters(quality: dict) -> dict:
    mode = quality["map_mode"]
    flags = quality["flags"]

    if flags["yellowed"]:
        wb_strength = 0.80
    else:
        wb_strength = 0.30

    if flags["low_local_contrast"]:
        clahe_clip = 2.4
    else:
        clahe_clip = 1.8

    if mode == "color":
        chroma_gain = 1.22
    elif mode == "limited_color_or_aged":
        chroma_gain = 1.12
    else:
        chroma_gain = 1.00

    return {
        "white_balance_strength": float(wb_strength),
        "lab_clahe_clip_limit": float(clahe_clip),
        "lab_clahe_tile_grid_size": 8,
        "chroma_gain": float(chroma_gain),
    }


# ---------------------------------------------------------------------
# COMPARISON PANEL
# ---------------------------------------------------------------------


def resize_for_panel(
    image: np.ndarray,
    width: int,
    height: int,
) -> np.ndarray:
    if image.ndim == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)

    h, w = image.shape[:2]
    scale = min(width / max(w, 1), height / max(h, 1))
    new_w = max(1, int(round(w * scale)))
    new_h = max(1, int(round(h * scale)))

    resized = cv2.resize(
        image,
        (new_w, new_h),
        interpolation=cv2.INTER_AREA,
    )

    canvas = np.full((height, width, 3), 245, dtype=np.uint8)
    x0 = (width - new_w) // 2
    y0 = (height - new_h) // 2
    canvas[y0 : y0 + new_h, x0 : x0 + new_w] = resized
    return canvas


def add_panel_label(panel: np.ndarray, text: str) -> np.ndarray:
    out = panel.copy()
    cv2.rectangle(
        out,
        (0, 0),
        (out.shape[1], 38),
        (255, 255, 255),
        -1,
    )
    cv2.putText(
        out,
        text,
        (10, 26),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.65,
        (0, 0, 0),
        1,
        cv2.LINE_AA,
    )
    return out


def make_comparison(items: list[tuple[str, np.ndarray]]) -> np.ndarray:
    panel_w = 650
    panel_h = 470
    cols = 3

    panels = []
    for title, image in items:
        panel = resize_for_panel(image, panel_w, panel_h)
        panels.append(add_panel_label(panel, title))

    while len(panels) % cols != 0:
        panels.append(np.full_like(panels[0], 245))

    rows = []
    for i in range(0, len(panels), cols):
        rows.append(np.hstack(panels[i : i + cols]))

    return np.vstack(rows)


# ---------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------


def run(input_path: Path, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 72)
    print("Adaptive geological-map multi-view enhancement")
    print("Input:", input_path)
    print("Output:", output_dir)
    print("=" * 72)

    original = read_color(input_path)
    quality = estimate_quality(original)
    params = choose_adaptive_parameters(quality)

    white_balance = gray_world_white_balance(
        original,
        strength=params["white_balance_strength"],
    )

    luminance_enhanced = lab_luminance_clahe(
        white_balance,
        clip_limit=params["lab_clahe_clip_limit"],
        tile_grid_size=params["lab_clahe_tile_grid_size"],
    )

    color_enhanced = enhance_color_separation(
        luminance_enhanced,
        chroma_gain=params["chroma_gain"],
    )

    structural_gray = structural_bw_view(white_balance)
    color_edges = color_edge_support(color_enhanced)

    line_evidence, line_params = combine_line_evidence(
        structural_gray,
        color_edges,
    )

    dark_line = multiscale_dark_line_response(structural_gray)
    oriented_line = oriented_line_response(structural_gray)

    comparison = make_comparison(
        [
            ("Original", original),
            ("White balance", white_balance),
            ("Luminance enhanced", luminance_enhanced),
            ("Colour separation enhanced", color_enhanced),
            ("Structural grayscale", structural_gray),
            ("Colour-boundary evidence", color_edges),
            ("Dark-line evidence", dark_line),
            ("Oriented-line evidence", oriented_line),
            ("Combined line evidence", line_evidence),
        ]
    )

    outputs = {
        "01_original.png": original,
        "02_white_balance.png": white_balance,
        "03_luminance_enhanced.png": luminance_enhanced,
        "04_color_separation_enhanced.png": color_enhanced,
        "05_structural_grayscale.png": structural_gray,
        "06_color_boundary_evidence.png": color_edges,
        "07_dark_line_evidence.png": dark_line,
        "08_oriented_line_evidence.png": oriented_line,
        "09_combined_line_evidence.png": line_evidence,
        "10_multiview_comparison.png": comparison,
    }

    for name, image in outputs.items():
        save_image(output_dir / name, image)

    report = {
        "input": str(input_path),
        "quality_assessment": quality,
        "adaptive_parameters": params,
        "line_evidence_parameters": line_params,
        "output_semantics": {
            "04_color_separation_enhanced.png": (
                "Colour feature view for geological unit discrimination. "
                "Not a segmentation mask."
            ),
            "05_structural_grayscale.png": (
                "Illumination-normalized structural view for aged/BW maps."
            ),
            "06_color_boundary_evidence.png": (
                "Palette-independent LAB gradient support for visible region edges."
            ),
            "07_dark_line_evidence.png": (
                "General dark line evidence. Contains non-geological linework too."
            ),
            "08_oriented_line_evidence.png": (
                "Long weak linear-feature evidence across multiple orientations."
            ),
            "09_combined_line_evidence.png": (
                "Fused structural evidence for downstream semantic models. "
                "Must not be exported directly as veins/faults/contacts."
            ),
        },
        "outputs": list(outputs.keys()),
    }

    report_path = output_dir / "restoration_report.json"
    report_path.write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("Map mode:", quality["map_mode"])
    print("Quality flags:", quality["flags"])
    print("Degradation score:", quality["degradation_score_0_to_4"])
    print("Yellow-cast score:", round(quality["yellow_cast_score"], 3))
    print("Local contrast score:", round(quality["local_contrast_score"], 3))
    print("Chroma spread:", round(quality["chroma_spread"], 3))
    print("Laplacian variance:", round(quality["laplacian_variance"], 3))
    print()
    print("Adaptive white-balance strength:", params["white_balance_strength"])
    print("Adaptive LAB CLAHE clip limit:", params["lab_clahe_clip_limit"])
    print("Adaptive chroma gain:", params["chroma_gain"])
    print()
    print("Complete")
    print("Colour feature view:", output_dir / "04_color_separation_enhanced.png")
    print("Structural view:", output_dir / "05_structural_grayscale.png")
    print("Colour-boundary evidence:", output_dir / "06_color_boundary_evidence.png")
    print("Dark-line evidence:", output_dir / "07_dark_line_evidence.png")
    print("Oriented-line evidence:", output_dir / "08_oriented_line_evidence.png")
    print("Combined line evidence:", output_dir / "09_combined_line_evidence.png")
    print("Comparison:", output_dir / "10_multiview_comparison.png")
    print("Report:", report_path)
    print("=" * 72)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate truthful multi-view enhancement channels for coloured, "
            "aged/yellowed, grayscale, or black/white geological maps."
        )
    )
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run(
        input_path=args.input,
        output_dir=args.output_dir,
    )
