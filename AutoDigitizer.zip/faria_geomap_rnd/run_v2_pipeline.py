﻿from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch

# ============================================================
# PROJECT PATH
# ============================================================
# ============================================================
# PROJECT IMPORTS
# ============================================================
from faria_geomap_rnd import config
from faria_geomap_rnd.models.model_prediction import ModelPrediction
from faria_geomap_rnd.models.se_unet import SEUNet
from faria_geomap_rnd.pipelines.graph_refinement_v2 import (
    refine_contact_network_v2,
)
from faria_geomap_rnd.pipelines.inference_core import predict_tiled_map
from faria_geomap_rnd.pipelines.ood_sanity_guard import check_out_of_distribution

# ============================================================
# SUPPORTED INPUT FORMATS
# ============================================================

SUPPORTED_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".tif",
    ".tiff",
}


# ============================================================
# CLASS DEFINITIONS
# ============================================================

BACKGROUND_CLASS = 0
CONTACT_CLASS = 1
VEIN_CLASS = 2
CLUTTER_CLASS = 3

CLASS_NAMES = {
    BACKGROUND_CLASS: "background",
    CONTACT_CLASS: "contact",
    VEIN_CLASS: "vein_or_structure",
    CLUTTER_CLASS: "clutter",
}


# RGB colours used in the prediction preview.
CLASS_COLORS_RGB = np.array(
    [
        [0, 0, 0],  # Background
        [255, 255, 255],  # Contact
        [255, 215, 0],  # Vein / structure
        [0, 110, 255],  # Clutter
    ],
    dtype=np.uint8,
)


# ============================================================
# DISPLAY SETTINGS
# ============================================================

CONTACT_DISPLAY_THICKNESS = 5
VEIN_DISPLAY_THICKNESS = 3
CLUTTER_DISPLAY_THICKNESS = 3

OVERLAY_ORIGINAL_WEIGHT = 0.58
OVERLAY_FEATURE_WEIGHT = 0.42

OOD_STRONG_CONTACT_THRESHOLD = 0.55
OOD_WEAK_CONTACT_THRESHOLD = 0.20


# ============================================================
# DEVICE SELECTION
# ============================================================


def choose_device(
    requested_device: str,
) -> torch.device:
    requested_device = requested_device.strip().lower()

    if requested_device == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")

        return torch.device("cpu")

    if requested_device == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA was requested, but no CUDA device is available.")

        return torch.device("cuda")

    if requested_device == "cpu":
        return torch.device("cpu")

    raise ValueError("Device must be one of: auto, cpu, cuda.")


# ============================================================
# INPUT COLLECTION
# ============================================================


def collect_maps(
    input_path: Path,
    recursive: bool,
) -> list[Path]:
    input_path = input_path.resolve()

    if not input_path.exists():
        raise FileNotFoundError(f"Input path does not exist: {input_path}")

    if input_path.is_file():
        extension = input_path.suffix.lower()

        if extension not in SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported map extension: {extension}")

        return [input_path]

    search_function = input_path.rglob if recursive else input_path.glob

    discovered_maps: set[Path] = set()

    for extension in SUPPORTED_EXTENSIONS:
        for map_path in search_function(f"*{extension}"):
            if map_path.is_file():
                discovered_maps.add(map_path.resolve())

        for map_path in search_function(f"*{extension.upper()}"):
            if map_path.is_file():
                discovered_maps.add(map_path.resolve())

    map_paths = sorted(discovered_maps)

    if not map_paths:
        raise RuntimeError(f"No supported maps were found in: {input_path}")

    return map_paths


# ============================================================
# MODEL LOADING
# ============================================================


def load_se_unet(
    checkpoint_path: Path,
    device: torch.device,
) -> tuple[SEUNet, dict[str, Any]]:
    checkpoint_path = checkpoint_path.resolve()

    if not checkpoint_path.exists():
        raise FileNotFoundError(f"SE-U-Net checkpoint not found: {checkpoint_path}")

    print(
        "Loading checkpoint:",
        checkpoint_path,
    )

    checkpoint = torch.load(
        checkpoint_path,
        map_location=device,
        weights_only=False,
    )

    number_of_classes = int(
        checkpoint.get(
            "num_classes",
            config.NUM_CLASSES,
        )
    )

    base_channels = int(
        checkpoint.get(
            "base_channels",
            config.BASE_CHANNELS,
        )
    )

    model = SEUNet(
        in_channels=3,
        num_classes=number_of_classes,
        base_channels=base_channels,
        use_se=True,
    ).to(device)

    if "model_state_dict" not in checkpoint:
        raise KeyError("Checkpoint does not contain 'model_state_dict'.")

    model.load_state_dict(checkpoint["model_state_dict"])

    model.eval()

    print("Model loaded successfully.")
    print("Classes:", number_of_classes)
    print("Base channels:", base_channels)

    print(
        "Checkpoint epoch:",
        checkpoint.get(
            "epoch",
            "unknown",
        ),
    )

    print(
        "Validation loss:",
        checkpoint.get(
            "validation_loss",
            checkpoint.get(
                "val_loss",
                "unknown",
            ),
        ),
    )

    return model, checkpoint


# ============================================================
# OUTPUT DIRECTORIES
# ============================================================


def create_output_directories(
    output_root: Path,
    map_name: str,
) -> dict[str, Path]:
    map_output_directory = output_root / map_name

    prediction_directory = map_output_directory / "prediction"

    report_directory = map_output_directory / "reports"

    prediction_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    report_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    return {
        "root": map_output_directory,
        "prediction": prediction_directory,
        "reports": report_directory,
    }


# ============================================================
# IMAGE SAVING HELPERS
# ============================================================


def save_image(
    path: Path,
    image: np.ndarray,
) -> None:
    success = cv2.imwrite(
        str(path),
        image,
    )

    if not success:
        raise RuntimeError(f"Could not save image: {path}")


def save_grayscale_float_map(
    path: Path,
    values: np.ndarray,
) -> None:
    image = np.clip(
        values * 255.0,
        0,
        255,
    ).astype(np.uint8)

    save_image(
        path,
        image,
    )


# ============================================================
# DISPLAY MASKS
# ============================================================


def create_display_mask(
    binary_mask: np.ndarray,
    thickness: int,
) -> np.ndarray:
    binary_mask = np.where(
        binary_mask > 0,
        255,
        0,
    ).astype(np.uint8)

    if thickness <= 1:
        return binary_mask

    if thickness % 2 == 0:
        thickness += 1

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (
            thickness,
            thickness,
        ),
    )

    return cv2.dilate(
        binary_mask,
        kernel,
        iterations=1,
    )


# ============================================================
# PREDICTION PREVIEW
# ============================================================


def create_prediction_preview(
    predicted_classes: np.ndarray,
) -> np.ndarray:
    maximum_class = int(predicted_classes.max())

    if maximum_class >= len(CLASS_COLORS_RGB):
        raise ValueError("Not enough preview colours for the predicted classes.")

    preview_rgb = CLASS_COLORS_RGB[predicted_classes]

    return cv2.cvtColor(
        preview_rgb,
        cv2.COLOR_RGB2BGR,
    )


# ============================================================
# PREDICTION OVERLAY
# ============================================================


def create_prediction_overlay(
    original_bgr: np.ndarray,
    predicted_classes: np.ndarray,
    refined_contacts: np.ndarray,
) -> np.ndarray:
    """
    Overlay colours:

    Red:
        refined contact network

    Yellow:
        predicted veins / major structures

    Blue:
        predicted clutter
    """

    colour_layer = original_bgr.copy()

    contact_display = create_display_mask(
        refined_contacts,
        thickness=CONTACT_DISPLAY_THICKNESS,
    )

    vein_mask = np.where(
        predicted_classes == VEIN_CLASS,
        255,
        0,
    ).astype(np.uint8)

    vein_display = create_display_mask(
        vein_mask,
        thickness=VEIN_DISPLAY_THICKNESS,
    )

    clutter_mask = np.where(
        predicted_classes == CLUTTER_CLASS,
        255,
        0,
    ).astype(np.uint8)

    clutter_display = create_display_mask(
        clutter_mask,
        thickness=CLUTTER_DISPLAY_THICKNESS,
    )

    # BGR colours.

    # Red contacts.
    colour_layer[contact_display > 0] = [
        0,
        0,
        255,
    ]

    # Yellow veins.
    colour_layer[vein_display > 0] = [
        0,
        215,
        255,
    ]

    # Blue clutter.
    colour_layer[clutter_display > 0] = [
        255,
        110,
        0,
    ]

    return cv2.addWeighted(
        original_bgr,
        OVERLAY_ORIGINAL_WEIGHT,
        colour_layer,
        OVERLAY_FEATURE_WEIGHT,
        0,
    )


# ============================================================
# SAVE PREDICTION OUTPUTS
# ============================================================


def save_prediction_outputs(
    original_bgr: np.ndarray,
    prediction: ModelPrediction,
    output_directories: dict[str, Path],
    save_probabilities: bool,
) -> tuple[
    dict[str, str],
    dict[str, object],
]:
    prediction_directory = output_directories["prediction"]

    classes_npy_path = prediction_directory / "predicted_classes.npy"

    classes_png_path = prediction_directory / "predicted_classes.png"

    preview_path = prediction_directory / "prediction_preview.png"

    overlay_path = prediction_directory / "prediction_overlay.png"

    refined_contacts_path = prediction_directory / "refined_contacts.png"

    confidence_path = prediction_directory / "confidence.png"

    uncertainty_path = prediction_directory / "uncertainty.png"

    probabilities_path = prediction_directory / "probabilities.npy"

    bridge_debug_path = prediction_directory / "bridge_debug.png"

    endpoints_debug_path = prediction_directory / "endpoints_debug.png"

    hysteresis_path = prediction_directory / "contact_hysteresis.png"

    junction_recovered_path = prediction_directory / "junction_recovered.png"

    # --------------------------------------------------------
    # Save raw class prediction
    # --------------------------------------------------------

    np.save(
        classes_npy_path,
        prediction.predicted_classes,
    )

    save_image(
        classes_png_path,
        prediction.predicted_classes.astype(np.uint8),
    )

    # --------------------------------------------------------
    # Create preview
    # --------------------------------------------------------

    preview_bgr = create_prediction_preview(prediction.predicted_classes)

    # --------------------------------------------------------
    # Graph-based contact refinement
    # --------------------------------------------------------

    if prediction.class_probabilities.shape[0] <= CONTACT_CLASS:
        raise RuntimeError("Contact probability class is missing from prediction.")

    contact_probability = prediction.class_probabilities[CONTACT_CLASS]

    # ============================================================
    # CONTACT PREDICTION SANITY / OOD GUARD
    # ============================================================

    strong_mask = (contact_probability >= OOD_STRONG_CONTACT_THRESHOLD).astype(
        np.uint8
    ) * 255

    weak_mask = (contact_probability >= OOD_WEAK_CONTACT_THRESHOLD).astype(
        np.uint8
    ) * 255

    ood_result = check_out_of_distribution(
        strong_mask=strong_mask,
        weak_mask=weak_mask,
    )

    print("\nContact prediction sanity check:")

    print(
        "Strong contact fraction:",
        f"{ood_result.strong_fraction:.2%}",
    )

    print(
        "Weak contact fraction:",
        f"{ood_result.weak_fraction:.2%}",
    )

    if ood_result.is_suspect:
        print("\n" + "!" * 72)

        print("WARNING: CONTACT PREDICTION FAILED SANITY CHECK")

        for reason in ood_result.reasons:
            print(
                " -",
                reason,
            )

        print(
            "Graph refinement will continue for inspection, "
            "but this prediction should NOT be trusted."
        )

        print("!" * 72 + "\n")

    else:
        print("Contact sanity check: OK")

    graph_start_time = time.perf_counter()

    graph_result = refine_contact_network_v2(
        original_bgr=original_bgr,
        contact_probability=contact_probability,
    )

    # ============================================================
    # CONTACT PROBABILITY DEBUG OUTPUTS
    # ============================================================

    debug_directory = prediction_directory / "debug"
    debug_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    # Raw probability as grayscale: 0.0 -> black, 1.0 -> white
    probability_grayscale = np.clip(
        contact_probability * 255.0,
        0,
        255,
    ).astype(np.uint8)

    cv2.imwrite(
        str(debug_directory / "01_contact_probability_grayscale.png"),
        probability_grayscale,
    )

    # Colored probability heatmap
    probability_heatmap = cv2.applyColorMap(
        probability_grayscale,
        cv2.COLORMAP_TURBO,
    )

    cv2.imwrite(
        str(debug_directory / "02_contact_probability_heatmap.png"),
        probability_heatmap,
    )

    # Strong model predictions
    cv2.imwrite(
        str(debug_directory / "03_strong_mask_055.png"),
        strong_mask,
    )

    cv2.imwrite(
        str(debug_directory / "04_weak_mask_020.png"),
        weak_mask,
    )

    # Pixels that are weak but not strong
    weak_only_mask = (
        (contact_probability >= 0.20) & (contact_probability < 0.55)
    ).astype(np.uint8) * 255

    cv2.imwrite(
        str(debug_directory / "05_weak_only_020_to_055.png"),
        weak_only_mask,
    )

    # Very weak evidence currently discarded by hysteresis
    very_weak_mask = (
        (contact_probability >= 0.05) & (contact_probability < 0.20)
    ).astype(np.uint8) * 255

    cv2.imwrite(
        str(debug_directory / "06_discarded_probability_005_to_020.png"),
        very_weak_mask,
    )

    # Heatmap overlay on original image
    heatmap_overlay = cv2.addWeighted(
        original_bgr,
        0.60,
        probability_heatmap,
        0.40,
        0.0,
    )

    cv2.imwrite(
        str(debug_directory / "07_probability_overlay.png"),
        heatmap_overlay,
    )

    graph_elapsed_seconds = time.perf_counter() - graph_start_time

    refined_contacts = np.asarray(
        graph_result["contacts"],
        dtype=np.uint8,
    )

    if refined_contacts.shape != prediction.predicted_classes.shape:
        raise RuntimeError(
            "Refined contact dimensions do not match prediction dimensions."
        )

    # --------------------------------------------------------
    # Create overlay
    # --------------------------------------------------------

    overlay_bgr = create_prediction_overlay(
        original_bgr=original_bgr,
        predicted_classes=prediction.predicted_classes,
        refined_contacts=refined_contacts,
    )

    # --------------------------------------------------------
    # Save normal outputs
    # --------------------------------------------------------

    save_image(
        refined_contacts_path,
        refined_contacts,
    )

    save_image(
        preview_path,
        preview_bgr,
    )

    save_image(
        overlay_path,
        overlay_bgr,
    )

    save_grayscale_float_map(
        confidence_path,
        prediction.confidence_map,
    )

    save_grayscale_float_map(
        uncertainty_path,
        prediction.uncertainty_map,
    )

    # --------------------------------------------------------
    # Save graph debug outputs
    # --------------------------------------------------------

    bridge_debug = np.asarray(
        graph_result["bridge_debug"],
        dtype=np.uint8,
    )

    endpoints_debug = np.asarray(
        graph_result["endpoints"],
        dtype=np.uint8,
    )

    hysteresis_mask = np.asarray(
        graph_result["hysteresis_mask"],
        dtype=np.uint8,
    )

    junction_recovered = np.asarray(
        graph_result["junction_recovered"],
        dtype=np.uint8,
    )

    save_image(
        bridge_debug_path,
        bridge_debug,
    )

    save_image(
        endpoints_debug_path,
        endpoints_debug,
    )

    save_image(
        hysteresis_path,
        hysteresis_mask,
    )

    save_image(
        junction_recovered_path,
        junction_recovered,
    )

    # --------------------------------------------------------
    # Build saved-file register
    # --------------------------------------------------------

    saved_files = {
        "predicted_classes_npy": str(classes_npy_path),
        "predicted_classes_png": str(classes_png_path),
        "prediction_preview": str(preview_path),
        "prediction_overlay": str(overlay_path),
        "refined_contacts": str(refined_contacts_path),
        "confidence": str(confidence_path),
        "uncertainty": str(uncertainty_path),
        "bridge_debug": str(bridge_debug_path),
        "endpoints_debug": str(endpoints_debug_path),
        "contact_hysteresis": str(hysteresis_path),
        "junction_recovered": str(junction_recovered_path),
    }

    if save_probabilities:
        np.save(
            probabilities_path,
            prediction.class_probabilities,
        )

        saved_files["probabilities"] = str(probabilities_path)

    refinement_statistics = {
        "candidate_count": int(
            graph_result.get(
                "candidate_count",
                0,
            )
        ),
        "accepted_bridge_count": int(
            graph_result.get(
                "accepted_bridge_count",
                0,
            )
        ),
        "graph_refinement_seconds": float(graph_elapsed_seconds),
        "refined_contact_pixels": int(np.count_nonzero(refined_contacts)),
        "final_endpoint_pixels": int(np.count_nonzero(endpoints_debug)),
        "ood_check": {
            "is_suspect": bool(ood_result.is_suspect),
            "strong_fraction": float(ood_result.strong_fraction),
            "weak_fraction": float(ood_result.weak_fraction),
            "reasons": list(ood_result.reasons),
        },
    }

    candidate_count = refinement_statistics["candidate_count"]

    accepted_bridge_count = refinement_statistics["accepted_bridge_count"]

    bridge_acceptance_ratio = accepted_bridge_count / max(candidate_count, 1)

    refinement_statistics["bridge_acceptance_ratio"] = float(bridge_acceptance_ratio)

    if candidate_count >= 50 and bridge_acceptance_ratio > 0.90:
        refinement_statistics["ood_check"]["is_suspect"] = True

        refinement_statistics["ood_check"]["reasons"].append(
            f"Graph refinement accepted "
            f"{bridge_acceptance_ratio:.1%} of "
            f"{candidate_count} bridge candidates. "
            "This unusually high acceptance rate may indicate "
            "over-connection of unrelated linework."
        )

    print(
        "Graph candidates:",
        refinement_statistics["candidate_count"],
    )

    print(
        "Accepted bridges:",
        refinement_statistics["accepted_bridge_count"],
    )

    print(
        "Bridge acceptance ratio:",
        f"{bridge_acceptance_ratio:.2%}",
    )

    print(
        "Graph refinement runtime:",
        (f"{graph_elapsed_seconds:.2f} " "seconds"),
    )

    return (
        saved_files,
        refinement_statistics,
    )


# ============================================================
# CLASS STATISTICS
# ============================================================


def calculate_class_statistics(
    predicted_classes: np.ndarray,
) -> dict[
    str,
    dict[str, float | int],
]:
    total_pixels = int(predicted_classes.size)

    statistics: dict[
        str,
        dict[str, float | int],
    ] = {}

    class_values, class_counts = np.unique(
        predicted_classes,
        return_counts=True,
    )

    for class_value, class_count in zip(
        class_values,
        class_counts,
    ):
        class_id = int(class_value)

        pixel_count = int(class_count)

        class_name = CLASS_NAMES.get(
            class_id,
            f"class_{class_id}",
        )

        statistics[class_name] = {
            "class_id": class_id,
            "pixel_count": pixel_count,
            "percentage": (
                pixel_count
                / max(
                    total_pixels,
                    1,
                )
                * 100.0
            ),
        }

    return statistics


# ============================================================
# REPORTING
# ============================================================


def save_run_report(
    map_path: Path,
    prediction: ModelPrediction,
    output_directories: dict[str, Path],
    saved_files: dict[str, str],
    refinement_statistics: dict[str, object],
    elapsed_seconds: float,
    checkpoint_path: Path,
    device: torch.device,
    tile_size: int,
    tile_overlap: int,
    confidence_alpha: float,
) -> Path:
    report_path = output_directories["reports"] / "run_report.json"

    report = {
        "schema_version": "1.1.0",
        "map_name": map_path.name,
        "source_path": str(map_path),
        "model_name": (prediction.model_name),
        "prediction_type": (prediction.prediction_type),
        "confidence_type": (prediction.confidence_type),
        "checkpoint_path": str(checkpoint_path),
        "device": str(device),
        "image_height": int(prediction.predicted_classes.shape[0]),
        "image_width": int(prediction.predicted_classes.shape[1]),
        "class_count": int(prediction.class_probabilities.shape[0]),
        "tile_size": int(tile_size),
        "tile_overlap": int(tile_overlap),
        "confidence_alpha": float(confidence_alpha),
        "contact_display_thickness": int(CONTACT_DISPLAY_THICKNESS),
        "mean_confidence": float(np.mean(prediction.confidence_map)),
        "minimum_confidence": float(np.min(prediction.confidence_map)),
        "maximum_confidence": float(np.max(prediction.confidence_map)),
        "mean_uncertainty": float(np.mean(prediction.uncertainty_map)),
        "elapsed_seconds": float(elapsed_seconds),
        "class_statistics": (calculate_class_statistics(prediction.predicted_classes)),
        "run_status": (
            "suspect" if refinement_statistics["ood_check"]["is_suspect"] else "ok"
        ),
        "ood_check": (refinement_statistics["ood_check"]),
        "graph_refinement": {
            key: value
            for key, value in refinement_statistics.items()
            if key != "ood_check"
        },
        "saved_files": saved_files,
        "prediction_metadata": (prediction.metadata),
    }

    with report_path.open(
        "w",
        encoding="utf-8",
    ) as report_file:
        json.dump(
            report,
            report_file,
            indent=2,
            default=str,
        )

    return report_path


# ============================================================
# SINGLE MAP PROCESSING
# ============================================================


def process_map(
    map_path: Path,
    model: SEUNet,
    checkpoint_path: Path,
    device: torch.device,
    output_root: Path,
    tile_size: int,
    tile_overlap: int,
    confidence_alpha: float,
    save_probabilities: bool,
    overwrite: bool,
) -> dict[str, object]:
    map_name = map_path.stem

    output_directories = create_output_directories(
        output_root=output_root,
        map_name=map_name,
    )

    existing_report_path = output_directories["reports"] / "run_report.json"

    if existing_report_path.exists() and not overwrite:
        print(
            "Skipping existing result:",
            map_name,
        )

        return {
            "map": map_name,
            "status": "skipped",
            "report": str(existing_report_path),
        }

    print()
    print("=" * 72)
    print("Processing:", map_path.name)
    print(
        "Output:",
        output_directories["root"],
    )
    print("=" * 72)

    original_bgr = cv2.imread(
        str(map_path),
        cv2.IMREAD_COLOR,
    )

    if original_bgr is None:
        raise FileNotFoundError(f"OpenCV could not read map: {map_path}")

    start_time = time.perf_counter()

    def progress_callback(
        completed: int,
        total: int,
    ) -> None:
        if completed == total or completed % 10 == 0:
            print(f"Tiles: {completed}/{total}")

    prediction = predict_tiled_map(
        model=model,
        image_bgr=original_bgr,
        model_name="se_unet",
        device=device,
        tile_size=tile_size,
        tile_overlap=tile_overlap,
        confidence_alpha=confidence_alpha,
        source_path=map_path,
        checkpoint_path=checkpoint_path,
        progress_callback=progress_callback,
    )

    prediction.validate()

    (
        saved_files,
        refinement_statistics,
    ) = save_prediction_outputs(
        original_bgr=original_bgr,
        prediction=prediction,
        output_directories=output_directories,
        save_probabilities=save_probabilities,
    )

    elapsed_seconds = time.perf_counter() - start_time

    report_path = save_run_report(
        map_path=map_path,
        prediction=prediction,
        output_directories=output_directories,
        saved_files=saved_files,
        refinement_statistics=(refinement_statistics),
        elapsed_seconds=elapsed_seconds,
        checkpoint_path=checkpoint_path,
        device=device,
        tile_size=tile_size,
        tile_overlap=tile_overlap,
        confidence_alpha=confidence_alpha,
    )

    print("Completed:", map_path.name)

    print(
        "Runtime:",
        f"{elapsed_seconds:.2f} seconds",
    )

    print(
        "Report:",
        report_path,
    )

    return {
        "map": map_name,
        "status": "completed",
        "elapsed_seconds": (elapsed_seconds),
        "report": str(report_path),
        "candidate_count": (refinement_statistics["candidate_count"]),
        "accepted_bridge_count": (refinement_statistics["accepted_bridge_count"]),
    }


# ============================================================
# COMMAND-LINE INTERFACE
# ============================================================


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run GeoMap R&D geological-map inference "
            "and graph-based contact refinement."
        )
    )

    parser.add_argument(
        "--input",
        required=True,
        type=Path,
        help=("Path to one geological map or a folder."),
    )

    parser.add_argument(
        "--output",
        type=Path,
        default=(config.OUTPUT_DIR / "v2_runs"),
        help=("Root output directory."),
    )

    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=(config.CHECKPOINT_DIR / "se_unet_v2_best.pth"),
        help=("SE-U-Net checkpoint path."),
    )

    parser.add_argument(
        "--device",
        choices=[
            "auto",
            "cpu",
            "cuda",
        ],
        default="auto",
    )

    parser.add_argument(
        "--tile-size",
        type=int,
        default=config.IMAGE_SIZE,
    )

    parser.add_argument(
        "--tile-overlap",
        type=int,
        default=config.TILE_OVERLAP,
    )

    parser.add_argument(
        "--confidence-alpha",
        type=float,
        default=0.5,
    )

    parser.add_argument(
        "--recursive",
        action="store_true",
    )

    parser.add_argument(
        "--continue-on-error",
        action="store_true",
    )

    parser.add_argument(
        "--overwrite",
        action="store_true",
    )

    parser.add_argument(
        "--save-probabilities",
        action="store_true",
        help=(
            "Save full probability arrays. " "These files may be hundreds of megabytes."
        ),
    )

    return parser


# ============================================================
# ARGUMENT VALIDATION
# ============================================================


def validate_arguments(
    arguments: argparse.Namespace,
) -> None:
    if arguments.tile_size <= 0:
        raise ValueError("tile-size must be positive.")

    if arguments.tile_overlap < 0:
        raise ValueError("tile-overlap cannot be negative.")

    if arguments.tile_overlap >= arguments.tile_size:
        raise ValueError("tile-overlap must be smaller than tile-size.")

    if not (0.0 <= arguments.confidence_alpha <= 1.0):
        raise ValueError("confidence-alpha must be between 0 and 1.")


# ============================================================
# MAIN
# ============================================================


def main() -> None:
    parser = build_parser()

    arguments = parser.parse_args()

    validate_arguments(arguments)

    device = choose_device(arguments.device)

    output_root = arguments.output.resolve()

    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    map_paths = collect_maps(
        input_path=arguments.input,
        recursive=arguments.recursive,
    )

    print("GeoMap R&D Pipeline")
    print("Device:", device)
    print("Maps found:", len(map_paths))

    model, _ = load_se_unet(
        checkpoint_path=arguments.checkpoint,
        device=device,
    )

    batch_results: list[dict[str, object]] = []

    batch_start_time = time.perf_counter()

    for map_index, map_path in enumerate(
        map_paths,
        start=1,
    ):
        print()

        print(f"[{map_index}/{len(map_paths)}] " f"{map_path.name}")

        try:
            result = process_map(
                map_path=map_path,
                model=model,
                checkpoint_path=(arguments.checkpoint.resolve()),
                device=device,
                output_root=output_root,
                tile_size=arguments.tile_size,
                tile_overlap=(arguments.tile_overlap),
                confidence_alpha=(arguments.confidence_alpha),
                save_probabilities=(arguments.save_probabilities),
                overwrite=arguments.overwrite,
            )

            batch_results.append(result)

        except Exception as error:
            failure = {
                "map": map_path.name,
                "status": "failed",
                "error": str(error),
            }

            batch_results.append(failure)

            print(
                "FAILED:",
                map_path.name,
            )

            print(
                "Reason:",
                error,
            )

            if not arguments.continue_on_error:
                raise

    batch_elapsed_seconds = time.perf_counter() - batch_start_time

    batch_report_path = output_root / "batch_report.json"

    completed_count = sum(
        result.get("status") == "completed" for result in batch_results
    )

    skipped_count = sum(result.get("status") == "skipped" for result in batch_results)

    failed_count = sum(result.get("status") == "failed" for result in batch_results)

    batch_report = {
        "schema_version": "1.1.0",
        "input": str(arguments.input.resolve()),
        "checkpoint": str(arguments.checkpoint.resolve()),
        "device": str(device),
        "map_count": len(map_paths),
        "completed_count": int(completed_count),
        "skipped_count": int(skipped_count),
        "failed_count": int(failed_count),
        "elapsed_seconds": float(batch_elapsed_seconds),
        "results": batch_results,
    }

    with batch_report_path.open(
        "w",
        encoding="utf-8",
    ) as report_file:
        json.dump(
            batch_report,
            report_file,
            indent=2,
            default=str,
        )

    print()
    print("=" * 72)
    print("Batch completed.")

    print(
        "Completed:",
        completed_count,
    )

    print(
        "Skipped:",
        skipped_count,
    )

    print(
        "Failed:",
        failed_count,
    )

    print(
        "Runtime:",
        f"{batch_elapsed_seconds:.2f} seconds",
    )

    print(
        "Batch report:",
        batch_report_path,
    )

    print("=" * 72)


if __name__ == "__main__":
    main()
