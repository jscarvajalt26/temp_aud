﻿# GeoMap R&D - Model and Algorithm Registry



## Purpose



This registry records the model families, learning approaches, and deterministic geometry components investigated during development of the GeoMap geological map digitization system.



The project is intentionally modular. The objective is not to force one neural network to solve every geological map interpretation problem.



Different model families are evaluated for the subproblems where their architectural strengths are most useful.



The final production architecture is not yet frozen.



Current research is intended to identify approximately four to five complementary components that together provide the strongest combination of:



* geological unit recognition
* local boundary accuracy
* global map understanding
* overlapping feature separation
* uncertain-region refinement
* topology preservation
* GIS-ready vector reconstruction



## 1. Architecture Philosophy



Geological map digitization contains several distinct problems:



1. Recognizing geological regions
2. Detecting geological contacts
3. Distinguishing faults from contacts
4. Separating roads, rivers, lakes, and symbols
5. Understanding large-scale geological context
6. Resolving uncertain or occluded regions
7. Preserving region adjacency and intersections
8. Reconstructing exact editable GIS geometry



These tasks do not necessarily have the same optimal model.



The R&D architecture therefore combines learned perception with deterministic geometry and topology reconstruction.



Conceptually:



Input geological map -> learned geological evidence -> evidence fusion and region reconstruction -> deterministic topology reconstruction -> vectorization and GIS output.



Learned geological evidence may come from complementary components for:



* local segmentation
* global context
* multi-head semantic segmentation
* region and affinity reasoning
* optional local refinement



## 2. Model Status Definitions



**Implemented:** Source code or integration exists within the GeoMap R&D project and the approach has been executed during development.



**Evaluated:** The model or approach has been experimentally investigated and its behavior has contributed to an engineering decision.



**Candidate:** The architecture remains under consideration for a particular role but has not been selected for the final system.



**Support / Refinement:** The model is useful for a restricted subproblem but is not intended to be the primary geological interpretation model.



**Rejected for Primary Role:** Experimental evidence showed that the approach should not perform the originally considered primary role. It may still remain useful for another restricted role.



## 3. U-Net Family



### U-Net



**Family:** Convolutional encoder-decoder segmentation



**Research role:** Baseline semantic segmentation architecture.



**Why considered:**



* strong local spatial modeling
* established segmentation baseline
* relatively simple training behavior
* useful reference point for evaluating more advanced architectures



**Potential geological role:**



* geological contact segmentation
* geological unit segmentation
* local feature extraction



**Status:** Baseline / candidate family



U-Net provides a reference architecture against which attention-based, transformer, state-space, and hybrid approaches can be compared.



## 4. SE-UNet



### Squeeze-and-Excitation U-Net



**Family:** CNN segmentation with channel attention



**Implemented:** Yes



**Research role:** Improved local geological segmentation and contact detection.



Squeeze-and-Excitation blocks allow the network to adaptively emphasize useful feature channels while suppressing less useful responses.



This is relevant to geological maps where unit colors, linework, texture, and cartographic clutter compete within the same image.



SE-UNet became one of the stronger early learned segmentation approaches investigated in the project.



**Potential final role:** Local/detail geological segmentation component.



**Status:** Implemented / active candidate



SE-UNet is not assumed to be the final segmentation model. It remains part of the comparative model pool.



## 5. TransUNet / 3D-TransUNet



### TransUNet Family



**Family:** CNN and Transformer segmentation



**Research role:** Combine convolutional local detail with transformer-based long-range context.



Geological boundaries and units may depend on structures extending far beyond a local image patch.



Transformer components may therefore help model:



* long geological units
* regional structural relationships
* discontinuous visual evidence
* long-range spatial context



Research included investigation of TransUNet-style architectures and 3D-TransUNet-related implementations.



**Potential final role:** Hybrid local/global segmentation component.



**Status:** Research candidate



Third-party research implementations are not treated as original GeoMap source code and should not be vendored into the company repository without appropriate licensing and approval.



## 6. SegFormer



### SegFormer / MiT-Style Global Context



**Family:** Transformer semantic segmentation



**Research role:** Efficient global-context geological feature extraction.



SegFormer-style hierarchical transformer encoders provide multi-scale features while modeling longer-range relationships than conventional local convolution alone.



Potential advantages include:



* map-wide geological context
* robustness to variable geological region size
* hierarchical feature extraction
* reduced dependence on purely local texture



The project also investigates custom transformer/global-context components inspired by this architectural family rather than relying exclusively on an external implementation.



**Potential final role:** Global-context branch complementary to local segmentation models.



**Status:** Implemented concept / active candidate family



## 7. HybridGeoMapNet



### Hybrid CNN and Global-Context Network



**Family:** Hybrid learned architecture



**Implemented:** Yes



**Research role:** Combine complementary local and global representations within the GeoMap system.



The architecture reflects the design hypothesis that geological map interpretation benefits from both:



* detailed local boundary information
* larger-scale geological context



**Potential final role:** Integrated geological evidence extractor.



**Status:** Implemented / evolving



HybridGeoMapNet remains subject to comparative evaluation against other candidate model combinations.



## 8. Multi-Head Geological Segmentation



### MultiHeadGeoMapNet



**Family:** Shared encoder with multiple binary prediction heads



**Implemented:** Yes



Current semantic heads include:



* contact
* fault
* road
* river
* lake
* strike/dip
* clutter



**Research motivation:** Geological maps contain overlapping semantic layers.



A road may cross a geological contact, a fault may pass through several geological units, and symbols may appear over otherwise valid geological regions. Representing all features as one mutually exclusive class can destroy this overlap information.



Independent prediction heads allow multiple semantic features to occupy the same spatial location.



Training research has included:



* feature-aware sampling
* map-level train/validation splitting
* hard-negative sampling
* layout/background negative supervision
* warm-start training experiments



Early full-map inference showed false detections in page-layout and non-geological areas. Hard-negative training was therefore introduced to improve suppression of these regions.



Experiments also demonstrated that excessive hard-negative emphasis can reduce geological recall, motivating a balanced sampling strategy.



**Potential final role:** Semantic geological/cartographic layer separation.



**Status:** Implemented / active research component



## 9. Mask2Former



**Family:** Transformer-based universal image segmentation



**Research role:** Instance and layer-oriented segmentation.



Some geological and cartographic structures may be better represented as distinct masks or objects rather than only per-pixel semantic probabilities.



Potential uses include:



* separating overlapping geological bodies
* distinguishing individual map objects
* handling complex semantic layers
* instance-aware reconstruction



**Potential final role:** Instance/layer separation component.



**Status:** Candidate / comparative research



Mask2Former has not been declared part of the final architecture.



## 10. Mamba / State-Space Models



### Mamba-Based Geological Modeling



**Family:** State-space sequence/vision architecture



**Research role:** Efficient long-range spatial reasoning.



Geological structures can extend across large portions of a map. State-space architectures provide another mechanism for modeling long-range relationships without relying exclusively on convolution or conventional self-attention.



Potential advantages include:



* long-range dependency modeling
* efficient large-context processing
* complementary behavior to CNN and transformer models



**Potential final role:** Global geological context and long-range structural reasoning.



**Status:** Active research candidate



Mamba remains under development and evaluation. It has not yet been selected as a final production component.



## 11. SAM2 / MapSAM2 Research



### Segment Anything Model 2



**Family:** Foundation segmentation model



**Evaluated:** Yes



**Research role:** Prompted local geological-region refinement.



SAM2 was experimentally evaluated on candidate geological bodies generated from reconstructed map regions.



### Successful Behavior



Several compact geological regions produced strong segmentation agreement.



Representative map_0103 validation results included:



* candidate 12: IoU approximately 0.970, area ratio approximately 1.022
* candidate 13: IoU approximately 0.989, area ratio approximately 1.009
* candidate 21: IoU approximately 0.888, area ratio approximately 1.123



These experiments demonstrated that SAM2 can provide useful refinement when the candidate geological body is well constrained.



### Failure Behavior



Other regions produced severe leakage.



Representative rejected examples included:



* candidate 26: IoU approximately 0.318, area ratio approximately 3.15
* candidate 27: IoU approximately 0.340, area ratio approximately 2.85



These masks expanded far beyond their intended geological candidate regions.



### Engineering Decision



SAM2 should not serve as the primary geological contact generator.



Instead, SAM2 / MapSAM2 is retained as a possible local refinement or rescue mechanism where another model or reconstruction stage has already identified an uncertain region.



**Potential final role:** Local uncertain-region refinement.



**Status:** Evaluated / support component



**Primary geological boundary role:** Rejected



## 12. Color-Region Reconstruction



### Adaptive Geological Color-Region Extraction



**Family:** Classical / unsupervised region reconstruction



**Implemented:** Yes



**Research role:** Recover geological regions before deriving geological boundaries.



The method uses components including:



* LAB color representation
* adaptive KMeans clustering
* connected-region processing
* small-component cleanup
* internal-hole reconstruction
* geological support masks
* shared-boundary extraction



### Engineering Result



On clean colored geological maps such as map_0103, region-first reconstruction produced substantially stronger geological geometry than treating a learned boundary probability raster as the final boundary representation.



This produced an important design principle:



**Reconstruct geological regions first, then derive geological boundaries from relationships between those regions.**



### Limitation



Color clustering alone cannot be assumed to generalize across every historical, scanned, faded, grayscale, black-and-white, or stylistically different geological map.



For that reason, this component is not considered a complete universal solution by itself.



**Potential final role:** High-confidence geological region proposal and reconstruction on suitable maps.



**Status:** Implemented / important current component



## 13. GeoRegion Affinity Learning



### GeoRegionAffinityNet



**Family:** Learned local region-relationship model



**Implemented:** Yes



The model predicts:



* horizontal same/different-region affinity
* vertical same/different-region affinity
* geological boundary probability



### Research Motivation



Direct geological palette classification can fail when different maps use different colors for equivalent geological concepts.



Affinity learning asks a more transferable question:



**Do neighboring pixels belong to the same geological region?**



This reduces dependence on a fixed geological color palette.



### Training Design



Affinity targets are generated from geological unit-label maps.



Map-level train/validation splitting is used to prevent leakage between tiles originating from the same source map.



Training research has also included:



* color inputs
* aged-map inputs
* grayscale inputs
* black-and-white inputs
* palette randomization
* boundary-focused crops
* random crops
* geological-interior crops



### Experimental Result



A six-epoch training experiment produced its strongest validation score at epoch 6.



Representative epoch-6 results were approximately:



* boundary IoU: 0.320
* horizontal affinity IoU: 0.307
* vertical affinity IoU: 0.311
* combined validation score: 0.316



The experiment demonstrated that palette-independent local geological relationship evidence can be learned.



However, direct thresholding of the learned probability rasters did not produce geometry as strong as the color-region reconstruction on the clean map_0103 example.



### Engineering Decision



Affinity predictions should be treated as evidence for geological region reconstruction rather than directly as final GIS geometry.



Future affinity-to-region reconstruction may investigate:



* graph reconstruction
* connected-region reasoning
* watershed-style reconstruction
* union-find region assembly



**Potential final role:** Palette-independent geological region evidence.



**Status:** Implemented / active research component



## 14. Direct Raster Topology Repair Experiment



### Skeleton / Endpoint / Gap Repair



**Family:** Deterministic raster topology refinement



**Evaluated:** Yes



An experimental topology repair pipeline attempted to transform boundary masks using:



* skeletonization
* endpoint detection
* boundary snapping
* gap connection
* junction reconstruction



One representative experiment produced:



* 4,310 coarse boundary pixels
* 5,006 snapped boundary pixels
* 52 endpoints before repair
* 7 accepted gap connections
* 5,027 final boundary pixels
* 43 final endpoints



### Failure Analysis



Visual inspection revealed significant problems including:



* false geological shapes
* duplicated or parallel edges
* incorrect geometry
* excessive expansion
* unstable intersections and junctions



### Engineering Decision



Blindly repairing predicted raster boundaries is not sufficient for reliable geological topology.



The experiment is preserved as negative engineering evidence because it motivated the transition toward region-based topology reconstruction.



**Status:** Evaluated / rejected as primary topology strategy



## 15. Exact Label-Interface Topology



### Deterministic Region Interface Extraction



**Family:** Exact topology / computational geometry



**Implemented:** Yes



**Research role:** Convert reconstructed geological region labels into exact shared geological interfaces.



Instead of inferring topology from a visually smoothed raster boundary, the algorithm examines neighboring labeled pixels.



Whenever neighboring pixels have different geological region labels, their shared pixel-cell interface defines an exact geological boundary.



Interfaces are grouped according to the unordered pair of geological regions they separate.



### Advantages



This approach:



* preserves geological region adjacency
* prevents arbitrary boundary duplication
* maintains shared interfaces
* identifies geological junctions
* separates internal contacts from the map perimeter
* provides a deterministic basis for vector geometry



A representative map_0103 topology reconstruction produced:



* 39 internal geological label pairs
* 30,235 exact internal interface edges
* 7,238 exact outer edges
* 92 pair-aware internal polylines
* 2 outer polylines
* 72 exact junction vertices



**Potential final role:** Core deterministic topology reconstruction stage.



**Status:** Implemented / strong current component



## 16. Geological Topology-Support Correction



### Cartographic Symbol-Hole Restoration



**Family:** Deterministic topology preprocessing



**Implemented:** Yes



### Problem



Dark cartographic symbols could be excluded from the geological color candidate mask.



This caused small symbols to become artificial holes in geological map support.



Those holes could subsequently appear as false closed geological boundaries.



### Root Cause



The earlier processing flow used the rendered/color-support mask for both visual segmentation and geological topology.



Pixels excluded because they represented dark cartographic symbols therefore had no geological label support.



### Solution



The system now distinguishes between:



* raw rendered-map support
* geological topology support



Small enclosed nuisance holes can be detected and restored in the topology-support mask.



Geological labels are propagated through the restored support without treating the dark symbol itself as a geological color class.



In the map_0103 diagnostic, 26 enclosed nuisance components were identified and restored.



### Engineering Decision



This problem should be corrected upstream in the geological region representation rather than attempting to delete false boundary rings after vectorization.



**Status:** Implemented



## 17. Exact Boundary Vectorization



**Family:** Computational geometry / GIS reconstruction



**Implemented:** Yes



Exact region interfaces can be converted into pair-aware vector polylines and GeoJSON geometry.



This separates geological interpretation from the final geometric representation.



The vectorization stage is responsible for converting valid region topology into editable GIS-oriented geometry while preserving:



* shared geological contacts
* region adjacency
* geological junctions
* outer map boundaries



**Status:** Implemented / evolving



## 18. Topology-Constrained Smoothing



**Family:** Computational geometry refinement



**Research role:** Reduce raster staircase artifacts without damaging geological topology.



### Current Limitation



Exact pixel-cell interfaces preserve topology but diagonal boundaries can retain visible raster stair-stepping.



Naive smoothing is unsafe because it may:



* move geological junctions
* alter region adjacency
* erase narrow geological units
* merge nearby contacts
* introduce gaps
* introduce overlaps



### Current Direction



The intended refinement is junction-locked, topology-constrained vector smoothing.



Critical junctions and region relationships should remain fixed while non-critical portions of geological boundaries are simplified or smoothed within a bounded geometric deviation.



**Status:** Active development



## 19. Current Candidate Role Matrix



| Component | Primary Research Role | Current Status |

|---|---|---|

| U-Net | segmentation baseline | baseline / candidate |

| SE-UNet | local geological detail | implemented / active candidate |

| TransUNet / 3D-TransUNet | local and global segmentation | research candidate |

| SegFormer / MiT-style encoder | global geological context | active candidate family |

| HybridGeoMapNet | local/global evidence fusion | implemented / evolving |

| MultiHeadGeoMapNet | semantic layer separation | implemented / active research |

| Mask2Former | instance and layer separation | comparative candidate |

| Mamba | long-range geological reasoning | active research candidate |

| SAM2 / MapSAM2 | uncertain-region refinement | evaluated / support |

| Color-region reconstruction | geological region reconstruction | implemented |

| GeoRegionAffinityNet | palette-independent region evidence | implemented / active research |

| Raster topology repair | predicted-boundary repair | rejected for primary role |

| Exact label-interface topology | topology preservation | implemented |

| Topology-support correction | symbol-hole correction | implemented |

| Exact vectorization | GIS geometry generation | implemented / evolving |

| Topology-constrained smoothing | geometric refinement | active development |



## 20. Final Component Selection Policy



The final production architecture has not yet been selected.



The current objective is to identify approximately four to five complementary learned and/or specialized components that provide measurable value for different geological-map subproblems.



A component should not be selected simply because it performs well on one example map.



Selection should consider:



- boundary IoU

- boundary precision and recall

- boundary F1

- geological region IoU

- geometric boundary displacement

- Chamfer or Hausdorff-style distance

- junction preservation

- endpoint behavior

- region adjacency correctness

- polygon validity

- gaps and overlaps

- robustness across different map styles

- robustness to colored, grayscale, aged, scanned, and black-and-white inputs

- inference cost

- integration complexity

- GIS usability



A model should remain in the final architecture only when it provides measurable value that is not adequately supplied by another component.



## 21. Current Research Direction



The current working hypothesis is a modular system containing complementary capabilities for:



- local geological detail

- global geological context

- semantic and/or instance layer separation

- palette-independent geological region reasoning

- optional uncertain-region refinement

- deterministic topology preservation

- GIS vector reconstruction



The exact learned models occupying these roles remain an experimental decision.



Deterministic topology and vectorization are intentionally separated from learned perception because neural probability maps alone cannot guarantee exact GIS topology.



## 22. Registry Maintenance



Update this registry when:



- a new model family is introduced

- a candidate is implemented

- comparative testing changes a component's intended role

- a model is rejected for a specific task

- a new checkpoint becomes a validated baseline

- a component is promoted into the selected architecture

- the final architecture changes



Model-selection decisions should be cross-referenced with:



- `EXPERIMENT_REGISTRY.md`

- `VERSION_HISTORY.md`

- `DESIGN_SPEC.md`

- the R&D engineering notebook



Large checkpoints, training datasets, generated inference outputs, and third-party research repositories should not be committed to this source repository.





