\# Version History



This document records the major development stages of the geological map

digitization R\&D project.



The purpose is to preserve the technical evolution of the work without

duplicating large datasets, generated outputs, checkpoints, or temporary

experiments inside the Azure DevOps repository.



\---



\## V1 — Classical Computer Vision Baseline



\### Status

Preserved working baseline.



\### Purpose

V1 established the first end-to-end geological map digitization workflow using

deterministic image-processing and geometry-processing methods.



\### Main Approach

The pipeline combined:



\- image preprocessing and inpainting

\- LAB colour-space clustering

\- geological region extraction

\- boundary extraction

\- skeletonization

\- geometric simplification

\- smoothing

\- vector/GIS export



Representative techniques included K-Means colour clustering, skeletonization,

Douglas-Peucker simplification, Chaikin-style smoothing, and GIS/vector

processing with Shapely, GeoPandas, and GDAL-compatible tooling.



\### Importance

V1 produced a usable final result and therefore remains an important technical

baseline rather than a discarded experiment.



It established several concepts that continue to influence later versions:



\- geological regions should be reconstructed before final GIS export

\- geological boundaries must remain topologically meaningful

\- raster output alone is insufficient for editable GIS workflows

\- post-processing is required to transform pixel predictions into usable

&#x20; vector geometry



\### Limitations

The V1 workflow depended strongly on colour and image appearance.



It was less robust to:



\- varying palettes

\- grayscale and aged maps

\- scanning artefacts

\- different layout styles

\- overlapping cartographic features

\- complex geological intersections



These limitations motivated the transition to learned and hybrid approaches.



\---



\## V2 — Learned and Hybrid Geological Segmentation



\### Status

Major R\&D development stage.



\### Purpose

V2 introduced machine-learning-based segmentation and hybrid computer-vision

methods in order to improve generalization beyond the appearance-dependent V1

pipeline.



\### Main Research Areas



V2 development included:



\- U-Net-style segmentation

\- SE-UNet

\- hybrid CNN/global-context architectures

\- transformer-based segmentation experiments

\- multi-head semantic segmentation

\- hard-negative sampling

\- geological contact extraction

\- cartographic feature separation

\- tiled inference

\- OOD sanity checks

\- deterministic post-processing and topology reconstruction



\### Multi-Head Segmentation



A multi-head model was developed to separate different map features instead of

treating all visible linework as geological contacts.



Current semantic heads include:



\- geological contacts

\- faults

\- roads

\- rivers

\- lakes

\- strike/dip symbols

\- clutter



This was an important architectural change because geological maps contain many

different line and symbol types that can visually resemble contacts.



\### Hard-Negative Research



Full-map inference showed false detections in page layout, labels, symbols, and

other non-geological regions.



Hard-negative sampling was introduced to provide stronger negative supervision.



Experiments showed that excessive hard-negative emphasis could suppress useful

geological recall, leading to a more balanced sampling strategy.



\---



\## V2.1 — Experimental Model and Topology Research



\### Status

Active experimental research branch / architectural evolution.



V2.1 represents the stage in which the project expanded beyond a single

segmentation model and began evaluating specialized models and topology-aware

methods for different geological subproblems.



It should not be interpreted as one frozen model architecture.



\### Model Research



Candidate and evaluated model families include:



\- U-Net

\- SE-UNet

\- TransUNet / 3D-TransUNet

\- SegFormer

\- transformer/global-context encoders

\- Mamba/state-space approaches

\- Mask2Former

\- SAM2 / MapSAM2

\- GeoRegion affinity learning

\- multi-head segmentation

\- deterministic topology and vectorization methods



The long-term objective is to select a small number of complementary components

according to measurable performance on specific geological tasks rather than

forcing one model to solve the entire problem.



\### SAM2 Research



SAM2 was evaluated as a geological-body refinement method.



Results showed that SAM2 can refine some compact geological bodies accurately,

but can also leak significantly outside the intended region.



As a result, SAM2 is currently treated as a local validated refinement or

rescue module rather than the primary geological boundary generator.



\### Region-First Reconstruction



A major research conclusion was that direct boundary prediction is not always

the most reliable route to GIS geometry.



The project therefore increasingly follows a region-first strategy:



1\. determine geological region membership

2\. reconstruct coherent geological regions

3\. derive interfaces between neighbouring geological regions

4\. preserve intersections and junctions

5\. convert those interfaces into GIS/vector geometry



\### GeoRegion Affinity Learning



A palette-independent affinity model was introduced to learn whether

neighbouring pixels belong to the same geological region.



The model predicts:



\- horizontal region affinity

\- vertical region affinity

\- boundary probability



This reduces dependence on memorizing geological colours.



The learned affinity output is currently considered supporting evidence for

generalization and region reconstruction rather than final GIS geometry by

itself.



\### Exact Topology Vectorization



An exact label-interface vectorization approach was developed.



Rather than smoothing an uncertain raster boundary directly, geological

interfaces are derived mathematically from neighbouring region labels.



This preserves:



\- geological adjacency

\- shared boundaries

\- junctions

\- topology relationships

\- outer map boundaries



The resulting geometry can then be simplified and smoothed under constrained

deviation.



\### Symbol-Hole Correction



A topology error was identified where small dark cartographic symbols could be

mistaken for holes in the geological support mask.



The corrected workflow separates:



\- raw visible geological support

\- topology support used for reconstruction



Small enclosed nuisance holes can therefore be restored without treating the

dark symbol itself as geological colour.



\---



\## Current R\&D State



\### Status

Active development.



The current Azure package contains the actively maintained research code and

should not yet be treated as a frozen final production architecture.



The project is currently evaluating complementary approaches for:



\- local geological detail

\- global context

\- semantic feature separation

\- geological region reconstruction

\- instance/layer separation

\- uncertain-region refinement

\- topology preservation

\- GIS/vector generation



The intended final architecture is modular.



A likely final system will combine approximately four to five complementary

components selected through benchmarking, followed by deterministic

topology/vectorization for exact GIS geometry.



The final model selection has not yet been frozen.



\---



\## Version Preservation Policy



Historical versions are preserved according to technical value.



\### V1

V1 should remain available as a runnable classical-computer-vision baseline

because it produced a meaningful end-to-end result.



\### V2

V2 is represented by the learned/hybrid development history and the current

maintained source where that work continues to evolve.



\### V2.1

Important V2.1 experiments and model research should be preserved where they

provide reproducible technical evidence, including both successful and failed

approaches.



\### Generated Data



The repository should not store large generated artefacts unless specifically

approved.



Examples normally excluded from source control include:



\- training datasets

\- generated affinity targets

\- model checkpoints

\- large NPY arrays

\- bulk prediction outputs

\- caches

\- virtual environments

\- third-party model repositories



Representative lightweight reports, figures, configuration files, and evidence

may be retained when useful for reproducibility and R\&D documentation.



\---



\## Current Repository Role



The Azure DevOps repository is the official company-side location for the

maintained project source.



The `faria\_geomap\_rnd` package is intentionally isolated from the existing

company `digitalize` implementation.



The package is structured so that research development can continue without

modifying or overwriting the existing company pipeline.

