﻿# GeoMap R&D - Run Guide



## 1. Purpose



This document describes how to execute the runnable GeoMap R&D pipelines and research components preserved in the `faria_geomap_rnd` subproject.



The repository contains multiple generations of geological-map digitization research.



The currently maintained top-level runner does not execute every experimental model described in the Model Registry.



The command:



`python -m faria_geomap_rnd.run_v2_pipeline`



currently executes the maintained SE-UNet V2 inference path consisting primarily of:



1. geological map loading

2. tiled SE-UNet inference

3. class prediction and confidence estimation

4. contact-probability sanity checking

5. graph-based contact refinement

6. prediction/debug output generation

7. per-map reporting

8. batch reporting



Newer experimental components such as multi-head segmentation, GeoRegion affinity learning, color-region reconstruction, SAM2-assisted refinement, and exact topology/vectorization are maintained as separate research modules while the final integrated architecture remains under evaluation.



---



## 2. Repository Location



Run commands from the root of the cloned AutoDigitizer repository.



Example:



```text

---

## 9. Output Location

If `--output` is not supplied, the runner uses:

```text
OUTPUT_DIR/v2_runs


## 10. One-Command Map-to-GIS Runner (`run_map`)

`run_map` takes a scanned geological map and writes each feature type as its own GIS layer, with no manual steps per map.

Run from the AutoDigitizer repository root:

```text
python -m faria_geomap_rnd.run_map --input path/to/map.tif --output-dir outputs/run_map
python -m faria_geomap_rnd.run_map --input-dir path/to/maps --output-dir outputs/run_map
```

Steps: map restoration, colour-region reconstruction, unit polygons and contacts, linear-feature extraction, line sorting, export.

Trained models (each used for what it is best at):

| Model | Checkpoint file | Used for | Status |
|---|---|---|---|
| Multi-head GeoMap net | `multihead_geomap_best.pth` | contacts, `faults`, roads and rivers in `other_lines`, clutter removal | trained |
| SE-UNet V2 | `se_unet_v2_best.pth` | second opinion on contacts, faults and clutter | trained |
| GeoRegionAffinityNet | `georegion_affinity_best.pth` | area boundaries (palette-independent) | trained |
| TransUNet | `transunet_geomap_best.pth` | thin contacts and faults that must stay continuous (CNN detail + ViT context), clutter | needs training |
| RS3Mamba | `rs3mamba_geomap_best.pth` | long faults and contacts across the whole tile (ResNet + visual state space branches) | needs training |
| Mask2Former | `mask2former_regions_best.pth` | one mask per map area, so similar-coloured neighbouring areas separate | needs training |
| SAM2.1 | `sam2.1_hiera_tiny.pt` (or small / base_plus / large) | settles the uncertain parts of the area boundary | public weights, no training |
| DIGMAPPER | none | slot only: code and weights not public (arXiv 2506.16006) | not available |

How they combine: line maps for the same target (contact, fault, clutter, road, river) are averaged over the models that predict it. Area-boundary maps (GeoRegionAffinityNet, Mask2Former) are combined by taking the maximum, then SAM2 looks only at the uncertain band (probability 0.3 to 0.7). Inside up to 40 boxes it raises pixels on a SAM2 mask edge to 0.8 and lowers the rest to 0.2. Contacts and area boundaries above `--model-threshold` split the colour areas.

The runner looks for these files under `--models-dir` (any subfolder), then in the training output folders under `faria_geomap_rnd/outputs/`. A model whose file is missing is skipped and the colour/rule step covers its job. A model whose lines or boundaries cover more than 35% of the map is reported under `models.ignored` and left out; this usually means an untrained or mismatched checkpoint. `run_report.json` lists which models ran (`models.used`), what each was used for (`models.roles`), which were missing, ignored or failed to load, and what SAM2 changed (`models.sam2`). `class_method` on every line names the models that produced it (for example `supervisor_multihead+transunet+se_unet`), or `heuristic_v0`. `--no-models` turns the models off, `--device` picks `cpu` or `cuda`, and `--model-threshold` (default 0.5) sets the probability cut-off.

Training the untrained models (on the Supervisor150 images and targets, best on the GPU VM):

```text
python -m faria_geomap_rnd.pipelines.train_supervisor_multihead --architecture transunet --device cuda --epochs 40 --batch-size 8
python -m faria_geomap_rnd.pipelines.train_supervisor_multihead --architecture rs3mamba --device cuda --epochs 40 --batch-size 8
python -m faria_geomap_rnd.versions.v3_mask2former.training.train_mask2former --device cuda --pretrained facebook/mask2former-swin-tiny-ade-semantic
```

The first two write to `outputs/checkpoints_<architecture>/`, Mask2Former to `outputs/checkpoints_mask2former/`. RS3Mamba runs anywhere; `pip install mamba-ssm` on a CUDA machine makes its scan much faster. SAM2 needs `pip install sam2` and a SAM2.1 checkpoint from the SAM2 release page placed in `--models-dir`.

Veins have no trained model yet, so `veins` always comes from the rule step.


- Coloured fill is grouped into colours (`--k`, default 20) after a light blur so stippled fills read as one colour.
- White ground inside the map is kept as its own area, so edges between coloured and white areas are kept.
- Areas are also split along printed dark outlines, so two areas of the same colour separated by a drawn line stay separate (`face_id`). Both pieces keep the same `unit_id`.
- Areas smaller than `--min-region-area` pixels merge into a neighbour.

Output per map (`OUTPUT_DIR/<map_id>/`):

```text
<map_id>.gpkg        one GeoPackage, one layer per feature type
geojson/<layer>.geojson
qa_overlay.png       contacts and map edge (bold black), faults (red), veins (green), other lines (grey)
run_report.json      counts, timings, georeference status, warnings
work/                intermediate restoration and line-extractor outputs
```

Layers and main attributes:

| Layer | Geometry | Attributes |
|---|---|---|
| `units` | Polygon | face_id, unit_id, legend_code, unit_name, legend_color, area, confidence |
| `contacts` | Line | contact_id, left_unit, right_unit, certainty, length, confidence |
| `faults` | Line | fault_id, fault_type, certainty, line_color, length, class_method, confidence |
| `veins` | Line | vein_id, vein_type, line_color, length, class_method, confidence |
| `other_lines` | Line | line_id, kind (river / unclassified), line_color, length, class_method, confidence |

Every row also has `map_id` and `source = "auto"`.

QGIS styling is applied automatically: the GeoPackage stores default styles (units filled with their legend colour and a bold black outline, contacts bold black, faults red, veins green, other lines grey), and each GeoJSON file has a matching `.qml` file.

Coordinates:

- GeoTIFF input with a CRS: layers are written in that CRS.
- Plain image input: layers are written in original-image pixel space with **no CRS** (y flipped so the map is upright in QGIS). Pixel coordinates are never labelled as EPSG:4326.

Current limits:

- `legend_code` and `unit_name` are empty until legend reading is built.
- Faults and veins are sorted by a simple colour/shape rule (`class_method = heuristic_v0`). The line extractor misses many thin coloured lines inside unit fills.
- Plain images are not yet georeferenced automatically.

Batch runs also write `batch_summary.json` in the output directory.
