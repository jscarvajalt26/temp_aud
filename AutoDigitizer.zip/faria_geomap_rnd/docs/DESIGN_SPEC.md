# GeoMap R&D — Design Specification

**Document Version:** 1.1  
**Pipeline Scope:** Active research, development, and evaluation  
**Author / Sole Builder:** Faria Samanta Akbar — Machine Learning and Computer Vision Intern  
**Supervised by:** Juan Carvajal — Geologist and GIS Analyst  
**Status:** Active development. The final architecture is not frozen; candidate models and deterministic processing components are evaluated and retained according to their measurable contribution to specific geological map digitization tasks.

> This specification documents the evolving architecture, implementation decisions, experiments, and validation strategy for the GeoMap R&D pipeline. The system is intentionally modular so that individual segmentation, region-reasoning, refinement, and topology components can be evaluated independently and combined where they provide complementary value.

> This document defines the current working architecture of the GeoMap R&D platform. It evolves as experiments, validation results, and integration evidence identify stronger approaches. Architectural changes should be documented here alongside the evidence that motivated them.

---

## 1. Vision

Develop a complete AI-powered geological map understanding system capable of automatically digitizing geological maps into structured, GIS-ready data.

The system should work on maps from different organizations, countries, color conventions, scales, and formats without requiring manual digitization.

The final output should preserve the complete original map while extracting every geological feature into editable vector layers.

---

## 2. Core Design Principles

- **Modular architecture** — every model or engine can be replaced without rewriting the pipeline.
- **Model-agnostic backend** — supports benchmarking and swapping models as better ones become available.
- **Preserve the original map** — never destroy or overwrite the source; all outputs are derived layers.
- **GIS-first outputs** — every detected feature is exportable as structured, editable GIS data.
- **Scalable processing** — the same backend processes a single map or thousands of maps with the same code path.
- **Human-review ready** — every prediction includes confidence information and allows manual correction later.
- **Extensible by design** — adding new feature detectors (mineral symbols, boreholes, cross-sections) means implementing a new module, not redesigning the system.
- **Fail gracefully** — low-confidence tiles or model failures degrade to partial output with clear flags, never a silent wrong answer or a pipeline crash.
- **Calibrated uncertainty** — every automated decision uses normalized, documented uncertainty rather than treating raw model probabilities as universally comparable.
- **Dataset governance** — every training sample has known provenance, split membership, licensing status, and annotation history.
- **Versioned shared representation** — all modules communicate through a versioned `MapAnalysisResult` schema. Silent schema drift is not permitted.
- **Reproducible experimentation** — every model comparison records dataset version, split version, model version, checkpoint hash, configuration, random seed, hardware, library versions, evaluation metrics, and benchmark weighting profile used.

---

## 3. Primary Objectives

The platform should automatically detect and extract:

### Geological Units
Rock units, lithological bodies, formations, intrusions, deposits.

### Boundaries
Unit contacts, faults, dykes, veins, fold boundaries, layer boundaries, internal/external boundaries.

### Structural Features
Fault intersections, contact intersections, cross-cutting relationships, junctions, terminations.

### Geological Relationships
Instead of only extracting objects, determine relationships between them, e.g.:
- Fault F1 *crosses* Granite Unit G2
- Quartz Vein V3 *terminates at* Fault F1
- Sandstone *overlies* Shale

### Map Information
Legend, labels, symbols, north arrow, scale, coordinate grid, title, metadata.

---

## 4. Supported Input

**Single file:** `map001.tif`

**Batch folder:**
```
InputMaps/
  map001.png
  map002.jpg
  map003.tif
  map004.pdf
```

**Supported formats:** PNG, JPEG, TIFF, GeoTIFF, PDF
**Future formats:** JP2, BMP, SVG

---

## 5. Processing Pipeline

```
Input
  ↓
Map Detection
  ↓
Preprocessing
  ↓
Georeferencing / GCP Handling
  ↓
Tile Generation
  ↓
AI Models
  ↓
Prediction Fusion
  ↓
Topology Engine
  ↓
Legend + OCR
  ↓
Graph Builder → MapAnalysisResult
  ↓
Vector Export
  ↓
Final Outputs
```

Every stage above is scheduled, monitored, and governed by the **Pipeline Controller** (Section 15) — configuration validation, dataset approval checks, schema compatibility checks, GPU memory management, and failure handling all live there rather than being scattered per-stage.

### Georeferencing / GCP Handling

Inputs are handled differently based on available metadata:

**GeoTIFF** — preserve projection, preserve coordinates.

**Scanned map** — detect coordinate grid if possible; if no spatial reference exists, export in image coordinates; allow future manual control points (GCPs).

This keeps geospatial information intact when available, without pretending a scanned map without any coordinate reference can produce one.

---

## 6. AI Model and Geometry Pipeline

The GeoMap R&D system uses a modular model-and-geometry architecture rather than assuming that a single neural network can solve every geological digitization problem.

Candidate models are evaluated according to the subproblem they are intended to solve. The final production architecture is expected to retain a small set of complementary components based on measured performance, generalization, computational cost, and topology quality. The exact final model combination is therefore not frozen.

### 6.1 Candidate Model Families

| Model / Approach | Primary Evaluation Role |
|---|---|
| **U-Net / SE-U-Net** | Local-detail semantic segmentation baseline for contacts, boundaries, and small geological features |
| **TransUNet / transformer-based U-Net variants** | Joint local and global contextual reasoning for large geological structures and long-range relationships |
| **SegFormer / hierarchical transformer encoders** | Global-context semantic segmentation and robustness to variation in map layout, texture, and color |
| **HybridGeoMapNet** | Learned fusion of CNN local-detail features with hierarchical transformer context features |
| **Mamba / state-space vision models** | Long-range spatial dependency modeling with an alternative computational structure to transformer attention |
| **MultiHeadGeoMapNet** | Independent prediction of overlapping geological and cartographic layers such as contacts, faults, roads, rivers, lakes, strike/dip symbols, and clutter |
| **Mask2Former** | Candidate instance-level separation of individual geological bodies and overlapping map features |
| **SAM2 / MapSAM2** | Local promptable refinement and recovery of uncertain geological regions; not used as the primary geological contact generator |
| **GeoRegion affinity learning** | Palette-independent prediction of whether neighboring pixels belong to the same geological region, supporting region reconstruction rather than direct boundary raster prediction |
| **Color-region reconstruction** | Deterministic reconstruction of geological regions on suitable color maps using clustering, component analysis, and topology-aware filling |
| **Topology and vectorization engines** | Deterministic conversion of reconstructed regions into exact shared interfaces, junctions, outer boundaries, and GIS-ready vector geometry |

### 6.2 Model Roles and Selection Strategy

The current architecture separates several complementary responsibilities:

- **Local semantic detail:** convolutional models such as U-Net and SE-U-Net provide strong local boundary and feature evidence.
- **Global spatial context:** transformer, SegFormer-style, TransUNet-style, and state-space candidates are evaluated for large-scale geological relationships and long-range continuity.
- **Overlapping feature separation:** the multi-head branch predicts contacts, faults, roads, rivers, lakes, strike/dip symbols, and clutter as independent layers rather than forcing them into a mutually exclusive semantic mask.
- **Instance reasoning:** Mask2Former is evaluated where separation of individual geological bodies or overlapping structures requires instance-level predictions.
- **Region reasoning:** GeoRegion affinity learning predicts local same-region / different-region relationships that can later be reconstructed into coherent geological regions.
- **Selective refinement:** SAM2 / MapSAM2 is used only where local uncertainty or incomplete region reconstruction justifies promptable refinement. Validation experiments showed that it can refine compact geological bodies effectively but may leak across elongated or weakly separated regions, so it is not treated as the primary boundary generator.
- **Deterministic geometry:** region labels are converted to shared boundaries and GIS geometry using topology-preserving algorithms rather than relying on raw probability masks as final geometry.

The final production system will not necessarily contain every candidate listed above. Models are retained only when benchmarking shows that they provide measurable and complementary value for a specific geological digitization subproblem.

### 6.3 Current Geometry Strategy

A central design decision is to reconstruct geological regions before generating final contacts wherever possible.

The current geometry path is:

```text
Map / scan
    ↓
Semantic and contextual evidence
    ↓
Geological region reconstruction
    ↓
Region labels / affinity relationships
    ↓
Exact shared label interfaces
    ↓
Junction-preserving topology
    ↓
Constrained smoothing and simplification
    ↓
GIS-ready vector boundaries and polygons
```

### 6.4 Candidate Evaluation

Every candidate model and geometry component is evaluated using consistent validation evidence rather than qualitative impression alone. Relevant measures include semantic accuracy, boundary quality, topology preservation, cross-map generalization, processing cost, and GIS validity.

**Named scoring profiles** — weights are provisional and hardware-dependent, not one fixed truth:

```yaml
benchmark_profiles:
  quality_first:
    mean_iou: 0.25
    boundary_f1: 0.25
    topology_correctness: 0.20
    inference_speed: 0.15
    gpu_memory: 0.10
    generalization: 0.05

  hardware_constrained:
    mean_iou: 0.20
    boundary_f1: 0.20
    topology_correctness: 0.20
    inference_speed: 0.20
    gpu_memory: 0.15
    generalization: 0.05
```

`generalization` is scored specifically against the external holdout set (Section 7), not the in-distribution test split — this is what actually distinguishes real generalization from memorized symbology.

---

## 7. Dataset Strategy

This is the highest-risk area of the project — model architecture choices are secondary to whether the models ever see enough well-governed, representative training data.

### Training Sources
- USGS
- Geoscience Australia
- Geological Survey of Canada
- British Geological Survey
- Open geological datasets / public academic papers
- Internal manually corrected maps

### Data Types
Color maps, black & white, scanned maps, GeoTIFF, PNG, PDF, synthetic augmentation.

### Ground Truth
Polygon masks, boundary masks, fault masks, vein masks, legend labels, OCR labels.

### Dataset Licensing and Provenance

Every external dataset must have its licensing and provenance recorded **before** being used for training, validation, benchmarking, or client-facing outputs.

```python
DatasetRecord:
    dataset_id
    source_organization
    source_url
    license_name
    license_reference
    attribution_required
    commercial_use_allowed
    modification_allowed
    redistribution_allowed
    geographic_region
    map_count
    annotation_type
    date_acquired
    internal_notes
```

Before approval, verify: training use is permitted, derivative model use is permitted, commercial use restrictions are understood, attribution requirements are recorded, redistribution restrictions are respected, and client deliverables do not violate source terms.

Dataset status is one of:
```
pending_review | approved_research_only | approved_commercial | restricted | rejected
```

No dataset enters the production training pipeline without an approved status. The Pipeline Controller enforces this gate (Section 15).

### Data Volume, Splits, and Leakage Prevention

**Split unit** — never split by tile. Split by the highest available grouping level:

```
survey project → map series → map sheet → tiles
```

All tiles from one map sheet stay in the same split; sheets from the same survey/publication stay together where possible.

**Split structure**, grouped and stratified by source organization, map style, region, color vs. grayscale, scanned vs. digital, complexity, scale, and feature availability:

```
Training   → Validation → Calibration → Testing → External Holdout
   70%          15%            (from                15%
                              training/val)
```

Calibration (Section 8) is carved out respecting the same survey/sheet/organization/publication grouping rules — it must never become another leakage path.

**Leakage prevention** — duplicate detection via filename/metadata checks, image hashing, perceptual hashing, map-title comparison, geographic extent comparison, and source publication identifiers. No survey, edition, rescan, crop, or derivative version crosses split boundaries.

**External generalization set** — a holdout from organizations/styles absent from training entirely (e.g., train on GSC + USGS style, hold out BGS or Geoscience Australia) to measure genuine generalization rather than memorized symbology.

**Dataset growth targets** — defined as maturity stages rather than a fixed number, since exact counts depend on a pilot annotation study measuring class frequency, annotation time, map diversity, performance variance, and learning-curve saturation:

```
Prototype dataset  → validates pipeline, exposes failure modes
Baseline dataset   → enough independent sheets for stable model comparison
Production dataset → broad coverage across orgs, styles, scales, conditions
```

---

## 8. Evidence Fusion and Specialist Routing

The GeoMap R&D pipeline combines evidence from multiple model families and deterministic processing components. Fusion is not limited to majority voting between semantic segmentation networks, and no candidate is assumed to be part of the final production system until benchmarking demonstrates complementary value.

### 8.1 Evidence Sources

Depending on the active experiment and map characteristics, evidence may come from:

```text
Input map
    ↓
Local semantic evidence
    ├── U-Net / SE-U-Net
    └── MultiHeadGeoMapNet

Global/contextual evidence
    ├── TransUNet-style models
    ├── SegFormer-style encoders
    ├── HybridGeoMapNet
    └── Mamba / state-space candidates

Region evidence
    ├── color-region reconstruction
    └── GeoRegion affinity prediction

Specialist evidence
    ├── SAM2 / MapSAM2 local refinement
    └── Mask2Former instance reasoning

Geometry evidence
    └── deterministic topology and vectorization
```

Not every branch is run on every map. Components are enabled or routed according to the experiment, map characteristics, uncertainty type, validation evidence, and deployment constraints.

### 8.2 Fusion Levels

#### A. Feature-Level Fusion

`HybridGeoMapNet` combines convolutional local-detail features with hierarchical global-context features before decoding. This is a learned feature-fusion architecture rather than a platform-level voting mechanism.

#### B. Prediction-Level Fusion

Independent registered predictions may be compared or combined using confidence weighting, calibrated probability fusion, rule-based arbitration, agreement/disagreement analysis, class-specific selection, or a learned meta-fusion approach if sufficient validation data becomes available.

#### C. Region-Level Fusion

Region-level evidence is used when pixel-wise predictions do not produce sufficiently coherent geological geometry. Sources can include reconstructed color regions, GeoRegion horizontal/vertical affinities, connected components, region adjacency, and independently reconstructed region labels.

This level is important because final geological contacts should represent interfaces between coherent geological regions rather than thresholded probability rasters.

#### D. Specialist Routing

Specialists are invoked only where their capabilities match the detected problem:

```text
Local uncertain region
    → consider SAM2 / MapSAM2 refinement

Instance or body ambiguity
    → consider Mask2Former

Weak palette reliability
    → increase reliance on learned region/context evidence

Strong clean color separation
    → use color-region reconstruction as a geometry source

Overlapping cartographic features
    → use independent multi-head layer evidence

Stable reconstructed regions
    → route to exact topology/vectorization
```

SAM2 / MapSAM2 is not automatically accepted for low-confidence regions. Experiments showed strong refinement on some compact bodies but severe leakage on some elongated or weakly separated regions. Candidate masks therefore require validation before acceptance.

### 8.3 Common Prediction Interface

Models participating in prediction-level fusion may expose a common representation:

```python
class ModelPrediction:
    model_name: str
    prediction_type:   # semantic | instance | promptable | affinity
    confidence_type:   # pixel_probability | mask_confidence | object_confidence
    class_probabilities
    predicted_mask
    raw_confidence
    normalized_confidence
    confidence_map
    uncertainty_map
```

Region reconstruction and deterministic geometry components are not forced into this interface when doing so would discard structural information.

### 8.4 Confidence and Calibration

For semantic models, confidence may combine maximum class probability and normalized predictive entropy:

```python
confidence = (
    alpha * max_probability
    + (1 - alpha) * (1 - normalized_entropy)
)
```

`alpha` is configurable and determined through validation. Models used in confidence-based fusion should be calibrated independently. Raw logits from unrelated architectures are not assumed to have directly comparable confidence semantics.

### 8.5 Routing and Acceptance

Routing depends on the type of uncertainty:

```text
Reliable semantic evidence
    → retain prediction
Model disagreement
    → compare calibrated evidence and relevant specialists
Region fragmentation
    → region reconstruction / affinity reasoning
Local uncertain body
    → optional SAM2 / MapSAM2 refinement + validation
Instance ambiguity
    → optional Mask2Former evaluation
Cartographic/geological overlap
    → independent layer reasoning
Stable region reconstruction
    → exact topology and vectorization
```

Thresholds used by individual experiments are recorded with their configuration and validation evidence rather than treated as permanently fixed architectural constants.

### 8.6 Current Research Direction

The strongest geometry path observed so far is not simple semantic-model voting followed by boundary repair. The current direction is:

```text
Multiple visual / semantic evidence sources
                ↓
        Geological region reasoning
                ↓
      Coherent region reconstruction
                ↓
       Exact shared interfaces
                ↓
     Junction-preserving topology
                ↓
Constrained vector smoothing / simplification
                ↓
          GIS-ready geometry
```

For suitable clean color geological maps, color-region reconstruction currently provides a particularly strong geometry source. GeoRegion affinity learning is being evaluated as a palette-independent learned complement for maps where deterministic color reconstruction is insufficient.

### 8.7 Threshold Optimization

Where a component requires thresholds, optimization is reproducible:

```text
1. Select validation data.
2. Search the defined parameter range.
3. Evaluate task-appropriate segmentation, geometry, topology, and processing metrics.
4. Identify Pareto-optimal configurations.
5. Record the selected configuration with experiment evidence.
```

---

## 9. Region Reconstruction, Topology, and Vectorization

The topology stage is not limited to repairing a predicted boundary raster. Wherever coherent region labels are available, final geological contacts are derived from the interfaces between those regions.

### 9.1 Region-First Principle

```text
Geological evidence
    ↓
Coherent region labels
    ↓
Exact neighboring-label interfaces
    ↓
Pair-aware boundary chains
    ↓
Junction-preserving topology
    ↓
Constrained smoothing / simplification
    ↓
Polygon and line validation
    ↓
GIS-ready geometry
```

This avoids treating thick, broken, duplicated, or threshold-sensitive neural boundary masks as authoritative geometry.

### 9.2 Color-Region Reconstruction

For suitable color maps, the current deterministic extractor uses color clustering and component reconstruction to recover geological regions before extracting their shared boundaries.

The topology support mask is intentionally distinct from the raw rendered geological mask. Small enclosed dark cartographic symbols can interrupt a rendered map without representing genuine geological holes. Selected nuisance holes may therefore be restored in topology support while clustering remains restricted to valid geological color evidence.

This distinction prevents point symbols from automatically becoming false geological rings while preserving the original source image and feature layers.

### 9.3 Learned Region Evidence

GeoRegion affinity learning predicts horizontal and vertical same-region relationships together with boundary evidence. Its purpose is palette-independent geological relationship learning rather than direct production of final GIS boundaries.

The current learned affinity branch provides useful generalization evidence but does not yet replace the stronger deterministic color-region geometry on the clean color-map cases evaluated so far. Affinity-to-region reconstruction remains an active integration task.

### 9.4 Exact Shared Interfaces

Given a region-label raster, every horizontally or vertically adjacent pair of pixels with different valid geological labels defines an exact shared interface. Interfaces are grouped by unordered region pair so a contact is represented once rather than independently traced from both polygons.

Outer map boundaries are handled separately from internal geological contacts.

### 9.5 Junction Preservation

Endpoints and multi-region junctions are structural constraints. Smoothing and simplification must not move, merge, or remove junctions in ways that change geological adjacency.

The current refinement direction is junction-locked, deviation-bounded vector smoothing rather than unconstrained smoothing of a rasterized boundary mask.

### 9.6 Topology Validation

Validation includes region adjacency preservation, endpoints and junctions, fragmented contacts, duplicate or parallel boundaries, gaps and overlaps, self-intersections, invalid rings, unexpected internal holes, shared-edge consistency, outer-boundary integrity, and GIS geometry validity.

Topology repair is applied only when supported by evidence. The system must not bridge gaps or create connections merely because endpoints are spatially close.


---

## 10. Graph Engine & Shared Representation

Rather than a late-stage add-on operating on raw raster masks, the Graph Engine is elevated to a **core shared data representation** that every module reads from and writes into. This is the single source of truth for the entire pipeline — all exports (PNG overlays, GeoJSON, CSVs, reports, future APIs) are generated from it, not reconstructed ad hoc at the end.

### `MapAnalysisResult`

```python
@dataclass
class MapAnalysisResult:
    schema_version: str
    pipeline_version: str
    run_id: str

    source: SourceMap
    spatial_reference: SpatialReference
    raster_layers: RasterLayerCollection
    vector_features: FeatureCollection
    legend: LegendResult
    text_annotations: TextAnnotationCollection
    topology: TopologyGraph
    relationships: RelationshipCollection
    quality: QualityAssessment
    processing: ProcessingMetadata
```

Relationships extracted, e.g.:
- Unit A *touches* Unit B
- Fault *crosses* Vein
- Dyke *intrudes* Granite

### Schema versioning

Semantic versioning (`MAJOR.MINOR.PATCH`):
- **Major** — breaking field or structure changes
- **Minor** — backward-compatible additions
- **Patch** — corrections that don't change structure

```
2.0.0 → initial V2 schema
2.1.0 → adds borehole features
2.1.1 → corrects field documentation
3.0.0 → changes topology representation incompatibly
```

### Engine compatibility

Every engine declares which schema versions it accepts and produces:

```python
class TopologyEngine:
    supported_input_schemas = [">=2.0.0,<3.0.0"]
    output_schema = "2.1.0"
```

Exporters fail clearly rather than silently ignoring unsupported fields:

```
ExporterCompatibilityError:
GeoJSONExporter 2.0 does not support MapAnalysisResult schema 3.0.0
```

### Migration support

```
schemas/
 map_analysis_result_v2.schema.json
 map_analysis_result_v2_1.schema.json
 migrations/
     v2_0_to_v2_1.py
     v2_1_to_v3_0.py
```

This protects saved results, batch resumes, old client projects, and future exporters from silent breakage.

---

## 11. Legend Engine

Broken into stages rather than a single step, since legend association is one of the hardest problems in the pipeline and is treated as such:

```
1. Detect legend region.
2. Segment legend entries.
3. OCR text.
4. Extract color/pattern samples.
5. Match legend entries to map polygons.
6. Build attribute table.
```

### Legend Normalization

Different organizations use different symbology — colors are not assumed to have universal meaning. Each map teaches the system its own legend before classification:

```
Map → Extract Legend → Build Map-specific Dictionary → Apply Dictionary to Units
```

---

## 12. OCR Engine

Extracts labels, abbreviations, formation names, and coordinate text; associates text with the correct geological unit whenever possible. This association step (fuzzy text matching plus spatial proximity heuristics) is a known-hard subproblem and carries its own test suite rather than being treated as a solved one-liner.

---

## 13. Outputs

**Complete Map** — preserves original map.

**Overlay** — units, contacts, faults, veins, dykes, boundaries, labels.

**Individual Layers** — units, boundaries, faults, veins, dykes, contacts, labels, legend, intersections.

**Vector Files** — GeoJSON (now), Shapefile (future), SVG (future).

**Tables (CSV)** — example:

| Feature | Name | Confidence | Relationship |
|---|---|---|---|
| Unit | Granite | 0.97 | touches Unit 5 |
| Fault | Fault 3 | 0.91 | crosses Vein 2 |

**Reports** — processing report, model confidence, detected feature counts, processing time, warnings.

All outputs are generated from `MapAnalysisResult` (Section 10), not assembled independently per exporter.

---

## 14. Backend API

```python
process_map(
    input_path,
    output_directory,
    config
)

process_folder(
    input_directory,
    output_directory,
    config
)
```

`config` carries its own version so old runs remain reproducible when defaults change later.

---

## 15. Pipeline Controller

The Pipeline Controller is the system governor — not just "runs the pipeline." It is where every cross-cutting rule from this document is actually enforced:

```
Pipeline Controller
  ↓
Validate configuration
  ↓
Verify dataset approval status (Section 7)
  ↓
Check schema compatibility (Section 10)
  ↓
Load models
  ↓
Manage GPU memory
  ↓
Schedule stages
  ↓
Resume interrupted batches
  ↓
Track progress
  ↓
Handle failures
  ↓
Generate run manifest
  ↓
Unload resources
```

Everything else — models, topology, OCR, exporters — becomes a plugin the Controller coordinates, loaded once, invoked as needed per the active fusion strategy and performance profile.

---

## 16. Output Directory Structure

```
outputs/
  map001/
    full_detected_map.png
    annotated_map.png
    clean_geology.png
    layers/
    vectors/
    tables/
    reports/
      legend.json
      topology.json
      processing_report.json
      run_manifest.json
```

### Run manifest example

```json
{
  "pipeline_version": "2.0",
  "git_commit": "abc123",
  "models": {
    "semantic_model": "example-version",
    "region_model": "example-version"
  },
  "configuration": "validated-profile-name",
  "device": "recorded-runtime-device",
  "processing_time": "recorded-per-run",
  "date": "2026-07-22",
  "schema_version": "2.0.0",
  "dataset_version": "baseline-2026-07",
  "split_version": "v1",
  "benchmark_profile": "hardware_constrained",
  "random_seed": 42
}
```

---

## 17. Evaluation & Testing Framework

A strong semantic score alone is not sufficient for a GIS digitization system.

### 17.1 Segmentation and Detection Metrics

- unit/class IoU and mean IoU;
- boundary IoU, precision, recall, and F1;
- per-layer precision, recall, F1, and IoU for supported multi-head targets;
- calibration quality where confidence controls routing.

### 17.2 Geometry and Topology Metrics

- boundary displacement;
- Chamfer and Hausdorff distance;
- polygon IoU;
- endpoint and junction preservation;
- adjacency correctness;
- gap and overlap counts;
- self-intersection and invalid-ring counts;
- GIS geometry validity.

### 17.3 Generalization and Performance

Evaluation uses map-level held-out validation and, where available, organization/style holdouts. Color, grayscale, black-and-white, aged, and scanned variants are evaluated where represented. Processing time, memory use, hardware, and runtime configuration are recorded.

All tiles from one map remain in the same split. Tile-level leakage is not permitted.

### 17.4 Experiment Record

Every benchmark records dataset and split versions, map IDs, model/component version, checkpoint hash where applicable, configuration, random seed, hardware, runtime/library versions, metrics, qualitative failures, and the resulting engineering decision.

Negative results are retained as engineering evidence rather than deleted.

### 17.5 Human Review

A future correction workflow may capture:

```text
Prediction → User edits → Correction record → Reviewed training candidate
```

Corrections do not automatically enter training data; provenance and review requirements from Section 7 still apply.


---

## 18. Performance Profiles

Deployment profiles are capability- and hardware-based rather than permanently tied to specific model names, because the final winning model combination is still under evaluation.

| Profile | Intended Behavior |
|---|---|
| **Lightweight** | Prefer lower-cost validated components and deterministic processing where appropriate; optional specialists disabled unless required |
| **Balanced** | Use the validated combination of local, contextual, region, and topology components that provides the best quality/cost trade-off |
| **Maximum Quality** | Enable additional validated complementary models or specialist refinement when their measured contribution justifies the computation |

Concrete model membership is versioned with the configuration after benchmarking. A candidate is not included merely because it exists in the research repository.


---

## 19. Non-Functional Requirements (NFRs)

Sections 1–18 define *what* the system does. This defines *how well* it should do it.

### Reliability
- Failed maps do not terminate a batch.
- Corrupted inputs are isolated.
- Every exception is logged.

### Scalability
Support 1 map, 10 maps, 100 maps, and 10,000 maps without architectural changes.

### Portability
Windows and Linux now; Docker and cloud deployment in future.

### Extensibility
A new AI model requires implementing the model interface and registering it — no modification to existing pipeline stages.

### Reproducibility
Every run records: git commit, configuration, dataset version, model versions, random seed, hardware, runtime, and schema version.

### Maintainability
Every module has unit tests, exposes documented interfaces, avoids circular dependencies, and remains independently replaceable.

### Performance
Lightweight / Balanced / Maximum Quality execution profiles are configurable without changing source code.

> **Note:** these NFRs are currently qualitative. Quantitative acceptance targets (e.g., exact throughput numbers, exact uptime/reliability targets) are deferred until after the pilot annotation study and initial benchmark runs establish a realistic baseline — setting numbers now would be guessing, not specifying.

---

## 20. Long-Term Goals

Future capabilities may include:

- stronger affinity-to-region reconstruction;
- broader cross-map and cross-organization generalization;
- robust legend and OCR association;
- georeferencing and GCP-assisted workflows;
- automatic polygon-face reconstruction and validation;
- repeatable QGIS/GIS topology validation;
- interactive editing;
- human-in-the-loop correction and reviewed retraining;
- multi-sheet map mosaicking;
- 3D geological reconstruction;
- LLM-assisted geological interpretation and reporting;
- QGIS and ArcGIS integration;
- cloud deployment and collaborative workflows.

These are roadmap directions, not claims of current implementation.

---

## 21. Architecture Evolution and Current Status

| Stage | Scope | Status |
|---|---|---|
| **V1** | Classical CV: color clustering, morphological processing, boundary extraction, simplification, and smoothing | Historical working baseline |
| **Early V2** | SE-U-Net-centered learned contact pipeline and prediction-level fusion concepts | Implemented/evaluated in part; retained as historical architecture |
| **Multi-head V2 research** | Independent overlapping layers for contacts, faults, roads, rivers, lakes, strike/dip, and clutter | Implemented and under evaluation |
| **SAM2 research** | Promptable candidate-region refinement with acceptance validation | Implemented experimentally; retained as selective refinement only |
| **GeoRegion research** | Palette-independent affinity learning for region relationships | Implemented/trained; region reconstruction integration remains active |
| **Color-region geometry** | Region reconstruction and shared-boundary extraction on suitable color maps | Implemented; currently a strong geometry source on evaluated clean color cases |
| **Exact topology/vectorization** | Pair-aware shared interfaces, outer-boundary separation, junction preservation, GIS vector output | Implemented in active refinement; constrained smoothing and broader validation remain active |
| **Final production architecture** | Small complementary subset of validated neural and deterministic components | Not frozen; selection pending broader benchmarking |

The role of the V1 classical CV path remains open. It may remain useful as a lightweight fallback or complementary deterministic component where validation demonstrates value.

---

## 22. Active Engineering Priorities

The repository skeleton and modular research package already exist. Current priorities are implementation and validation rather than creation of placeholder architecture.

1. Validate the symbol-hole topology-support correction across additional maps.
2. Complete junction-locked, deviation-bounded vector smoothing without losing true contacts.
3. Reconstruct coherent regions from learned GeoRegion affinities rather than treating raw affinity/boundary probability rasters as final geometry.
4. Benchmark the broader candidate model pool across map-level splits and relevant style/organization holdouts.
5. Determine which approximately four to five complementary components, if any, provide sufficient measurable value for the production pipeline.
6. Add topology-focused regression metrics and tests.
7. Validate polygon-face reconstruction, gaps, overlaps, and GIS geometry.
8. Establish repeatable QGIS/GIS topology validation.
9. Continue improving multi-head feature separation and hard-negative handling without sacrificing geological recall.
10. Keep legend semantics, OCR association, georeferencing, and higher-level geological relationship reasoning as explicit modules with evidence-based implementation status.

Architectural changes should be documented alongside the experiments or validation evidence that motivated them.

---

## Change Log

- **v1.0 (Historical design baseline)** — Established the initial modular V2 design, fusion framework, dataset governance, shared `MapAnalysisResult`, Pipeline Controller concept, performance profiles, evaluation framework, and non-functional requirements.
- **v1.1 (Active R&D architecture)** — Expanded the architecture to reflect the broader candidate model pool and implemented research: multi-head overlapping layers, transformer/state-space candidates, SAM2 selective refinement, GeoRegion affinity learning, color-region reconstruction, exact shared-interface topology, topology-support handling for cartographic symbol holes, and evidence-driven model selection. Removed the assumption that V2 or a fixed five-model pipeline is frozen.
