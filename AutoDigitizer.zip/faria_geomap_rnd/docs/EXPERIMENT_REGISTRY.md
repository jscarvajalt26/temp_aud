﻿# GeoMap R&D - Experiment Registry



## Purpose



This registry records experiments that materially influenced the architecture and engineering decisions of the GeoMap geological map digitization project.



It is intentionally different from the Model Registry.



The Model Registry records which model families and algorithmic components have been investigated. This Experiment Registry records what was tested, what happened, and what engineering conclusion was drawn from the evidence.



Where available, experiments record:



- objective

- configuration

- quantitative results

- qualitative observations

- interpretation

- engineering decision

- associated evidence or artifacts



Experimental results should not be interpreted as universal performance unless they were evaluated across an appropriate held-out dataset.



---



## EXP-001 - Early Learned Geological Segmentation



### Objective



Evaluate learned semantic segmentation as an alternative to relying entirely on the classical V1 geological map processing pipeline.



### Approaches Investigated



Early learned segmentation research included U-Net-family architectures and SE-UNet.



SE-UNet became an important early candidate because channel attention could potentially help distinguish geological information from competing color, linework, texture, and cartographic clutter.



### Result



SE-UNet demonstrated that learned segmentation was viable enough to continue developing the V2 learned pipeline.



However, semantic segmentation alone did not solve all downstream problems.



In particular, geological map digitization still required explicit handling of:



- overlapping semantic layers

- non-geological linework

- map-layout clutter

- geological region reconstruction

- exact topology

- GIS vector geometry



### Interpretation



A single binary contact model was insufficient as the complete architecture.



The project therefore evolved from a single learned segmentation concept toward a modular hybrid system.



### Engineering Decision



Retain SE-UNet as an active local/detail candidate while expanding the architecture to include complementary semantic, global-context, region-reasoning, refinement, and deterministic geometry components.



### Status



Completed architectural baseline experiment.



---



## EXP-002 - Multi-Head Geological Semantic Segmentation



### Objective



Determine whether geological and cartographic features should be predicted using independent semantic heads rather than one mutually exclusive segmentation mask.



### Model



MultiHeadGeoMapNet



### Prediction Heads



- contact

- fault

- road

- river

- lake

- strike/dip

- clutter



### Dataset Design



Training moved toward Supervisor150-derived multilayer targets.



The dataset is split at the map level rather than randomly at the tile level in order to reduce leakage between training and validation data originating from the same source map.



The Supervisor150 dataset contains 149 available map entries.



A representative map-level split used:



- 104 training maps

- 22 validation maps

- remaining maps reserved for testing



### Motivation



Geological maps contain overlapping information.



For example:



- a road may cross a geological contact

- a fault may cross multiple geological units

- symbols may lie over geological regions

- lakes may occlude underlying geology



A single mutually exclusive class representation cannot naturally preserve all of these relationships.



### Initial Full-Map Observation



Initial multi-head inference showed that the model could produce separate semantic layers, but full-map predictions also contained significant false detections in page-layout and non-geological areas.



For the map_0103 diagnostic frame:



- total pixels: 3,200,000

- valid geological-unit pixels: 1,717,962

- outside/invalid pixels: 1,482,038

- valid geological fraction: approximately 53.69%

- outside/invalid fraction: approximately 46.31%



This demonstrated that a large portion of the image could act as negative or layout context.



### Interpretation



Feature-aware sampling was emphasizing positive geological features but did not provide sufficient representation of difficult non-geological negatives.



### Engineering Decision



Retain independent semantic heads, but redesign sampling to explicitly include hard-negative page/layout regions.



### Status



Multi-head architecture retained; training strategy revised.



---



## EXP-003 - Hard-Negative Sampling and Balanced V3 Training



### Objective



Reduce false positive detections in page-layout and non-geological regions without destroying geological feature recall.



### Initial Problem



Early full-map multi-head inference produced detections outside the geological map body.



The issue was initially considered as a possible invalid-pixel masking problem.



Further analysis showed that simply ignoring these pixels would remove useful negative supervision.



The more important problem was sampling imbalance.



### Hard-Negative Strategy



Training was modified to deliberately sample difficult negative regions outside the geological footprint.



An experimental sampling strategy used approximately:



- 65% feature-focused crops

- 20% hard-negative crops

- remaining samples as random crops



### Observation



Hard-negative sampling improved suppression of non-geological regions.



However, excessive emphasis on hard negatives could also reduce geological recall.



This demonstrated that background suppression and geological sensitivity must be balanced rather than optimized independently.



### V3 Strategy



The preferred V3 training direction used a more conservative balance:



- approximately 70% feature-focused sampling

- approximately 10% hard-negative sampling

- approximately 20% random sampling



The experiment also used warm-start training and reduced the influence of hard-negative loss so that background suppression would not dominate feature learning.



### Representative Training Result



During the V3 experiment:



- epoch 2 validation mean-head IoU was approximately 0.490

- epoch 3 showed instability

- epoch 2 remained the stronger checkpoint for comparison



### Interpretation



Hard negatives are necessary because full geological-map pages contain substantial non-geological content.



However, aggressive hard-negative training can overcorrect the model.



The best direction is balanced feature, random, and hard-negative sampling.



### Engineering Decision



Retain hard-negative supervision as part of the training design, but use it as a controlled fraction of training rather than the dominant sampling mode.



Model selection must consider full-map qualitative behavior in addition to aggregate validation metrics.



### Status



Completed training-strategy experiment; balanced sampling retained as the preferred direction.


---

## EXP-004 - SAM2 Geological Body Candidate Refinement

### Objective

Evaluate whether SAM2 can refine geological bodies after another stage has already proposed a candidate region.

### Candidate Generation

Early candidate generation based on exact or quantized colors missed geological regions.

The proposer was therefore changed to use LAB color clustering followed by connected-component extraction.

For the representative map_0103 experiment:

- 14 LAB KMeans clusters were used
- minimum component area was 180 pixels
- minimum interior distance was 4 pixels
- 32 candidate geological regions were generated

Disconnected bodies with similar colors were treated as separate candidate components.

### Validation Strategy

SAM2 masks were not accepted automatically.

Candidate masks were evaluated using measurements including:

- candidate-to-mask IoU
- area ratio
- seed/candidate coverage
- centroid displacement
- leakage outside the proposed geological region

### Successful Examples

Representative accepted candidates included:

#### Candidate 12

- IoU: approximately 0.970
- area ratio: approximately 1.022
- candidate coverage: approximately 0.995
- centroid shift: approximately 2.16 pixels

#### Candidate 13

- IoU: approximately 0.989
- area ratio: approximately 1.009
- centroid shift: approximately 0.37 pixels

Candidate 13 was one of the strongest examples and demonstrated that SAM2 can closely follow a well-constrained geological body.

#### Candidate 21

- IoU: approximately 0.888
- area ratio: approximately 1.123
- centroid shift: approximately 2.34 pixels

### Interpretation

SAM2 can provide high-quality local segmentation when the geological candidate supplied to it is compact and sufficiently constrained.

### Engineering Decision

Retain SAM2 as a possible local refinement mechanism.

Do not assume that a strong result on selected compact candidates makes SAM2 reliable as the primary geological segmentation system.

### Status

Successful for restricted candidate refinement.

---

## EXP-005 - SAM2 Leakage Failure and Primary-Role Rejection

### Objective

Determine whether SAM2 candidate refinement remains reliable across more difficult geological body shapes.

### Failure Examples

#### Candidate 26

- IoU: approximately 0.318
- area ratio: approximately 3.15
- centroid shift: approximately 47.62 pixels

The generated SAM2 mask expanded substantially beyond the proposed geological body.

#### Candidate 27

- IoU: approximately 0.340
- area ratio: approximately 2.85
- centroid shift: approximately 66.97 pixels

This candidate also showed substantial mask leakage.

### Qualitative Observation

Leakage was particularly problematic for some elongated, pale, or weakly constrained geological bodies.

The segmentation could follow visually plausible neighboring areas rather than remaining restricted to the intended geological unit.

### Interpretation

SAM2's general segmentation capability does not guarantee geological correctness.

A visually plausible segmentation can still violate the intended geological region.

### Engineering Decision

SAM2 was rejected as the primary geological contact or geological-body generator.

It remains useful only when:

1. another component has already identified a plausible geological region,
2. SAM2 is used locally,
3. the resulting mask passes geological/candidate validation.

### Architectural Consequence

The project moved away from:

SAM2 -> geological boundary

toward:

geological evidence / region proposal -> local SAM2 refinement if needed -> validation -> topology reconstruction

### Status

Primary role rejected; support/refinement role retained.

---

## EXP-006 - SAM2-Derived Raster Topology Repair

### Objective

Test whether validated segmentation masks could be transformed into a reliable geological boundary network using deterministic raster repair.

### Processing Stages

The experimental pipeline used:

- validated region masks
- coarse boundary extraction
- boundary snapping
- endpoint detection
- gap repair
- junction reconstruction

### Representative Result

One map_0103 run produced:

- coarse boundary pixels: 4,310
- snapped boundary pixels: 5,006
- endpoints before repair: 52
- accepted gap connections: 7
- final boundary pixels: 5,027
- final endpoints: 43

### Qualitative Failure

Despite apparently reasonable numerical changes, visual inspection showed:

- false geological shapes
- duplicated or parallel edges
- incorrect geometry
- excessive boundary expansion
- unreliable intersections
- unstable junction reconstruction

The endpoint count decreased, but the geological topology did not become reliably correct.

### Interpretation

Reducing endpoints or connecting gaps is not equivalent to recovering geological topology.

A boundary network can become numerically more connected while becoming geologically less correct.

### Engineering Decision

Reject blind skeleton/endpoint/gap repair as the primary topology reconstruction strategy.

Preserve this experiment as negative evidence.

The failure directly motivated greater emphasis on reconstructing geological regions first and deriving exact boundaries from region relationships.

### Status

Failed experiment / architecture-changing negative result.

---

## EXP-007 - Color-Region Reconstruction

### Objective

Test whether geological boundaries can be recovered more reliably by reconstructing geological regions first instead of directly predicting or repairing boundary pixels.

### Representative Configuration

For the map_0103 experiment:

- geological color clusters: 12
- minimum region area: 250 pixels
- linework fill distance: 8 pixels

### Representative Result

The reconstructed region representation produced:

- boundary pixels: approximately 24,707
- junction pixels: approximately 340

The resulting boundaries were visually substantially cleaner and more continuous than the direct learned-affinity boundary raster on the same representative map.

### Key Observation

The strongest geometry was obtained when the system first determined which geological region each pixel belonged to and only afterward calculated interfaces between neighboring regions.

### Remaining Problems

The result was not yet final GIS geometry.

Observed limitations included:

- raster stair-stepping along diagonal contacts
- some missing or interrupted contacts
- interference from linework and intersections
- artificial holes around cartographic symbols
- dependence on color clustering

### Interpretation

Boundary extraction is better formulated as a consequence of geological region reconstruction rather than as an isolated boundary-pixel detection problem.

### Engineering Decision

Adopt region-first reconstruction as an important architectural principle.

Color-region reconstruction remains an important current component for suitable colored maps, but it must be complemented by more palette-independent approaches for broader generalization.

### Status

Successful architecture-changing experiment.

---

## EXP-008 - GeoRegion Affinity Learning

### Objective

Determine whether a learned model can infer geological region relationships without depending directly on a fixed map color palette.

### Model

GeoRegionAffinityNet

### Prediction Targets

The model predicts:

- horizontal same/different-region affinity
- vertical same/different-region affinity
- geological boundary probability

Targets are derived from geological unit-label maps.

### Dataset

Supervisor150 map-level splitting was used.

Representative training configuration:

- training maps: 104
- validation maps: 22
- training samples: 832
- validation samples: 88
- crop size: 256
- base channels: 16
- different-region affinity weight: 12
- boundary positive weight: 15
- palette randomization probability: 0.35

Training inputs included variations such as:

- color
- aged
- grayscale
- black-and-white
- palette-randomized geological units

### Training Results

Validation performance improved substantially over the six-epoch experiment.

Representative combined validation scores were:

- epoch 1: approximately 0.129
- epoch 2: approximately 0.222
- epoch 3: approximately 0.290
- epoch 4: approximately 0.260
- epoch 5: approximately 0.289
- epoch 6: approximately 0.316

The best checkpoint was epoch 6.

Representative epoch-6 metrics:

- boundary IoU: approximately 0.320
- horizontal affinity IoU: approximately 0.307
- vertical affinity IoU: approximately 0.311
- combined validation score: approximately 0.316

### Interpretation

The model learned meaningful local geological relationship evidence despite variation in map appearance and palette.

This supports the hypothesis that same-region/different-region reasoning can provide more transferable information than fixed color identity.

### Engineering Decision

Retain GeoRegion affinity learning as an active research component for palette-independent geological region reasoning.

### Status

Successful learning experiment; downstream reconstruction still required.

---

## EXP-009 - Direct GeoRegion Affinity Inference

### Objective

Determine whether GeoRegion affinity and boundary probability outputs can directly replace region reconstruction and serve as final geological geometry.

### Representative Inference

For map_0103:

- inference tiles: 117
- tile size: 256
- overlap: 64
- CPU inference time: approximately 4.3 seconds
- direct boundary foreground fraction: approximately 0.389%
- affinity-derived boundary fraction: approximately 0.811%
- combined boundary fraction: approximately 0.403%

### Qualitative Result

The learned boundary representation was more fragmented and less geometrically complete than the color-region reconstruction on this clean colored example.

The probability raster contained useful geological evidence, but direct thresholding did not produce sufficiently reliable GIS geometry.

### Interpretation

Successful learned evidence does not imply successful geometric reconstruction.

The learned model answers a local relationship question, while final geological digitization requires globally consistent regions and topology.

### Engineering Decision

Do not treat the affinity probability raster as final geometry.

The intended architecture becomes:

learned affinity evidence -> geological region reconstruction -> exact topology -> vector geometry

Potential future reconstruction methods include:

- graph-based region assembly
- watershed-style reconstruction
- connected-region reasoning
- union-find reconstruction

### Status

Direct-geometry role rejected; evidence role retained.

---

## EXP-010 - Exact Label-Interface Topology

### Objective

Generate geological contacts directly from reconstructed region labels while preserving exact adjacency and shared topology.

### Method

For each pair of horizontally or vertically adjacent pixels:

- if the geological labels are identical, no contact is created
- if the geological labels differ, their shared pixel-cell edge becomes an exact geological interface

Interfaces are grouped by the unordered pair of geological labels they separate.

Junction vertices are preserved explicitly.

The outer geological-map perimeter is handled separately from internal geological contacts.

### Initial Representative Result

For map_0103, the exact interface analysis identified approximately:

- 39 internal geological label pairs
- 29,987 internal interface edges

This demonstrated that the geological contact network could be derived deterministically from region relationships without relying on skeletonization.

### Advantages Observed

The method provided:

- explicit region adjacency
- shared interfaces
- deterministic geological contacts
- pair-aware geometry
- explicit junction representation
- separation between internal contacts and the outer perimeter

### Remaining Limitation

Exact pixel-cell interfaces preserve topology but retain raster staircase geometry, especially along diagonal contacts.

### Engineering Decision

Adopt exact label-interface extraction as the basis for topology-preserving geological vectorization.

Perform geometric smoothing only after topology has been established.

### Status

Successful / strong current topology component.

---

## EXP-011 - Cartographic Symbol-Hole Diagnosis

### Objective

Determine why small false closed geological boundaries appeared around repeated dark cartographic symbols.

### Diagnostic Analysis

The geological map-support mask for map_0103 contained 27 invalid connected components:

- 1 border-connected exterior component
- 26 enclosed internal holes

Most enclosed holes corresponded to repeated small dark cartographic symbols.

Many were approximately:

- 17 x 17 pixels
- approximately 213 to 230 pixels in area

One larger enclosed component was approximately:

- 28 x 27 pixels
- 489 pixels in area

### Root Cause

The color-region pipeline excluded sufficiently dark pixels when constructing the geological color candidate mask.

KMeans geological labeling was then performed only inside that support mask.

The nearest-label filling stage also operated only inside the same support.

Therefore, once a dark symbol became a hole in the geological support mask, the pipeline had no mechanism to assign underlying geological support through that location.

The symbol could consequently become a false closed boundary during later topology extraction.

### Interpretation

This was not fundamentally a vectorization problem.

Removing the resulting rings after vectorization would treat the symptom rather than the cause.

### Engineering Decision

Separate rendered/color support from geological topology support.

Restore suitable enclosed nuisance holes before exact topology reconstruction.

### Status

Root cause identified.

---

## EXP-012 - Geological Topology-Support Correction

### Objective

Test whether small enclosed cartographic-symbol holes can be restored without incorrectly treating dark symbols as geological color classes.

### Method

The revised color-region extractor distinguishes:

- raw map support
- geological topology support
- restored nuisance-hole regions

Candidate nuisance holes are identified from enclosed invalid connected components while excluding the border-connected exterior.

Selected holes are restored only in topology support.

Geological labels are then propagated through these restored regions from nearby valid geological labels.

The dark cartographic symbol itself is not introduced as a geological KMeans class.

### Representative map_0103 Result

The revised extractor inspected:

- 26 enclosed components

It restored:

- 26 nuisance holes

The reconstructed map produced:

- 12 geological color classes
- 24,889 boundary pixels
- 351 junction pixels

### Interpretation

The experiment confirmed the earlier component diagnosis at the geological-support level.

It also established a broader architectural distinction:

The pixels used to interpret visible map appearance do not always need to be identical to the pixels used to represent underlying geological topology.

### Engineering Decision

Retain separate raw and topology-support masks.

Perform symbol-hole correction upstream before exact topology/vectorization.

### Status

Implemented and successfully executed.

---

## EXP-013 - Exact Topology v4 to v5 After Symbol-Hole Correction

### Objective

Measure how corrected geological topology support changes exact label-interface reconstruction.

### v4 Reference

Before the revised topology-support correction, the representative exact-topology result contained:

- internal geological label pairs: 39
- exact internal edges: 29,987
- exact outer edges: 7,238
- internal polylines: 99
- outer polylines: 2
- exact junction vertices: 69

### v5 Result

After using the revised topology-support representation:

- internal geological label pairs: 39
- exact internal edges: 30,235
- exact outer edges: 7,238
- internal polylines: 92
- outer polylines: 2
- exact junction vertices: 72

### Difference

From v4 to v5:

- internal label pairs: unchanged
- internal edges: +248
- outer edges: unchanged
- internal polylines: -7
- outer polylines: unchanged
- junction vertices: +3

### Interpretation

The unchanged outer-edge count indicates that the map perimeter was not altered by the internal symbol-hole correction.

The internal topology changed while preserving the same number of geological label-pair relationships.

The reduction from 99 to 92 internal polylines is consistent with reduced fragmentation in parts of the internal contact network, although numerical counts alone are not sufficient to prove geometric correctness.

### Engineering Decision

Retain the topology-support correction and v5-compatible exact vectorization.

Continue to require visual and topology-aware validation rather than declaring success from edge/polyline counts alone.

### Status

Implemented / current exact-topology revision.

---

## EXP-014 - Topology-Preserving Smoothing Limitation

### Objective

Determine how to convert exact raster-derived geological interfaces into visually smooth GIS boundaries without changing geological topology.

### Current Observation

Exact label-interface extraction successfully preserves geological adjacency and junction structure.

However, diagonal interfaces can contain visible pixel-grid stair-stepping.

Earlier smoothing attempts demonstrated that aggressive raster or polyline smoothing can introduce new problems including:

- displaced boundaries
- lost contacts
- duplicated geometry
- changed junction locations
- narrow-region distortion
- excessive geometric deviation

### Interpretation

The remaining problem is no longer simply boundary detection.

It is a constrained computational-geometry problem:

How can a boundary be simplified or smoothed while preserving the geological relationships encoded by the exact topology?

### Current Direction

The planned approach is junction-locked, topology-constrained vector smoothing.

Important constraints include:

- preserve geological junctions
- preserve region adjacency
- preserve shared contacts
- prevent gaps
- prevent overlaps
- protect narrow geological units
- limit geometric displacement from the exact interface

Potential evaluation measurements include:

- maximum boundary displacement
- mean boundary displacement
- Chamfer distance
- Hausdorff-style distance
- junction displacement
- adjacency preservation
- polygon validity
- gap/overlap counts

### Engineering Decision

Do not apply unconstrained smoothing merely to improve visual appearance.

Topology must remain authoritative.

### Status

Active research problem.

---

## Experiment Registry Summary

The experiments recorded here demonstrate the major architectural progression of the GeoMap R&D system:

1. classical geological map processing established the initial working baseline
2. learned segmentation introduced adaptive geological perception
3. multi-head prediction addressed overlapping semantic layers
4. hard-negative training addressed full-page false positives
5. SAM2 demonstrated useful local refinement but unreliable unrestricted segmentation
6. failed raster topology repair demonstrated that connectivity metrics alone do not guarantee geological correctness
7. region-first reconstruction produced stronger geological structure
8. GeoRegion affinity introduced palette-independent relationship learning
9. direct affinity probabilities proved insufficient as final geometry
10. exact label interfaces provided deterministic geological topology
11. topology-support correction addressed cartographic-symbol holes upstream
12. exact vectorization provided GIS-oriented geometry
13. topology-constrained smoothing remains an active geometric refinement problem

The final production architecture remains under evaluation. Experimental components should be promoted based on reproducible cross-map evidence rather than performance on a single representative map.


