"""
One-command runner: scanned geological map -> separate GIS layers.

    python -m faria_geomap_rnd.run_map --input path/to/map.tif --output-dir out/

Steps (no manual input per map):
  1. Read the image and its georeference (GeoTIFF CRS when present).
  2. Multi-view restoration (pipelines/map_restoration.py).
  3. Colour-region reconstruction (models/refinement/
     color_region_boundary_extractor.py).
  4. Unit polygons and contacts from the region labels.
  5. Linear-feature extraction (models/refinement/linear_feature_extractor.py),
     traced into polylines and sorted into faults, veins and other lines.
  6. Write <map_id>.gpkg (one layer per feature type), one GeoJSON per layer,
     a QA overlay and run_report.json.

Run with --input-dir to process every image in a folder.
"""

from __future__ import annotations

import argparse
import json
import math
import time
import traceback
from pathlib import Path

import cv2
import numpy as np

from faria_geomap_rnd.gis_export import vectorize
from faria_geomap_rnd.gis_export.experts import ExpertOutputs, run_experts
from faria_geomap_rnd.gis_export.georef import (
    GeoReference,
    read_georeference,
    read_image_bgr,
)
from faria_geomap_rnd.gis_export.layers import build_layer, write_layers
from faria_geomap_rnd.models.refinement import color_region_boundary_extractor as cre
from faria_geomap_rnd.models.refinement import linear_feature_extractor as lfe
from faria_geomap_rnd.pipelines import map_restoration

# More colour clusters than the extractor default (12) so pale and similar
# fills separate; tiny clusters are merged back by the small-region step.
DEFAULT_K = 20

IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".tif", ".tiff"}


# ---------------------------------------------------------------------
# STEPS
# ---------------------------------------------------------------------


def prepare_image(
    image: np.ndarray,
    max_side: int,
) -> tuple[np.ndarray, float]:
    h, w = image.shape[:2]
    longest = max(h, w)
    if max_side <= 0 or longest <= max_side:
        return image, 1.0
    scale = max_side / float(longest)
    resized = cv2.resize(
        image,
        (int(round(w * scale)), int(round(h * scale))),
        interpolation=cv2.INTER_AREA,
    )
    return resized, scale


def map_frame_mask(colored: np.ndarray) -> np.ndarray:
    """
    The mapped area: large coloured areas closed over the white gaps
    between them, with enclosed holes filled. Small separate blobs such as
    legend swatches are left out.
    """
    from scipy import ndimage

    size = max(15, int(0.02 * max(colored.shape)) | 1)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (size, size))
    closed = cv2.morphologyEx(colored.astype(np.uint8), cv2.MORPH_CLOSE, kernel)
    filled = ndimage.binary_fill_holes(closed).astype(np.uint8)

    n, comp, stats, _ = cv2.connectedComponentsWithStats(filled, connectivity=8)
    min_area = 0.01 * colored.size
    keep = stats[:, cv2.CC_STAT_AREA] >= min_area
    keep[0] = False
    return keep[comp].astype(np.uint8)


def cluster_colours(
    image: np.ndarray,
    mask: np.ndarray,
    k: int,
    sample_size: int = 200_000,
) -> np.ndarray:
    """
    K-means in LAB on a random sample of the masked pixels, then every
    masked pixel takes its nearest centre. Much faster than clustering all
    pixels and gives the same palette for practical purposes.
    """
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    ys, xs = np.nonzero(mask)
    pixels = lab[ys, xs].astype(np.float32)
    if len(pixels) < k:
        raise RuntimeError("Not enough coloured pixels to cluster.")

    rng = np.random.default_rng(0)
    take = rng.choice(len(pixels), min(len(pixels), sample_size), replace=False)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)
    _, _, centers = cv2.kmeans(
        pixels[take], k, None, criteria, 4, cv2.KMEANS_PP_CENTERS
    )

    assigned = np.empty(len(pixels), dtype=np.int16)
    for start in range(0, len(pixels), 1_000_000):
        chunk = pixels[start : start + 1_000_000]
        d = ((chunk[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        assigned[start : start + 1_000_000] = d.argmin(axis=1)

    labels = np.full(mask.shape, -1, dtype=np.int16)
    labels[ys, xs] = assigned
    return labels


def extract_region_labels(
    image: np.ndarray,
    k: int,
    min_region_area: int,
    model_boundaries: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """
    Label every pixel of the mapped area with a unit id.

    - Coloured fill is clustered into k colour units (after a median blur so
      halftone/stippled fills read as one colour).
    - White or near-white ground inside the mapped area is its own unit
      (id k), so outlines between coloured and white areas are kept instead
      of being filled over.
    - Thin linework, text and symbols take the label of the nearest unit.
    - Regions smaller than min_region_area merge into a neighbour.
    - Areas are split along printed dark lines and, when given, along
      boundaries predicted by the trained models (model_boundaries).
    """
    from scipy import ndimage
    from skimage.morphology import skeletonize

    smooth = cv2.medianBlur(image, 5)
    hsv = cv2.cvtColor(smooth, cv2.COLOR_BGR2HSV)
    sat, val = hsv[:, :, 1], hsv[:, :, 2]

    colored = (sat >= cre.MIN_FILL_SATURATION) & (val > cre.DARK_VALUE_THRESHOLD)
    white = (sat < 25) & (val >= 200)
    frame = map_frame_mask(colored) > 0

    labels = cluster_colours(smooth, colored & frame, k)
    white_id = k
    labels[white & frame] = white_id

    # Linework, text and symbols inside the frame: nearest unit label.
    missing = frame & (labels < 0)
    if missing.any():
        _, (rows, cols) = ndimage.distance_transform_edt(
            labels < 0, return_indices=True
        )
        labels[missing] = labels[rows[missing], cols[missing]]
    labels[~frame] = -1

    labels, absorbed = absorb_small_regions(labels, min_region_area)

    printed = printed_line_mask(image) & frame
    if model_boundaries is not None:
        # One-pixel centre lines are enough to separate 4-connected faces.
        printed |= skeletonize(model_boundaries & frame)
    faces, face_unit = split_faces_on_printed_lines(labels, printed, min_region_area)
    labels = np.where(faces >= 0, face_unit[np.maximum(faces, 0)], -1).astype(
        labels.dtype
    )

    info = {
        "map_body_pixels": int(frame.sum()),
        "white_ground_pixels": int((labels == white_id).sum()),
        "small_regions_absorbed": absorbed,
        "printed_line_pixels": int(printed.sum()),
        "faces": int(len(face_unit)),
        "unit_classes": int(len(np.unique(labels[labels >= 0]))),
    }
    return labels, faces, info


def printed_line_mask(image: np.ndarray) -> np.ndarray:
    """
    Dark printed linework (unit outlines, faults, contacts). Thin dark
    strokes only: large dark fills are not lines.
    """
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    dark = ((hsv[:, :, 2] <= 110) & (hsv[:, :, 1] <= 120)).astype(np.uint8)

    # Remove dark areas wider than a line.
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    wide = cv2.morphologyEx(dark, cv2.MORPH_OPEN, kernel)
    return (dark > 0) & (wide == 0)


def split_faces_on_printed_lines(
    labels: np.ndarray,
    printed: np.ndarray,
    min_area: int,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Split unit regions into faces along printed lines, so two areas of the
    same colour separated by a drawn boundary become separate polygons.

    Returns (faces, face_unit): a face-id raster (-1 outside the map) and
    the unit id of each face.
    """
    from scipy import ndimage
    from skimage.measure import label as label_regions

    cut = labels.astype(np.int32).copy()
    cut[printed] = -1
    faces = label_regions(cut + 1, connectivity=1, background=0) - 1

    sizes = np.bincount(faces[faces >= 0].ravel())
    small = (faces >= 0) & (sizes[np.maximum(faces, 0)] < min_area)
    faces[small] = -1

    # Line pixels and tiny faces take the nearest kept face.
    inside = labels >= 0
    missing = inside & (faces < 0)
    if missing.any() and (faces >= 0).any():
        _, (rows, cols) = ndimage.distance_transform_edt(faces < 0, return_indices=True)
        faces[missing] = faces[rows[missing], cols[missing]]
    faces[~inside] = -1

    # Renumber faces 0..n-1 and record each face's unit.
    ids, faces_flat = np.unique(faces, return_inverse=True)
    faces = faces_flat.reshape(faces.shape) - (1 if ids[0] < 0 else 0)
    faces[~inside] = -1

    n = int(faces.max()) + 1 if faces.max() >= 0 else 0
    face_unit = np.zeros(n, dtype=np.int32)
    sel = faces >= 0
    # Majority unit per face (lines may have mixed labels).
    pairs = faces[sel].astype(np.int64) * 1000 + labels[sel].astype(np.int64)
    uniq, counts = np.unique(pairs, return_counts=True)
    best = {}
    for key, cnt in zip(uniq, counts):
        f, u = divmod(int(key), 1000)
        if cnt > best.get(f, (0, -1))[0]:
            best[f] = (cnt, u)
    for f, (_, u) in best.items():
        face_unit[f] = u

    return faces.astype(np.int32), face_unit


def absorb_small_regions(
    labels: np.ndarray,
    min_area: int,
) -> tuple[np.ndarray, int]:
    """
    Merge unit regions smaller than min_area into their nearest neighbour.

    Uses 4-connectivity, the same as polygonization, so no polygon smaller
    than min_area pixels is exported. Pixels outside the map (label < 0)
    stay outside.
    """
    from scipy import ndimage

    small = np.zeros(labels.shape, dtype=bool)
    count = 0
    for uid in np.unique(labels[labels >= 0]):
        n, comp, stats, _ = cv2.connectedComponentsWithStats(
            (labels == uid).astype(np.uint8),
            connectivity=4,
        )
        tiny = stats[:, cv2.CC_STAT_AREA] < min_area
        tiny[0] = False
        count += int(tiny.sum())
        small |= tiny[comp]

    if not small.any():
        return labels, 0

    keep = (labels >= 0) & ~small
    if not keep.any():
        return labels, 0

    _, (rows, cols) = ndimage.distance_transform_edt(~keep, return_indices=True)
    out = labels.copy()
    out[small] = labels[rows[small], cols[small]]
    return out, count


def extract_line_mask(
    image_path: Path,
    work_dir: Path,
) -> np.ndarray:
    restoration_dir = work_dir / "restoration"
    lines_dir = work_dir / "linear_features"

    map_restoration.run(input_path=image_path, output_dir=restoration_dir)
    lfe.run(
        restoration_dir=restoration_dir,
        output_dir=lines_dir,
        original_path=None,
        initial_percentile=84.0,
        max_gap=42.0,
        max_angle_deg=18.0,
    )

    mask = cv2.imread(
        str(lines_dir / "05_final_linear_feature_mask.png"),
        cv2.IMREAD_GRAYSCALE,
    )
    if mask is None:
        raise RuntimeError("Linear-feature extractor produced no mask.")
    return (mask > 0).astype(np.uint8)


def build_unit_rows(
    labels: np.ndarray,
    faces: np.ndarray,
    image: np.ndarray,
    ref: GeoReference,
    simplify_px: float,
) -> list[dict]:
    colours = vectorize.unit_colour_table(image, labels)
    records = vectorize.polygonize_units(
        faces,
        ref.transform,
        simplify_tolerance=simplify_px * ref.pixel_size(),
    )
    sel = faces >= 0
    ids, first = np.unique(faces[sel], return_index=True)
    face_unit = dict(zip(ids.tolist(), labels[sel][first].tolist()))

    rows = []
    for record in records:
        geom = record["geometry"]
        face_id = record["unit_id"]
        unit_id = int(face_unit[face_id])
        rows.append(
            {
                "face_id": face_id,
                "unit_id": unit_id,
                "legend_code": None,
                "unit_name": None,
                "legend_color": colours.get(unit_id),
                "area": float(geom.area),
                "confidence": 0.5,
                "geometry": geom,
            }
        )
    return rows


def build_contact_rows(unit_rows: list[dict]) -> list[dict]:
    contacts = vectorize.extract_contacts(unit_rows)
    rows = []
    for i, c in enumerate(contacts, start=1):
        rows.append(
            {
                "contact_id": i,
                "left_unit": c["left_unit"],
                "right_unit": c["right_unit"],
                "certainty": None,
                "length": float(c["geometry"].length),
                "confidence": 0.5,
                "geometry": c["geometry"],
            }
        )
    return rows


def map_body_mask(labels: np.ndarray) -> np.ndarray:
    """
    Area covered by the map itself: unit pixels, closed over the white gaps
    between units (lakes, unmapped ground) and with holes filled. Used to
    drop legend, title and margin linework.
    """
    from scipy import ndimage

    units = (labels >= 0).astype(np.uint8)
    size = max(15, int(0.02 * max(labels.shape)) | 1)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (size, size))
    closed = cv2.morphologyEx(units, cv2.MORPH_CLOSE, kernel)
    return ndimage.binary_fill_holes(closed).astype(np.uint8)


def model_line_masks(
    experts: ExpertOutputs | None,
    body: np.ndarray,
    threshold: float,
) -> dict[str, tuple[np.ndarray, np.ndarray, str]]:
    """
    Line layers the trained models can provide:
    {kind: (mask, probability, method)} for fault, road and river.
    """
    if experts is None:
        return {}

    out = {}
    fault_prob, method = experts.probability("fault")
    if fault_prob is not None:
        out["fault"] = ((fault_prob >= threshold) & (body > 0), fault_prob, method)
    for kind in ("road", "river"):
        prob, kind_method = experts.probability(kind)
        if prob is not None:
            out[kind] = ((prob >= threshold) & (body > 0), prob, kind_method)
    return out


def build_line_rows(
    line_mask: np.ndarray,
    labels: np.ndarray,
    image: np.ndarray,
    ref: GeoReference,
    min_length_px: float,
    experts: ExpertOutputs | None = None,
    model_threshold: float = 0.5,
) -> tuple[dict[str, list[dict]], dict]:
    contact_px = vectorize.contact_raster(labels, width_px=3)
    body = map_body_mask(labels)
    diagonal = math.hypot(*labels.shape)

    image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    out = {"faults": [], "veins": [], "other_lines": []}
    dropped_as_contact = 0
    dropped_outside_map = 0
    dropped_for_model = 0

    # Text and symbols the models mark as clutter are not linework.
    if experts is not None:
        clutter, _ = experts.probability("clutter")
        if clutter is not None:
            line_mask = line_mask & (clutter < model_threshold)

    # Trained models first: each provides the layer it was trained for.
    model_masks = model_line_masks(experts, body, model_threshold)
    covered = np.zeros(labels.shape, dtype=np.uint8)
    for kind, (mask, prob, method) in model_masks.items():
        for polyline in vectorize.skeleton_polylines(mask, min_length_px):
            geom = vectorize.pixel_line_to_geometry(polyline, ref.transform)
            if geom.is_empty or geom.length <= 0:
                continue
            pts = np.round(polyline).astype(int)
            confidence = float(prob[pts[:, 1], pts[:, 0]].mean())
            colour = vectorize.sample_line_colour(image, image_hsv, mask, polyline)
            common = {
                "line_color": colour["hex"],
                "length": float(geom.length),
                "class_method": method,
                "confidence": round(confidence, 3),
                "geometry": geom,
            }
            if kind == "fault":
                out["faults"].append(
                    {
                        "fault_id": len(out["faults"]) + 1,
                        "fault_type": None,
                        "certainty": None,
                        **common,
                    }
                )
            else:
                out["other_lines"].append(
                    {"line_id": len(out["other_lines"]) + 1, "kind": kind, **common}
                )
        covered |= cv2.dilate(mask.astype(np.uint8), np.ones((7, 7), np.uint8))

    polylines = vectorize.skeleton_polylines(line_mask, min_length_px=min_length_px)

    for polyline in polylines:
        # Legend, title and margin linework is not map content.
        if vectorize.contact_overlap_fraction(polyline, body) < 0.5:
            dropped_outside_map += 1
            continue

        # Already delivered by a trained model.
        if vectorize.contact_overlap_fraction(polyline, covered) >= 0.5:
            dropped_for_model += 1
            continue

        length_px = float(np.sum(np.hypot(*np.diff(polyline, axis=0).T)))
        colour = vectorize.sample_line_colour(image, image_hsv, line_mask, polyline)
        layer, kind, confidence = vectorize.classify_line(
            colour=colour,
            length_px=length_px,
            straightness=vectorize.straightness(polyline),
            contact_overlap=vectorize.contact_overlap_fraction(polyline, contact_px),
            image_diagonal_px=diagonal,
        )
        if layer == "drop_contact":
            dropped_as_contact += 1
            continue

        # When a model provides faults or rivers, the rules do not add more.
        if (layer == "faults" and "fault" in model_masks) or (
            kind == "river" and "river" in model_masks
        ):
            dropped_for_model += 1
            continue

        geom = vectorize.pixel_line_to_geometry(polyline, ref.transform)
        if geom.is_empty or geom.length <= 0:
            continue

        common = {
            "line_color": colour["hex"],
            "length": float(geom.length),
            "class_method": "heuristic_v0",
            "confidence": confidence,
            "geometry": geom,
        }
        if layer == "faults":
            out["faults"].append(
                {
                    "fault_id": len(out["faults"]) + 1,
                    "fault_type": None,
                    "certainty": None,
                    **common,
                }
            )
        elif layer == "veins":
            out["veins"].append(
                {"vein_id": len(out["veins"]) + 1, "vein_type": None, **common}
            )
        else:
            out["other_lines"].append(
                {"line_id": len(out["other_lines"]) + 1, "kind": kind, **common}
            )

    info = {
        "traced_polylines": len(polylines),
        "dropped_as_contact": dropped_as_contact,
        "dropped_outside_map": dropped_outside_map,
        "dropped_for_model": dropped_for_model,
        "model_layers": {k: v[2] for k, v in model_masks.items()},
    }
    return out, info


def make_qa_overlay(
    image: np.ndarray,
    labels: np.ndarray,
    line_rows: dict[str, list[dict]],
    ref: GeoReference,
) -> np.ndarray:
    """
    Faded map with bold boundaries: contacts black, faults red, veins green,
    other lines grey. Line width scales with image size so it stays visible
    when the image is viewed zoomed out.
    """
    width = max(1, int(round(max(labels.shape) / 2500.0)))

    # Fade the scan so the drawn lines stand out.
    overlay = cv2.addWeighted(image, 0.55, np.full_like(image, 255), 0.45, 0)

    contacts = vectorize.contact_raster(labels, width_px=width) > 0
    outer = (labels >= 0).astype(np.uint8)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * width + 1,) * 2)
    outer_edge = cv2.morphologyEx(outer, cv2.MORPH_GRADIENT, kernel) > 0
    overlay[contacts | outer_edge] = (0, 0, 0)

    inverse = ~ref.transform
    colours = {
        "other_lines": (130, 130, 130),
        "veins": (0, 170, 0),
        "faults": (0, 0, 230),
    }
    for name in ["other_lines", "veins", "faults"]:
        for row in line_rows[name]:
            pts = np.array(
                [inverse * xy for xy in row["geometry"].coords],
                dtype=np.float64,
            )
            pts = (pts - 0.5).round().astype(np.int32).reshape(-1, 1, 2)
            cv2.polylines(
                overlay,
                [pts],
                False,
                colours[name],
                thickness=width + 1,
                lineType=cv2.LINE_AA,
            )

    return overlay


# ---------------------------------------------------------------------
# RUN
# ---------------------------------------------------------------------


def run_map(
    input_path: Path,
    output_dir: Path,
    k: int = DEFAULT_K,
    max_side: int = 4000,
    min_region_area: int = cre.MIN_REGION_AREA,
    simplify_px: float = 1.0,
    min_line_length_px: float = 15.0,
    models_dir: Path | None = None,
    use_models: bool = True,
    device: str = "auto",
    model_threshold: float = 0.5,
) -> dict:
    started = time.time()
    map_id = input_path.stem
    map_out = output_dir / map_id
    work_dir = map_out / "work"
    work_dir.mkdir(parents=True, exist_ok=True)

    report: dict = {
        "map_id": map_id,
        "input": str(input_path),
        "status": "running",
        "steps": {},
    }

    original = read_image_bgr(input_path)
    image, scale = prepare_image(original, max_side)
    ref = read_georeference(input_path).scaled(scale)

    report["input_shape"] = list(original.shape[:2])
    report["processing_shape"] = list(image.shape[:2])
    report["georeference"] = ref.to_report()
    report["measure_units"] = (
        "CRS units (area in units^2)"
        if ref.georeferenced
        else "original-image pixels (area in px^2)"
    )
    if not ref.georeferenced:
        report.setdefault("warnings", []).append(
            "Input has no CRS. Layers are in pixel space with no CRS assigned. "
            "Automatic grid/corner georeferencing is not built yet."
        )

    processing_path = work_dir / "processing_input.png"
    cv2.imwrite(str(processing_path), image)

    experts = None
    model_boundaries = None
    if use_models:
        t = time.time()
        experts = run_experts(image, models_dir, device)
        report["models"] = {**experts.to_report(), "seconds": round(time.time() - t, 1)}
        if not experts.used:
            report.setdefault("warnings", []).append(
                "No trained model checkpoints found; colour and rule steps only."
            )

        boundary_maps = []
        contact_prob, _ = experts.probability("contact")
        if contact_prob is not None:
            boundary_maps.append(contact_prob)
        if experts.region_boundary is not None:
            boundary_maps.append(experts.region_boundary)
        if boundary_maps:
            model_boundaries = np.max(boundary_maps, axis=0) >= model_threshold

    t = time.time()
    labels, faces, region_info = extract_region_labels(
        image, k, min_region_area, model_boundaries
    )
    report["steps"]["regions"] = {**region_info, "seconds": round(time.time() - t, 1)}

    t = time.time()
    unit_rows = build_unit_rows(labels, faces, image, ref, simplify_px)
    contact_rows = build_contact_rows(unit_rows)
    report["steps"]["polygons"] = {
        "units": len(unit_rows),
        "contacts": len(contact_rows),
        "invalid_polygons": sum(not r["geometry"].is_valid for r in unit_rows),
        "seconds": round(time.time() - t, 1),
    }

    t = time.time()
    line_mask = extract_line_mask(processing_path, work_dir)
    line_rows, line_info = build_line_rows(
        line_mask,
        labels,
        image,
        ref,
        min_line_length_px,
        experts=experts,
        model_threshold=model_threshold,
    )
    report["steps"]["lines"] = {
        **line_info,
        **{name: len(rows) for name, rows in line_rows.items()},
        "seconds": round(time.time() - t, 1),
    }

    crs = ref.crs
    layers = {
        "units": build_layer("units", unit_rows, map_id, crs),
        "contacts": build_layer("contacts", contact_rows, map_id, crs),
        "faults": build_layer("faults", line_rows["faults"], map_id, crs),
        "veins": build_layer("veins", line_rows["veins"], map_id, crs),
        "other_lines": build_layer(
            "other_lines", line_rows["other_lines"], map_id, crs
        ),
    }
    report["outputs"] = write_layers(layers, map_out, map_id)

    qa_path = map_out / "qa_overlay.png"
    cv2.imwrite(str(qa_path), make_qa_overlay(image, faces, line_rows, ref))
    report["outputs"]["qa_overlay"] = str(qa_path)

    report["status"] = "ok"
    report["seconds_total"] = round(time.time() - started, 1)
    (map_out / "run_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    return report


def iter_inputs(input_dir: Path) -> list[Path]:
    return sorted(
        p
        for p in input_dir.iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Scanned geological map -> GeoPackage/GeoJSON layers "
        "(units, contacts, faults, veins, other_lines)."
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--input", type=Path, help="One map image or GeoTIFF.")
    source.add_argument("--input-dir", type=Path, help="Folder of map images.")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--k", type=int, default=DEFAULT_K, help="Colour clusters.")
    parser.add_argument(
        "--max-side",
        type=int,
        default=4000,
        help="Downscale so the longest side is at most this many pixels "
        "(0 = full size). Output coordinates stay in the original frame.",
    )
    parser.add_argument("--min-region-area", type=int, default=cre.MIN_REGION_AREA)
    parser.add_argument(
        "--simplify-px",
        type=float,
        default=1.0,
        help="Polygon simplification in pixels; shared edges stay shared.",
    )
    parser.add_argument("--min-line-length-px", type=float, default=15.0)
    parser.add_argument(
        "--models-dir",
        type=Path,
        default=None,
        help="Folder with trained checkpoints (*.pth), searched by file name. "
        "Defaults to the training output folders under faria_geomap_rnd/outputs.",
    )
    parser.add_argument(
        "--no-models",
        action="store_true",
        help="Skip the trained models and use the colour/rule steps only.",
    )
    parser.add_argument("--device", default="auto", help="auto, cpu or cuda.")
    parser.add_argument("--model-threshold", type=float, default=0.5)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    inputs = [args.input] if args.input else iter_inputs(args.input_dir)

    summary = []
    for path in inputs:
        print("=" * 72)
        print("Map:", path)
        try:
            report = run_map(
                path,
                args.output_dir,
                k=args.k,
                max_side=args.max_side,
                min_region_area=args.min_region_area,
                simplify_px=args.simplify_px,
                min_line_length_px=args.min_line_length_px,
                models_dir=args.models_dir,
                use_models=not args.no_models,
                device=args.device,
                model_threshold=args.model_threshold,
            )
            summary.append(
                {
                    "map_id": report["map_id"],
                    "status": "ok",
                    "seconds": report["seconds_total"],
                    **{
                        k: v
                        for k, v in {
                            **report["steps"]["polygons"],
                            **report["steps"]["lines"],
                        }.items()
                        if k in {"units", "contacts", "faults", "veins", "other_lines"}
                    },
                    "georeferenced": report["georeference"]["georeferenced"],
                    "models_used": sorted(report.get("models", {}).get("used", {})),
                }
            )
        except Exception as exc:  # keep going on batch runs
            traceback.print_exc()
            summary.append({"map_id": path.stem, "status": "failed", "error": str(exc)})

    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "batch_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print("=" * 72)
    for row in summary:
        print(row)


if __name__ == "__main__":
    main()
