import torch
import torch.nn as nn
import torch.nn.functional as F


class SEBlock(nn.Module):
    def __init__(
        self,
        channels: int,
        reduction: int = 16,
    ):
        super().__init__()

        reduced_channels = max(
            channels // reduction,
            1,
        )

        self.squeeze = nn.AdaptiveAvgPool2d(1)

        self.excitation = nn.Sequential(
            nn.Conv2d(
                channels,
                reduced_channels,
                kernel_size=1,
            ),
            nn.ReLU(inplace=True),
            nn.Conv2d(
                reduced_channels,
                channels,
                kernel_size=1,
            ),
            nn.Sigmoid(),
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        scale = self.squeeze(x)
        scale = self.excitation(scale)

        return x * scale


class ConvBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        use_se: bool = True,
    ):
        super().__init__()

        self.conv = nn.Sequential(
            nn.Conv2d(
                in_channels,
                out_channels,
                kernel_size=3,
                padding=1,
            ),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(
                out_channels,
                out_channels,
                kernel_size=3,
                padding=1,
            ),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

        self.se = SEBlock(out_channels) if use_se else nn.Identity()

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        x = self.conv(x)
        x = self.se(x)

        return x


class SEUNet(nn.Module):
    def __init__(
        self,
        in_channels: int = 3,
        num_classes: int = 4,
        base_channels: int = 32,
        use_se: bool = True,
    ):
        super().__init__()

        self.enc1 = ConvBlock(
            in_channels,
            base_channels,
            use_se,
        )

        self.enc2 = ConvBlock(
            base_channels,
            base_channels * 2,
            use_se,
        )

        self.enc3 = ConvBlock(
            base_channels * 2,
            base_channels * 4,
            use_se,
        )

        self.enc4 = ConvBlock(
            base_channels * 4,
            base_channels * 8,
            use_se,
        )

        self.pool = nn.MaxPool2d(2)

        self.bottleneck = ConvBlock(
            base_channels * 8,
            base_channels * 16,
            use_se,
        )

        self.up4 = nn.ConvTranspose2d(
            base_channels * 16,
            base_channels * 8,
            kernel_size=2,
            stride=2,
        )

        self.dec4 = ConvBlock(
            base_channels * 16,
            base_channels * 8,
            use_se,
        )

        self.up3 = nn.ConvTranspose2d(
            base_channels * 8,
            base_channels * 4,
            kernel_size=2,
            stride=2,
        )

        self.dec3 = ConvBlock(
            base_channels * 8,
            base_channels * 4,
            use_se,
        )

        self.up2 = nn.ConvTranspose2d(
            base_channels * 4,
            base_channels * 2,
            kernel_size=2,
            stride=2,
        )

        self.dec2 = ConvBlock(
            base_channels * 4,
            base_channels * 2,
            use_se,
        )

        self.up1 = nn.ConvTranspose2d(
            base_channels * 2,
            base_channels,
            kernel_size=2,
            stride=2,
        )

        self.dec1 = ConvBlock(
            base_channels * 2,
            base_channels,
            use_se,
        )

        self.classifier = nn.Conv2d(
            base_channels,
            num_classes,
            kernel_size=1,
        )

    def forward(
        self,
        x: torch.Tensor,
        return_features: bool = False,
    ):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        e4 = self.enc4(self.pool(e3))

        bottleneck = self.bottleneck(self.pool(e4))

        d4 = self.up4(bottleneck)
        d4 = self._match_and_concat(d4, e4)
        d4 = self.dec4(d4)

        d3 = self.up3(d4)
        d3 = self._match_and_concat(d3, e3)
        d3 = self.dec3(d3)

        d2 = self.up2(d3)
        d2 = self._match_and_concat(d2, e2)
        d2 = self.dec2(d2)

        d1 = self.up1(d2)
        d1 = self._match_and_concat(d1, e1)
        d1 = self.dec1(d1)

        logits = self.classifier(d1)

        if not return_features:
            return logits

        return {
            "logits": logits,
            "features": {
                "stage1": e1,
                "stage2": e2,
                "stage3": e3,
                "stage4": e4,
                "bottleneck": bottleneck,
                "decoder": d1,
            },
        }

    @staticmethod
    def _match_and_concat(
        decoder_feature: torch.Tensor,
        encoder_feature: torch.Tensor,
    ) -> torch.Tensor:
        if decoder_feature.shape[-2:] != encoder_feature.shape[-2:]:
            decoder_feature = F.interpolate(
                decoder_feature,
                size=encoder_feature.shape[-2:],
                mode="bilinear",
                align_corners=False,
            )

        return torch.cat(
            [
                decoder_feature,
                encoder_feature,
            ],
            dim=1,
        )


if __name__ == "__main__":
    model = SEUNet(
        in_channels=3,
        num_classes=4,
        base_channels=32,
        use_se=True,
    )

    x = torch.randn(
        1,
        3,
        512,
        512,
    )

    with torch.inference_mode():
        output = model(
            x,
            return_features=True,
        )

    print("Input:", tuple(x.shape))
    print("Logits:", tuple(output["logits"].shape))

    for name, feature in output["features"].items():
        print(
            f"{name:12s}",
            tuple(feature.shape),
        )
