"""
Mask2Former area model (after Cheng et al., 2022, "Masked-attention Mask
Transformer for Universal Image Segmentation"), through HuggingFace
transformers.

Its job is areas, not lines: it proposes one mask per map area, so it can
separate neighbouring areas that are printed in similar colours and where
the boundary line is faint or missing. Every area is the same class
("area"); the legend decides later which unit an area belongs to, so the
model works on any map palette.

The runner turns its masks into an area-boundary probability: the chance
that two neighbouring pixels fall in different masks. That joins the
GeoRegionAffinityNet boundary when the faces are split.

Training: versions/v3_mask2former/training/train_mask2former.py, on the
Supervisor150 unit_labels.npy targets (each connected area is one mask).
"""

from __future__ import annotations

import cv2
import numpy as np
import torch
import torch.nn.functional as F

IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
IMAGENET_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)

CHECKPOINT_NAME = "mask2former_regions_best.pth"

# A COCO/ADE-pretrained starting point, downloaded on the VM when training.
DEFAULT_PRETRAINED = "facebook/mask2former-swin-tiny-ade-semantic"


def small_config(**overrides):
    """A light configuration that trains from scratch (no download)."""
    from transformers import Mask2FormerConfig, SwinConfig

    backbone = SwinConfig(
        embed_dim=overrides.pop("embed_dim", 48),
        depths=overrides.pop("depths", [2, 2, 2, 2]),
        num_heads=overrides.pop("num_heads", [2, 4, 8, 16]),
        window_size=7,
        out_features=["stage1", "stage2", "stage3", "stage4"],
    )
    values = dict(
        backbone_config=backbone,
        num_labels=1,
        num_queries=50,
        hidden_dim=128,
        mask_feature_size=128,
        feature_size=128,
        encoder_layers=3,
        decoder_layers=4,
        dim_feedforward=512,
        num_attention_heads=4,
    )
    values.update(overrides)
    return Mask2FormerConfig(**values)


def build_region_model(config=None, pretrained: str | None = None):
    """
    pretrained: a HuggingFace model id (needs internet) to start from
    pretrained weights; the class head is replaced by the single area class.
    """
    from transformers import Mask2FormerForUniversalSegmentation

    if pretrained:
        return Mask2FormerForUniversalSegmentation.from_pretrained(
            pretrained,
            num_labels=1,
            id2label={0: "area"},
            label2id={"area": 0},
            ignore_mismatched_sizes=True,
        )
    return Mask2FormerForUniversalSegmentation(config or small_config())


def load_region_model(path, device):
    from transformers import Mask2FormerConfig

    checkpoint = torch.load(path, map_location=device, weights_only=False)
    config = Mask2FormerConfig.from_dict(checkpoint["hf_config"])
    model = build_region_model(config).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, checkpoint


def to_pixel_values(image_rgb: np.ndarray) -> torch.Tensor:
    array = (image_rgb.astype(np.float32) / 255.0 - IMAGENET_MEAN) / IMAGENET_STD
    return torch.from_numpy(array.transpose(2, 0, 1)).unsqueeze(0)


def area_membership(outputs, size: tuple[int, int]) -> torch.Tensor:
    """
    Soft assignment of each pixel to the predicted areas, shape (Q, H, W),
    summing to 1 over Q. Query weight = P(area) * mask probability.
    """
    scores = outputs.class_queries_logits[0].softmax(-1)[:, :-1].sum(-1)  # (Q,)
    masks = outputs.masks_queries_logits[0]  # (Q, h, w)
    masks = F.interpolate(masks[None], size=size, mode="bilinear", align_corners=False)[
        0
    ].sigmoid()
    weights = scores[:, None, None] * masks
    return weights / weights.sum(0, keepdim=True).clamp_min(1e-6)


def membership_boundary(membership: torch.Tensor) -> torch.Tensor:
    """P(two neighbouring pixels fall in different areas), shape (H, W)."""
    q, h, w = membership.shape
    boundary = torch.zeros(h, w, device=membership.device)
    same_h = (membership[:, :, 1:] * membership[:, :, :-1]).sum(0)
    same_v = (membership[:, 1:, :] * membership[:, :-1, :]).sum(0)
    boundary[:, 1:] = torch.maximum(boundary[:, 1:], 1 - same_h)
    boundary[:, :-1] = torch.maximum(boundary[:, :-1], 1 - same_h)
    boundary[1:, :] = torch.maximum(boundary[1:, :], 1 - same_v)
    boundary[:-1, :] = torch.maximum(boundary[:-1, :], 1 - same_v)
    return boundary


@torch.no_grad()
def predict_region_boundary(
    model,
    image_bgr: np.ndarray,
    device,
    tile_size: int = 384,
    overlap: int = 64,
) -> np.ndarray:
    """Tiled area-boundary probability (H x W, 0..1) for a whole map."""
    from faria_geomap_rnd.pipelines.infer_supervisor_multihead import (
        generate_positions,
        pad_tile,
    )

    h, w = image_bgr.shape[:2]
    step = tile_size - overlap
    total = np.zeros((h, w), dtype=np.float32)
    weight = np.zeros((h, w), dtype=np.float32)

    for y in generate_positions(h, tile_size, step):
        for x in generate_positions(w, tile_size, step):
            tile = image_bgr[y : y + tile_size, x : x + tile_size]
            padded, vh, vw = pad_tile(tile, tile_size)
            rgb = cv2.cvtColor(padded, cv2.COLOR_BGR2RGB)
            outputs = model(pixel_values=to_pixel_values(rgb).to(device))
            membership = area_membership(outputs, (tile_size, tile_size))
            boundary = membership_boundary(membership).cpu().numpy()
            total[y : y + vh, x : x + vw] += boundary[:vh, :vw]
            weight[y : y + vh, x : x + vw] += 1.0

    return total / np.maximum(weight, 1.0)


def area_targets(
    units: np.ndarray,
    min_area: int = 16,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Training targets from a unit-label crop: one binary mask per connected
    area (negative ids are outside the map), all of class 0 ("area").
    """
    masks = []
    for uid in np.unique(units[units >= 0]):
        count, components = cv2.connectedComponents(
            (units == uid).astype(np.uint8), connectivity=4
        )
        for c in range(1, count):
            m = components == c
            if m.sum() >= min_area:
                masks.append(m)
    h, w = units.shape
    if not masks:
        return torch.zeros(0, h, w), torch.zeros(0, dtype=torch.long)
    stacked = torch.from_numpy(np.stack(masks).astype(np.float32))
    return stacked, torch.zeros(len(masks), dtype=torch.long)
