"""
RS3Mamba-style network for geological maps (after Ma et al., 2024,
"RS3Mamba: Visual State Space Model for Remote Sensing Images Semantic
Segmentation").

Two encoders run side by side:

- a ResNet branch for local detail (line edges, small symbols), and
- a visual state space (VSS / Mamba) branch that scans the feature map in
  four directions, so evidence travels along the whole tile. This is what
  helps long faults and contacts stay continuous.

A collaborative completion module fuses the two at every scale, and a U-Net
decoder predicts the same heads as MultiHeadGeoMapNet. It trains with
pipelines/train_supervisor_multihead.py --architecture rs3mamba.

The selective scan uses mamba_ssm's CUDA kernel when it is installed and the
model is on a GPU (pip install mamba-ssm on the VM). Otherwise a chunked
pure-PyTorch scan gives the same result more slowly, so the model also runs
and trains on CPU.
"""

from __future__ import annotations

import math
from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F

from faria_geomap_rnd.models.hybrid.multihead_geomap_net import HEAD_NAMES

try:  # optional CUDA kernel
    from mamba_ssm.ops.selective_scan_interface import selective_scan_fn

    MAMBA_KERNEL_AVAILABLE = True
except Exception:  # ImportError, or a build without CUDA
    selective_scan_fn = None
    MAMBA_KERNEL_AVAILABLE = False


# ---------------------------------------------------------------------
# SELECTIVE SCAN
# ---------------------------------------------------------------------


def selective_scan_reference(
    u: torch.Tensor,
    delta: torch.Tensor,
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    D: torch.Tensor,
    chunk: int = 64,
) -> torch.Tensor:
    """
    y_t = C_t . h_t + D u_t,  h_t = exp(delta_t A) h_{t-1} + delta_t B_t u_t

    u, delta: (b, d, L); A: (d, n); B, C: (b, n, L); D: (d,).
    Computed chunk by chunk with the closed form inside each chunk.
    """
    b, d, length = u.shape
    n = A.shape[1]
    h = u.new_zeros(b, d, n)
    outputs = []

    for start in range(0, length, chunk):
        end = min(start + chunk, length)
        t = end - start
        dt = delta[:, :, start:end]  # (b, d, t)
        dA = dt.unsqueeze(-1) * A[None, :, None, :]  # (b, d, t, n), all <= 0
        cum = torch.cumsum(dA, dim=2)  # (b, d, t, n)

        # decay[i, j] = exp(cum_i - cum_j) for j <= i
        diff = cum.unsqueeze(3) - cum.unsqueeze(2)  # (b, d, t, t, n)
        causal = torch.ones(t, t, dtype=torch.bool, device=u.device).tril()
        diff = diff.masked_fill(~causal[None, None, :, :, None], float("-inf"))
        decay = torch.exp(diff)

        bu = (dt * u[:, :, start:end]).unsqueeze(-1) * B[:, :, start:end].transpose(
            1, 2
        ).unsqueeze(
            1
        )  # (b, d, t, n)
        states = torch.einsum("bdijn,bdjn->bdin", decay, bu)
        states = states + torch.exp(cum) * h.unsqueeze(2)

        c = C[:, :, start:end].transpose(1, 2).unsqueeze(1)  # (b, 1, t, n)
        outputs.append((states * c).sum(-1))
        h = states[:, :, -1]

    y = torch.cat(outputs, dim=2)
    return y + u * D[None, :, None]


class SS2D(nn.Module):
    """2D selective scan over four directions (row, column, and reversed)."""

    def __init__(self, dim: int, state: int = 16, expand: int = 2) -> None:
        super().__init__()
        inner = dim * expand
        self.inner = inner
        self.state = state
        self.dt_rank = max(1, math.ceil(dim / 16))
        self.directions = 4

        self.in_proj = nn.Linear(dim, inner * 2, bias=False)
        self.dwconv = nn.Conv2d(inner, inner, 3, padding=1, groups=inner)
        self.x_proj = nn.Parameter(
            torch.randn(self.directions, self.dt_rank + 2 * state, inner)
            / math.sqrt(inner)
        )
        self.dt_proj_weight = nn.Parameter(
            torch.randn(self.directions, inner, self.dt_rank) / math.sqrt(self.dt_rank)
        )
        dt = torch.exp(
            torch.rand(self.directions, inner) * (math.log(0.1) - math.log(0.001))
            + math.log(0.001)
        )
        self.dt_proj_bias = nn.Parameter(dt + torch.log(-torch.expm1(-dt)))
        a = torch.arange(1, state + 1, dtype=torch.float32).repeat(
            self.directions * inner, 1
        )
        self.A_log = nn.Parameter(torch.log(a))
        self.D = nn.Parameter(torch.ones(self.directions * inner))
        self.out_norm = nn.LayerNorm(inner)
        self.out_proj = nn.Linear(inner, dim, bias=False)

    def _scan(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        length = h * w
        rows = x.flatten(2)
        cols = x.transpose(2, 3).flatten(2)
        seqs = torch.stack([rows, cols, rows.flip(-1), cols.flip(-1)], dim=1)

        proj = torch.einsum("bkdl,kcd->bkcl", seqs, self.x_proj)
        dts, Bs, Cs = torch.split(proj, [self.dt_rank, self.state, self.state], dim=2)
        dts = torch.einsum("bkrl,kdr->bkdl", dts, self.dt_proj_weight)

        u = seqs.reshape(b, -1, length)
        delta = dts.reshape(b, -1, length)
        A = -torch.exp(self.A_log.float())
        bias = self.dt_proj_bias.reshape(-1)

        if MAMBA_KERNEL_AVAILABLE and x.is_cuda:
            y = selective_scan_fn(
                u.float(),
                delta.float(),
                A,
                Bs.float(),
                Cs.float(),
                self.D.float(),
                delta_bias=bias.float(),
                delta_softplus=True,
            )
            y = y.view(b, self.directions, c, length)
            y_rows = y[:, 0] + y[:, 2].flip(-1)
            y_cols = y[:, 1] + y[:, 3].flip(-1)
        else:
            delta = F.softplus(delta + bias[None, :, None])
            parts = []
            for k in range(self.directions):
                sl = slice(k * c, (k + 1) * c)
                parts.append(
                    selective_scan_reference(
                        u[:, sl], delta[:, sl], A[sl], Bs[:, k], Cs[:, k], self.D[sl]
                    )
                )
            y_rows = parts[0] + parts[2].flip(-1)
            y_cols = parts[1] + parts[3].flip(-1)

        y_cols = y_cols.view(b, c, w, h).transpose(2, 3).reshape(b, c, length)
        return (y_rows + y_cols).view(b, c, h, w)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (b, h, w, dim)
        xz = self.in_proj(x)
        x, z = xz.chunk(2, dim=-1)
        x = F.silu(self.dwconv(x.permute(0, 3, 1, 2)))
        y = self._scan(x).permute(0, 2, 3, 1)
        y = self.out_norm(y) * F.silu(z)
        return self.out_proj(y)


class VSSBlock(nn.Module):
    def __init__(self, dim: int, state: int = 16) -> None:
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.ss2d = SS2D(dim, state=state)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim * 2), nn.GELU(), nn.Linear(dim * 2, dim)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (b, c, h, w)
        y = x.permute(0, 2, 3, 1)
        y = y + self.ss2d(self.norm(y))
        y = y + self.mlp(self.norm2(y))
        return y.permute(0, 3, 1, 2)


# ---------------------------------------------------------------------
# ENCODERS, FUSION, DECODER
# ---------------------------------------------------------------------


class ConvBNReLU(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
        super().__init__(
            nn.Conv2d(in_channels, out_channels, 3, stride, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )


class BasicBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int) -> None:
        super().__init__()
        self.conv1 = ConvBNReLU(in_channels, out_channels, stride)
        self.conv2 = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_channels),
        )
        self.skip = (
            nn.Identity()
            if stride == 1 and in_channels == out_channels
            else nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.relu(self.conv2(self.conv1(x)) + self.skip(x))


class CollaborativeCompletion(nn.Module):
    """Fuses CNN and VSS features: concatenation, then channel gating."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.mix = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )
        self.gate = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, max(channels // 4, 4), 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(max(channels // 4, 4), channels, 1),
            nn.Sigmoid(),
        )

    def forward(self, cnn: torch.Tensor, vss: torch.Tensor) -> torch.Tensor:
        mixed = self.mix(torch.cat([cnn, vss], dim=1))
        return cnn + mixed * self.gate(mixed)


class UpBlock(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int):
        super().__init__()
        self.conv = nn.Sequential(
            ConvBNReLU(in_channels + skip_channels, out_channels),
            ConvBNReLU(out_channels, out_channels),
        )

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        return self.conv(torch.cat([x, skip], dim=1))


class RS3MambaGeoMap(nn.Module):
    def __init__(
        self,
        in_channels: int = 3,
        base_channels: int = 32,
        head_names: tuple[str, ...] = HEAD_NAMES,
        state: int = 16,
    ) -> None:
        super().__init__()

        c0 = base_channels
        widths = [base_channels * m for m in (2, 4, 8, 8)]  # 1/4 .. 1/32

        self.head_names = tuple(head_names)

        # ResNet branch
        self.stem = nn.Sequential(ConvBNReLU(in_channels, c0), ConvBNReLU(c0, c0, 2))
        cnn = []
        previous = c0
        for width in widths:
            cnn.append(
                nn.Sequential(
                    BasicBlock(previous, width, 2), BasicBlock(width, width, 1)
                )
            )
            previous = width
        self.cnn_stages = nn.ModuleList(cnn)

        # VSS branch
        self.patch_embed = nn.Sequential(
            nn.Conv2d(in_channels, widths[0], 4, 4), nn.BatchNorm2d(widths[0])
        )
        vss = []
        previous = widths[0]
        for i, width in enumerate(widths):
            down = (
                nn.Identity()
                if i == 0
                else nn.Sequential(
                    nn.Conv2d(previous, width, 2, 2), nn.BatchNorm2d(width)
                )
            )
            vss.append(nn.Sequential(down, VSSBlock(width, state=state)))
            previous = width
        self.vss_stages = nn.ModuleList(vss)

        self.fusions = nn.ModuleList(CollaborativeCompletion(w) for w in widths)

        self.up3 = UpBlock(widths[3], widths[2], widths[2])
        self.up2 = UpBlock(widths[2], widths[1], widths[1])
        self.up1 = UpBlock(widths[1], widths[0], widths[0])
        self.up0 = UpBlock(widths[0], c0, c0)

        self.heads = nn.ModuleDict(
            OrderedDict(
                (name, nn.Sequential(ConvBNReLU(c0, c0), nn.Conv2d(c0, 1, 1)))
                for name in self.head_names
            )
        )

    def forward(self, x: torch.Tensor) -> dict[str, torch.Tensor]:
        size = x.shape[-2:]
        stem = self.stem(x)  # 1/2

        features = []
        cnn = stem
        vss = self.patch_embed(x)  # 1/4
        for cnn_stage, vss_stage, fuse in zip(
            self.cnn_stages, self.vss_stages, self.fusions
        ):
            cnn = cnn_stage(cnn)
            vss = vss_stage(vss)
            if vss.shape[-2:] != cnn.shape[-2:]:
                vss = F.interpolate(
                    vss, size=cnn.shape[-2:], mode="bilinear", align_corners=False
                )
            cnn = fuse(cnn, vss)
            features.append(cnn)

        d = self.up3(features[3], features[2])
        d = self.up2(d, features[1])
        d = self.up1(d, features[0])
        d = self.up0(d, stem)
        d = F.interpolate(d, size=size, mode="bilinear", align_corners=False)

        return {name: head(d) for name, head in self.heads.items()}
