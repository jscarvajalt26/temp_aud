"""
TransUNet for geological maps (after Chen et al., 2021, "TransUNet:
Transformers Make Strong Encoders for Medical Image Segmentation").

A CNN encoder keeps the fine detail of thin printed lines, a Vision
Transformer on the 1/16 feature map sees the whole tile at once (so a fault
or contact keeps going across gaps and labels), and a cascaded upsampler
with skip connections brings the result back to full resolution.

It predicts the same heads as MultiHeadGeoMapNet (contact, fault, road,
river, lake, strike_dip, clutter), so it trains with
pipelines/train_supervisor_multihead.py --architecture transunet and runs
through the same tiled inference.
"""

from __future__ import annotations

from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F

from faria_geomap_rnd.models.hybrid.multihead_geomap_net import HEAD_NAMES


class ConvBNReLU(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
        super().__init__(
            nn.Conv2d(in_channels, out_channels, 3, stride, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )


class ResidualStage(nn.Module):
    """Two residual blocks; the first one halves the resolution."""

    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        self.down = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 1, 2, bias=False),
            nn.BatchNorm2d(out_channels),
        )
        self.block1 = nn.Sequential(
            ConvBNReLU(in_channels, out_channels, stride=2),
            nn.Conv2d(out_channels, out_channels, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_channels),
        )
        self.block2 = nn.Sequential(
            ConvBNReLU(out_channels, out_channels),
            nn.Conv2d(out_channels, out_channels, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.block1(x) + self.down(x))
        return F.relu(self.block2(x) + x)


class ViTEncoder(nn.Module):
    """Transformer over the 1/16 feature map, one token per position."""

    def __init__(
        self,
        in_channels: int,
        hidden: int,
        layers: int,
        heads: int,
        grid: int = 16,
    ) -> None:
        super().__init__()
        self.embed = nn.Conv2d(in_channels, hidden, 1)
        self.position = nn.Parameter(torch.zeros(1, hidden, grid, grid))
        nn.init.trunc_normal_(self.position, std=0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=hidden,
            nhead=heads,
            dim_feedforward=hidden * 4,
            dropout=0.1,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(
            layer, num_layers=layers, enable_nested_tensor=False
        )
        self.norm = nn.LayerNorm(hidden)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.embed(x)
        b, c, h, w = x.shape
        position = self.position
        if position.shape[-2:] != (h, w):
            position = F.interpolate(
                position, size=(h, w), mode="bilinear", align_corners=False
            )
        tokens = (x + position).flatten(2).transpose(1, 2)
        tokens = self.norm(self.encoder(tokens))
        return tokens.transpose(1, 2).reshape(b, c, h, w)


class UpBlock(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int):
        super().__init__()
        self.conv = nn.Sequential(
            ConvBNReLU(in_channels + skip_channels, out_channels),
            ConvBNReLU(out_channels, out_channels),
        )

    def forward(self, x: torch.Tensor, skip: torch.Tensor | None) -> torch.Tensor:
        size = skip.shape[-2:] if skip is not None else None
        if size is None:
            x = F.interpolate(x, scale_factor=2, mode="bilinear", align_corners=False)
        else:
            x = F.interpolate(x, size=size, mode="bilinear", align_corners=False)
            x = torch.cat([x, skip], dim=1)
        return self.conv(x)


class TransUNetGeoMap(nn.Module):
    def __init__(
        self,
        in_channels: int = 3,
        base_channels: int = 32,
        head_names: tuple[str, ...] = HEAD_NAMES,
        vit_layers: int = 6,
        vit_heads: int = 8,
    ) -> None:
        super().__init__()

        c1 = base_channels
        c2 = base_channels * 2
        c3 = base_channels * 4
        c4 = base_channels * 8
        hidden = base_channels * 8

        self.head_names = tuple(head_names)

        self.stem = nn.Sequential(ConvBNReLU(in_channels, c1), ConvBNReLU(c1, c1))
        self.stage1 = ResidualStage(c1, c2)  # 1/2
        self.stage2 = ResidualStage(c2, c3)  # 1/4
        self.stage3 = ResidualStage(c3, c4)  # 1/8
        self.stage4 = ResidualStage(c4, c4)  # 1/16

        self.vit = ViTEncoder(c4, hidden, vit_layers, vit_heads)

        self.up3 = UpBlock(hidden, c4, c4)  # 1/8
        self.up2 = UpBlock(c4, c3, c3)  # 1/4
        self.up1 = UpBlock(c3, c2, c2)  # 1/2
        self.up0 = UpBlock(c2, c1, c1)  # 1/1

        self.heads = nn.ModuleDict(
            OrderedDict(
                (
                    name,
                    nn.Sequential(ConvBNReLU(c1, c1), nn.Conv2d(c1, 1, 1)),
                )
                for name in self.head_names
            )
        )

    def forward(self, x: torch.Tensor) -> dict[str, torch.Tensor]:
        s0 = self.stem(x)
        s1 = self.stage1(s0)
        s2 = self.stage2(s1)
        s3 = self.stage3(s2)
        s4 = self.stage4(s3)

        d = self.vit(s4)
        d = self.up3(d, s3)
        d = self.up2(d, s2)
        d = self.up1(d, s1)
        d = self.up0(d, s0)

        return {name: head(d) for name, head in self.heads.items()}
