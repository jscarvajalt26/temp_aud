from __future__ import annotations

import torch
import torch.nn as nn


class FusionBlock(nn.Module):
    def __init__(
        self,
        local_channels: int,
        context_channels: int,
        output_channels: int,
    ):
        super().__init__()

        self.local_projection = nn.Conv2d(
            local_channels,
            output_channels,
            kernel_size=1,
        )

        self.context_projection = nn.Conv2d(
            context_channels,
            output_channels,
            kernel_size=1,
        )

        self.fusion = nn.Sequential(
            nn.Conv2d(
                output_channels * 2,
                output_channels,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(output_channels),
            nn.ReLU(inplace=True),
        )

    def forward(
        self,
        local_feature: torch.Tensor,
        context_feature: torch.Tensor,
    ) -> torch.Tensor:
        if local_feature.shape[-2:] != context_feature.shape[-2:]:
            raise ValueError(
                "Local and context feature maps must have matching spatial sizes."
            )

        local_feature = self.local_projection(local_feature)

        context_feature = self.context_projection(context_feature)

        fused = torch.cat(
            [
                local_feature,
                context_feature,
            ],
            dim=1,
        )

        return self.fusion(fused)


class MultiScaleFusion(nn.Module):
    def __init__(self):
        super().__init__()

        self.fuse_128 = FusionBlock(
            local_channels=128,
            context_channels=32,
            output_channels=128,
        )

        self.fuse_64 = FusionBlock(
            local_channels=256,
            context_channels=64,
            output_channels=256,
        )

        self.fuse_32 = FusionBlock(
            local_channels=512,
            context_channels=160,
            output_channels=512,
        )

    def forward(
        self,
        local_features: dict[str, torch.Tensor],
        context_features: dict[str, torch.Tensor],
    ) -> dict[str, torch.Tensor]:
        fused_128 = self.fuse_128(
            local_features["stage3"],
            context_features["stage1"],
        )

        fused_64 = self.fuse_64(
            local_features["stage4"],
            context_features["stage2"],
        )

        fused_32 = self.fuse_32(
            local_features["bottleneck"],
            context_features["stage3"],
        )

        return {
            "fused_128": fused_128,
            "fused_64": fused_64,
            "fused_32": fused_32,
        }


if __name__ == "__main__":
    module = MultiScaleFusion()

    local = {
        "stage3": torch.randn(1, 128, 128, 128),
        "stage4": torch.randn(1, 256, 64, 64),
        "bottleneck": torch.randn(1, 512, 32, 32),
    }

    context = {
        "stage1": torch.randn(1, 32, 128, 128),
        "stage2": torch.randn(1, 64, 64, 64),
        "stage3": torch.randn(1, 160, 32, 32),
    }

    with torch.inference_mode():
        fused = module(
            local,
            context,
        )

    for name, feature in fused.items():
        print(
            f"{name:10s}",
            tuple(feature.shape),
        )
