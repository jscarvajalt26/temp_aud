from __future__ import annotations

from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F

HEAD_NAMES = (
    "affinity_h",
    "affinity_v",
    "boundary",
)


class ConvBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
    ) -> None:
        super().__init__()

        self.block = nn.Sequential(
            nn.Conv2d(
                in_channels,
                out_channels,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(out_channels),
            nn.GELU(),
            nn.Conv2d(
                out_channels,
                out_channels,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(out_channels),
            nn.GELU(),
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        return self.block(x)


class SEBlock(nn.Module):
    def __init__(
        self,
        channels: int,
        reduction: int = 8,
    ) -> None:
        super().__init__()

        hidden = max(
            channels // reduction,
            8,
        )

        self.pool = nn.AdaptiveAvgPool2d(1)

        self.fc = nn.Sequential(
            nn.Conv2d(
                channels,
                hidden,
                1,
            ),
            nn.GELU(),
            nn.Conv2d(
                hidden,
                channels,
                1,
            ),
            nn.Sigmoid(),
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        return x * self.fc(self.pool(x))


class EncoderBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
    ) -> None:
        super().__init__()

        self.conv = ConvBlock(
            in_channels,
            out_channels,
        )

        self.se = SEBlock(out_channels)

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        return self.se(self.conv(x))


class DecoderBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        skip_channels: int,
        out_channels: int,
    ) -> None:
        super().__init__()

        self.up = nn.ConvTranspose2d(
            in_channels,
            out_channels,
            kernel_size=2,
            stride=2,
        )

        self.conv = ConvBlock(
            out_channels + skip_channels,
            out_channels,
        )

        self.se = SEBlock(out_channels)

    def forward(
        self,
        x: torch.Tensor,
        skip: torch.Tensor,
    ) -> torch.Tensor:

        x = self.up(x)

        if x.shape[-2:] != skip.shape[-2:]:
            x = F.interpolate(
                x,
                size=skip.shape[-2:],
                mode="bilinear",
                align_corners=False,
            )

        x = torch.cat(
            [x, skip],
            dim=1,
        )

        return self.se(self.conv(x))


class GeoRegionAffinityNet(nn.Module):
    """
    Palette-independent geological region affinity model.

    Outputs:
        affinity_h logits
        affinity_v logits
        boundary logits
    """

    def __init__(
        self,
        in_channels: int = 3,
        base_channels: int = 16,
    ) -> None:
        super().__init__()

        c1 = base_channels
        c2 = base_channels * 2
        c3 = base_channels * 4
        c4 = base_channels * 8
        cb = base_channels * 16

        self.enc1 = EncoderBlock(
            in_channels,
            c1,
        )

        self.enc2 = EncoderBlock(
            c1,
            c2,
        )

        self.enc3 = EncoderBlock(
            c2,
            c3,
        )

        self.enc4 = EncoderBlock(
            c3,
            c4,
        )

        self.pool = nn.MaxPool2d(2)

        self.bottleneck = nn.Sequential(
            ConvBlock(
                c4,
                cb,
            ),
            SEBlock(cb),
        )

        self.dec4 = DecoderBlock(
            cb,
            c4,
            c4,
        )

        self.dec3 = DecoderBlock(
            c4,
            c3,
            c3,
        )

        self.dec2 = DecoderBlock(
            c3,
            c2,
            c2,
        )

        self.dec1 = DecoderBlock(
            c2,
            c1,
            c1,
        )

        self.shared_refine = nn.Sequential(
            ConvBlock(
                c1,
                c1,
            ),
            SEBlock(c1),
        )

        self.heads = nn.ModuleDict(
            OrderedDict(
                (
                    name,
                    nn.Sequential(
                        nn.Conv2d(
                            c1,
                            c1,
                            kernel_size=3,
                            padding=1,
                            bias=False,
                        ),
                        nn.BatchNorm2d(c1),
                        nn.GELU(),
                        nn.Conv2d(
                            c1,
                            1,
                            kernel_size=1,
                        ),
                    ),
                )
                for name in HEAD_NAMES
            )
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> dict[str, torch.Tensor]:

        e1 = self.enc1(x)

        e2 = self.enc2(self.pool(e1))

        e3 = self.enc3(self.pool(e2))

        e4 = self.enc4(self.pool(e3))

        b = self.bottleneck(self.pool(e4))

        d4 = self.dec4(
            b,
            e4,
        )

        d3 = self.dec3(
            d4,
            e3,
        )

        d2 = self.dec2(
            d3,
            e2,
        )

        d1 = self.dec1(
            d2,
            e1,
        )

        shared = self.shared_refine(d1)

        return {name: head(shared) for name, head in self.heads.items()}


if __name__ == "__main__":

    model = GeoRegionAffinityNet(base_channels=16)

    x = torch.randn(
        1,
        3,
        256,
        256,
    )

    with torch.no_grad():
        outputs = model(x)

    print(
        "Input:",
        tuple(x.shape),
    )

    for name, tensor in outputs.items():
        print(
            f"{name:12s}",
            tuple(tensor.shape),
        )
