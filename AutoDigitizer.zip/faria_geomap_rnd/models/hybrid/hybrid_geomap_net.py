﻿from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from faria_geomap_rnd.models.hybrid.context_transformer_encoder import (
    ContextTransformerEncoder,
)
from faria_geomap_rnd.models.hybrid.multiscale_fusion import (
    MultiScaleFusion,
)
from faria_geomap_rnd.models.se_unet import SEUNet


class HybridDecoder(nn.Module):
    def __init__(
        self,
        num_classes: int,
    ):
        super().__init__()

        self.decode_32 = nn.Sequential(
            nn.Conv2d(
                512,
                256,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
        )

        self.decode_64 = nn.Sequential(
            nn.Conv2d(
                256 + 256,
                256,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(
                256,
                128,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
        )

        self.decode_128 = nn.Sequential(
            nn.Conv2d(
                128 + 128,
                128,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(
                128,
                64,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
        )

        self.refine_256 = nn.Sequential(
            nn.Conv2d(
                64,
                64,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
        )

        self.refine_512 = nn.Sequential(
            nn.Conv2d(
                64,
                32,
                kernel_size=3,
                padding=1,
                bias=False,
            ),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
        )

        self.classifier = nn.Conv2d(
            32,
            num_classes,
            kernel_size=1,
        )

    def forward(
        self,
        fused_features: dict[str, torch.Tensor],
        output_size: tuple[int, int],
    ) -> torch.Tensor:
        fused_32 = fused_features["fused_32"]
        fused_64 = fused_features["fused_64"]
        fused_128 = fused_features["fused_128"]

        x = self.decode_32(fused_32)

        x = F.interpolate(
            x,
            size=fused_64.shape[-2:],
            mode="bilinear",
            align_corners=False,
        )

        x = torch.cat(
            [
                x,
                fused_64,
            ],
            dim=1,
        )

        x = self.decode_64(x)

        x = F.interpolate(
            x,
            size=fused_128.shape[-2:],
            mode="bilinear",
            align_corners=False,
        )

        x = torch.cat(
            [
                x,
                fused_128,
            ],
            dim=1,
        )

        x = self.decode_128(x)

        x = F.interpolate(
            x,
            scale_factor=2.0,
            mode="bilinear",
            align_corners=False,
        )

        x = self.refine_256(x)

        x = F.interpolate(
            x,
            size=output_size,
            mode="bilinear",
            align_corners=False,
        )

        x = self.refine_512(x)

        logits = self.classifier(x)

        return logits


class HybridGeoMapNetV1(nn.Module):
    def __init__(
        self,
        in_channels: int = 3,
        num_classes: int = 4,
        base_channels: int = 32,
    ):
        super().__init__()

        self.local_branch = SEUNet(
            in_channels=in_channels,
            num_classes=num_classes,
            base_channels=base_channels,
            use_se=True,
        )

        self.context_branch = ContextTransformerEncoder(
            in_channels=in_channels,
        )

        self.fusion = MultiScaleFusion()

        self.decoder = HybridDecoder(
            num_classes=num_classes,
        )

    def forward(
        self,
        x: torch.Tensor,
        return_features: bool = False,
    ):
        local_output = self.local_branch(
            x,
            return_features=True,
        )

        local_features = local_output["features"]

        context_features = self.context_branch(x)

        fused_features = self.fusion(
            local_features,
            context_features,
        )

        logits = self.decoder(
            fused_features,
            output_size=x.shape[-2:],
        )

        if not return_features:
            return logits

        return {
            "logits": logits,
            "local_logits": local_output["logits"],
            "local_features": local_features,
            "context_features": context_features,
            "fused_features": fused_features,
        }


if __name__ == "__main__":
    model = HybridGeoMapNetV1(
        in_channels=3,
        num_classes=4,
        base_channels=32,
    )

    model.eval()

    test_input = torch.randn(
        1,
        3,
        512,
        512,
    )

    with torch.inference_mode():
        output = model(
            test_input,
            return_features=True,
        )

    print(
        "Input:",
        tuple(test_input.shape),
    )

    print(
        "Logits:",
        tuple(output["logits"].shape),
    )

    print(
        "Local logits:",
        tuple(output["local_logits"].shape),
    )

    print("\nFused features:")

    for name, feature in output["fused_features"].items():
        print(
            f"{name:10s}",
            tuple(feature.shape),
        )
