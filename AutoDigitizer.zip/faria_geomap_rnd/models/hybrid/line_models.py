"""
The line and boundary networks that share the multi-head targets
(contact, fault, road, river, lake, strike_dip, clutter). They train with
pipelines/train_supervisor_multihead.py --architecture <name> and load
through pipelines/infer_supervisor_multihead.load_model, which reads the
architecture from the checkpoint.
"""

from __future__ import annotations

import torch.nn as nn

from faria_geomap_rnd.models.hybrid.multihead_geomap_net import (
    HEAD_NAMES,
    MultiHeadGeoMapNet,
)
from faria_geomap_rnd.models.hybrid.rs3mamba_geomap import RS3MambaGeoMap
from faria_geomap_rnd.models.hybrid.transunet_geomap import TransUNetGeoMap

ARCHITECTURES = {
    "multihead": MultiHeadGeoMapNet,
    "transunet": TransUNetGeoMap,
    "rs3mamba": RS3MambaGeoMap,
}

# Checkpoints are saved as <stem>_best.pth and <stem>_last.pth.
CHECKPOINT_STEMS = {
    "multihead": "multihead_geomap",
    "transunet": "transunet_geomap",
    "rs3mamba": "rs3mamba_geomap",
}


def build_line_model(
    architecture: str = "multihead",
    base_channels: int = 16,
    head_names: tuple[str, ...] = HEAD_NAMES,
) -> nn.Module:
    if architecture not in ARCHITECTURES:
        raise ValueError(
            f"Unknown architecture {architecture!r}; "
            f"choose from {sorted(ARCHITECTURES)}"
        )
    return ARCHITECTURES[architecture](
        in_channels=3,
        base_channels=base_channels,
        head_names=tuple(head_names),
    )
