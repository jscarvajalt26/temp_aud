from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np


# ---------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------


def read_mask(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"Could not read mask: {path}")
    return (image > 0).astype(np.uint8)


def read_color(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return image


def save_mask(path: Path, mask: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ok = cv2.imwrite(str(path), (mask > 0).astype(np.uint8) * 255)
    if not ok:
        raise IOError(f"Could not write mask: {path}")


# ---------------------------------------------------------------------
# BASIC GEOMETRY
# ---------------------------------------------------------------------


def compute_shared_boundaries(labels: np.ndarray) -> np.ndarray:
    h, w = labels.shape
    boundary = np.zeros((h, w), dtype=np.uint8)

    a = labels[:, :-1]
    b = labels[:, 1:]
    valid = (a >= 0) & (b >= 0) & (a != b)
    boundary[:, :-1][valid] = 1

    a = labels[:-1, :]
    b = labels[1:, :]
    valid = (a >= 0) & (b >= 0) & (a != b)
    boundary[:-1, :][valid] = 1

    return boundary


def mask_boundary(mask: np.ndarray) -> np.ndarray:
    """
    Exact one-pixel inner perimeter of the recovered visible object mask.

    A rectangular 3x3 erosion is used deliberately. Unlike the earlier
    topology-support morphology, this does not intentionally round square
    cartographic symbols.
    """
    mask = (mask > 0).astype(np.uint8)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    eroded = cv2.erode(mask, kernel, iterations=1)
    return (mask & (1 - eroded)).astype(np.uint8)


def dilate_mask(mask: np.ndarray, radius: int) -> np.ndarray:
    if radius <= 0:
        return (mask > 0).astype(np.uint8)

    size = radius * 2 + 1
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (size, size))
    return cv2.dilate((mask > 0).astype(np.uint8), kernel, iterations=1)


# ---------------------------------------------------------------------
# SEED-GUIDED VISIBLE DARK-OBJECT RECOVERY
# ---------------------------------------------------------------------


def build_dark_pixel_mask(
    image_bgr: np.ndarray,
    dark_value_threshold: int = 105,
    adaptive_percentile: float = 18.0,
) -> tuple[np.ndarray, dict]:
    """
    Build a conservative dark-pixel candidate mask from the ORIGINAL image.

    The old restored-hole mask is not used as geometry here. It is only used
    later as a seed map telling us where a foreground dark object is expected.

    The threshold combines:
      1. a fixed HSV value ceiling;
      2. a percentile-derived ceiling, useful for aged/dim scans.

    This preserves the actual rendered shape of black squares and connected
    dark extensions much better than tracing the rounded topology hole.
    """
    hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
    value = hsv[:, :, 2]

    percentile_threshold = int(
        np.clip(
            np.percentile(value, adaptive_percentile),
            45,
            145,
        )
    )

    effective_threshold = max(
        int(dark_value_threshold),
        percentile_threshold,
    )

    dark = (value <= effective_threshold).astype(np.uint8)

    # Only a tiny rectangular close: bridge antialiased one-pixel breaks
    # without turning squares into circles or aggressively joining features.
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    dark_closed = cv2.morphologyEx(
        dark,
        cv2.MORPH_CLOSE,
        kernel,
        iterations=1,
    )

    report = {
        "fixed_dark_value_threshold": int(dark_value_threshold),
        "adaptive_percentile": float(adaptive_percentile),
        "percentile_threshold": int(percentile_threshold),
        "effective_dark_value_threshold": int(effective_threshold),
    }

    return dark_closed.astype(np.uint8), report


def recover_seeded_dark_objects(
    dark_mask: np.ndarray,
    seed_mask: np.ndarray,
    seed_touch_radius: int = 2,
    min_seed_overlap_pixels: int = 1,
) -> tuple[np.ndarray, list[dict]]:
    """
    Recover TRUE visible dark connected components from the original image.

    `seed_mask` is the old restored-symbol-hole mask. It is used only to locate
    objects. Every dark connected component touching a seed is retained using
    its actual dark-pixel geometry.

    Consequences:
      - a square remains square;
      - a connected black extension is retained;
      - rounded topology-support holes are no longer used as the object outline.

    A component may include a connected line extension. That is intentional at
    this stage: this module answers "what is visibly in front?", not yet
    "is this a symbol, fault, vein, leader line, or annotation?"
    """
    dark = (dark_mask > 0).astype(np.uint8)
    seeds = (seed_mask > 0).astype(np.uint8)

    seed_touch = dilate_mask(seeds, seed_touch_radius)

    n, components, stats, _ = cv2.connectedComponentsWithStats(
        dark,
        connectivity=8,
    )

    recovered = np.zeros_like(dark, dtype=np.uint8)
    report: list[dict] = []

    for component_id in range(1, n):
        component = components == component_id
        overlap_pixels = int(np.count_nonzero(component & (seed_touch > 0)))

        if overlap_pixels < min_seed_overlap_pixels:
            continue

        x = int(stats[component_id, cv2.CC_STAT_LEFT])
        y = int(stats[component_id, cv2.CC_STAT_TOP])
        w = int(stats[component_id, cv2.CC_STAT_WIDTH])
        h = int(stats[component_id, cv2.CC_STAT_HEIGHT])
        area = int(stats[component_id, cv2.CC_STAT_AREA])

        recovered[component] = 1

        report.append(
            {
                "component": int(component_id),
                "area": area,
                "bbox": [x, y, w, h],
                "seed_overlap_pixels": overlap_pixels,
                "aspect_ratio": float(max(w, h) / max(1, min(w, h))),
            }
        )

    return recovered, report


def recover_seed_local_dark_objects(
    dark_mask: np.ndarray,
    seed_mask: np.ndarray,
    global_recovered: np.ndarray,
    padding: int = 4,
) -> np.ndarray:
    """
    Fill tiny local dark fragments immediately adjacent to each seed.

    The global connected-component recovery already preserves long connected
    extensions. This local pass catches antialiased corner pixels that may have
    remained disconnected by one pixel, while staying inside a small box around
    the original seed component.
    """
    seeds = (seed_mask > 0).astype(np.uint8)
    dark = (dark_mask > 0).astype(np.uint8)
    recovered = (global_recovered > 0).astype(np.uint8).copy()

    n, seed_components, stats, _ = cv2.connectedComponentsWithStats(
        seeds,
        connectivity=8,
    )

    h_img, w_img = seeds.shape

    for seed_id in range(1, n):
        x = int(stats[seed_id, cv2.CC_STAT_LEFT])
        y = int(stats[seed_id, cv2.CC_STAT_TOP])
        w = int(stats[seed_id, cv2.CC_STAT_WIDTH])
        h = int(stats[seed_id, cv2.CC_STAT_HEIGHT])

        x0 = max(0, x - padding)
        y0 = max(0, y - padding)
        x1 = min(w_img, x + w + padding)
        y1 = min(h_img, y + h + padding)

        seed_roi = seed_components[y0:y1, x0:x1] == seed_id
        dark_roi = dark[y0:y1, x0:x1]

        # Rectangular dilation retains compact symbol geometry better than an
        # elliptical growth operation.
        seed_near = cv2.dilate(
            seed_roi.astype(np.uint8),
            cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)),
            iterations=1,
        )

        local_add = (dark_roi > 0) & (seed_near > 0)
        recovered[y0:y1, x0:x1][local_add] = 1

    return recovered



# ---------------------------------------------------------------------
# SEEDLESS VISIBLE LINEAR-FEATURE RECOVERY
# ---------------------------------------------------------------------


def oriented_dark_line_response(gray: np.ndarray) -> np.ndarray:
    """
    Recover weak gray/black elongated marks even when they were never a
    topology-hole seed.

    This is deliberately an evidence detector. It can contain faults, veins,
    roads, symbols, leader lines, or other foreground linework. Semantic
    classification happens later.
    """
    responses = []

    for length in (9, 17, 29, 41):
        base = np.zeros((length, length), dtype=np.uint8)
        center = length // 2

        for angle in (0, 30, 60, 90, 120, 150):
            kernel = base.copy()
            theta = np.deg2rad(angle)
            dx = int(round((length - 1) * 0.45 * np.cos(theta)))
            dy = int(round((length - 1) * 0.45 * np.sin(theta)))

            p1 = (center - dx, center - dy)
            p2 = (center + dx, center + dy)

            cv2.line(kernel, p1, p2, 1, thickness=3)
            response = cv2.morphologyEx(
                gray,
                cv2.MORPH_BLACKHAT,
                kernel,
            )
            responses.append(response.astype(np.float32))

    response = np.stack(responses, axis=0).max(axis=0)

    lo = float(np.percentile(response, 1.0))
    hi = float(np.percentile(response, 99.5))
    if hi <= lo + 1e-6:
        return np.zeros_like(gray)

    response = (response - lo) * (255.0 / (hi - lo))
    return np.clip(response, 0, 255).astype(np.uint8)


def component_pca_shape(component_mask: np.ndarray) -> tuple[float, float, float]:
    """
    Return (major_length, minor_length, elongation_ratio) from component pixels.
    """
    ys, xs = np.where(component_mask)
    if len(xs) < 2:
        return 0.0, 0.0, 1.0

    points = np.column_stack([xs, ys]).astype(np.float64)
    centered = points - points.mean(axis=0, keepdims=True)

    cov = np.cov(centered, rowvar=False)
    eigvals = np.linalg.eigvalsh(cov)
    eigvals = np.maximum(eigvals, 1e-9)

    minor = float(np.sqrt(eigvals[0]) * 4.0)
    major = float(np.sqrt(eigvals[1]) * 4.0)
    ratio = major / max(minor, 1e-6)

    return major, minor, ratio


def recover_seedless_linear_features(
    original_bgr: np.ndarray,
    topology_map_mask: np.ndarray,
    seeded_occluders: np.ndarray,
    min_major_length: float = 12.0,
    min_elongation: float = 3.0,
    max_minor_width: float = 18.0,
    min_area: int = 8,
    max_area: int = 5000,
) -> tuple[np.ndarray, list[dict], np.ndarray]:
    """
    Recover visible elongated foreground features that do NOT have a restored
    topology-hole seed.

    This fixes cases such as a faded gray/black vein/fault/line extension that
    is visible in the scan but was previously ignored because the visibility
    module only followed symbol-hole seeds.
    """
    gray = cv2.cvtColor(original_bgr, cv2.COLOR_BGR2GRAY)
    response = oriented_dark_line_response(gray)

    inside = topology_map_mask > 0
    response_inside = response[inside]

    if response_inside.size == 0:
        threshold = 255
    else:
        # Keep only strong line-response pixels. A floor prevents broad scan
        # texture from becoming foreground geometry on aged maps.
        threshold = int(
            max(
                32,
                np.percentile(response_inside, 88.0),
            )
        )

    candidate = (
        (response >= threshold)
        & inside
        & (seeded_occluders == 0)
    ).astype(np.uint8)

    # Bridge tiny anti-aliased gaps, but keep a rectangular kernel to avoid
    # rounding compact geometry.
    candidate = cv2.morphologyEx(
        candidate,
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)),
        iterations=1,
    )

    n, components, stats, _ = cv2.connectedComponentsWithStats(
        candidate,
        connectivity=8,
    )

    recovered = np.zeros_like(candidate, dtype=np.uint8)
    report: list[dict] = []

    for component_id in range(1, n):
        area = int(stats[component_id, cv2.CC_STAT_AREA])
        if area < min_area or area > max_area:
            continue

        component = components == component_id
        major, minor, elongation = component_pca_shape(component)

        accepted = (
            major >= min_major_length
            and elongation >= min_elongation
            and minor <= max_minor_width
        )

        if not accepted:
            continue

        x = int(stats[component_id, cv2.CC_STAT_LEFT])
        y = int(stats[component_id, cv2.CC_STAT_TOP])
        w = int(stats[component_id, cv2.CC_STAT_WIDTH])
        h = int(stats[component_id, cv2.CC_STAT_HEIGHT])

        recovered[component] = 1
        report.append(
            {
                "component": int(component_id),
                "area": area,
                "bbox": [x, y, w, h],
                "major_length": major,
                "minor_width": minor,
                "elongation": elongation,
            }
        )

    return recovered, report, response



# ---------------------------------------------------------------------
# CONTINUITY-BASED WEAK LINE EXTENSION
# ---------------------------------------------------------------------


def normalize_float_u8(arr: np.ndarray) -> np.ndarray:
    arr = arr.astype(np.float32)
    lo = float(np.percentile(arr, 1.0))
    hi = float(np.percentile(arr, 99.5))
    if hi <= lo + 1e-6:
        return np.zeros(arr.shape, dtype=np.uint8)
    out = (arr - lo) * (255.0 / (hi - lo))
    return np.clip(out, 0, 255).astype(np.uint8)


def dark_local_residual(gray: np.ndarray) -> np.ndarray:
    """
    Evidence for weak gray/black linework relative to the local paper/unit tone.
    This is more useful than an absolute darkness threshold for faded scans.
    """
    background = cv2.GaussianBlur(gray, (0, 0), sigmaX=7.0)
    residual = background.astype(np.float32) - gray.astype(np.float32)
    residual = np.maximum(residual, 0.0)
    return normalize_float_u8(residual)


def pca_axis_from_component(component_mask: np.ndarray):
    ys, xs = np.where(component_mask)
    if len(xs) < 4:
        return None

    pts = np.column_stack([xs, ys]).astype(np.float64)
    center = pts.mean(axis=0)
    centered = pts - center

    cov = np.cov(centered, rowvar=False)
    eigvals, eigvecs = np.linalg.eigh(cov)
    axis = eigvecs[:, int(np.argmax(eigvals))]
    norm = float(np.linalg.norm(axis))
    if norm <= 1e-9:
        return None

    axis = axis / norm
    projections = centered @ axis

    p_min = pts[int(np.argmin(projections))]
    p_max = pts[int(np.argmax(projections))]

    return center, axis, p_min, p_max


def trace_weak_continuation(
    start_xy: np.ndarray,
    direction_xy: np.ndarray,
    evidence: np.ndarray,
    allowed_mask: np.ndarray,
    existing_mask: np.ndarray,
    max_steps: int = 70,
    search_radius: int = 2,
    min_evidence: int = 42,
    max_misses: int = 5,
) -> np.ndarray:
    """
    Follow a weak continuation from one endpoint.

    The predicted location advances along the component's PCA direction. At
    each step only pixels in a very small corridor around that direction are
    considered. This lets a strong detected segment continue into a faded gray
    continuation without allowing the path to wander freely into unrelated
    contacts.
    """
    h, w = evidence.shape
    traced = np.zeros_like(evidence, dtype=np.uint8)

    pos = np.asarray(start_xy, dtype=np.float64).copy()
    direction = np.asarray(direction_xy, dtype=np.float64)
    norm = float(np.linalg.norm(direction))
    if norm <= 1e-9:
        return traced
    direction /= norm

    misses = 0

    for _ in range(max_steps):
        predicted = pos + direction

        cx = int(round(predicted[0]))
        cy = int(round(predicted[1]))

        best = None
        best_score = -1e9

        for yy in range(cy - search_radius, cy + search_radius + 1):
            if yy < 0 or yy >= h:
                continue
            for xx in range(cx - search_radius, cx + search_radius + 1):
                if xx < 0 or xx >= w:
                    continue
                if not allowed_mask[yy, xx]:
                    continue

                ev = int(evidence[yy, xx])
                if ev < min_evidence:
                    continue

                delta = np.array([xx, yy], dtype=np.float64) - pos
                forward = float(np.dot(delta, direction))
                if forward <= 0.15:
                    continue

                perpendicular = abs(
                    float(
                        delta[0] * (-direction[1])
                        + delta[1] * direction[0]
                    )
                )

                # Strict narrow corridor around the current direction.
                if perpendicular > 2.75:
                    continue

                distance_from_prediction = float(
                    np.linalg.norm(
                        np.array([xx, yy], dtype=np.float64) - predicted
                    )
                )

                score = (
                    2.0 * ev
                    - 18.0 * perpendicular
                    - 8.0 * distance_from_prediction
                )

                if existing_mask[yy, xx] > 0:
                    # Do not preferentially jump sideways into already detected
                    # unrelated linework at intersections.
                    score -= 20.0

                if score > best_score:
                    best_score = score
                    best = (xx, yy)

        if best is None:
            misses += 1
            pos = predicted
            if misses > max_misses:
                break
            continue

        misses = 0
        x, y = best

        cv2.line(
            traced,
            (int(round(pos[0])), int(round(pos[1]))),
            (x, y),
            1,
            thickness=2,
            lineType=cv2.LINE_8,
        )

        new_pos = np.array([x, y], dtype=np.float64)
        step_vec = new_pos - pos
        step_norm = float(np.linalg.norm(step_vec))

        if step_norm > 1e-6:
            step_dir = step_vec / step_norm
            # Slowly adapt direction while retaining strong continuity.
            direction = 0.85 * direction + 0.15 * step_dir
            direction /= max(float(np.linalg.norm(direction)), 1e-9)

        pos = new_pos

    return traced


def extend_linear_features_by_continuity(
    original_bgr: np.ndarray,
    initial_linear_mask: np.ndarray,
    oriented_response: np.ndarray,
    topology_map_mask: np.ndarray,
    max_steps: int = 70,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """
    Extend already-detected elongated components into weaker collinear visible
    continuations.

    This specifically addresses features where the strong portion is detected
    but a faded gray continuation disappears near/through an intersection.
    """
    gray = cv2.cvtColor(original_bgr, cv2.COLOR_BGR2GRAY)
    residual = dark_local_residual(gray)

    evidence = np.maximum(
        oriented_response.astype(np.uint8),
        residual.astype(np.uint8),
    )

    allowed = topology_map_mask > 0

    n, components, stats, _ = cv2.connectedComponentsWithStats(
        (initial_linear_mask > 0).astype(np.uint8),
        connectivity=8,
    )

    extension = np.zeros_like(initial_linear_mask, dtype=np.uint8)
    traced_components = 0

    inside_vals = evidence[allowed]
    if inside_vals.size:
        low_threshold = int(max(30, np.percentile(inside_vals, 62.0)))
    else:
        low_threshold = 42

    for component_id in range(1, n):
        area = int(stats[component_id, cv2.CC_STAT_AREA])
        if area < 10:
            continue

        component = components == component_id
        axis_info = pca_axis_from_component(component)
        if axis_info is None:
            continue

        _, axis, p_min, p_max = axis_info

        # Trace away from both ends.
        ext_a = trace_weak_continuation(
            start_xy=p_min,
            direction_xy=-axis,
            evidence=evidence,
            allowed_mask=allowed,
            existing_mask=initial_linear_mask,
            max_steps=max_steps,
            min_evidence=low_threshold,
        )
        ext_b = trace_weak_continuation(
            start_xy=p_max,
            direction_xy=axis,
            evidence=evidence,
            allowed_mask=allowed,
            existing_mask=initial_linear_mask,
            max_steps=max_steps,
            min_evidence=low_threshold,
        )

        component_extension = np.maximum(ext_a, ext_b)
        if np.any(component_extension):
            traced_components += 1
            extension = np.maximum(extension, component_extension)

    # Keep only genuinely new pixels for diagnostics.
    extension[initial_linear_mask > 0] = 0

    extended = np.maximum(
        (initial_linear_mask > 0).astype(np.uint8),
        extension,
    ).astype(np.uint8)

    # One small close joins subpixel gaps introduced by antialiasing.
    extended = cv2.morphologyEx(
        extended,
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)),
        iterations=1,
    )

    report = {
        "continuity_low_evidence_threshold": int(low_threshold),
        "continuity_traced_components": int(traced_components),
        "continuity_extension_pixels": int(extension.sum()),
        "continuity_max_steps": int(max_steps),
    }

    return extended, extension, report


# ---------------------------------------------------------------------
# VISIBLE / HIDDEN GEOLOGY
# ---------------------------------------------------------------------


def build_visible_labels(
    inferred_labels: np.ndarray,
    raw_map_mask: np.ndarray,
    recovered_occluder_mask: np.ndarray,
) -> np.ndarray:
    """
    Preserve inferred geological labels separately, but remove pixels covered
    by visibly foreground dark objects.

    `raw_map_mask == 0` also remains non-visible geology, because that is the
    geological support before topology-hole reconstruction.
    """
    visible = inferred_labels.copy()

    hidden = (raw_map_mask == 0) | (recovered_occluder_mask > 0)
    visible[hidden] = -1

    return visible


def split_visible_and_hidden_contacts(
    inferred_boundary: np.ndarray,
    recovered_occluder_mask: np.ndarray,
    suppression_radius: int = 1,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Split inferred geological contacts into visibly rendered and hidden parts.
    """
    suppression = dilate_mask(
        recovered_occluder_mask,
        suppression_radius,
    )

    hidden = (
        (inferred_boundary > 0)
        & (suppression > 0)
    ).astype(np.uint8)

    visible = (
        (inferred_boundary > 0)
        & (suppression == 0)
    ).astype(np.uint8)

    return visible, hidden


# ---------------------------------------------------------------------
# OVERLAYS
# ---------------------------------------------------------------------


def make_visible_overlay(
    original: np.ndarray,
    visible_contacts: np.ndarray,
    occluder_boundary: np.ndarray,
) -> np.ndarray:
    overlay = original.copy()

    # Visible geological contacts.
    overlay[visible_contacts > 0] = (0, 255, 0)

    # Exact recovered foreground-object perimeter.
    overlay[occluder_boundary > 0] = (255, 0, 255)

    return overlay


def make_hidden_overlay(
    original: np.ndarray,
    hidden_contacts: np.ndarray,
) -> np.ndarray:
    overlay = original.copy()
    overlay[hidden_contacts > 0] = (0, 0, 255)
    return overlay


def make_seed_vs_recovered_overlay(
    original: np.ndarray,
    seed_mask: np.ndarray,
    recovered_mask: np.ndarray,
) -> np.ndarray:
    """
    Diagnostic:
      cyan    = old topology-hole seed
      magenta = recovered original dark-object perimeter
    """
    overlay = original.copy()

    seed_boundary = mask_boundary(seed_mask)
    recovered_boundary = mask_boundary(recovered_mask)

    overlay[seed_boundary > 0] = (255, 255, 0)
    overlay[recovered_boundary > 0] = (255, 0, 255)

    return overlay


# ---------------------------------------------------------------------
# VALIDATION / MAIN
# ---------------------------------------------------------------------


def validate_shapes(
    labels: np.ndarray,
    raw_map_mask: np.ndarray,
    topology_map_mask: np.ndarray,
    seed_mask: np.ndarray,
    original: np.ndarray,
) -> None:
    expected = labels.shape

    for name, array in [
        ("raw_map_mask", raw_map_mask),
        ("topology_map_mask", topology_map_mask),
        ("seed_mask", seed_mask),
    ]:
        if array.shape != expected:
            raise ValueError(
                f"Shape mismatch: labels={expected}, {name}={array.shape}"
            )

    if original.shape[:2] != expected:
        raise ValueError(
            f"Shape mismatch: labels={expected}, original={original.shape[:2]}"
        )


def run(
    input_dir: Path,
    output_dir: Path,
    suppression_radius: int,
    dark_value_threshold: int,
    adaptive_percentile: float,
    seed_touch_radius: int,
    recover_linear_features: bool,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    labels_path = input_dir / "region_labels.npy"
    raw_mask_path = input_dir / "03a_raw_map_mask.png"
    topology_mask_path = input_dir / "03b_topology_map_mask.png"
    seed_path = input_dir / "03c_restored_symbol_holes.png"
    original_path = input_dir / "01_original.png"

    required = [
        labels_path,
        raw_mask_path,
        topology_mask_path,
        seed_path,
        original_path,
    ]

    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Required extractor outputs are missing:\n  "
            + "\n  ".join(missing)
        )

    inferred_labels = np.load(labels_path)
    raw_map_mask = read_mask(raw_mask_path)
    topology_map_mask = read_mask(topology_mask_path)
    seed_mask = read_mask(seed_path)
    original = read_color(original_path)

    validate_shapes(
        inferred_labels,
        raw_map_mask,
        topology_map_mask,
        seed_mask,
        original,
    )

    print("=" * 72)
    print("GeoMap visibility / original-object recovery")
    print("Input:", input_dir)
    print("Output:", output_dir)
    print("Shape:", inferred_labels.shape)
    print("Suppression radius:", suppression_radius)
    print("Dark value threshold:", dark_value_threshold)
    print("Adaptive percentile:", adaptive_percentile)
    print("Seed touch radius:", seed_touch_radius)
    print("=" * 72)

    # ---------------------------------------------------------
    # 1. Recover actual visible dark geometry from ORIGINAL scan
    # ---------------------------------------------------------

    dark_candidate_mask, dark_report = build_dark_pixel_mask(
        original,
        dark_value_threshold=dark_value_threshold,
        adaptive_percentile=adaptive_percentile,
    )

    recovered_occluders, recovered_components = recover_seeded_dark_objects(
        dark_candidate_mask,
        seed_mask,
        seed_touch_radius=seed_touch_radius,
    )

    recovered_occluders = recover_seed_local_dark_objects(
        dark_candidate_mask,
        seed_mask,
        recovered_occluders,
        padding=4,
    )

    recovered_occluder_boundary = mask_boundary(recovered_occluders)

    # ---------------------------------------------------------
    # 2. Recover visible seedless elongated foreground linework
    # ---------------------------------------------------------

    if recover_linear_features:
        linear_features_initial, linear_report, line_response = (
            recover_seedless_linear_features(
                original,
                topology_map_mask,
                recovered_occluders,
            )
        )

        (
            linear_features,
            continuity_extension,
            continuity_report,
        ) = extend_linear_features_by_continuity(
            original,
            linear_features_initial,
            line_response,
            topology_map_mask,
            max_steps=70,
        )
    else:
        linear_features_initial = np.zeros_like(recovered_occluders)
        linear_features = np.zeros_like(recovered_occluders)
        continuity_extension = np.zeros_like(recovered_occluders)
        line_response = np.zeros_like(recovered_occluders)
        linear_report = []
        continuity_report = {
            "continuity_low_evidence_threshold": 0,
            "continuity_traced_components": 0,
            "continuity_extension_pixels": 0,
            "continuity_max_steps": 0,
        }

    # All visibly foreground geometry suppresses hidden geology.
    visible_foreground = np.maximum(
        recovered_occluders,
        linear_features,
    ).astype(np.uint8)

    visible_foreground_boundary = mask_boundary(visible_foreground)

    # ---------------------------------------------------------
    # 3. Separate inferred and visible geological topology
    # ---------------------------------------------------------

    inferred_boundary = compute_shared_boundaries(inferred_labels)

    visible_labels = build_visible_labels(
        inferred_labels,
        raw_map_mask,
        visible_foreground,
    )

    visible_boundary_from_labels = compute_shared_boundaries(
        visible_labels
    )

    (
        visible_inferred_boundary,
        hidden_inferred_boundary,
    ) = split_visible_and_hidden_contacts(
        inferred_boundary,
        visible_foreground,
        suppression_radius=suppression_radius,
    )

    visible_contact = (
        (visible_inferred_boundary > 0)
        & (visible_boundary_from_labels > 0)
    ).astype(np.uint8)

    # ---------------------------------------------------------
    # 4. Save data products
    # ---------------------------------------------------------

    np.save(
        output_dir / "inferred_region_labels.npy",
        inferred_labels,
    )
    np.save(
        output_dir / "visible_region_labels.npy",
        visible_labels,
    )

    save_mask(
        output_dir / "01_topology_hole_seeds.png",
        seed_mask,
    )
    save_mask(
        output_dir / "02_dark_candidate_pixels.png",
        dark_candidate_mask,
    )
    save_mask(
        output_dir / "03_recovered_visible_occluders.png",
        recovered_occluders,
    )
    save_mask(
        output_dir / "04_recovered_occluder_boundary.png",
        visible_foreground_boundary,
    )
    save_mask(
        output_dir / "05_oriented_line_response.png",
        line_response,
    )
    save_mask(
        output_dir / "06_seedless_linear_features_initial.png",
        linear_features_initial,
    )
    save_mask(
        output_dir / "07_continuity_extension.png",
        continuity_extension,
    )
    save_mask(
        output_dir / "08_recovered_seedless_linear_features.png",
        linear_features,
    )
    save_mask(
        output_dir / "09_visible_foreground_mask.png",
        visible_foreground,
    )
    save_mask(
        output_dir / "10_visible_foreground_boundary.png",
        visible_foreground_boundary,
    )
    save_mask(
        output_dir / "11_inferred_contacts.png",
        inferred_boundary,
    )
    save_mask(
        output_dir / "12_visible_contacts.png",
        visible_contact,
    )
    save_mask(
        output_dir / "13_hidden_inferred_contacts.png",
        hidden_inferred_boundary,
    )

    visible_overlay = make_visible_overlay(
        original,
        visible_contact,
        recovered_occluder_boundary,
    )
    hidden_overlay = make_hidden_overlay(
        original,
        hidden_inferred_boundary,
    )
    seed_recovery_overlay = make_seed_vs_recovered_overlay(
        original,
        seed_mask,
        recovered_occluders,
    )

    cv2.imwrite(
        str(output_dir / "14_visible_geometry_overlay.png"),
        visible_overlay,
    )
    cv2.imwrite(
        str(output_dir / "15_hidden_contact_diagnostic.png"),
        hidden_overlay,
    )
    cv2.imwrite(
        str(output_dir / "16_seed_vs_recovered_object.png"),
        seed_recovery_overlay,
    )

    # ---------------------------------------------------------
    # 5. Report
    # ---------------------------------------------------------

    restored_support = (
        (topology_map_mask > 0)
        & (raw_map_mask == 0)
    ).astype(np.uint8)

    seed_components = (
        cv2.connectedComponents(
            seed_mask.astype(np.uint8),
            connectivity=8,
        )[0]
        - 1
    )

    recovered_components_count = (
        cv2.connectedComponents(
            recovered_occluders.astype(np.uint8),
            connectivity=8,
        )[0]
        - 1
    )

    report = {
        "input_dir": str(input_dir),
        "shape": [
            int(inferred_labels.shape[0]),
            int(inferred_labels.shape[1]),
        ],
        "parameters": {
            "suppression_radius": int(suppression_radius),
            "dark_value_threshold": int(dark_value_threshold),
            "adaptive_percentile": float(adaptive_percentile),
            "seed_touch_radius": int(seed_touch_radius),
        },
        "dark_mask": dark_report,
        "seed_components": int(max(0, seed_components)),
        "seed_pixels": int(seed_mask.sum()),
        "recovered_occluder_components": int(
            max(0, recovered_components_count)
        ),
        "recovered_occluder_pixels": int(
            recovered_occluders.sum()
        ),
        "recovered_component_details": recovered_components,
        "seedless_linear_feature_components": int(len(linear_report)),
        "seedless_linear_feature_pixels": int(linear_features.sum()),
        "seedless_linear_feature_details": linear_report,
        "continuity_extension": continuity_report,
        "visible_foreground_pixels": int(visible_foreground.sum()),
        "topology_support_restored_pixels": int(
            restored_support.sum()
        ),
        "inferred_contact_pixels": int(
            inferred_boundary.sum()
        ),
        "visible_contact_pixels": int(
            visible_contact.sum()
        ),
        "hidden_inferred_contact_pixels": int(
            hidden_inferred_boundary.sum()
        ),
        "visible_geology_pixels": int(
            (visible_labels >= 0).sum()
        ),
        "inferred_geology_pixels": int(
            (inferred_labels >= 0).sum()
        ),
        "semantics": {
            "01_topology_hole_seeds.png": (
                "Old restored topology holes. Location seeds only; "
                "NOT visible-object geometry."
            ),
            "03_recovered_visible_occluders.png": (
                "Visible dark foreground geometry recovered from "
                "01_original.png using topology-hole seeds."
            ),
            "04_recovered_occluder_boundary.png": (
                "Perimeter of actual recovered visible dark geometry."
            ),
            "06_seedless_linear_features_initial.png": (
                "Initial strong elongated foreground linework before continuity tracing."
            ),
            "07_continuity_extension.png": (
                "Additional weak collinear line pixels recovered by endpoint continuity."
            ),
            "08_recovered_seedless_linear_features.png": (
                "Union of strong seedless linework and continuity-recovered weak segments."
            ),
            "09_visible_foreground_mask.png": (
                "Union of compact seeded occluders and seedless visible linework."
            ),
            "12_visible_contacts.png": (
                "Geological contacts permitted for visible-map/GIS export."
            ),
            "13_hidden_inferred_contacts.png": (
                "Geological contacts inferred beneath foreground objects. "
                "Diagnostic/inference layer only."
            ),
        },
    }

    report_path = output_dir / "visibility_report.json"
    report_path.write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("Seed components:", report["seed_components"])
    print(
        "Recovered visible-object components:",
        report["recovered_occluder_components"],
    )
    print("Seed pixels:", report["seed_pixels"])
    print(
        "Recovered visible-object pixels:",
        report["recovered_occluder_pixels"],
    )
    print(
        "Seedless linear-feature components:",
        report["seedless_linear_feature_components"],
    )
    print(
        "Seedless linear-feature pixels:",
        report["seedless_linear_feature_pixels"],
    )
    print(
        "Continuity extension pixels:",
        report["continuity_extension"]["continuity_extension_pixels"],
    )
    print(
        "Continuity-traced components:",
        report["continuity_extension"]["continuity_traced_components"],
    )
    print(
        "Inferred contact pixels:",
        report["inferred_contact_pixels"],
    )
    print(
        "Visible contact pixels:",
        report["visible_contact_pixels"],
    )
    print(
        "Hidden inferred contact pixels:",
        report["hidden_inferred_contact_pixels"],
    )
    print()
    print("Complete")
    print(
        "Visible overlay:",
        output_dir / "14_visible_geometry_overlay.png",
    )
    print(
        "Seed-vs-recovered diagnostic:",
        output_dir / "16_seed_vs_recovered_object.png",
    )
    print("Report:", report_path)
    print("=" * 72)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Recover actual visible foreground dark-object geometry from the "
            "original geological map using topology-restored holes only as "
            "location seeds, then separate visible from hidden geology."
        )
    )

    parser.add_argument(
        "--input-dir",
        type=Path,
        required=True,
        help="Directory produced by color_region_boundary_extractor.py",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "--suppression-radius",
        type=int,
        default=1,
        help=(
            "Pixels around recovered foreground objects in which inferred "
            "geological contacts are considered hidden. Default: 1."
        ),
    )
    parser.add_argument(
        "--dark-value-threshold",
        type=int,
        default=105,
        help=(
            "Base HSV value threshold for visible dark-object recovery. "
            "Default: 105."
        ),
    )
    parser.add_argument(
        "--adaptive-percentile",
        type=float,
        default=18.0,
        help=(
            "Image value percentile used to adapt dark threshold on aged/dim "
            "scans. Default: 18."
        ),
    )
    parser.add_argument(
        "--seed-touch-radius",
        type=int,
        default=2,
        help=(
            "Radius allowing original dark components to connect to topology "
            "hole seeds despite antialiasing. Default: 2."
        ),
    )
    parser.add_argument(
        "--no-linear-recovery",
        action="store_true",
        help=(
            "Disable recovery of visible elongated foreground linework that "
            "does not have a topology-hole seed."
        ),
    )

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    run(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        suppression_radius=args.suppression_radius,
        dark_value_threshold=args.dark_value_threshold,
        adaptive_percentile=args.adaptive_percentile,
        seed_touch_radius=args.seed_touch_radius,
        recover_linear_features=not args.no_linear_recovery,
    )
