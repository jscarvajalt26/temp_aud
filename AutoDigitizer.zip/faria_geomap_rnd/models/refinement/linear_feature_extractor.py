from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np


# ---------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------


def read_gray(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"Could not read grayscale image: {path}")
    return image


def read_color(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read color image: {path}")
    return image


def save_mask(path: Path, mask: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ok = cv2.imwrite(str(path), (mask > 0).astype(np.uint8) * 255)
    if not ok:
        raise IOError(f"Could not write: {path}")


# ---------------------------------------------------------------------
# BASIC HELPERS
# ---------------------------------------------------------------------


def normalize_u8(arr: np.ndarray) -> np.ndarray:
    arr = arr.astype(np.float32)
    lo = float(np.percentile(arr, 1.0))
    hi = float(np.percentile(arr, 99.5))

    if hi <= lo + 1e-6:
        return np.zeros(arr.shape, dtype=np.uint8)

    out = (arr - lo) * (255.0 / (hi - lo))
    return np.clip(out, 0, 255).astype(np.uint8)


def angle_between(v1: np.ndarray, v2: np.ndarray) -> float:
    a = np.asarray(v1, dtype=np.float64)
    b = np.asarray(v2, dtype=np.float64)

    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))

    if na <= 1e-9 or nb <= 1e-9:
        return 180.0

    a /= na
    b /= nb

    # Lines are orientation-invariant, so v and -v represent same axis.
    c = abs(float(np.dot(a, b)))
    c = max(-1.0, min(1.0, c))

    return float(np.degrees(np.arccos(c)))


def point_distance(a, b) -> float:
    return float(
        math.hypot(
            float(a[0]) - float(b[0]),
            float(a[1]) - float(b[1]),
        )
    )


# ---------------------------------------------------------------------
# EVIDENCE FUSION
# ---------------------------------------------------------------------


def build_line_evidence(
    structural_gray: np.ndarray,
    dark_line: np.ndarray,
    oriented_line: np.ndarray,
    combined_line: np.ndarray,
) -> np.ndarray:
    """
    Fuse restoration outputs into one line-likelihood image.

    Structural grayscale contributes local dark residuals so weak gray
    continuations can survive even when they were not strong enough in the
    morphology-derived line channels.
    """
    background = cv2.GaussianBlur(
        structural_gray,
        (0, 0),
        sigmaX=7.0,
    )

    local_dark = np.maximum(
        background.astype(np.float32)
        - structural_gray.astype(np.float32),
        0.0,
    )
    local_dark = normalize_u8(local_dark)

    fused = (
        0.22 * local_dark.astype(np.float32)
        + 0.24 * dark_line.astype(np.float32)
        + 0.30 * oriented_line.astype(np.float32)
        + 0.24 * combined_line.astype(np.float32)
    )

    return normalize_u8(fused)


# ---------------------------------------------------------------------
# INITIAL LINE MASK
# ---------------------------------------------------------------------


def build_initial_line_mask(
    evidence: np.ndarray,
    percentile: float = 84.0,
    minimum_threshold: int = 36,
) -> tuple[np.ndarray, int]:
    threshold = int(
        max(
            minimum_threshold,
            np.percentile(evidence, percentile),
        )
    )

    mask = (evidence >= threshold).astype(np.uint8)

    # Only bridge tiny breaks. No large morphology here.
    mask = cv2.morphologyEx(
        mask,
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(
            cv2.MORPH_RECT,
            (3, 3),
        ),
        iterations=1,
    )

    return mask, threshold


# ---------------------------------------------------------------------
# COMPONENT FILTERING
# ---------------------------------------------------------------------


def component_pca(component_mask: np.ndarray):
    ys, xs = np.where(component_mask)

    if len(xs) < 3:
        return None

    points = np.column_stack([xs, ys]).astype(np.float64)
    center = points.mean(axis=0)

    centered = points - center

    cov = np.cov(
        centered,
        rowvar=False,
    )

    eigvals, eigvecs = np.linalg.eigh(cov)

    order = np.argsort(eigvals)
    minor_val = max(float(eigvals[order[0]]), 1e-9)
    major_val = max(float(eigvals[order[-1]]), 1e-9)

    axis = eigvecs[:, order[-1]]
    axis /= max(
        float(np.linalg.norm(axis)),
        1e-9,
    )

    projections = centered @ axis

    p_min = points[
        int(np.argmin(projections))
    ]
    p_max = points[
        int(np.argmax(projections))
    ]

    major_length = (
        float(np.sqrt(major_val))
        * 4.0
    )
    minor_width = (
        float(np.sqrt(minor_val))
        * 4.0
    )

    elongation = (
        major_length
        / max(minor_width, 1e-6)
    )

    return {
        "center": center,
        "axis": axis,
        "endpoint_a": p_min,
        "endpoint_b": p_max,
        "major_length": major_length,
        "minor_width": minor_width,
        "elongation": elongation,
    }


def filter_linear_components(
    initial_mask: np.ndarray,
    min_area: int = 8,
    max_area: int = 8000,
    min_major_length: float = 10.0,
    min_elongation: float = 2.4,
    max_minor_width: float = 24.0,
):
    n, components, stats, _ = cv2.connectedComponentsWithStats(
        initial_mask.astype(np.uint8),
        connectivity=8,
    )

    kept = np.zeros_like(
        initial_mask,
        dtype=np.uint8,
    )

    records = []

    for component_id in range(1, n):
        area = int(
            stats[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        if area < min_area or area > max_area:
            continue

        x = int(
            stats[
                component_id,
                cv2.CC_STAT_LEFT,
            ]
        )
        y = int(
            stats[
                component_id,
                cv2.CC_STAT_TOP,
            ]
        )
        w = int(
            stats[
                component_id,
                cv2.CC_STAT_WIDTH,
            ]
        )
        h = int(
            stats[
                component_id,
                cv2.CC_STAT_HEIGHT,
            ]
        )

        # Work inside the component's bounding box instead of the full image.
        component = components[y : y + h, x : x + w] == component_id

        pca = component_pca(component)
        if pca is None:
            continue

        offset = np.array([x, y], dtype=np.float64)
        pca["center"] = pca["center"] + offset
        pca["endpoint_a"] = pca["endpoint_a"] + offset
        pca["endpoint_b"] = pca["endpoint_b"] + offset

        accepted = (
            pca["major_length"] >= min_major_length
            and pca["elongation"] >= min_elongation
            and pca["minor_width"] <= max_minor_width
        )

        if not accepted:
            continue

        kept[y : y + h, x : x + w][component] = 1

        records.append(
            {
                "component_id": int(component_id),
                "area": area,
                "bbox": [x, y, w, h],
                "center": [
                    float(pca["center"][0]),
                    float(pca["center"][1]),
                ],
                "axis": [
                    float(pca["axis"][0]),
                    float(pca["axis"][1]),
                ],
                "endpoint_a": [
                    float(pca["endpoint_a"][0]),
                    float(pca["endpoint_a"][1]),
                ],
                "endpoint_b": [
                    float(pca["endpoint_b"][0]),
                    float(pca["endpoint_b"][1]),
                ],
                "major_length": float(
                    pca["major_length"]
                ),
                "minor_width": float(
                    pca["minor_width"]
                ),
                "elongation": float(
                    pca["elongation"]
                ),
            }
        )

    return kept, records


# ---------------------------------------------------------------------
# CROSSING-AWARE GAP RECONSTRUCTION
# ---------------------------------------------------------------------


def candidate_endpoint_pairs(
    records: list[dict],
    max_gap: float,
    max_angle_deg: float,
):
    candidates = []

    # Only pairs with at least one endpoint pair within max_gap can produce
    # a candidate, so find those first instead of testing every pair.
    from scipy.spatial import cKDTree

    endpoints = np.asarray(
        [rec["endpoint_a"] for rec in records]
        + [rec["endpoint_b"] for rec in records],
        dtype=np.float64,
    ).reshape(-1, 2)
    owner = np.concatenate([np.arange(len(records))] * 2)

    near = defaultdict(set)
    if len(records) > 1:
        for a, b in cKDTree(endpoints).query_pairs(max_gap):
            i, j = sorted((int(owner[a]), int(owner[b])))
            if i != j:
                near[i].add(j)

    for i in range(len(records)):
        rec_i = records[i]
        axis_i = np.asarray(
            rec_i["axis"],
            dtype=np.float64,
        )

        endpoints_i = [
            np.asarray(
                rec_i["endpoint_a"],
                dtype=np.float64,
            ),
            np.asarray(
                rec_i["endpoint_b"],
                dtype=np.float64,
            ),
        ]

        for j in sorted(near[i]):
            rec_j = records[j]
            axis_j = np.asarray(
                rec_j["axis"],
                dtype=np.float64,
            )

            axis_angle = angle_between(
                axis_i,
                axis_j,
            )

            if axis_angle > max_angle_deg:
                continue

            endpoints_j = [
                np.asarray(
                    rec_j["endpoint_a"],
                    dtype=np.float64,
                ),
                np.asarray(
                    rec_j["endpoint_b"],
                    dtype=np.float64,
                ),
            ]

            for ei, p in enumerate(endpoints_i):
                for ej, q in enumerate(endpoints_j):
                    gap = point_distance(p, q)

                    if gap > max_gap:
                        continue

                    connector = q - p

                    if float(np.linalg.norm(connector)) <= 1e-9:
                        continue

                    # Connector should align with both line axes.
                    angle_i = angle_between(
                        connector,
                        axis_i,
                    )
                    angle_j = angle_between(
                        connector,
                        axis_j,
                    )

                    if (
                        angle_i > max_angle_deg
                        or angle_j > max_angle_deg
                    ):
                        continue

                    candidates.append(
                        {
                            "i": i,
                            "j": j,
                            "ei": ei,
                            "ej": ej,
                            "p": p,
                            "q": q,
                            "gap": gap,
                            "axis_angle": axis_angle,
                            "connector_angle_i": angle_i,
                            "connector_angle_j": angle_j,
                        }
                    )

    candidates.sort(
        key=lambda x: (
            x["gap"],
            x["axis_angle"],
        )
    )

    return candidates


def sample_segment_evidence(
    evidence: np.ndarray,
    p: np.ndarray,
    q: np.ndarray,
    corridor_radius: int = 2,
) -> dict:
    length = max(
        2,
        int(
            round(
                point_distance(
                    p,
                    q,
                )
            )
        )
        + 1,
    )

    xs = np.linspace(
        p[0],
        q[0],
        length,
    )
    ys = np.linspace(
        p[1],
        q[1],
        length,
    )

    values = []

    h, w = evidence.shape

    for x, y in zip(xs, ys):
        cx = int(round(x))
        cy = int(round(y))

        local = []

        for yy in range(
            cy - corridor_radius,
            cy + corridor_radius + 1,
        ):
            if yy < 0 or yy >= h:
                continue

            for xx in range(
                cx - corridor_radius,
                cx + corridor_radius + 1,
            ):
                if xx < 0 or xx >= w:
                    continue

                local.append(
                    int(
                        evidence[
                            yy,
                            xx,
                        ]
                    )
                )

        if local:
            values.append(
                max(local)
            )

    if not values:
        return {
            "mean": 0.0,
            "median": 0.0,
            "support_fraction": 0.0,
        }

    arr = np.asarray(
        values,
        dtype=np.float32,
    )

    return {
        "mean": float(arr.mean()),
        "median": float(np.median(arr)),
        "support_fraction": float(
            np.mean(
                arr >= 32
            )
        ),
    }


def reconstruct_collinear_gaps(
    filtered_mask: np.ndarray,
    records: list[dict],
    evidence: np.ndarray,
    max_gap: float = 42.0,
    max_angle_deg: float = 18.0,
    minimum_mean_evidence: float = 38.0,
    minimum_support_fraction: float = 0.48,
):
    """
    Bridge only near-collinear component endpoints with sufficient evidence
    along the missing path.

    This is intended for crossings where one visible line temporarily
    disappears beneath/through another feature.
    """
    reconstructed = np.zeros_like(
        filtered_mask,
        dtype=np.uint8,
    )

    accepted = []

    used_endpoints = set()

    candidates = candidate_endpoint_pairs(
        records,
        max_gap=max_gap,
        max_angle_deg=max_angle_deg,
    )

    for candidate in candidates:
        key_i = (
            candidate["i"],
            candidate["ei"],
        )
        key_j = (
            candidate["j"],
            candidate["ej"],
        )

        if key_i in used_endpoints or key_j in used_endpoints:
            continue

        evidence_stats = sample_segment_evidence(
            evidence,
            candidate["p"],
            candidate["q"],
            corridor_radius=2,
        )

        if (
            evidence_stats["mean"]
            < minimum_mean_evidence
            or evidence_stats["support_fraction"]
            < minimum_support_fraction
        ):
            continue

        p = tuple(
            np.round(
                candidate["p"]
            ).astype(int)
        )
        q = tuple(
            np.round(
                candidate["q"]
            ).astype(int)
        )

        cv2.line(
            reconstructed,
            p,
            q,
            1,
            thickness=2,
            lineType=cv2.LINE_8,
        )

        used_endpoints.add(key_i)
        used_endpoints.add(key_j)

        accepted.append(
            {
                "component_i": int(
                    candidate["i"]
                ),
                "component_j": int(
                    candidate["j"]
                ),
                "gap": float(
                    candidate["gap"]
                ),
                "axis_angle_deg": float(
                    candidate["axis_angle"]
                ),
                "mean_evidence": float(
                    evidence_stats["mean"]
                ),
                "median_evidence": float(
                    evidence_stats["median"]
                ),
                "support_fraction": float(
                    evidence_stats[
                        "support_fraction"
                    ]
                ),
            }
        )

    return reconstructed, accepted


# ---------------------------------------------------------------------
# OVERLAY
# ---------------------------------------------------------------------


def make_overlay(
    original: np.ndarray,
    filtered_mask: np.ndarray,
    reconstructed_gaps: np.ndarray,
) -> np.ndarray:
    overlay = original.copy()

    # Detected linework: cyan.
    overlay[
        filtered_mask > 0
    ] = (
        255,
        255,
        0,
    )

    # Reconstructed missing path: magenta.
    overlay[
        reconstructed_gaps > 0
    ] = (
        255,
        0,
        255,
    )

    return overlay


# ---------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------


def run(
    restoration_dir: Path,
    output_dir: Path,
    original_path: Path | None,
    initial_percentile: float,
    max_gap: float,
    max_angle_deg: float,
) -> None:
    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    structural_path = (
        restoration_dir
        / "05_structural_grayscale.png"
    )
    dark_path = (
        restoration_dir
        / "07_dark_line_evidence.png"
    )
    oriented_path = (
        restoration_dir
        / "08_oriented_line_evidence.png"
    )
    combined_path = (
        restoration_dir
        / "09_combined_line_evidence.png"
    )

    if original_path is None:
        original_path = (
            restoration_dir
            / "01_original.png"
        )

    required = [
        structural_path,
        dark_path,
        oriented_path,
        combined_path,
        original_path,
    ]

    missing = [
        str(path)
        for path in required
        if not path.exists()
    ]

    if missing:
        raise FileNotFoundError(
            "Required restoration outputs are missing:\n  "
            + "\n  ".join(missing)
        )

    structural_gray = read_gray(
        structural_path
    )
    dark_line = read_gray(
        dark_path
    )
    oriented_line = read_gray(
        oriented_path
    )
    combined_line = read_gray(
        combined_path
    )
    original = read_color(
        original_path
    )

    shape = structural_gray.shape

    for name, image in [
        ("dark_line", dark_line),
        ("oriented_line", oriented_line),
        ("combined_line", combined_line),
    ]:
        if image.shape != shape:
            raise ValueError(
                f"{name} shape {image.shape} "
                f"!= structural shape {shape}"
            )

    if original.shape[:2] != shape:
        raise ValueError(
            f"original shape {original.shape[:2]} "
            f"!= structural shape {shape}"
        )

    print("=" * 72)
    print(
        "GeoMap independent linear-feature extractor"
    )
    print(
        "Restoration input:",
        restoration_dir,
    )
    print(
        "Output:",
        output_dir,
    )
    print(
        "Shape:",
        shape,
    )
    print("=" * 72)

    evidence = build_line_evidence(
        structural_gray,
        dark_line,
        oriented_line,
        combined_line,
    )

    initial_mask, threshold = (
        build_initial_line_mask(
            evidence,
            percentile=initial_percentile,
            minimum_threshold=36,
        )
    )

    (
        filtered_mask,
        component_records,
    ) = filter_linear_components(
        initial_mask,
        min_area=8,
        max_area=8000,
        min_major_length=10.0,
        min_elongation=2.4,
        max_minor_width=24.0,
    )

    (
        reconstructed_gaps,
        accepted_connections,
    ) = reconstruct_collinear_gaps(
        filtered_mask,
        component_records,
        evidence,
        max_gap=max_gap,
        max_angle_deg=max_angle_deg,
        minimum_mean_evidence=38.0,
        minimum_support_fraction=0.48,
    )

    final_mask = np.maximum(
        filtered_mask,
        reconstructed_gaps,
    ).astype(np.uint8)

    save_mask(
        output_dir
        / "01_fused_line_evidence.png",
        evidence,
    )
    save_mask(
        output_dir
        / "02_initial_line_mask.png",
        initial_mask,
    )
    save_mask(
        output_dir
        / "03_filtered_linear_components.png",
        filtered_mask,
    )
    save_mask(
        output_dir
        / "04_reconstructed_collinear_gaps.png",
        reconstructed_gaps,
    )
    save_mask(
        output_dir
        / "05_final_linear_feature_mask.png",
        final_mask,
    )

    overlay = make_overlay(
        original,
        filtered_mask,
        reconstructed_gaps,
    )

    cv2.imwrite(
        str(
            output_dir
            / "06_linear_feature_overlay.png"
        ),
        overlay,
    )

    report = {
        "restoration_dir": str(
            restoration_dir
        ),
        "shape": [
            int(shape[0]),
            int(shape[1]),
        ],
        "parameters": {
            "initial_percentile": float(
                initial_percentile
            ),
            "initial_threshold": int(
                threshold
            ),
            "max_gap": float(
                max_gap
            ),
            "max_angle_deg": float(
                max_angle_deg
            ),
            "minimum_mean_evidence": 38.0,
            "minimum_support_fraction": 0.48,
        },
        "component_count": int(
            len(component_records)
        ),
        "accepted_gap_connections": int(
            len(accepted_connections)
        ),
        "component_records": component_records,
        "gap_connections": accepted_connections,
        "pixels": {
            "initial_mask": int(
                initial_mask.sum()
            ),
            "filtered_components": int(
                filtered_mask.sum()
            ),
            "reconstructed_gaps": int(
                reconstructed_gaps.sum()
            ),
            "final_linear_features": int(
                final_mask.sum()
            ),
        },
        "semantics": {
            "03_filtered_linear_components.png": (
                "Visible elongated linework detected independently of "
                "geological region topology."
            ),
            "04_reconstructed_collinear_gaps.png": (
                "Only short, near-collinear, evidence-supported missing "
                "segments reconstructed between component endpoints."
            ),
            "05_final_linear_feature_mask.png": (
                "Candidate visible linear objects. Not yet semantically "
                "classified as vein/fault/road/etc."
            ),
        },
    }

    report_path = (
        output_dir
        / "linear_feature_report.json"
    )

    report_path.write_text(
        json.dumps(
            report,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(
        "Initial threshold:",
        threshold,
    )
    print(
        "Filtered linear components:",
        len(component_records),
    )
    print(
        "Accepted collinear gap connections:",
        len(accepted_connections),
    )
    print(
        "Filtered line pixels:",
        int(filtered_mask.sum()),
    )
    print(
        "Reconstructed gap pixels:",
        int(reconstructed_gaps.sum()),
    )
    print(
        "Final line pixels:",
        int(final_mask.sum()),
    )
    print()
    print(
        "Overlay:",
        output_dir
        / "06_linear_feature_overlay.png",
    )
    print(
        "Report:",
        report_path,
    )
    print("=" * 72)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Extract visible linear geological/cartographic features "
            "independently of polygon topology, then reconnect short "
            "evidence-supported collinear gaps across crossings."
        )
    )

    parser.add_argument(
        "--restoration-dir",
        type=Path,
        required=True,
        help=(
            "Directory produced by map_restoration.py multi-view mode."
        ),
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
    )

    parser.add_argument(
        "--original",
        type=Path,
        default=None,
        help=(
            "Optional original image. Defaults to "
            "<restoration-dir>/01_original.png"
        ),
    )

    parser.add_argument(
        "--initial-percentile",
        type=float,
        default=84.0,
        help=(
            "Evidence percentile for initial line candidates. Default: 84."
        ),
    )

    parser.add_argument(
        "--max-gap",
        type=float,
        default=42.0,
        help=(
            "Maximum endpoint gap in pixels for collinear reconstruction. "
            "Default: 42."
        ),
    )

    parser.add_argument(
        "--max-angle-deg",
        type=float,
        default=18.0,
        help=(
            "Maximum orientation mismatch for gap reconstruction. "
            "Default: 18 degrees."
        ),
    )

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    run(
        restoration_dir=args.restoration_dir,
        output_dir=args.output_dir,
        original_path=args.original,
        initial_percentile=args.initial_percentile,
        max_gap=args.max_gap,
        max_angle_deg=args.max_angle_deg,
    )
