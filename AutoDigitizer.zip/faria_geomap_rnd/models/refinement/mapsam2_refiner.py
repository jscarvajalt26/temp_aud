﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
import torch

from faria_geomap_rnd import config

try:
    from sam2.build_sam import build_sam2
    from sam2.sam2_image_predictor import SAM2ImagePredictor

    SAM2_AVAILABLE = True
except ImportError:
    build_sam2 = None
    SAM2ImagePredictor = None
    SAM2_AVAILABLE = False


# ============================================================
# DEFAULT LOCAL SAM2 PATHS
# ============================================================

DEFAULT_SAM2_ROOT = config.SAM2_ROOT

DEFAULT_CHECKPOINT = DEFAULT_SAM2_ROOT / "checkpoints" / "sam2.1_hiera_tiny.pt"

DEFAULT_CONFIG = "configs/sam2.1/sam2.1_hiera_t.yaml"


# ============================================================
# RESULT STRUCTURE
# ============================================================


@dataclass
class SAM2RefinementResult:
    mask: np.ndarray
    score: float
    box_xyxy: tuple[int, int, int, int]
    positive_points: np.ndarray
    negative_points: np.ndarray


# ============================================================
# REFINER
# ============================================================


class MapSAM2Refiner:
    """
    Local SAM2 specialist for geological-map refinement.

    IMPORTANT:
    SAM2 is NOT used as the primary geological detector.

    Expected pipeline:

        MultiHeadGeoMapNet
                |
                v
        V3 probability map
                |
                v
        suspicious / uncertain ROI
                |
                v
        MapSAM2Refiner
                |
                v
        refined local segmentation
                |
                v
        topology repair

    SAM2 therefore only receives local regions selected using
    the primary geological model.
    """

    def __init__(
        self,
        checkpoint_path: str | Path = DEFAULT_CHECKPOINT,
        config_name: str = DEFAULT_CONFIG,
        device: str = "cpu",
    ) -> None:

        if not SAM2_AVAILABLE:
            raise ImportError(
                "SAM2 support is not installed. "
                "Install the optional SAM2 backend before using MapSAM2Refiner."
            )

        self.checkpoint_path = Path(checkpoint_path)
        self.config_name = config_name
        self.device_name = device

        if not self.checkpoint_path.exists():
            raise FileNotFoundError(
                f"SAM2 checkpoint not found:\n" f"{self.checkpoint_path}"
            )

        if device == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but torch.cuda.is_available() is False.")

        self.device = torch.device(device)

        print("Loading MapSAM2 refiner...")
        print("SAM2 checkpoint:", self.checkpoint_path)
        print("SAM2 config:", self.config_name)
        print("SAM2 device:", self.device)

        model = build_sam2(
            self.config_name,
            str(self.checkpoint_path),
            device=self.device,
        )

        model.eval()

        self.predictor = SAM2ImagePredictor(model)

        print("MapSAM2 refiner ready.")

    # ========================================================
    # IMAGE UTILITIES
    # ========================================================

    @staticmethod
    def _ensure_rgb(image: np.ndarray) -> np.ndarray:

        if image.ndim != 3:
            raise ValueError(f"Expected HxWx3 image, got {image.shape}")

        if image.shape[2] != 3:
            raise ValueError(f"Expected 3 channels, got {image.shape}")

        if image.dtype != np.uint8:
            image = np.clip(
                image,
                0,
                255,
            ).astype(np.uint8)

        return np.ascontiguousarray(image)

    @staticmethod
    def _clip_box(
        box: tuple[int, int, int, int],
        width: int,
        height: int,
    ) -> tuple[int, int, int, int]:

        x1, y1, x2, y2 = box

        x1 = max(0, min(int(x1), width - 1))
        y1 = max(0, min(int(y1), height - 1))

        x2 = max(x1 + 1, min(int(x2), width))
        y2 = max(y1 + 1, min(int(y2), height))

        return x1, y1, x2, y2

    # ========================================================
    # V3 â†’ PROMPT GENERATION
    # ========================================================

    @staticmethod
    def probability_to_prompts(
        probability: np.ndarray,
        box_xyxy: tuple[int, int, int, int],
        positive_threshold: float = 0.70,
        negative_threshold: float = 0.10,
        max_positive_points: int = 8,
        max_negative_points: int = 8,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Generate SAM2 point prompts from V3 probabilities.

        High-confidence V3 pixels:
            positive SAM2 prompts

        Very-low-confidence V3 pixels:
            negative SAM2 prompts

        Medium-confidence pixels are intentionally ignored.
        """

        if probability.ndim != 2:
            raise ValueError("probability must be HxW")

        h, w = probability.shape

        x1, y1, x2, y2 = MapSAM2Refiner._clip_box(
            box_xyxy,
            width=w,
            height=h,
        )

        roi = probability[
            y1:y2,
            x1:x2,
        ]

        positive_yx = np.argwhere(roi >= positive_threshold)

        negative_yx = np.argwhere(roi <= negative_threshold)

        positive_points = MapSAM2Refiner._sample_points(
            positive_yx,
            max_positive_points,
            x_offset=x1,
            y_offset=y1,
        )

        negative_points = MapSAM2Refiner._sample_points(
            negative_yx,
            max_negative_points,
            x_offset=x1,
            y_offset=y1,
        )

        return (
            positive_points,
            negative_points,
        )

    @staticmethod
    def _sample_points(
        coordinates_yx: np.ndarray,
        maximum: int,
        x_offset: int,
        y_offset: int,
    ) -> np.ndarray:

        if len(coordinates_yx) == 0:
            return np.empty(
                (0, 2),
                dtype=np.float32,
            )

        if len(coordinates_yx) > maximum:
            indices = np.linspace(
                0,
                len(coordinates_yx) - 1,
                maximum,
                dtype=np.int64,
            )

            coordinates_yx = coordinates_yx[indices]

        # SAM expects XY rather than YX.
        points = np.stack(
            [
                coordinates_yx[:, 1] + x_offset,
                coordinates_yx[:, 0] + y_offset,
            ],
            axis=1,
        )

        return points.astype(np.float32)

    # ========================================================
    # SAM2 LOCAL REFINEMENT
    # ========================================================

    @torch.inference_mode()
    def refine_box(
        self,
        image_rgb: np.ndarray,
        probability: np.ndarray,
        box_xyxy: tuple[int, int, int, int],
        positive_threshold: float = 0.70,
        negative_threshold: float = 0.10,
    ) -> Optional[SAM2RefinementResult]:
        """
        Refine one V3-selected region.

        Returns None when V3 cannot provide a meaningful
        positive prompt.
        """

        image_rgb = self._ensure_rgb(image_rgb)

        h, w = image_rgb.shape[:2]

        if probability.shape != (h, w):
            raise ValueError(
                "Image/probability size mismatch: "
                f"{image_rgb.shape[:2]} vs "
                f"{probability.shape}"
            )

        box = self._clip_box(
            box_xyxy,
            width=w,
            height=h,
        )

        positive_points, negative_points = self.probability_to_prompts(
            probability=probability,
            box_xyxy=box,
            positive_threshold=positive_threshold,
            negative_threshold=negative_threshold,
        )

        # SAM2 needs at least some indication of what
        # foreground object we actually want.
        if len(positive_points) == 0:
            return None

        if len(negative_points) > 0:

            points = np.concatenate(
                [
                    positive_points,
                    negative_points,
                ],
                axis=0,
            )

            labels = np.concatenate(
                [
                    np.ones(
                        len(positive_points),
                        dtype=np.int32,
                    ),
                    np.zeros(
                        len(negative_points),
                        dtype=np.int32,
                    ),
                ]
            )

        else:

            points = positive_points

            labels = np.ones(
                len(positive_points),
                dtype=np.int32,
            )

        self.predictor.set_image(image_rgb)

        box_array = np.asarray(
            box,
            dtype=np.float32,
        )

        masks, scores, _ = self.predictor.predict(
            point_coords=points,
            point_labels=labels,
            box=box_array,
            multimask_output=True,
        )

        if masks is None or len(masks) == 0:
            return None

        best_index = int(np.argmax(scores))

        best_mask = masks[best_index].astype(np.uint8)

        best_score = float(scores[best_index])

        # Restrict result to the selected ROI.
        x1, y1, x2, y2 = box

        roi_constraint = np.zeros_like(
            best_mask,
            dtype=np.uint8,
        )

        roi_constraint[
            y1:y2,
            x1:x2,
        ] = 1

        best_mask *= roi_constraint

        return SAM2RefinementResult(
            mask=best_mask,
            score=best_score,
            box_xyxy=box,
            positive_points=positive_points,
            negative_points=negative_points,
        )

    # ========================================================
    # UNCERTAIN REGION DISCOVERY
    # ========================================================

    @staticmethod
    def find_uncertain_regions(
        probability: np.ndarray,
        low_threshold: float = 0.30,
        high_threshold: float = 0.70,
        minimum_area: int = 30,
        padding: int = 32,
    ) -> list[tuple[int, int, int, int]]:
        """
        Find connected uncertain regions.

        These are candidate ROIs for SAM2.

        We deliberately do NOT send the entire map.
        """

        if probability.ndim != 2:
            raise ValueError("probability must be HxW")

        h, w = probability.shape

        uncertainty = (
            (probability >= low_threshold) & (probability <= high_threshold)
        ).astype(np.uint8)

        # Join very small uncertainty gaps so one geological
        # region does not produce dozens of tiny SAM calls.
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (5, 5),
        )

        uncertainty = cv2.morphologyEx(
            uncertainty,
            cv2.MORPH_CLOSE,
            kernel,
        )

        count, labels, stats, _ = cv2.connectedComponentsWithStats(
            uncertainty,
            connectivity=8,
        )

        boxes: list[tuple[int, int, int, int]] = []

        for component in range(1, count):

            area = int(
                stats[
                    component,
                    cv2.CC_STAT_AREA,
                ]
            )

            if area < minimum_area:
                continue

            x = int(
                stats[
                    component,
                    cv2.CC_STAT_LEFT,
                ]
            )

            y = int(
                stats[
                    component,
                    cv2.CC_STAT_TOP,
                ]
            )

            component_w = int(
                stats[
                    component,
                    cv2.CC_STAT_WIDTH,
                ]
            )

            component_h = int(
                stats[
                    component,
                    cv2.CC_STAT_HEIGHT,
                ]
            )

            x1 = max(
                0,
                x - padding,
            )

            y1 = max(
                0,
                y - padding,
            )

            x2 = min(
                w,
                x + component_w + padding,
            )

            y2 = min(
                h,
                y + component_h + padding,
            )

            boxes.append(
                (
                    x1,
                    y1,
                    x2,
                    y2,
                )
            )

        return boxes

    # ========================================================
    # MERGING
    # ========================================================

    @staticmethod
    def merge_refinement(
        original_mask: np.ndarray,
        refinement: SAM2RefinementResult,
        mode: str = "union",
    ) -> np.ndarray:
        """
        Merge SAM2 refinement with V3.

        union:
            preserves V3 and adds SAM2 pixels

        replace_roi:
            SAM2 replaces V3 only inside the ROI
        """

        if original_mask.ndim != 2:
            raise ValueError("original_mask must be HxW")

        base = (original_mask > 0).astype(np.uint8)

        refined = (refinement.mask > 0).astype(np.uint8)

        if base.shape != refined.shape:
            raise ValueError("Mask size mismatch.")

        if mode == "union":

            output = np.maximum(
                base,
                refined,
            )

        elif mode == "replace_roi":

            output = base.copy()

            x1, y1, x2, y2 = refinement.box_xyxy

            output[
                y1:y2,
                x1:x2,
            ] = refined[
                y1:y2,
                x1:x2,
            ]

        else:
            raise ValueError(f"Unknown merge mode: {mode}")

        return output.astype(np.uint8) * 255


# ============================================================
# SIMPLE LOAD TEST
# ============================================================

if __name__ == "__main__":

    refiner = MapSAM2Refiner(device="cpu")

    print()
    print("MapSAM2Refiner loaded successfully.")
