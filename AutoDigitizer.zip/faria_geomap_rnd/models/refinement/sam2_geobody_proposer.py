import argparse
from pathlib import Path

import cv2
import numpy as np

# ============================================================
# SETTINGS
# ============================================================

KMEANS_CLASSES = 14

# Ignore almost-white page/background pixels
WHITE_L_THRESHOLD = 245

# Component must have at least this many pixels
MIN_COMPONENT_AREA = 180

# Filled geological bodies should contain a reasonably thick interior.
# Thin roads/faults/text generally fail this.
MIN_INTERIOR_DISTANCE = 4.0

# Don't allow one candidate to consume almost the whole image.
MAX_IMAGE_FRACTION = 0.70

# Remove tiny isolated noise before component analysis
MORPH_KERNEL_SIZE = 3

RANDOM_SEED = 42

# Reject achromatic dark ink: text, symbols, faults, frame, etc.
MAX_BLACK_RGB = 55

# Ignore known page-layout regions.
# Coordinates are for the current 2400x1776 Supervisor150 layout.
IGNORE_RECTS = [
    # upper-right legend
    (2070, 100, 2399, 380),
    # lower-right legend
    (1600, 1280, 2070, 1700),
    # bottom-left scale bar
    (40, 1620, 390, 1760),
    # title/header strip
    (0, 0, 2400, 135),
]

# ============================================================
# HELPERS
# ============================================================


def quantize_lab_kmeans(image_bgr, valid_mask, n_clusters):
    """
    Cluster valid image pixels in LAB colour space.

    Returns
    -------
    labels_full : HxW int32
        Cluster id for every valid pixel; -1 elsewhere.
    centers_lab : Kx3 float32
        LAB cluster centres.
    """

    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB)

    ys, xs = np.where(valid_mask)
    pixels = lab[ys, xs].astype(np.float32)

    if len(pixels) == 0:
        raise RuntimeError("No valid pixels available for clustering.")

    n_clusters = min(n_clusters, len(pixels))

    criteria = (
        cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
        50,
        0.5,
    )

    cv2.setRNGSeed(RANDOM_SEED)

    _, labels, centers = cv2.kmeans(
        pixels,
        n_clusters,
        None,
        criteria,
        5,
        cv2.KMEANS_PP_CENTERS,
    )

    labels_full = np.full(valid_mask.shape, -1, dtype=np.int32)
    labels_full[ys, xs] = labels.reshape(-1)

    return labels_full, centers


def clean_binary_mask(mask):
    mask_u8 = mask.astype(np.uint8) * 255

    kernel = np.ones(
        (MORPH_KERNEL_SIZE, MORPH_KERNEL_SIZE),
        dtype=np.uint8,
    )

    # Opening removes tiny isolated pixels.
    cleaned = cv2.morphologyEx(
        mask_u8,
        cv2.MORPH_OPEN,
        kernel,
        iterations=1,
    )

    # Closing reconnects tiny cracks without aggressively changing shape.
    cleaned = cv2.morphologyEx(
        cleaned,
        cv2.MORPH_CLOSE,
        kernel,
        iterations=1,
    )

    return cleaned > 0


def component_thickness(component_mask):
    """
    Distance transform gives distance from each foreground pixel
    to the nearest boundary.

    Thin line:
        max distance ~1-3 px

    Filled polygon/body:
        substantially larger max distance
    """

    binary = component_mask.astype(np.uint8) * 255

    dist = cv2.distanceTransform(
        binary,
        cv2.DIST_L2,
        5,
    )

    return float(dist.max())


def median_bgr(image_bgr, mask):
    pixels = image_bgr[mask]

    if len(pixels) == 0:
        return (0, 0, 0)

    med = np.median(pixels, axis=0)

    return tuple(int(round(x)) for x in med)


# ============================================================
# CANDIDATE EXTRACTION
# ============================================================


def extract_geobody_candidates(image_bgr):
    h, w = image_bgr.shape[:2]
    image_area = h * w

    lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB)

    # OpenCV LAB L is 0-255.
    lightness = lab[:, :, 0]

    # Exclude white page/background.
    valid_mask = lightness < WHITE_L_THRESHOLD

    labels_full, centers_lab = quantize_lab_kmeans(
        image_bgr,
        valid_mask,
        KMEANS_CLASSES,
    )

    candidates = []

    candidate_id = 1

    for cluster_id in range(len(centers_lab)):

        cluster_mask = labels_full == cluster_id

        cluster_mask = clean_binary_mask(cluster_mask)

        binary = cluster_mask.astype(np.uint8)

        num_labels, component_labels, stats, centroids = (
            cv2.connectedComponentsWithStats(
                binary,
                connectivity=8,
            )
        )

        for component_id in range(1, num_labels):

            area = int(stats[component_id, cv2.CC_STAT_AREA])

            if area < MIN_COMPONENT_AREA:
                continue

            fraction = area / image_area

            if fraction > MAX_IMAGE_FRACTION:
                continue

            component_mask = component_labels == component_id

            # ------------------------------------------------------------
            # Reject components whose centre lies inside page-layout areas
            # ------------------------------------------------------------
            cx, cy = centroids[component_id]

            inside_layout = False

            for x1, y1, x2, y2 in IGNORE_RECTS:
                if x1 <= cx <= x2 and y1 <= cy <= y2:
                    inside_layout = True
                    break

            if inside_layout:
                continue

            # ------------------------------------------------------------
            # Reject black/near-black ink
            # ------------------------------------------------------------
            bgr = median_bgr(
                image_bgr,
                component_mask,
            )

            b, g, r = bgr

            if max(r, g, b) <= MAX_BLACK_RGB:
                continue

            thickness = component_thickness(component_mask)

            # This is the important road/fault rejection.
            if thickness < MIN_INTERIOR_DISTANCE:
                continue

            x = int(stats[component_id, cv2.CC_STAT_LEFT])

            y = int(stats[component_id, cv2.CC_STAT_TOP])

            bw = int(stats[component_id, cv2.CC_STAT_WIDTH])

            bh = int(stats[component_id, cv2.CC_STAT_HEIGHT])

            cx, cy = centroids[component_id]

            bgr = median_bgr(
                image_bgr,
                component_mask,
            )

            candidate = {
                "id": candidate_id,
                "cluster_id": cluster_id,
                "mask": component_mask,
                "area": area,
                "fraction": fraction,
                "thickness": thickness,
                "bbox": (x, y, bw, bh),
                "center": (
                    int(round(cx)),
                    int(round(cy)),
                ),
                "bgr": bgr,
            }

            candidates.append(candidate)

            candidate_id += 1

    # Largest filled regions first.
    candidates.sort(
        key=lambda c: c["area"],
        reverse=True,
    )

    # Renumber after sorting.
    for i, candidate in enumerate(candidates, start=1):
        candidate["id"] = i

    return candidates


# ============================================================
# DEBUG OUTPUT
# ============================================================


def make_debug_image(image_bgr, candidates):
    debug = image_bgr.copy()

    for candidate in candidates:

        cid = candidate["id"]

        x, y, bw, bh = candidate["bbox"]
        cx, cy = candidate["center"]

        b, g, r = candidate["bgr"]

        cv2.circle(
            debug,
            (cx, cy),
            7,
            (0, 255, 0),
            -1,
        )

        text = (
            f"{cid} "
            f"RGB=({r},{g},{b}) "
            f"A={candidate['area']} "
            f"T={candidate['thickness']:.1f}"
        )

        cv2.putText(
            debug,
            text,
            (cx + 10, cy - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            (0, 0, 255),
            1,
            cv2.LINE_AA,
        )

    return debug


def make_candidate_mask(candidates, shape):
    combined = np.zeros(shape[:2], dtype=np.uint8)

    for candidate in candidates:
        combined[candidate["mask"]] = 255

    return combined


# ============================================================
# CLI
# ============================================================


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Generate geological body candidates using LAB colour "
            "clustering and filled-region geometry."
        )
    )

    parser.add_argument(
        "--input",
        required=True,
        help="Input geological map image.",
    )

    parser.add_argument(
        "--output",
        required=True,
        help="Output directory.",
    )

    args = parser.parse_args()

    input_path = Path(args.input)
    output_dir = Path(args.output)

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    image = cv2.imread(
        str(input_path),
        cv2.IMREAD_COLOR,
    )

    if image is None:
        raise FileNotFoundError(f"Could not read image: {input_path}")

    print("=" * 72)
    print("LAB geological-body proposer")
    print("Input:", input_path)
    print("Shape:", image.shape)
    print("KMeans clusters:", KMEANS_CLASSES)
    print("Minimum component area:", MIN_COMPONENT_AREA)
    print("Minimum interior distance:", MIN_INTERIOR_DISTANCE)
    print("=" * 72)

    candidates = extract_geobody_candidates(image)

    print()
    print("Candidates:", len(candidates))
    print()

    for candidate in candidates:

        b, g, r = candidate["bgr"]

        print(
            f"{candidate['id']:02d} "
            f"cluster={candidate['cluster_id']:02d} "
            f"area={candidate['area']:7d} "
            f"thickness={candidate['thickness']:6.2f} "
            f"RGB=({r},{g},{b}) "
            f"center={candidate['center']}"
        )

    debug = make_debug_image(
        image,
        candidates,
    )

    combined = make_candidate_mask(
        candidates,
        image.shape,
    )

    debug_path = output_dir / "lab_geobody_candidates.png"

    mask_path = output_dir / "lab_geobody_candidate_mask.png"

    cv2.imwrite(
        str(debug_path),
        debug,
    )

    cv2.imwrite(
        str(mask_path),
        combined,
    )

    # Save each component independently.
    components_dir = output_dir / "components"

    components_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    for candidate in candidates:

        component_image = np.zeros(
            image.shape[:2],
            dtype=np.uint8,
        )

        component_image[candidate["mask"]] = 255

        component_path = components_dir / f"candidate_{candidate['id']:03d}.png"

        cv2.imwrite(
            str(component_path),
            component_image,
        )

    print()
    print("Debug image:", debug_path)
    print("Combined mask:", mask_path)
    print("Components:", components_dir)


if __name__ == "__main__":
    main()
