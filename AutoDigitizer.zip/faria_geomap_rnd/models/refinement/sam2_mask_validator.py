from __future__ import annotations

import cv2
import numpy as np


def ensure_binary_mask(mask: np.ndarray) -> np.ndarray:
    """
    Convert any input mask to uint8 binary {0, 1}.
    """
    if mask is None:
        raise ValueError("Mask cannot be None.")

    mask = np.asarray(mask)

    if mask.ndim > 2:
        mask = np.squeeze(mask)

    if mask.ndim != 2:
        raise ValueError(f"Expected 2D mask after squeeze, got shape {mask.shape}")

    return (mask > 0).astype(np.uint8)


def largest_component(mask: np.ndarray) -> np.ndarray:
    """
    Keep only the largest connected foreground component.
    """
    mask_u8 = ensure_binary_mask(mask)

    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        mask_u8,
        connectivity=8,
    )

    if n_labels <= 1:
        return mask_u8

    component_areas = stats[1:, cv2.CC_STAT_AREA]

    if component_areas.size == 0:
        return mask_u8

    best_label = 1 + int(np.argmax(component_areas))

    output = np.zeros_like(mask_u8)
    output[labels == best_label] = 1

    return output


def mask_iou(
    a: np.ndarray,
    b: np.ndarray,
) -> float:
    """
    Intersection-over-Union between two binary masks.
    """
    a = ensure_binary_mask(a).astype(bool)
    b = ensure_binary_mask(b).astype(bool)

    intersection = np.logical_and(a, b).sum()
    union = np.logical_or(a, b).sum()

    if union == 0:
        return 0.0

    return float(intersection / union)


def mask_dice(
    a: np.ndarray,
    b: np.ndarray,
) -> float:
    """
    Dice coefficient between two binary masks.
    """
    a = ensure_binary_mask(a).astype(bool)
    b = ensure_binary_mask(b).astype(bool)

    intersection = np.logical_and(a, b).sum()

    denominator = a.sum() + b.sum()

    if denominator == 0:
        return 0.0

    return float((2.0 * intersection) / denominator)


def centroid(mask: np.ndarray) -> tuple[float, float] | None:
    """
    Return centroid as (x, y).
    """
    mask_u8 = ensure_binary_mask(mask)

    moments = cv2.moments(mask_u8)

    if moments["m00"] <= 0:
        return None

    x = float(moments["m10"] / moments["m00"])
    y = float(moments["m01"] / moments["m00"])

    return x, y


def centroid_distance(
    a: np.ndarray,
    b: np.ndarray,
) -> float:
    """
    Euclidean distance between mask centroids.
    """
    ca = centroid(a)
    cb = centroid(b)

    if ca is None or cb is None:
        return float("inf")

    dx = ca[0] - cb[0]
    dy = ca[1] - cb[1]

    return float(np.sqrt(dx * dx + dy * dy))


def boundary_from_mask(
    mask: np.ndarray,
    thickness: int = 1,
) -> np.ndarray:
    """
    Extract a clean inner boundary.

    thickness=1 normally produces a compact,
    continuous one-pixel-ish perimeter.
    """
    mask_u8 = ensure_binary_mask(mask)

    thickness = max(1, int(thickness))

    kernel = np.ones((3, 3), dtype=np.uint8)

    eroded = cv2.erode(
        mask_u8,
        kernel,
        iterations=thickness,
    )

    boundary = cv2.subtract(mask_u8, eroded)

    return (boundary > 0).astype(np.uint8)


def remove_small_satellites(
    mask: np.ndarray,
    min_area: int = 100,
    keep_largest_always: bool = True,
) -> np.ndarray:
    """
    Remove small disconnected SAM blobs.

    This is especially important because SAM2 can produce
    tiny islands around text, symbols, lines, or noise.
    """
    mask_u8 = ensure_binary_mask(mask)

    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        mask_u8,
        connectivity=8,
    )

    if n_labels <= 1:
        return mask_u8

    output = np.zeros_like(mask_u8)

    areas = stats[1:, cv2.CC_STAT_AREA]

    largest_label = None

    if areas.size:
        largest_label = 1 + int(np.argmax(areas))

    for label in range(1, n_labels):
        area = int(stats[label, cv2.CC_STAT_AREA])

        if area >= min_area:
            output[labels == label] = 1

        elif keep_largest_always and label == largest_label:
            output[labels == label] = 1

    return output


def fill_small_holes(
    mask: np.ndarray,
    max_hole_area: int = 500,
) -> np.ndarray:
    """
    Fill small holes inside a segmentation while preserving
    genuinely large internal holes.

    Useful when roads, symbols, text, or thin linework punch
    tiny holes through a SAM result.
    """
    mask_u8 = ensure_binary_mask(mask)

    inverse = (1 - mask_u8).astype(np.uint8)

    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        inverse,
        connectivity=8,
    )

    output = mask_u8.copy()

    h, w = mask_u8.shape

    for label in range(1, n_labels):
        x = int(stats[label, cv2.CC_STAT_LEFT])
        y = int(stats[label, cv2.CC_STAT_TOP])
        cw = int(stats[label, cv2.CC_STAT_WIDTH])
        ch = int(stats[label, cv2.CC_STAT_HEIGHT])
        area = int(stats[label, cv2.CC_STAT_AREA])

        touches_border = x <= 0 or y <= 0 or x + cw >= w or y + ch >= h

        if touches_border:
            continue

        if area <= max_hole_area:
            output[labels == label] = 1

    return output


def smooth_mask(
    mask: np.ndarray,
    close_iterations: int = 1,
    open_iterations: int = 0,
) -> np.ndarray:
    """
    Very conservative morphology.

    We intentionally do NOT aggressively dilate the mask,
    because that was causing boundaries to move too far
    outside the real geological polygon.
    """
    mask_u8 = ensure_binary_mask(mask)

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (3, 3),
    )

    output = mask_u8.copy()

    if close_iterations > 0:
        output = cv2.morphologyEx(
            output,
            cv2.MORPH_CLOSE,
            kernel,
            iterations=int(close_iterations),
        )

    if open_iterations > 0:
        output = cv2.morphologyEx(
            output,
            cv2.MORPH_OPEN,
            kernel,
            iterations=int(open_iterations),
        )

    return (output > 0).astype(np.uint8)


def candidate_overlap_fraction(
    candidate_mask: np.ndarray,
    sam_mask: np.ndarray,
) -> float:
    """
    Fraction of the original candidate covered by SAM.

    This prevents SAM from selecting a vaguely nearby
    but fundamentally different region.
    """
    candidate = ensure_binary_mask(candidate_mask).astype(bool)
    sam = ensure_binary_mask(sam_mask).astype(bool)

    candidate_area = candidate.sum()

    if candidate_area == 0:
        return 0.0

    intersection = np.logical_and(candidate, sam).sum()

    return float(intersection / candidate_area)


def sam_overlap_fraction(
    candidate_mask: np.ndarray,
    sam_mask: np.ndarray,
) -> float:
    """
    Fraction of SAM proposal overlapping the candidate.

    This is useful for detecting runaway SAM masks.
    """
    candidate = ensure_binary_mask(candidate_mask).astype(bool)
    sam = ensure_binary_mask(sam_mask).astype(bool)

    sam_area = sam.sum()

    if sam_area == 0:
        return 0.0

    intersection = np.logical_and(candidate, sam).sum()

    return float(intersection / sam_area)


def validate_sam_mask(
    candidate_mask: np.ndarray,
    sam_mask: np.ndarray,
    min_area_ratio: float = 0.65,
    max_area_ratio: float = 1.40,
    min_iou: float = 0.45,
    min_candidate_coverage: float = 0.60,
    min_sam_overlap: float = 0.55,
    max_centroid_shift_fraction: float = 0.25,
) -> tuple[np.ndarray, dict]:
    """
    Decide whether SAM2 improved the original color/LAB proposal.

    IMPORTANT:

    SAM2 is treated as a REFINER.

    It is NOT allowed to replace the geological proposal with
    an arbitrary larger polygon just because SAM gives it a
    high confidence score.

    If SAM2 fails these geometric checks, the original proposal
    is preserved.
    """

    candidate = largest_component(candidate_mask)
    sam = largest_component(sam_mask)

    candidate_area = int(candidate.sum())
    sam_area = int(sam.sum())

    if candidate_area <= 0:
        report = {
            "candidate_area": 0,
            "sam_area": sam_area,
            "area_ratio": 0.0,
            "proposal_iou": 0.0,
            "dice": 0.0,
            "candidate_coverage": 0.0,
            "sam_overlap": 0.0,
            "centroid_distance": None,
            "max_centroid_distance": None,
            "accepted": False,
            "reason": "empty_candidate",
        }

        return candidate.astype(np.uint8), report

    if sam_area <= 0:
        report = {
            "candidate_area": candidate_area,
            "sam_area": 0,
            "area_ratio": 0.0,
            "proposal_iou": 0.0,
            "dice": 0.0,
            "candidate_coverage": 0.0,
            "sam_overlap": 0.0,
            "centroid_distance": None,
            "max_centroid_distance": None,
            "accepted": False,
            "reason": "empty_sam_mask",
        }

        return candidate.astype(np.uint8), report

    area_ratio = float(sam_area / candidate_area)

    iou = mask_iou(candidate, sam)

    dice = mask_dice(candidate, sam)

    candidate_coverage = candidate_overlap_fraction(
        candidate,
        sam,
    )

    sam_overlap = sam_overlap_fraction(
        candidate,
        sam,
    )

    distance = centroid_distance(candidate, sam)

    x, y, w, h = cv2.boundingRect(candidate.astype(np.uint8))

    candidate_diagonal = float(np.sqrt((w * w) + (h * h)))

    max_centroid_distance = candidate_diagonal * max_centroid_shift_fraction

    area_ok = min_area_ratio <= area_ratio <= max_area_ratio

    iou_ok = iou >= min_iou

    candidate_coverage_ok = candidate_coverage >= min_candidate_coverage

    sam_overlap_ok = sam_overlap >= min_sam_overlap

    centroid_ok = distance <= max_centroid_distance

    accepted = (
        area_ok and iou_ok and candidate_coverage_ok and sam_overlap_ok and centroid_ok
    )

    reasons = []

    if not area_ok:
        reasons.append("area_ratio")

    if not iou_ok:
        reasons.append("low_iou")

    if not candidate_coverage_ok:
        reasons.append("low_candidate_coverage")

    if not sam_overlap_ok:
        reasons.append("sam_spill")

    if not centroid_ok:
        reasons.append("centroid_shift")

    if accepted:
        final_mask = sam
        reason = "accepted_sam"
    else:
        final_mask = candidate

        if reasons:
            reason = "fallback:" + ",".join(reasons)
        else:
            reason = "fallback_to_candidate"

    report = {
        "candidate_area": candidate_area,
        "sam_area": sam_area,
        "area_ratio": float(area_ratio),
        "proposal_iou": float(iou),
        "dice": float(dice),
        "candidate_coverage": float(candidate_coverage),
        "sam_overlap": float(sam_overlap),
        "centroid_distance": float(distance),
        "max_centroid_distance": float(max_centroid_distance),
        "accepted": bool(accepted),
        "reason": reason,
    }

    return final_mask.astype(np.uint8), report


def clean_validated_mask(
    mask: np.ndarray,
    min_satellite_area: int = 100,
    max_hole_area: int = 250,
) -> np.ndarray:
    """
    Final conservative cleanup after validation.

    Designed to:
        - remove SAM speckles
        - close tiny interruptions
        - preserve true polygon position
        - avoid making geological bodies artificially larger
    """
    output = ensure_binary_mask(mask)

    output = remove_small_satellites(
        output,
        min_area=min_satellite_area,
        keep_largest_always=True,
    )

    output = fill_small_holes(
        output,
        max_hole_area=max_hole_area,
    )

    output = smooth_mask(
        output,
        close_iterations=1,
        open_iterations=0,
    )

    output = largest_component(output)

    return output.astype(np.uint8)


def extract_one_pixel_perimeter(
    mask: np.ndarray,
) -> np.ndarray:
    """
    Produce the final thin continuous geological boundary.

    This uses the INSIDE edge of the polygon so we do not
    artificially push the boundary several pixels outward.
    """
    clean = ensure_binary_mask(mask)

    kernel = np.ones(
        (3, 3),
        dtype=np.uint8,
    )

    eroded = cv2.erode(
        clean,
        kernel,
        iterations=1,
    )

    perimeter = cv2.subtract(
        clean,
        eroded,
    )

    return (perimeter > 0).astype(np.uint8)


def validate_and_finalize_sam_mask(
    candidate_mask: np.ndarray,
    sam_mask: np.ndarray,
    min_area_ratio: float = 0.65,
    max_area_ratio: float = 1.40,
    min_iou: float = 0.45,
    min_candidate_coverage: float = 0.60,
    min_sam_overlap: float = 0.55,
    max_centroid_shift_fraction: float = 0.25,
    min_satellite_area: int = 100,
    max_hole_area: int = 250,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """
    Convenience function for the geological pipeline.

    Returns:

        final_mask
        perimeter
        validation_report
    """

    final_mask, report = validate_sam_mask(
        candidate_mask=candidate_mask,
        sam_mask=sam_mask,
        min_area_ratio=min_area_ratio,
        max_area_ratio=max_area_ratio,
        min_iou=min_iou,
        min_candidate_coverage=min_candidate_coverage,
        min_sam_overlap=min_sam_overlap,
        max_centroid_shift_fraction=max_centroid_shift_fraction,
    )

    final_mask = clean_validated_mask(
        final_mask,
        min_satellite_area=min_satellite_area,
        max_hole_area=max_hole_area,
    )

    perimeter = extract_one_pixel_perimeter(final_mask)

    report["final_area"] = int(final_mask.sum())

    report["perimeter_pixels"] = int(perimeter.sum())

    return (
        final_mask.astype(np.uint8),
        perimeter.astype(np.uint8),
        report,
    )


if __name__ == "__main__":
    print("sam2_mask_validator.py loaded successfully")
