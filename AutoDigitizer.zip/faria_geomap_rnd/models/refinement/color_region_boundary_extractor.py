﻿from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

from faria_geomap_rnd import config

# ============================================================
# DEFAULTS
# ============================================================

DEFAULT_INPUT = config.SUPERVISOR150_ROOT / "map_0103" / "map_0103_color.png"

DEFAULT_OUTPUT = config.OUTPUT_DIR / "color_region_boundaries_map0103"

DEFAULT_K = 12

WHITE_VALUE_THRESHOLD = 245
WHITE_SATURATION_THRESHOLD = 18

DARK_VALUE_THRESHOLD = 70

# Pure blue / colored linework is usually not a geological fill.
MIN_FILL_SATURATION = 20

MIN_REGION_AREA = 250

# Used to reconstruct geological fill underneath thin linework.
MAX_LINEWORK_FILL_DISTANCE = 8


# ============================================================
# HELPERS
# ============================================================


def save_mask(path: Path, mask: np.ndarray) -> None:
    cv2.imwrite(
        str(path),
        (mask > 0).astype(np.uint8) * 255,
    )


def normalize_image(x: np.ndarray) -> np.ndarray:
    x = x.astype(np.float32)

    lo = float(x.min())
    hi = float(x.max())

    if hi <= lo:
        return np.zeros_like(x, dtype=np.uint8)

    x = (x - lo) / (hi - lo)

    return np.clip(
        x * 255.0,
        0,
        255,
    ).astype(np.uint8)


# ============================================================
# MAP / PAGE MASKS
# ============================================================


def build_white_mask(image_bgr: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2HSV,
    )

    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]

    white = (value >= WHITE_VALUE_THRESHOLD) & (
        saturation <= WHITE_SATURATION_THRESHOLD
    )

    return white.astype(np.uint8)


def build_dark_mask(image_bgr: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2HSV,
    )

    value = hsv[:, :, 2]

    return (value <= DARK_VALUE_THRESHOLD).astype(np.uint8)


def build_colored_candidate_mask(
    image_bgr: np.ndarray,
) -> np.ndarray:

    hsv = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2HSV,
    )

    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]

    candidate = (saturation >= MIN_FILL_SATURATION) & (value > DARK_VALUE_THRESHOLD)

    return candidate.astype(np.uint8)


def keep_main_map_components(
    candidate: np.ndarray,
    min_area: int = 4000,
) -> np.ndarray:
    """
    Keeps large colored structures while rejecting tiny legend boxes,
    text fragments, symbols, etc.
    """

    n, labels, stats, _ = cv2.connectedComponentsWithStats(
        candidate.astype(np.uint8),
        connectivity=8,
    )

    out = np.zeros_like(candidate, dtype=np.uint8)

    for label in range(1, n):
        area = int(
            stats[
                label,
                cv2.CC_STAT_AREA,
            ]
        )

        if area >= min_area:
            out[labels == label] = 1

    # Merge nearby geological polygons separated by thin black lines.
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (9, 9),
    )

    out = cv2.morphologyEx(
        out,
        cv2.MORPH_CLOSE,
        kernel,
        iterations=2,
    )

    return out


def build_topology_map_mask(
    raw_map_mask: np.ndarray,
    image_bgr: np.ndarray,
    max_hole_fraction: float = 0.0005,
    min_dark_fraction: float = 0.55,
) -> tuple[np.ndarray, np.ndarray, list[dict]]:
    """
    Build geological topology support from the raw colored-map mask.

    Small enclosed holes dominated by dark pixels are assumed to be
    cartographic interruptions such as:
      - point symbols
      - black squares
      - strike/dip marks
      - dark annotations
      - compact linework symbols

    They are filled in the TOPOLOGY mask, but the original image is
    never modified.

    Exterior background components are never filled.
    """

    raw = (raw_map_mask > 0).astype(np.uint8)

    h, w = raw.shape

    invalid = (raw == 0).astype(np.uint8)

    n, components, stats, _ = cv2.connectedComponentsWithStats(
        invalid,
        connectivity=8,
    )

    dark_mask = build_dark_mask(image_bgr).astype(bool)

    topology = raw.copy()

    restored_holes = np.zeros_like(
        raw,
        dtype=np.uint8,
    )

    # Scale threshold with map size instead of hard-coding
    # a map-specific number.
    max_hole_area = max(
        250,
        int(h * w * max_hole_fraction),
    )

    report: list[dict] = []

    for component_id in range(1, n):

        x = int(
            stats[
                component_id,
                cv2.CC_STAT_LEFT,
            ]
        )

        y = int(
            stats[
                component_id,
                cv2.CC_STAT_TOP,
            ]
        )

        cw = int(
            stats[
                component_id,
                cv2.CC_STAT_WIDTH,
            ]
        )

        ch = int(
            stats[
                component_id,
                cv2.CC_STAT_HEIGHT,
            ]
        )

        area = int(
            stats[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        # Anything touching the image border belongs to
        # exterior background and must never be filled.
        touches_border = x == 0 or y == 0 or (x + cw) >= w or (y + ch) >= h

        component_mask = components == component_id

        if touches_border:
            continue

        component_dark_fraction = float(dark_mask[component_mask].mean())

        accepted = (
            area <= max_hole_area and component_dark_fraction >= min_dark_fraction
        )

        report.append(
            {
                "component": int(component_id),
                "area": area,
                "bbox": [x, y, cw, ch],
                "dark_fraction": component_dark_fraction,
                "restored": bool(accepted),
            }
        )

        if accepted:

            topology[component_mask] = 1

            restored_holes[component_mask] = 1

    return (
        topology,
        restored_holes,
        report,
    )


def fill_selected_holes_with_nearest_label(
    labels: np.ndarray,
    hole_mask: np.ndarray,
) -> np.ndarray:
    """
    Extend surrounding geological labels through selected nuisance holes.

    This uses nearest valid geological labels rather than assigning the
    entire hole one majority class.

    Therefore, if a symbol lies across a real geological contact, labels
    from both sides can propagate through it and the contact can continue
    underneath the symbol.
    """

    result = labels.copy()

    target = (hole_mask > 0) & (labels < 0)

    if not np.any(target):
        return result

    valid = (labels >= 0).astype(np.uint8)

    if not np.any(valid):
        return result

    # distanceTransformWithLabels expects zeros to be source pixels.
    source = np.where(
        valid > 0,
        0,
        1,
    ).astype(np.uint8)

    _, nearest = cv2.distanceTransformWithLabels(
        source,
        cv2.DIST_L2,
        5,
        labelType=cv2.DIST_LABEL_PIXEL,
    )

    zero_y, zero_x = np.where(source == 0)

    pixel_id_to_class = np.full(
        len(zero_y) + 1,
        -1,
        dtype=np.int16,
    )

    for idx, (yy, xx) in enumerate(
        zip(zero_y, zero_x),
        start=1,
    ):
        pixel_id_to_class[idx] = labels[yy, xx]

    fillable = target & (nearest > 0) & (nearest < len(pixel_id_to_class))

    result[fillable] = pixel_id_to_class[nearest[fillable]]

    return result


# ============================================================
# KMEANS GEOLOGICAL COLOR CLUSTERING
# ============================================================


def cluster_geological_colors(
    image_bgr: np.ndarray,
    valid_mask: np.ndarray,
    k: int,
) -> tuple[np.ndarray, np.ndarray]:

    lab = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2LAB,
    )

    ys, xs = np.where(valid_mask > 0)

    pixels = lab[ys, xs].astype(np.float32)

    if len(pixels) < k:
        raise RuntimeError("Not enough valid pixels for KMeans.")

    criteria = (
        cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
        100,
        0.2,
    )

    _, labels, centers = cv2.kmeans(
        pixels,
        k,
        None,
        criteria,
        8,
        cv2.KMEANS_PP_CENTERS,
    )

    region_labels = np.full(
        valid_mask.shape,
        -1,
        dtype=np.int16,
    )

    region_labels[ys, xs] = labels[:, 0].astype(np.int16)

    return region_labels, centers


# ============================================================
# CLEAN EACH COLOR REGION
# ============================================================


def remove_small_components_per_class(
    labels: np.ndarray,
    number_of_classes: int,
    min_area: int,
) -> np.ndarray:

    cleaned = labels.copy()

    for class_id in range(number_of_classes):

        mask = (labels == class_id).astype(np.uint8)

        n, components, stats, _ = cv2.connectedComponentsWithStats(
            mask,
            connectivity=8,
        )

        # One lookup per pixel instead of one full-image pass per component.
        small = stats[:, cv2.CC_STAT_AREA] < min_area
        small[0] = False

        cleaned[small[components]] = -1

    return cleaned


# ============================================================
# RESTORE FILL THROUGH LINEWORK
# ============================================================


def nearest_label_fill(
    labels: np.ndarray,
    map_mask: np.ndarray,
    max_distance: int,
) -> np.ndarray:
    """
    Fill unlabeled pixels inside the geological map using the nearest
    geological-region label, but only over a small distance.

    This allows geological fill to continue beneath:
      - black faults
      - blue roads/rivers
      - strike/dip symbols
      - thin outlines

    It does NOT fill arbitrary large white areas.
    """

    result = labels.copy()

    valid = (labels >= 0).astype(np.uint8)

    missing = (map_mask > 0) & (labels < 0)

    if not np.any(missing):
        return result

    # distanceTransformWithLabels finds nearest zero pixel, so invert:
    source = np.where(
        valid > 0,
        0,
        1,
    ).astype(np.uint8)

    distance, nearest = cv2.distanceTransformWithLabels(
        source,
        cv2.DIST_L2,
        5,
        labelType=cv2.DIST_LABEL_PIXEL,
    )

    # Map distance-transform pixel IDs back to region classes.
    zero_y, zero_x = np.where(source == 0)

    pixel_id_to_class = np.full(
        len(zero_y) + 1,
        -1,
        dtype=np.int16,
    )

    for idx, (y, x) in enumerate(
        zip(zero_y, zero_x),
        start=1,
    ):
        pixel_id_to_class[idx] = labels[y, x]

    fillable = (
        missing
        & (distance <= max_distance)
        & (nearest > 0)
        & (nearest < len(pixel_id_to_class))
    )

    result[fillable] = pixel_id_to_class[nearest[fillable]]

    return result


# ============================================================
# MAJORITY CLEANING
# ============================================================


def majority_filter_labels(
    labels: np.ndarray,
    passes: int = 2,
) -> np.ndarray:

    result = labels.copy()

    class_ids = sorted(int(v) for v in np.unique(result) if v >= 0)

    for _ in range(passes):

        votes = []

        for class_id in class_ids:

            class_mask = (result == class_id).astype(np.uint8)

            count = cv2.boxFilter(
                class_mask,
                cv2.CV_16U,
                (3, 3),
                normalize=False,
                borderType=cv2.BORDER_CONSTANT,
            )

            votes.append(count)

        if not votes:
            break

        stack = np.stack(
            votes,
            axis=0,
        )

        best_index = np.argmax(
            stack,
            axis=0,
        )

        best_vote = np.max(
            stack,
            axis=0,
        )

        new_result = result.copy()

        update = (result >= 0) & (best_vote >= 5)

        class_array = np.asarray(
            class_ids,
            dtype=np.int16,
        )

        new_result[update] = class_array[best_index[update]]

        result = new_result

    return result


# ============================================================
# SHARED REGION BOUNDARIES
# ============================================================


def compute_shared_boundaries(
    labels: np.ndarray,
) -> np.ndarray:
    """
    A boundary exists exactly where neighboring valid geological
    region IDs differ.

    Each shared contact is produced once.
    """

    h, w = labels.shape

    boundary = np.zeros(
        (h, w),
        dtype=np.uint8,
    )

    # Horizontal neighbors.
    a = labels[:, :-1]
    b = labels[:, 1:]

    valid = (a >= 0) & (b >= 0) & (a != b)

    boundary[:, :-1][valid] = 1

    # Vertical neighbors.
    a = labels[:-1, :]
    b = labels[1:, :]

    valid = (a >= 0) & (b >= 0) & (a != b)

    boundary[:-1, :][valid] = 1

    return boundary


# ============================================================
# TRUE REGION JUNCTIONS
# ============================================================


def compute_region_junctions(
    labels: np.ndarray,
) -> np.ndarray:
    """
    Junction = at least 3 different valid region IDs present in
    a local 3x3 neighborhood.

    Much safer than counting skeleton neighbors.
    """

    h, w = labels.shape

    junction = np.zeros(
        (h, w),
        dtype=np.uint8,
    )

    padded = np.pad(
        labels,
        1,
        mode="edge",
    )

    for y in range(h):
        for x in range(w):

            window = padded[
                y : y + 3,
                x : x + 3,
            ]

            unique = np.unique(window[window >= 0])

            if len(unique) >= 3:
                junction[y, x] = 1

    return junction


def extract_outer_map_boundary(
    map_mask: np.ndarray,
) -> np.ndarray:
    """
    Extract ONLY the exterior perimeter of the geological map footprint.

    Internal holes caused by symbols / black points / linework are ignored.
    """

    mask = (map_mask > 0).astype(np.uint8)

    # Close tiny breaks along the footprint edge.
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (5, 5),
    )

    mask = cv2.morphologyEx(
        mask,
        cv2.MORPH_CLOSE,
        kernel,
        iterations=1,
    )

    contours, _ = cv2.findContours(
        mask,
        cv2.RETR_EXTERNAL,  # IMPORTANT: ignore all internal holes
        cv2.CHAIN_APPROX_NONE,
    )

    outer = np.zeros_like(
        mask,
        dtype=np.uint8,
    )

    if not contours:
        return outer

    # Geological footprint should be the largest external contour.
    largest = max(
        contours,
        key=cv2.contourArea,
    )

    cv2.drawContours(
        outer,
        [largest],
        contourIdx=-1,
        color=1,
        thickness=1,
        lineType=cv2.LINE_8,
    )

    return outer


# ============================================================
# LABEL PREVIEW
# ============================================================


def make_label_preview(
    labels: np.ndarray,
    centers_lab: np.ndarray,
) -> np.ndarray:

    h, w = labels.shape

    lab_preview = np.zeros(
        (h, w, 3),
        dtype=np.uint8,
    )

    lab_preview[:] = (
        255,
        128,
        128,
    )

    for class_id in range(len(centers_lab)):

        mask = labels == class_id

        center = np.clip(
            centers_lab[class_id],
            0,
            255,
        ).astype(np.uint8)

        lab_preview[mask] = center

    return cv2.cvtColor(
        lab_preview,
        cv2.COLOR_LAB2BGR,
    )


# ============================================================
# OVERLAY
# ============================================================


def make_overlay(
    image_bgr: np.ndarray,
    boundary: np.ndarray,
    junctions: np.ndarray,
) -> np.ndarray:

    overlay = image_bgr.copy()

    # Bright green shared geological contacts.
    overlay[boundary > 0] = (
        0,
        255,
        0,
    )

    # Red true 3+ region junctions.
    ys, xs = np.where(junctions > 0)

    for x, y in zip(
        xs,
        ys,
    ):
        cv2.circle(
            overlay,
            (int(x), int(y)),
            2,
            (0, 0, 255),
            -1,
        )

    return overlay


# ============================================================
# MAIN
# ============================================================


def main() -> None:

    parser = argparse.ArgumentParser(
        description=(
            "Extract geological shared boundaries directly from "
            "original color-region adjacency."
        )
    )

    parser.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_INPUT,
    )

    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
    )

    parser.add_argument(
        "--k",
        type=int,
        default=DEFAULT_K,
    )

    parser.add_argument(
        "--min-region-area",
        type=int,
        default=MIN_REGION_AREA,
    )

    parser.add_argument(
        "--fill-distance",
        type=int,
        default=MAX_LINEWORK_FILL_DISTANCE,
    )

    args = parser.parse_args()

    args.output.mkdir(
        parents=True,
        exist_ok=True,
    )

    image = cv2.imread(
        str(args.input),
        cv2.IMREAD_COLOR,
    )

    if image is None:
        raise RuntimeError(f"Could not load image: {args.input}")

    print("=" * 72)
    print("Color-region geological boundary extractor")
    print("Input:", args.input)
    print("Shape:", image.shape)
    print("KMeans geological colors:", args.k)
    print("Minimum region area:", args.min_region_area)
    print("Linework fill distance:", args.fill_distance)
    print("=" * 72)

    cv2.imwrite(
        str(args.output / "01_original.png"),
        image,
    )

    # --------------------------------------------------------
    # Identify colored map body
    # --------------------------------------------------------

    colored = build_colored_candidate_mask(image)

    save_mask(
        args.output / "02_colored_pixels.png",
        colored,
    )

    raw_map_mask = keep_main_map_components(colored)

    save_mask(
        args.output / "03a_raw_map_mask.png",
        raw_map_mask,
    )

    (
        topology_map_mask,
        restored_symbol_holes,
        topology_report,
    ) = build_topology_map_mask(
        raw_map_mask,
        image,
    )

    save_mask(
        args.output / "03b_topology_map_mask.png",
        topology_map_mask,
    )

    save_mask(
        args.output / "03c_restored_symbol_holes.png",
        restored_symbol_holes,
    )

    print()
    print("Topology-mask reconstruction:")
    print(
        "  enclosed components inspected:",
        len(topology_report),
    )

    print(
        "  restored nuisance holes:",
        sum(int(x["restored"]) for x in topology_report),
    )

    # --------------------------------------------------------
    # Initial clustering
    # --------------------------------------------------------

    labels, centers = cluster_geological_colors(
        image,
        raw_map_mask,
        args.k,
    )

    labels = remove_small_components_per_class(
        labels,
        args.k,
        args.min_region_area,
    )

    initial_preview = make_label_preview(
        labels,
        centers,
    )

    cv2.imwrite(
        str(args.output / "04_initial_regions.png"),
        initial_preview,
    )

    # --------------------------------------------------------
    # Restore geology beneath thin linework
    # --------------------------------------------------------

    # Restore ordinary thin linework gaps.
    labels = nearest_label_fill(
        labels,
        topology_map_mask,
        args.fill_distance,
    )

    # Fully reconstruct the specifically identified symbol / nuisance holes.
    labels = fill_selected_holes_with_nearest_label(
        labels,
        restored_symbol_holes,
    )

    labels = majority_filter_labels(
        labels,
        passes=2,
    )

    final_preview = make_label_preview(
        labels,
        centers,
    )

    cv2.imwrite(
        str(args.output / "05_reconstructed_regions.png"),
        final_preview,
    )

    # --------------------------------------------------------
    # Shared region contacts
    # --------------------------------------------------------

    internal_boundary = compute_shared_boundaries(labels)

    outer_boundary = extract_outer_map_boundary(topology_map_mask)

    boundary = np.maximum(
        internal_boundary,
        outer_boundary,
    ).astype(np.uint8)

    save_mask(
        args.output / "06a_internal_boundaries.png",
        internal_boundary,
    )

    save_mask(
        args.output / "06b_outer_map_boundary.png",
        outer_boundary,
    )

    save_mask(
        args.output / "06_shared_boundaries.png",
        boundary,
    )

    junctions = compute_region_junctions(labels)

    save_mask(
        args.output / "07_region_junctions.png",
        junctions,
    )

    overlay = make_overlay(
        image,
        boundary,
        junctions,
    )

    cv2.imwrite(
        str(args.output / "08_boundary_overlay.png"),
        overlay,
    )

    # Keep label IDs for later pipeline stages.
    np.save(
        args.output / "region_labels.npy",
        labels,
    )

    unique, counts = np.unique(
        labels[labels >= 0],
        return_counts=True,
    )

    print()
    print("Detected region classes:")

    for label_id, count in zip(
        unique,
        counts,
    ):
        print(f"  class {int(label_id):02d}: " f"{int(count):9d} pixels")

    print()
    print(
        "Boundary pixels:",
        int(boundary.sum()),
    )

    print(
        "Junction pixels:",
        int(junctions.sum()),
    )

    print()
    print(
        "Output:",
        args.output,
    )

    print("=" * 72)

    with open(
        args.output / "topology_mask_report.json",
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            topology_report,
            f,
            indent=2,
        )


if __name__ == "__main__":
    main()
