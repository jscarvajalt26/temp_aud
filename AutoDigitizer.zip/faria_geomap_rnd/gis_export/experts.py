"""
Trained-model experts for the runner. Each model is used for what it is
best at (ROLES below):

    supervisor_multihead  contact, fault, road, river, lake, strike_dip and
                          clutter probability maps
    transunet             contacts, faults and clutter (CNN detail + ViT
                          context for thin, continuous lines)
    rs3mamba              contacts and faults (state-space scans carry long
                          lines across the whole tile)
    se_unet               contact / structural (fault or vein) / clutter
                          classes, used as a second opinion
    georegion_affinity    palette-independent area-boundary probability
    mask2former           area masks, turned into an area-boundary
                          probability (separates similar-coloured areas)
    sam2                  settles the uncertain parts of the area boundary
                          (public SAM2.1 weights, no training)

Line maps for the same target are averaged over the models that predict
it; area-boundary maps are combined by taking the maximum, then SAM2
refines the uncertain band. A model runs only when its checkpoint file is
found; missing models are reported and the runner falls back to the colour
and rule-based steps. A model whose output covers an implausible share of
the map (for example an untrained checkpoint) is reported and ignored.

Checkpoints are looked up by file name under --models-dir, or at the paths
the training scripts write to (faria_geomap_rnd/outputs/...).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np

from faria_geomap_rnd import config

CHECKPOINT_FILES = {
    "supervisor_multihead": (
        config.OUTPUT_DIR / "checkpoints_supervisor_multihead",
        "multihead_geomap_best.pth",
    ),
    "transunet": (
        config.OUTPUT_DIR / "checkpoints_transunet",
        "transunet_geomap_best.pth",
    ),
    "rs3mamba": (
        config.OUTPUT_DIR / "checkpoints_rs3mamba",
        "rs3mamba_geomap_best.pth",
    ),
    "se_unet": (
        config.CHECKPOINT_DIR,
        "se_unet_v2_best.pth",
    ),
    "georegion_affinity": (
        config.OUTPUT_DIR / "checkpoints_georegion_affinity",
        "georegion_affinity_best.pth",
    ),
    "mask2former": (
        config.OUTPUT_DIR / "checkpoints_mask2former",
        "mask2former_regions_best.pth",
    ),
    # SAM2 runs last: it refines the combined area boundary.
    "sam2": (
        config.SAM2_ROOT / "checkpoints",
        "sam2.1_hiera_*.pt",
    ),
}

# Which outputs of each model the runner uses.
ROLES = {
    "supervisor_multihead": (
        "contact",
        "fault",
        "road",
        "river",
        "lake",
        "strike_dip",
        "clutter",
    ),
    "transunet": ("contact", "fault", "clutter"),
    "rs3mamba": ("contact", "fault"),
    "se_unet": ("contact", "fault", "clutter"),
    "georegion_affinity": ("area_boundary",),
    "mask2former": ("area_boundary",),
    "sam2": ("area_boundary_refinement",),
}

LINE_MODELS = ("supervisor_multihead", "transunet", "rs3mamba", "se_unet")
AREA_MODELS = ("georegion_affinity", "mask2former")

# A thin-feature or boundary map above 0.5 on more than this share of the
# map is not believable (typically an untrained or mismatched checkpoint).
MAX_PLAUSIBLE_COVERAGE = 0.35

SAM2_CONFIGS = {
    "tiny": "configs/sam2.1/sam2.1_hiera_t.yaml",
    "small": "configs/sam2.1/sam2.1_hiera_s.yaml",
    "base_plus": "configs/sam2.1/sam2.1_hiera_b+.yaml",
    "large": "configs/sam2.1/sam2.1_hiera_l.yaml",
}


@dataclass
class ExpertOutputs:
    """Probability maps (H x W, 0..1) at the processing resolution."""

    used: dict[str, str] = field(default_factory=dict)
    missing: list[str] = field(default_factory=list)
    errors: dict[str, str] = field(default_factory=dict)
    ignored: dict[str, str] = field(default_factory=dict)
    line: dict[str, dict[str, np.ndarray]] = field(default_factory=dict)
    area: dict[str, np.ndarray] = field(default_factory=dict)
    region_boundary: np.ndarray | None = None
    sam2: dict = field(default_factory=dict)

    @property
    def multihead(self) -> dict[str, np.ndarray]:
        return self.line.get("supervisor_multihead", {})

    def probability(self, name: str) -> tuple[np.ndarray | None, str]:
        """
        Fused probability for a line target ('contact', 'fault', 'road',
        'river', 'clutter', ...), averaging the models whose role covers
        it. Returns (probability, method name).
        """
        maps, methods = [], []
        for model, heads in self.line.items():
            if name in heads:
                maps.append(heads[name])
                methods.append(model)
        if not maps:
            return None, ""
        return np.mean(maps, axis=0).astype(np.float32), "+".join(methods)

    def to_report(self) -> dict:
        return {
            "used": self.used,
            "missing": self.missing,
            "errors": self.errors,
            "ignored": self.ignored,
            "roles": {name: list(ROLES[name]) for name in self.used},
            "sam2": self.sam2,
        }


def find_checkpoints(models_dir: Path | None) -> dict[str, Path | None]:
    found: dict[str, Path | None] = {}
    for name, (default_dir, filename) in CHECKPOINT_FILES.items():
        path = None
        if models_dir is not None and models_dir.exists():
            matches = sorted(models_dir.rglob(filename))
            path = matches[0] if matches else None
        if path is None and default_dir.exists():
            matches = sorted(default_dir.glob(filename))
            path = matches[0] if matches else None
        found[name] = path
    return found


def _device(name: str):
    import torch

    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(name)


# ---------------------------------------------------------------------
# LINE MODELS
# ---------------------------------------------------------------------


def _run_line_model(image_bgr, path, device) -> dict[str, np.ndarray]:
    """Multi-head, TransUNet and RS3Mamba share one loader and tiling."""
    from faria_geomap_rnd.pipelines import infer_supervisor_multihead as mh

    model, checkpoint = mh.load_model(path, device)
    tile = int(checkpoint.get("crop_size", 256))
    probs, _ = mh.predict_tiled(model, image_bgr, device, tile, min(64, tile // 4))
    return probs


def _run_se_unet(image_bgr, path, device) -> dict[str, np.ndarray]:
    from faria_geomap_rnd.orchestrator.adapters.se_unet_adapter import (
        SEUNetAdapter,
    )
    from faria_geomap_rnd.orchestrator.label_schema import GeoMapClass
    from faria_geomap_rnd.pipelines.inference_core import predict_tiled_map

    adapter = SEUNetAdapter(path, device=device)
    adapter.load()
    prediction = predict_tiled_map(
        model=adapter.model,
        image_bgr=image_bgr,
        model_name="se_unet",
        device=adapter.device,
        tile_size=adapter.tile_size,
        tile_overlap=adapter.tile_overlap,
    )
    p = prediction.class_probabilities
    return {
        "contact": p[GeoMapClass.CONTACT].astype(np.float32),
        "fault": p[GeoMapClass.STRUCTURAL_FEATURE].astype(np.float32),
        "clutter": p[GeoMapClass.CLUTTER].astype(np.float32),
    }


# ---------------------------------------------------------------------
# AREA MODELS
# ---------------------------------------------------------------------


def _run_affinity(image_bgr, path, device) -> np.ndarray:
    import torch

    from faria_geomap_rnd.models.hybrid.georegion_affinity_net import (
        GeoRegionAffinityNet,
    )
    from faria_geomap_rnd.pipelines import infer_georegion_affinity as ga

    checkpoint = torch.load(path, map_location=device, weights_only=False)
    model = GeoRegionAffinityNet(
        base_channels=int(checkpoint.get("base_channels", 16))
    ).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    tile = int(checkpoint.get("crop_size", 256))
    rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    with torch.no_grad():
        probs = ga.predict_tiled(model, rgb, device, tile, min(64, tile // 4))

    h_diff, v_diff = ga.build_difference_probability(probs)
    affinity_boundary = ga.build_affinity_boundary_probability(h_diff, v_diff)
    return ga.combine_boundary_evidence(probs["boundary"], affinity_boundary, 0.60)


def _run_mask2former(image_bgr, path, device) -> np.ndarray:
    from faria_geomap_rnd.models import mask2former_regions as m2f

    model, checkpoint = m2f.load_region_model(path, device)
    tile = int(checkpoint.get("crop_size", 384))
    return m2f.predict_region_boundary(
        model, image_bgr, device, tile, min(64, tile // 4)
    ).astype(np.float32)


# ---------------------------------------------------------------------
# SAM2 REFINEMENT
# ---------------------------------------------------------------------


def sam2_config_for(path: Path) -> str:
    stem = path.stem.lower()
    for size in ("base_plus", "small", "large", "tiny"):
        if size in stem:
            return SAM2_CONFIGS[size]
    return SAM2_CONFIGS["tiny"]


def uncertain_boxes(
    boundary: np.ndarray,
    low: float = 0.3,
    high: float = 0.7,
    pad: int = 32,
    min_side: int = 96,
    max_boxes: int = 40,
) -> list[tuple[int, int, int, int]]:
    """Boxes (x1, y1, x2, y2) around the largest uncertain-boundary areas."""
    band = ((boundary >= low) & (boundary <= high)).astype(np.uint8)
    band = cv2.dilate(band, np.ones((9, 9), np.uint8))
    count, _, stats, _ = cv2.connectedComponentsWithStats(band, connectivity=8)
    h, w = boundary.shape
    order = np.argsort(-stats[1:, cv2.CC_STAT_AREA]) + 1
    boxes = []
    for i in order[:max_boxes]:
        x, y, bw, bh = stats[i, :4]
        cx, cy = x + bw / 2, y + bh / 2
        half_w = max(bw / 2 + pad, min_side / 2)
        half_h = max(bh / 2 + pad, min_side / 2)
        x1, x2 = int(max(cx - half_w, 0)), int(min(cx + half_w, w))
        y1, y2 = int(max(cy - half_h, 0)), int(min(cy + half_h, h))
        if x2 - x1 >= 16 and y2 - y1 >= 16:
            boxes.append((x1, y1, x2, y2))
    return boxes


def _refine_with_sam2(image_bgr, path, device, boundary, max_boxes=40):
    """
    Inside each uncertain box, SAM2 proposes area masks. Uncertain pixels
    on a SAM2 mask edge are raised to boundary, the others lowered.
    """
    from sam2.automatic_mask_generator import SAM2AutomaticMaskGenerator
    from sam2.build_sam import build_sam2

    model = build_sam2(sam2_config_for(path), str(path), device=str(device))
    generator = SAM2AutomaticMaskGenerator(
        model,
        points_per_side=16,
        pred_iou_thresh=0.7,
        stability_score_thresh=0.85,
        min_mask_region_area=50,
    )

    refined = boundary.copy()
    uncertain = (boundary >= 0.3) & (boundary <= 0.7)
    kernel = np.ones((3, 3), np.uint8)
    boxes = uncertain_boxes(boundary, max_boxes=max_boxes)
    raised = lowered = 0

    for x1, y1, x2, y2 in boxes:
        crop = cv2.cvtColor(image_bgr[y1:y2, x1:x2], cv2.COLOR_BGR2RGB)
        edge = np.zeros(crop.shape[:2], dtype=np.uint8)
        for mask in generator.generate(crop):
            seg = mask["segmentation"].astype(np.uint8)
            edge |= seg - cv2.erode(seg, kernel)
        edge = cv2.dilate(edge, kernel, iterations=2) > 0

        roi = refined[y1:y2, x1:x2]
        sel = uncertain[y1:y2, x1:x2]
        up = sel & edge
        down = sel & ~edge
        roi[up] = np.maximum(roi[up], 0.8)
        roi[down] = np.minimum(roi[down], 0.2)
        raised += int(up.sum())
        lowered += int(down.sum())

    return refined, {
        "boxes": len(boxes),
        "pixels_raised": raised,
        "pixels_lowered": lowered,
    }


RUNNERS = {
    "supervisor_multihead": _run_line_model,
    "transunet": _run_line_model,
    "rs3mamba": _run_line_model,
    "se_unet": _run_se_unet,
    "georegion_affinity": _run_affinity,
    "mask2former": _run_mask2former,
}


def _coverage(probability: np.ndarray) -> float:
    return float(np.mean(probability >= 0.5))


def run_experts(
    image_bgr: np.ndarray,
    models_dir: Path | None,
    device: str = "auto",
    sam2_max_boxes: int = 40,
) -> ExpertOutputs:
    out = ExpertOutputs()
    checkpoints = find_checkpoints(models_dir)

    if not any(checkpoints.values()):
        out.missing = list(checkpoints)
        return out

    try:
        dev = _device(device)
    except ImportError as exc:
        out.missing = list(checkpoints)
        out.errors["torch"] = str(exc)
        return out

    for name, runner in RUNNERS.items():
        path = checkpoints[name]
        if path is None:
            out.missing.append(name)
            continue
        try:
            result = runner(image_bgr, path, dev)
        except Exception as exc:  # a broken checkpoint must not stop the run
            out.errors[name] = f"{type(exc).__name__}: {exc}"
            continue
        out.used[name] = str(path)

        if name in LINE_MODELS:
            heads = {k: v for k, v in result.items() if k in ROLES[name]}
            worst = max(_coverage(heads[k]) for k in heads if k != "clutter")
            if worst > MAX_PLAUSIBLE_COVERAGE:
                out.ignored[name] = (
                    f"lines cover {worst:.0%} of the map; checkpoint looks "
                    "untrained or wrong for this map"
                )
                del out.used[name]
                continue
            out.line[name] = heads
        else:
            if _coverage(result) > MAX_PLAUSIBLE_COVERAGE:
                out.ignored[name] = (
                    f"area boundaries cover {_coverage(result):.0%} of the map; "
                    "checkpoint looks untrained or wrong for this map"
                )
                del out.used[name]
                continue
            out.area[name] = result

    if out.area:
        out.region_boundary = np.max(list(out.area.values()), axis=0)

    sam2_path = checkpoints["sam2"]
    if sam2_path is None:
        out.missing.append("sam2")
    elif out.region_boundary is None:
        out.sam2 = {"skipped": "no area-boundary model output to refine"}
    else:
        try:
            out.region_boundary, out.sam2 = _refine_with_sam2(
                image_bgr, sam2_path, dev, out.region_boundary, sam2_max_boxes
            )
            out.used["sam2"] = str(sam2_path)
        except Exception as exc:
            out.errors["sam2"] = f"{type(exc).__name__}: {exc}"

    return out
