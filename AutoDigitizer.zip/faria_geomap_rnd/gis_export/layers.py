"""
Output layer schema and writer.

Every feature type is its own layer with its own attribute table:

    units        Polygon   map unit faces
    contacts     Line      boundaries between two different units
    faults       Line
    veins        Line
    other_lines  Line      roads, rivers and unclassified linework

All layers go into one GeoPackage (<map_id>.gpkg) and are also written as
one GeoJSON file per layer. Every row carries map_id and source="auto" so
hand edits made later in QGIS can be told apart.
"""

from __future__ import annotations

import warnings
from pathlib import Path

import geopandas as gpd

from faria_geomap_rnd.gis_export.qgis_styles import (
    write_gpkg_styles,
    write_qml_sidecar,
)

LAYER_FIELDS: dict[str, list[str]] = {
    "units": [
        "face_id",
        "unit_id",
        "legend_code",
        "unit_name",
        "legend_color",
        "area",
        "confidence",
    ],
    "contacts": [
        "contact_id",
        "left_unit",
        "right_unit",
        "certainty",
        "length",
        "confidence",
    ],
    "faults": [
        "fault_id",
        "fault_type",
        "certainty",
        "line_color",
        "length",
        "class_method",
        "confidence",
    ],
    "veins": [
        "vein_id",
        "vein_type",
        "line_color",
        "length",
        "class_method",
        "confidence",
    ],
    "other_lines": [
        "line_id",
        "kind",
        "line_color",
        "length",
        "class_method",
        "confidence",
    ],
}

LAYER_GEOMETRY = {
    "units": "Polygon",
    "contacts": "LineString",
    "faults": "LineString",
    "veins": "LineString",
    "other_lines": "LineString",
}

COMMON_FIELDS = ["map_id", "source"]


def build_layer(
    name: str,
    rows: list[dict],
    map_id: str,
    crs,
) -> gpd.GeoDataFrame:
    fields = LAYER_FIELDS[name]
    data = {f: [row.get(f) for row in rows] for f in fields}
    data["map_id"] = [map_id] * len(rows)
    data["source"] = ["auto"] * len(rows)
    geometry = [row["geometry"] for row in rows]

    return gpd.GeoDataFrame(
        data,
        geometry=gpd.GeoSeries(geometry, crs=crs),
        crs=crs,
    )


def write_layers(
    layers: dict[str, gpd.GeoDataFrame],
    output_dir: Path,
    map_id: str,
) -> dict[str, str]:
    """
    Write every layer, including empty ones, so the output always has the
    same structure. Returns the paths written.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    gpkg_path = output_dir / f"{map_id}.gpkg"
    geojson_dir = output_dir / "geojson"
    geojson_dir.mkdir(exist_ok=True)

    if gpkg_path.exists():
        gpkg_path.unlink()

    written = {"gpkg": str(gpkg_path)}

    # Layers without a CRS are pixel-space on purpose; see georef.py.
    warnings.filterwarnings("ignore", message="'crs' was not provided")

    for name in LAYER_FIELDS:
        gdf = layers[name]
        gdf.to_file(
            gpkg_path,
            layer=name,
            driver="GPKG",
            engine="pyogrio",
            geometry_type=LAYER_GEOMETRY[name],
        )

        geojson_path = geojson_dir / f"{name}.geojson"
        if geojson_path.exists():
            geojson_path.unlink()
        gdf.to_file(geojson_path, driver="GeoJSON", engine="pyogrio")
        write_qml_sidecar(geojson_path, name)
        written[name] = str(geojson_path)

    write_gpkg_styles(gpkg_path, list(LAYER_FIELDS))

    return written
