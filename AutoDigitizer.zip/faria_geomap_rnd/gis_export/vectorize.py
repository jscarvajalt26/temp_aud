"""
Raster-to-vector conversion for the exported layers.

- Unit polygons come from the region label raster. Polygons are traced on
  pixel edges, so neighbouring units share identical boundaries (a valid
  planar coverage with no gaps or overlaps). Optional smoothing uses
  shapely's coverage simplification, which keeps shared edges shared.
- Contacts are the shared edges between neighbouring polygons of different
  units, with the unit on each side recorded.
- Linear features are skeletonized and traced into polylines, then sorted
  into faults, veins and other lines.
"""

from __future__ import annotations

import cv2
import numpy as np
import shapely
from affine import Affine
from shapely.geometry import LineString, MultiLineString, shape
from shapely.ops import linemerge

# ---------------------------------------------------------------------
# UNITS
# ---------------------------------------------------------------------


def polygonize_units(
    labels: np.ndarray,
    transform: Affine,
    simplify_tolerance: float = 0.0,
) -> list[dict]:
    """
    Return one record per connected unit polygon:
    {"unit_id": int, "geometry": Polygon}.

    `labels` holds unit ids >= 0; negative values are outside the map.
    """
    from rasterio import features

    lab = labels.astype(np.int32)
    valid = lab >= 0

    records = []
    for geom, value in features.shapes(
        lab,
        mask=valid,
        connectivity=4,
        transform=transform,
    ):
        poly = shape(geom)
        if poly.is_empty:
            continue
        records.append({"unit_id": int(value), "geometry": poly})

    if simplify_tolerance > 0 and records:
        geoms = np.array([r["geometry"] for r in records], dtype=object)
        simplified = shapely.coverage_simplify(geoms, simplify_tolerance)
        for record, geom in zip(records, simplified):
            if geom is not None and not geom.is_empty and geom.is_valid:
                record["geometry"] = geom

    return records


def extract_contacts(unit_records: list[dict]) -> list[dict]:
    """
    Shared boundaries between neighbouring polygons of different units.
    Returns {"left_unit", "right_unit", "geometry": LineString}.
    """
    geoms = [r["geometry"] for r in unit_records]
    if not geoms:
        return []

    tree = shapely.STRtree(geoms)
    boundaries = [g.boundary for g in geoms]

    contacts = []
    for i, geom in enumerate(geoms):
        for j in tree.query(geom, predicate="touches"):
            j = int(j)
            if j <= i:
                continue
            a = unit_records[i]["unit_id"]
            b = unit_records[j]["unit_id"]
            # Faces split by a printed line can share a unit; without face
            # ids, polygons of the same unit never touch.
            if "face_id" not in unit_records[i] and a == b:
                continue

            shared = boundaries[i].intersection(boundaries[j])
            for line in _as_lines(shared):
                if line.length <= 0:
                    continue
                contacts.append(
                    {
                        "left_unit": min(a, b),
                        "right_unit": max(a, b),
                        "geometry": line,
                    }
                )

    return contacts


def _as_lines(geom) -> list[LineString]:
    if geom.is_empty:
        return []
    if isinstance(geom, LineString):
        return [geom]
    if isinstance(geom, MultiLineString):
        merged = linemerge(geom)
        if isinstance(merged, LineString):
            return [merged]
        return list(merged.geoms)
    if hasattr(geom, "geoms"):
        parts = [g for g in geom.geoms if isinstance(g, LineString)]
        if not parts:
            return []
        return _as_lines(MultiLineString(parts))
    return []


# ---------------------------------------------------------------------
# LINES
# ---------------------------------------------------------------------

_NEIGHBOURS = [
    (-1, -1),
    (-1, 0),
    (-1, 1),
    (0, -1),
    (0, 1),
    (1, -1),
    (1, 0),
    (1, 1),
]


def skeleton_polylines(
    mask: np.ndarray,
    min_length_px: float = 15.0,
) -> list[np.ndarray]:
    """
    Skeletonize a binary line mask and trace it into pixel polylines.
    Each polyline is an (N, 2) array of (col, row).
    """
    from skimage.morphology import skeletonize

    skel = skeletonize(mask > 0)
    rows, cols = np.nonzero(skel)
    pixels = set(zip(rows.tolist(), cols.tolist()))

    def neighbours(p):
        r, c = p
        return [
            (r + dr, c + dc) for dr, dc in _NEIGHBOURS if (r + dr, c + dc) in pixels
        ]

    degree = {p: len(neighbours(p)) for p in pixels}
    nodes = {p for p, d in degree.items() if d != 2}

    visited_edges = set()
    polylines = []

    def walk(start, nxt):
        path = [start, nxt]
        visited_edges.add(frozenset((start, nxt)))
        prev, cur = start, nxt
        while cur not in nodes:
            step = None
            for n in neighbours(cur):
                if n == prev:
                    continue
                edge = frozenset((cur, n))
                if edge in visited_edges:
                    continue
                step = n
                break
            if step is None:
                break
            visited_edges.add(frozenset((cur, step)))
            path.append(step)
            prev, cur = cur, step
        return path

    for node in nodes:
        for n in neighbours(node):
            if frozenset((node, n)) not in visited_edges:
                polylines.append(walk(node, n))

    # Closed loops with no nodes.
    for p in pixels:
        if p in nodes:
            continue
        for n in neighbours(p):
            if frozenset((p, n)) not in visited_edges:
                nodes.add(p)
                polylines.append(walk(p, n))
                nodes.discard(p)
                break

    out = []
    for path in polylines:
        arr = np.array([(c, r) for r, c in path], dtype=np.float64)
        if len(arr) < 2:
            continue
        length = float(np.sum(np.hypot(*np.diff(arr, axis=0).T)))
        if length >= min_length_px:
            out.append(arr)

    return out


def pixel_line_to_geometry(
    polyline: np.ndarray,
    transform: Affine,
    simplify_px: float = 1.0,
) -> LineString:
    line = LineString(polyline + 0.5)  # pixel centres
    if simplify_px > 0:
        line = line.simplify(simplify_px, preserve_topology=False)
    coords = [transform * xy for xy in line.coords]
    return LineString(coords)


def sample_line_colour(
    image_bgr: np.ndarray,
    image_hsv: np.ndarray,
    line_mask: np.ndarray,
    polyline: np.ndarray,
    radius: int = 2,
) -> dict:
    """
    Median colour of the drawn line pixels around a traced polyline.
    Works inside the polyline's bounding box.
    """
    h, w = line_mask.shape
    pad = radius + 1
    x0 = max(int(np.floor(polyline[:, 0].min())) - pad, 0)
    y0 = max(int(np.floor(polyline[:, 1].min())) - pad, 0)
    x1 = min(int(np.ceil(polyline[:, 0].max())) + pad + 1, w)
    y1 = min(int(np.ceil(polyline[:, 1].max())) + pad + 1, h)

    canvas = np.zeros((y1 - y0, x1 - x0), dtype=np.uint8)
    pts = np.round(polyline - [x0, y0]).astype(np.int32).reshape(-1, 1, 2)
    cv2.polylines(canvas, [pts], False, 1, thickness=2 * radius + 1)

    sel = (canvas > 0) & (line_mask[y0:y1, x0:x1] > 0)
    if not sel.any():
        sel = canvas > 0

    pix_hsv = image_hsv[y0:y1, x0:x1][sel]
    pix_bgr = image_bgr[y0:y1, x0:x1][sel]

    hue = _circular_median_hue(pix_hsv[:, 0])
    sat = float(np.median(pix_hsv[:, 1]))
    val = float(np.median(pix_hsv[:, 2]))
    b, g, r = (int(x) for x in np.median(pix_bgr, axis=0))

    return {
        "hue": hue,
        "saturation": sat,
        "value": val,
        "hex": f"#{r:02X}{g:02X}{b:02X}",
    }


def _circular_median_hue(h: np.ndarray) -> float:
    # OpenCV hue is 0..179.
    ang = h.astype(np.float64) * (2 * np.pi / 180.0)
    mean = np.arctan2(np.sin(ang).mean(), np.cos(ang).mean())
    return float((mean * 180.0 / (2 * np.pi)) % 180.0)


def classify_line(
    colour: dict,
    length_px: float,
    straightness: float,
    contact_overlap: float,
    image_diagonal_px: float,
) -> tuple[str, str, float]:
    """
    Rule-based first pass (heuristic_v0). Returns (layer, kind, confidence).

    - Lines lying on unit contacts are dropped (the contacts layer already
      has them).
    - Red / magenta / orange saturated lines are veins (common vein styling).
    - Long, nearly straight lines of any other colour are faults. Faults are
      usually drawn straighter and longer than rivers, roads or text.
    - Wiggly saturated blue lines are rivers.
    - Everything else goes to other_lines.

    This is a placeholder until the trained fault/vein classifier exists.
    """
    if contact_overlap >= 0.7:
        return "drop_contact", "contact", 0.0

    hue, sat, val = colour["hue"], colour["saturation"], colour["value"]
    saturated = sat >= 90 and val >= 70

    if saturated and (hue <= 15 or hue >= 150):
        return "veins", "vein", 0.45

    if length_px >= 0.04 * image_diagonal_px and straightness >= 0.9:
        return "faults", "fault", 0.35

    if saturated and 95 <= hue <= 130:
        return "other_lines", "river", 0.4

    return "other_lines", "unclassified", 0.2


def straightness(polyline: np.ndarray) -> float:
    if len(polyline) < 2:
        return 0.0
    path = float(np.sum(np.hypot(*np.diff(polyline, axis=0).T)))
    chord = float(np.hypot(*(polyline[-1] - polyline[0])))
    return chord / path if path > 0 else 0.0


def contact_overlap_fraction(
    polyline: np.ndarray,
    contact_mask_px: np.ndarray,
) -> float:
    """
    Fraction of polyline samples that fall on the (dilated) contact raster.
    """
    h, w = contact_mask_px.shape
    pts = np.round(polyline).astype(int)
    cols = np.clip(pts[:, 0], 0, w - 1)
    rows = np.clip(pts[:, 1], 0, h - 1)
    return float(np.mean(contact_mask_px[rows, cols] > 0))


def contact_raster(labels: np.ndarray, width_px: int = 3) -> np.ndarray:
    """
    Pixels on or next to a boundary between two different units, grown by
    width_px on each side (0 = the one-pixel edge only).
    """
    lab = labels.astype(np.int32)
    edge = np.zeros(lab.shape, dtype=np.uint8)
    edge[:, 1:] |= (lab[:, 1:] != lab[:, :-1]).astype(np.uint8)
    edge[1:, :] |= (lab[1:, :] != lab[:-1, :]).astype(np.uint8)
    edge[lab < 0] = 0
    if width_px > 0:
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (width_px * 2 + 1,) * 2)
        edge = cv2.dilate(edge, kernel)
    return edge


def unit_colour_table(
    image_bgr: np.ndarray,
    labels: np.ndarray,
) -> dict[int, str]:
    """
    Median fill colour per unit id, as #RRGGBB.
    """
    out = {}
    for uid in np.unique(labels[labels >= 0]):
        sel = labels == uid
        b, g, r = (int(x) for x in np.median(image_bgr[sel], axis=0))
        out[int(uid)] = f"#{r:02X}{g:02X}{b:02X}"
    return out
