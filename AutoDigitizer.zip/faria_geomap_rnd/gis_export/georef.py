"""
Coordinate handling for exported layers.

Rules:
- If the input raster carries a CRS and geotransform (GeoTIFF, or an image
  with a world file that rasterio can read), every layer is written in that
  CRS.
- Otherwise the layers are written in pixel space with NO CRS and the y axis
  flipped, so QGIS shows the map upright. Pixel coordinates are never
  labelled as EPSG:4326 or any other real CRS.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from affine import Affine


@dataclass
class GeoReference:
    transform: Affine
    crs: object | None
    georeferenced: bool
    source: str

    def scaled(self, scale: float) -> "GeoReference":
        """
        Reference for an image resized by `scale` (processing size divided
        by original size). Output coordinates stay in the original frame.
        """
        if scale == 1.0:
            return self
        return GeoReference(
            transform=self.transform * Affine.scale(1.0 / scale),
            crs=self.crs,
            georeferenced=self.georeferenced,
            source=self.source,
        )

    def pixel_size(self) -> float:
        return float(abs(self.transform.a))

    def to_report(self) -> dict:
        return {
            "georeferenced": self.georeferenced,
            "source": self.source,
            "crs": None if self.crs is None else str(self.crs),
            "transform": list(self.transform)[:6],
        }


def pixel_reference() -> GeoReference:
    # x = column, y = -row: north-up display in QGIS without a CRS.
    return GeoReference(
        transform=Affine(1.0, 0.0, 0.0, 0.0, -1.0, 0.0),
        crs=None,
        georeferenced=False,
        source="pixel_space",
    )


def read_georeference(path: Path) -> GeoReference:
    """
    Read the CRS and transform from the input raster when it has them.
    """
    try:
        import rasterio
        from rasterio.errors import NotGeoreferencedWarning
    except ImportError:
        return pixel_reference()

    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", NotGeoreferencedWarning)
        try:
            with rasterio.open(path) as src:
                crs = src.crs
                transform = src.transform
        except Exception:
            return pixel_reference()

    if crs is None or transform == Affine.identity():
        return pixel_reference()

    return GeoReference(
        transform=transform,
        crs=crs,
        georeferenced=True,
        source="input_raster",
    )


def read_image_bgr(path: Path) -> np.ndarray:
    """
    Read an image as 8-bit BGR. Falls back to rasterio for GeoTIFFs that
    OpenCV cannot decode (for example multi-band or 16-bit files).
    """
    import cv2

    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is not None:
        return image

    import rasterio

    with rasterio.open(path) as src:
        bands = src.read(indexes=list(range(1, min(src.count, 3) + 1)))

    if bands.shape[0] == 1:
        bands = np.repeat(bands, 3, axis=0)

    rgb = np.moveaxis(bands, 0, -1).astype(np.float32)
    lo, hi = np.percentile(rgb, 0.5), np.percentile(rgb, 99.5)
    rgb = np.clip((rgb - lo) * 255.0 / max(hi - lo, 1e-6), 0, 255)

    return cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2BGR)
