"""
Default QGIS styles for the exported layers.

Styles are stored in the GeoPackage's `layer_styles` table with
useAsDefault = 1, which QGIS applies automatically when the layer is added.
The same style is written as a .qml file next to each GeoJSON file, which
QGIS also picks up automatically.

    units        fill from legend_color, bold black outline
    contacts     bold black line
    faults       thick red line
    veins        green line
    other_lines  thin grey line
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

LINE_STYLES = {
    "contacts": ("0,0,0,255", "0.6"),
    "faults": ("230,0,0,255", "0.8"),
    "veins": ("0,170,0,255", "0.6"),
    "other_lines": ("130,130,130,255", "0.3"),
}


def _option(name: str, value: str) -> str:
    return f'<Option type="QString" name="{name}" value="{value}"/>'


def line_qml(color: str, width_mm: str) -> str:
    options = "".join(
        [
            _option("line_color", color),
            _option("line_width", width_mm),
            _option("line_width_unit", "MM"),
            _option("line_style", "solid"),
            _option("capstyle", "round"),
            _option("joinstyle", "round"),
        ]
    )
    return (
        '<!DOCTYPE qgis PUBLIC "http://mrcc.com/qgis.dtd" "SYSTEM">'
        '<qgis version="3.28.0" styleCategories="Symbology">'
        '<renderer-v2 type="singleSymbol" symbollevels="0" enableorderby="0"'
        ' forceraster="0"><symbols>'
        '<symbol type="line" name="0" alpha="1" clip_to_extent="1" force_rhr="0">'
        '<layer class="SimpleLine" enabled="1" locked="0" pass="0">'
        f'<Option type="Map">{options}</Option>'
        "</layer></symbol></symbols></renderer-v2></qgis>"
    )


def units_qml() -> str:
    options = "".join(
        [
            _option("color", "200,200,200,255"),
            _option("style", "solid"),
            _option("outline_color", "0,0,0,255"),
            _option("outline_width", "0.4"),
            _option("outline_width_unit", "MM"),
            _option("outline_style", "solid"),
            _option("joinstyle", "round"),
        ]
    )
    # Fill colour comes from the legend_color attribute (#RRGGBB).
    data_defined = (
        '<data_defined_properties><Option type="Map">'
        '<Option type="QString" name="name" value=""/>'
        '<Option name="properties" type="Map">'
        '<Option name="fillColor" type="Map">'
        '<Option type="bool" name="active" value="true"/>'
        '<Option type="QString" name="expression"'
        " value=\"coalesce(&quot;legend_color&quot;, '#C8C8C8')\"/>"
        '<Option type="int" name="type" value="3"/>'
        "</Option></Option>"
        '<Option type="QString" name="type" value="collection"/>'
        "</Option></data_defined_properties>"
    )
    return (
        '<!DOCTYPE qgis PUBLIC "http://mrcc.com/qgis.dtd" "SYSTEM">'
        '<qgis version="3.28.0" styleCategories="Symbology">'
        '<renderer-v2 type="singleSymbol" symbollevels="0" enableorderby="0"'
        ' forceraster="0"><symbols>'
        '<symbol type="fill" name="0" alpha="0.85" clip_to_extent="1"'
        ' force_rhr="0">'
        '<layer class="SimpleFill" enabled="1" locked="0" pass="0">'
        f'<Option type="Map">{options}</Option>{data_defined}'
        "</layer></symbol></symbols></renderer-v2></qgis>"
    )


def layer_qml(name: str) -> str:
    if name == "units":
        return units_qml()
    return line_qml(*LINE_STYLES[name])


def write_gpkg_styles(gpkg_path: Path, layer_names: list[str]) -> None:
    """
    Add QGIS default styles to the GeoPackage's layer_styles table.
    """
    con = sqlite3.connect(gpkg_path)
    try:
        con.execute("""
            CREATE TABLE IF NOT EXISTS layer_styles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                f_table_catalog TEXT(256),
                f_table_schema TEXT(256),
                f_table_name TEXT(256),
                f_geometry_column TEXT(256),
                styleName TEXT(30),
                styleQML TEXT,
                styleSLD TEXT,
                useAsDefault BOOLEAN,
                description TEXT,
                owner TEXT(30),
                ui TEXT(30),
                update_time DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """)
        con.execute(
            "INSERT OR IGNORE INTO gpkg_contents (table_name, data_type, identifier)"
            " VALUES ('layer_styles', 'attributes', 'layer_styles')"
        )
        for name in layer_names:
            geom_col = con.execute(
                "SELECT column_name FROM gpkg_geometry_columns WHERE table_name = ?",
                (name,),
            ).fetchone()
            con.execute("DELETE FROM layer_styles WHERE f_table_name = ?", (name,))
            con.execute(
                "INSERT INTO layer_styles (f_table_catalog, f_table_schema,"
                " f_table_name, f_geometry_column, styleName, styleQML, styleSLD,"
                " useAsDefault, description, owner, ui)"
                " VALUES ('', '', ?, ?, ?, ?, '', 1, 'GeoMap default', '', '')",
                (name, geom_col[0] if geom_col else "geom", name, layer_qml(name)),
            )
        con.commit()
    finally:
        con.close()


def write_qml_sidecar(geojson_path: Path, name: str) -> Path:
    qml_path = geojson_path.with_suffix(".qml")
    qml_path.write_text(layer_qml(name), encoding="utf-8")
    return qml_path
