﻿# GeoMap R&D



Research and development workspace for automated geological map digitization within the AutoDigitizer repository.



This directory is intentionally isolated from the existing `digitalize/` implementation. Development in this subproject should not modify or depend on the internal structure of the existing production code unless an integration decision is made separately.



## Objective



The project investigates a hybrid computer-vision pipeline for converting geological maps and scanned map products into structured geological and GIS information.



Target outputs include:



\- geological unit regions;

\- geological contacts and boundaries;

\- faults;

\- roads;

\- rivers;

\- lakes;

\- strike/dip symbols and other cartographic features;

\- topology-preserving vector geometry;

\- GIS-ready outputs for downstream inspection and editing.



The research emphasizes preservation of geological topology, separation of overlapping map features, robustness across map styles, and conversion from raster predictions to usable vector geometry.



## Research Approach



The architecture is intentionally modular. No single model family is assumed to solve every part of geological map digitization.



Candidate and evaluated approaches include:



\- U-Net and SE-UNet segmentation;

\- transformer/global-context segmentation;

\- SegFormer-inspired architectures;

\- TransUNet-style approaches;

\- Mamba/state-space architectures;

\- multi-head semantic segmentation;

\- Mask2Former-style instance/layer separation;

\- SAM2/MapSAM2 local refinement;

\- geological region-affinity learning;

\- deterministic region reconstruction and topology-aware vectorization.



Models are evaluated according to the geological subproblem they address. The final system is expected to combine a small number of complementary components rather than select a single universal network.



## Current Architecture



Current R&D components include:



1\.  Local semantic segmentation

&#x20;  - SE-UNet and related convolutional models.



2\.  Global/context-aware segmentation

&#x20;  - Hybrid CNN/global-context models and transformer-based candidates.



3\. Multi-layer feature extraction

&#x20;  - Independent prediction heads for contacts, faults, roads, rivers, lakes, strike/dip symbols, and clutter.



4\. Geological region reasoning

&#x20;  - Horizontal and vertical region affinity prediction.

&#x20;  - Boundary prediction.

&#x20;  - Region reconstruction research.



5\. Local refinement

&#x20;  - SAM2/MapSAM2 experiments for uncertain-region refinement.

&#x20;  - SAM2 is optional and is not treated as the primary geological boundary generator.



6\. Topology and vectorization

&#x20;  - Region-based boundary extraction.

&#x20;  - Exact label-interface reconstruction.

&#x20;  - Junction-aware topology handling.

&#x20;  - GeoJSON/vector output generation.



The final production architecture remains under evaluation.



## Repository Layout



```text

geomap\_rnd/

 configs/       Configuration assets

 datasets/      Dataset loaders and sampling logic

 docs/          Design and R&D documentation

 models/        Neural and deterministic model components

 pipelines/     Training, inference, and refinement pipelines

 tests/         Automated smoke/regression tests

 tools/         Dataset, validation, and visualization utilities

 config.py      Portable project paths and shared configuration

 run\_v2\_pipeline.py

 pyproject.toml

 uv.lock

```



Generated datasets, outputs, checkpoints, virtual environments, and external research repositories are intentionally excluded from version control.



## Environment



Python 3.10 or newer is required.



The project uses `uv` for environment and dependency management.



From the AutoDigitizer repository root:



```powershell

$env:UV\_PROJECT\_ENVIRONMENT = "C:\\PROJECT\\AzureDevOps\\AutoDigitizer\\geomap\_rnd\\.venv"

uv sync --project ".\\geomap\_rnd"

```



The absolute environment path is recommended when working inside the parent AutoDigitizer repository so that the R&D environment remains isolated from the repository-level environment.



## External Data



Large research datasets are not stored in Git.



The Supervisor150 dataset can be supplied through:



```text

GEOMAP\_SUPERVISOR150\_ROOT

```



Example:



```powershell

$env:GEOMAP\_SUPERVISOR150\_ROOT = "C:\\path\\to\\Supervisor150"

```



If the variable is not set, the project falls back to:



```text

geomap\_rnd/data/Supervisor150

```



The `data/` directory is ignored by Git.



## External Research Models



Third-party research repositories are not vendored into this subproject.



External model locations may be configured using:



```text

GEOMAP\_RESEARCH\_MODEL\_ROOT

GEOMAP\_SAM2\_ROOT

```



The default local location for external research dependencies is:



```text

geomap\_rnd/external\_models/

```



This directory is excluded from version control.



SAM2 support is optional. Core GeoMap modules can be imported and tested without SAM2 installed.



## Development Checks



### Lint



```powershell

uv run --project ".\\geomap\_rnd" ruff check .\\geomap\_rnd

```



### Format



On managed Windows environments where direct executable spawning is restricted:



```powershell

uv run --project ".\\geomap\_rnd" python -m black .\\geomap\_rnd

```



### Tests



```powershell

uv run --project ".\\geomap\_rnd" python -m pytest .\\geomap\_rnd\\tests -q

```



### Compile Check



```powershell

uv run --project ".\\geomap\_rnd" python -m compileall -q .\\geomap\_rnd

```



## Current Validation Baseline



Repository smoke tests currently verify:



\- portable project configuration;

\- optional SAM2 dependency handling;

\- SE-UNet forward execution;

\- hybrid model forward execution;

\- GeoRegion affinity output structure;

\- multi-head segmentation output structure.



These tests are structural safeguards and do not replace dataset-level accuracy or topology validation.



## Validation Direction



Model and pipeline evaluation should include, where applicable:



\- boundary precision, recall, F1, and IoU;

\- region/polygon IoU;

\- boundary displacement;

\- Chamfer or Hausdorff distance;

\- endpoint and junction preservation;

\- topology validity;

\- gaps and overlaps;

\- GIS geometry validity;

\- cross-map generalization;

\- processing time.



Map-level train/validation/test separation should be maintained to avoid leakage between tiles from the same source map.



## Research Status



This is an active R&D system.



Individual models and refinement methods may be retained as experimental candidates even when they are not part of the current primary execution path. Experimental code should be evaluated using recorded evidence before promotion to, or removal from, the candidate architecture.



See `docs/DESIGN\_SPEC.md` for design details and architecture decisions.


