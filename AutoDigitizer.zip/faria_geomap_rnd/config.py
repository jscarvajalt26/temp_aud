﻿import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

DATA_DIR = BASE_DIR / "data"
RAW_MAP_DIR = DATA_DIR / "raw_maps"
VALIDATION_DIR = DATA_DIR / "validation"
TRAINING_DATA_DIR = DATA_DIR / "training"
MASK_DIR = DATA_DIR / "masks"

LAYOUT_MASK_PATH = MASK_DIR / "layout_ignore_mask.png"

OUTPUT_DIR = BASE_DIR / "outputs"
PREDICTION_DIR = OUTPUT_DIR / "predictions"
CHECKPOINT_DIR = OUTPUT_DIR / "checkpoints_v2"

SUPERVISOR150_ROOT = Path(
    os.environ.get(
        "GEOMAP_SUPERVISOR150_ROOT",
        DATA_DIR / "Supervisor150",
    )
)

SUPERVISOR_MULTILAYER_TARGET_DIR = DATA_DIR / "supervisor_multilayer_targets"

SUPERVISOR_TARGET_DIR = DATA_DIR / "supervisor_targets"

GEOREGION_AFFINITY_TARGET_DIR = DATA_DIR / "georegion_affinity_targets"

SUPERVISOR_SPLIT_DIR = OUTPUT_DIR / "dataset_splits"

SUPERVISOR_SPLIT_PATH = SUPERVISOR_SPLIT_DIR / "supervisor150_split.json"

DATASET_AUDIT_DIR = OUTPUT_DIR / "dataset_audit"

ALIGNMENT_DEBUG_DIR = OUTPUT_DIR / "alignment_debug"

ALIGNMENT_VECTOR_CHECK_DIR = OUTPUT_DIR / "alignment_vector_check"

RESEARCH_MODEL_ROOT = Path(
    os.environ.get(
        "GEOMAP_RESEARCH_MODEL_ROOT",
        BASE_DIR / "external_models",
    )
)

SAM2_ROOT = Path(
    os.environ.get(
        "GEOMAP_SAM2_ROOT",
        RESEARCH_MODEL_ROOT / "sam2",
    )
)

NUM_CLASSES = 4
IGNORE_INDEX = 255

IMAGE_SIZE = 512
BASE_CHANNELS = 32

BATCH_SIZE = 2
EPOCHS = 30
LEARNING_RATE = 1e-4

TILE_OVERLAP = 128

MODEL_NAME = "se_unet"
DEVICE = "auto"
