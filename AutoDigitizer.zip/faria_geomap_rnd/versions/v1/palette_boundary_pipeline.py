from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.morphology import thin
from sklearn.cluster import KMeans


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

INPUT_PATH = BASE_DIR / "data" / "raw_maps" / "current_test_map.tif"

OUTPUT_DIR = (
    BASE_DIR
    / "outputs"
    / "palette_boundary"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

LABELS_PATH = (
    OUTPUT_DIR
    / "class_labels.npy"
)

PALETTE_OUTPUT_PATH = (
    OUTPUT_DIR
    / "learned_palette_rgb.npy"
)

CLASS_PREVIEW_PATH = (
    OUTPUT_DIR
    / "classified_preview.png"
)

INTERNAL_BOUNDARY_PATH = (
    OUTPUT_DIR
    / "internal_boundaries.png"
)

OUTER_BOUNDARY_PATH = (
    OUTPUT_DIR
    / "outer_boundary.png"
)

BOUNDARY_ONLY_PATH = (
    OUTPUT_DIR
    / "all_boundaries.png"
)

OVERLAY_PATH = (
    OUTPUT_DIR
    / "boundary_overlay.png"
)

SMOOTH_OVERLAY_PATH = (
    OUTPUT_DIR
    / "boundary_overlay_4x.png"
)

PROCESSING_MASK_PATH = (
    OUTPUT_DIR
    / "processing_region.png"
)

SMOOTHED_IMAGE_PATH = (
    OUTPUT_DIR
    / "smoothed_input.png"
)

CARTOGRAPHIC_MASK_PATH = (
    OUTPUT_DIR
    / "cartographic_noise_mask.png"
)

CLEANED_COLOUR_INPUT_PATH = (
    OUTPUT_DIR
    / "cleaned_colour_input.png"
)

CHROMA_GRADIENT_PATH = (
    OUTPUT_DIR
    / "chroma_gradient.png"
)


# ============================================================
# SERBIA-SPECIFIC SETTINGS
# ============================================================

# Main colour segmentation.
DARK_VALUE_THRESHOLD = 92

WHITE_VALUE_THRESHOLD = 248
WHITE_SATURATION_THRESHOLD = 12

MINIMUM_SATURATION = 6

MAX_DARK_FILL_DISTANCE = 6
MAX_EDGE_FILL_DISTANCE = 4

MAX_INTERNAL_HOLE_SIZE = 2200
MIN_CLASS_COMPONENT_SIZE = 35

ADAPTIVE_CLASS_COUNT = 14
KMEANS_SAMPLE_SIZE = 160_000

MAX_TEST_WIDTH = 3400
DISPLAY_SCALE = 4

MAJORITY_FILTER_PASSES = 2

# Final boundary cleanup.
MIN_INTERNAL_BOUNDARY_LENGTH = 10
MIN_OUTER_BOUNDARY_LENGTH = 18

BOUNDARY_GAP_SIZE = 3

# Main geological-map frame.
MAP_X_MIN_RATIO = 0.10
MAP_X_MAX_RATIO = 0.82

MAP_Y_MIN_RATIO = 0.05
MAP_Y_MAX_RATIO = 0.86

# Cartographic texture detection.
CARTOGRAPHIC_DARK_THRESHOLD = 145
CARTOGRAPHIC_MAX_SATURATION = 52

CARTOGRAPHIC_COMPONENT_MIN_AREA = 3
CARTOGRAPHIC_COMPONENT_MAX_AREA = 300

CARTOGRAPHIC_MAX_THICKNESS = 4.0

# Protect dark lines near broad lithological colour changes.
CHROMA_GRADIENT_THRESHOLD = 11.0
CHROMA_PROTECTION_RADIUS = 3

# Local colour replacement.
CARTOGRAPHIC_REPLACEMENT_BLUR = 9


# ============================================================
# SAVE HELPERS
# ============================================================

def save_bgr(
    path: Path,
    image: np.ndarray,
) -> None:
    success = cv2.imwrite(
        str(path),
        image,
    )

    if not success:
        raise RuntimeError(
            f"Could not save image: {path}"
        )


def save_rgb(
    path: Path,
    image_rgb: np.ndarray,
) -> None:
    save_bgr(
        path,
        cv2.cvtColor(
            image_rgb,
            cv2.COLOR_RGB2BGR,
        ),
    )


def save_boundary_image(
    path: Path,
    boundary: np.ndarray,
    reference_rgb: np.ndarray,
) -> None:
    output_rgb = np.full_like(
        reference_rgb,
        255,
    )

    output_rgb[
        boundary > 0
    ] = [
        0,
        0,
        0,
    ]

    save_rgb(
        path,
        output_rgb,
    )


# ============================================================
# PROCESSING REGION
# ============================================================

def create_processing_mask(
    height: int,
    width: int,
) -> np.ndarray:
    """
    True means ignored.
    False means processed.
    """

    ignore_mask = np.ones(
        (height, width),
        dtype=bool,
    )

    x1 = int(
        round(
            width
            * MAP_X_MIN_RATIO
        )
    )

    x2 = int(
        round(
            width
            * MAP_X_MAX_RATIO
        )
    )

    y1 = int(
        round(
            height
            * MAP_Y_MIN_RATIO
        )
    )

    y2 = int(
        round(
            height
            * MAP_Y_MAX_RATIO
        )
    )

    x1 = max(
        0,
        min(
            x1,
            width - 1,
        ),
    )

    x2 = max(
        x1 + 1,
        min(
            x2,
            width,
        ),
    )

    y1 = max(
        0,
        min(
            y1,
            height - 1,
        ),
    )

    y2 = max(
        y1 + 1,
        min(
            y2,
            height,
        ),
    )

    ignore_mask[
        y1:y2,
        x1:x2,
    ] = False

    print(
        "Processing frame:",
        f"x={x1}:{x2},",
        f"y={y1}:{y2}",
    )

    return ignore_mask


# ============================================================
# LABEL CLEANING
# ============================================================

def fill_from_nearest_class(
    labels: np.ndarray,
    fill_mask: np.ndarray,
    max_distance: float,
) -> np.ndarray:
    result = labels.copy()

    valid = (
        result != 255
    )

    if not np.any(valid):
        raise RuntimeError(
            "No valid geological classes were detected."
        )

    distances, indices = ndi.distance_transform_edt(
        ~valid,
        return_distances=True,
        return_indices=True,
    )

    allowed = (
        fill_mask
        & (~valid)
        & (
            distances
            <= max_distance
        )
    )

    if not np.any(allowed):
        return result

    result[
        allowed
    ] = result[
        indices[0][allowed],
        indices[1][allowed],
    ]

    return result


def fill_internal_holes(
    labels: np.ndarray,
    ignore_mask: np.ndarray,
    maximum_size: int,
) -> np.ndarray:
    result = labels.copy()

    invalid = (
        (result == 255)
        & (~ignore_mask)
    )

    structure = np.ones(
        (3, 3),
        dtype=np.uint8,
    )

    components, component_count = ndi.label(
        invalid,
        structure=structure,
    )

    fill_mask = np.zeros_like(
        invalid,
        dtype=bool,
    )

    height, width = result.shape

    for component_id in range(
        1,
        component_count + 1,
    ):
        region = (
            components
            == component_id
        )

        area = int(
            region.sum()
        )

        if (
            area == 0
            or area > maximum_size
        ):
            continue

        ys, xs = np.where(
            region
        )

        if len(xs) == 0:
            continue

        touches_border = (
            ys.min() == 0
            or xs.min() == 0
            or ys.max() == height - 1
            or xs.max() == width - 1
        )

        if touches_border:
            continue

        fill_mask |= region

    if not np.any(fill_mask):
        return result

    return fill_from_nearest_class(
        result,
        fill_mask=fill_mask,
        max_distance=24,
    )


def remove_tiny_components(
    labels: np.ndarray,
    class_count: int,
    minimum_size: int,
) -> np.ndarray:
    result = labels.copy()

    removal_mask = np.zeros_like(
        result,
        dtype=bool,
    )

    structure = np.ones(
        (3, 3),
        dtype=np.uint8,
    )

    for class_id in range(
        class_count
    ):
        binary = (
            result == class_id
        )

        components, component_count = ndi.label(
            binary,
            structure=structure,
        )

        if component_count == 0:
            continue

        sizes = np.bincount(
            components.ravel()
        )

        for component_id in range(
            1,
            component_count + 1,
        ):
            if (
                sizes[component_id]
                < minimum_size
            ):
                removal_mask |= (
                    components
                    == component_id
                )

    result[
        removal_mask
    ] = 255

    if not np.any(
        result != 255
    ):
        return result

    return fill_from_nearest_class(
        result,
        fill_mask=removal_mask,
        max_distance=10,
    )


def conservative_majority_filter(
    labels: np.ndarray,
    class_count: int,
) -> np.ndarray:
    """
    Remove strongly isolated pixels while avoiding broad region merging.
    """

    result = labels.copy()

    class_votes = []

    for class_id in range(
        class_count
    ):
        class_mask = (
            result == class_id
        ).astype(
            np.uint8
        )

        local_votes = cv2.boxFilter(
            class_mask,
            ddepth=cv2.CV_16U,
            ksize=(3, 3),
            normalize=False,
            borderType=cv2.BORDER_REPLICATE,
        )

        class_votes.append(
            local_votes
        )

    class_votes = np.stack(
        class_votes,
        axis=0,
    )

    majority_class = np.argmax(
        class_votes,
        axis=0,
    ).astype(
        np.uint8
    )

    majority_count = np.max(
        class_votes,
        axis=0,
    )

    safe_labels = result.copy()

    safe_labels[
        safe_labels == 255
    ] = 0

    current_count = np.take_along_axis(
        class_votes,
        safe_labels[
            None,
            :,
            :,
        ],
        axis=0,
    )[0]

    change_mask = (
        (result != 255)
        & (
            majority_class
            != result
        )
        & (
            majority_count
            >= 6
        )
        & (
            current_count
            <= 2
        )
    )

    result[
        change_mask
    ] = majority_class[
        change_mask
    ]

    return result


# ============================================================
# CARTOGRAPHIC TEXTURE SUPPRESSION
# ============================================================

def calculate_chroma_gradient(
    image_bgr: np.ndarray,
) -> np.ndarray:
    """
    Detect broad changes in geological colour using LAB a/b channels.
    """

    image_lab = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2LAB,
    ).astype(
        np.float32
    )

    a_channel = image_lab[
        :,
        :,
        1,
    ]

    b_channel = image_lab[
        :,
        :,
        2,
    ]

    a_channel = cv2.GaussianBlur(
        a_channel,
        (7, 7),
        sigmaX=1.7,
    )

    b_channel = cv2.GaussianBlur(
        b_channel,
        (7, 7),
        sigmaX=1.7,
    )

    a_dx = cv2.Sobel(
        a_channel,
        cv2.CV_32F,
        1,
        0,
        ksize=3,
    )

    a_dy = cv2.Sobel(
        a_channel,
        cv2.CV_32F,
        0,
        1,
        ksize=3,
    )

    b_dx = cv2.Sobel(
        b_channel,
        cv2.CV_32F,
        1,
        0,
        ksize=3,
    )

    b_dy = cv2.Sobel(
        b_channel,
        cv2.CV_32F,
        0,
        1,
        ksize=3,
    )

    gradient = np.sqrt(
        (
            a_dx * a_dx
        )
        + (
            a_dy * a_dy
        )
        + (
            b_dx * b_dx
        )
        + (
            b_dy * b_dy
        )
    )

    return gradient


def suppress_cartographic_texture(
    image_bgr: np.ndarray,
    valid_mask: np.ndarray,
) -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
]:
    """
    Suppress small, thin, low-saturation cartographic marks.

    Major dark contacts beside strong lithological colour changes are
    protected and are not removed.
    """

    hsv = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2HSV,
    )

    gray = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    saturation = hsv[
        :,
        :,
        1,
    ]

    chroma_gradient = calculate_chroma_gradient(
        image_bgr
    )

    strong_colour_change = (
        chroma_gradient
        >= CHROMA_GRADIENT_THRESHOLD
    ).astype(
        np.uint8
    )

    protection_size = (
        CHROMA_PROTECTION_RADIUS
        * 2
        + 1
    )

    protected_contact_zone = cv2.dilate(
        strong_colour_change,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (
                protection_size,
                protection_size,
            ),
        ),
        iterations=1,
    ) > 0

    low_saturation_dark = (
        (
            gray
            < CARTOGRAPHIC_DARK_THRESHOLD
        )
        & (
            saturation
            <= CARTOGRAPHIC_MAX_SATURATION
        )
        & valid_mask
        & (~protected_contact_zone)
    )

    candidate = (
        low_saturation_dark.astype(
            np.uint8
        )
        * 255
    )

    component_count, component_labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            (
                candidate > 0
            ).astype(
                np.uint8
            ),
            connectivity=8,
        )
    )

    removal_mask = np.zeros_like(
        candidate,
        dtype=np.uint8,
    )

    for component_id in range(
        1,
        component_count,
    ):
        area = int(
            stats[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        component_width = int(
            stats[
                component_id,
                cv2.CC_STAT_WIDTH,
            ]
        )

        component_height = int(
            stats[
                component_id,
                cv2.CC_STAT_HEIGHT,
            ]
        )

        if (
            area < CARTOGRAPHIC_COMPONENT_MIN_AREA
            or area > CARTOGRAPHIC_COMPONENT_MAX_AREA
        ):
            continue

        long_side = max(
            component_width,
            component_height,
            1,
        )

        estimated_thickness = (
            area
            / long_side
        )

        if (
            estimated_thickness
            > CARTOGRAPHIC_MAX_THICKNESS
        ):
            continue

        component = (
            component_labels
            == component_id
        )

        removal_mask[
            component
        ] = 255

    # Expand slightly to include antialiased edges.
    removal_mask = cv2.dilate(
        removal_mask,
        np.ones(
            (3, 3),
            dtype=np.uint8,
        ),
        iterations=1,
    )

    removal_mask[
        ~valid_mask
    ] = 0

    # Use local averaging rather than inpainting.
    # This avoids inventing colours or reshaping lithological regions.
    blur_size = CARTOGRAPHIC_REPLACEMENT_BLUR

    if blur_size % 2 == 0:
        blur_size += 1

    locally_blurred = cv2.GaussianBlur(
        image_bgr,
        (
            blur_size,
            blur_size,
        ),
        sigmaX=1.5,
    )

    cleaned_bgr = image_bgr.copy()

    cleaned_bgr[
        removal_mask > 0
    ] = locally_blurred[
        removal_mask > 0
    ]

    return (
        cleaned_bgr,
        removal_mask,
        chroma_gradient,
    )


# ============================================================
# BOUNDARY HELPERS
# ============================================================

def remove_boundary_fragments(
    boundary: np.ndarray,
    minimum_length: int,
) -> np.ndarray:
    binary = (
        boundary > 0
    ).astype(
        np.uint8
    )

    component_count, component_labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            binary,
            connectivity=8,
        )
    )

    cleaned = np.zeros_like(
        boundary,
        dtype=np.uint8,
    )

    for component_id in range(
        1,
        component_count,
    ):
        area = int(
            stats[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        if area < minimum_length:
            continue

        cleaned[
            component_labels
            == component_id
        ] = 255

    return cleaned


def close_short_boundary_gaps(
    boundary: np.ndarray,
) -> np.ndarray:
    result = boundary.copy()

    size = BOUNDARY_GAP_SIZE

    if size % 2 == 0:
        size += 1

    kernels = [
        cv2.getStructuringElement(
            cv2.MORPH_RECT,
            (
                size,
                1,
            ),
        ),
        cv2.getStructuringElement(
            cv2.MORPH_RECT,
            (
                1,
                size,
            ),
        ),
        np.eye(
            size,
            dtype=np.uint8,
        ),
        np.fliplr(
            np.eye(
                size,
                dtype=np.uint8,
            )
        ).copy(),
    ]

    for kernel in kernels:
        closed = cv2.morphologyEx(
            result,
            cv2.MORPH_CLOSE,
            kernel,
            iterations=1,
        )

        result = np.maximum(
            result,
            closed,
        )

    return result


def create_boundaries(
    labels: np.ndarray,
    ignore_mask: np.ndarray,
) -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
]:
    """
    Create stable boundaries from cleaned class transitions only.
    """

    valid = (
        (labels != 255)
        & (~ignore_mask)
    )

    internal = np.zeros(
        labels.shape,
        dtype=np.uint8,
    )

    outer = np.zeros(
        labels.shape,
        dtype=np.uint8,
    )

    # Horizontal internal transitions.
    left_valid = valid[
        :,
        :-1,
    ]

    right_valid = valid[
        :,
        1:,
    ]

    horizontal_difference = (
        left_valid
        & right_valid
        & (
            labels[:, :-1]
            != labels[:, 1:]
        )
    )

    ys, xs = np.where(
        horizontal_difference
    )

    internal[
        ys,
        xs,
    ] = 255

    internal[
        ys,
        xs + 1,
    ] = 255

    # Horizontal outer transitions.
    horizontal_outer = (
        left_valid
        ^ right_valid
    )

    ys, xs = np.where(
        horizontal_outer
        & left_valid
    )

    outer[
        ys,
        xs,
    ] = 255

    ys, xs = np.where(
        horizontal_outer
        & right_valid
    )

    outer[
        ys,
        xs + 1,
    ] = 255

    # Vertical internal transitions.
    upper_valid = valid[
        :-1,
        :,
    ]

    lower_valid = valid[
        1:,
        :,
    ]

    vertical_difference = (
        upper_valid
        & lower_valid
        & (
            labels[:-1, :]
            != labels[1:, :]
        )
    )

    ys, xs = np.where(
        vertical_difference
    )

    internal[
        ys,
        xs,
    ] = 255

    internal[
        ys + 1,
        xs,
    ] = 255

    # Vertical outer transitions.
    vertical_outer = (
        upper_valid
        ^ lower_valid
    )

    ys, xs = np.where(
        vertical_outer
        & upper_valid
    )

    outer[
        ys,
        xs,
    ] = 255

    ys, xs = np.where(
        vertical_outer
        & lower_valid
    )

    outer[
        ys + 1,
        xs,
    ] = 255

    # Image edges.
    outer[
        0,
        valid[
            0,
            :,
        ],
    ] = 255

    outer[
        -1,
        valid[
            -1,
            :,
        ],
    ] = 255

    outer[
        valid[
            :,
            0,
        ],
        0,
    ] = 255

    outer[
        valid[
            :,
            -1,
        ],
        -1,
    ] = 255

    internal = close_short_boundary_gaps(
        internal
    )

    outer = close_short_boundary_gaps(
        outer
    )

    internal = thin(
        internal > 0
    ).astype(
        np.uint8
    ) * 255

    outer = thin(
        outer > 0
    ).astype(
        np.uint8
    ) * 255

    internal = remove_boundary_fragments(
        internal,
        minimum_length=MIN_INTERNAL_BOUNDARY_LENGTH,
    )

    outer = remove_boundary_fragments(
        outer,
        minimum_length=MIN_OUTER_BOUNDARY_LENGTH,
    )

    combined = np.maximum(
        internal,
        outer,
    )

    combined = close_short_boundary_gaps(
        combined
    )

    combined = thin(
        combined > 0
    ).astype(
        np.uint8
    ) * 255

    combined = remove_boundary_fragments(
        combined,
        minimum_length=MIN_INTERNAL_BOUNDARY_LENGTH,
    )

    return (
        internal,
        outer,
        combined,
    )


def create_antialiased_overlay(
    image_rgb: np.ndarray,
    boundary: np.ndarray,
) -> np.ndarray:
    alpha = (
        boundary.astype(
            np.float32
        )
        / 255.0
    )

    alpha = cv2.GaussianBlur(
        alpha,
        ksize=(3, 3),
        sigmaX=0.55,
    )

    alpha = np.clip(
        alpha * 1.65,
        0.0,
        1.0,
    )[..., None]

    result = (
        image_rgb.astype(
            np.float32
        )
        * (
            1.0
            - alpha
        )
    )

    return np.clip(
        result,
        0,
        255,
    ).astype(
        np.uint8
    )


# ============================================================
# LOAD IMAGE
# ============================================================

image_bgr = cv2.imread(
    str(INPUT_PATH),
    cv2.IMREAD_COLOR,
)

if image_bgr is None:
    raise FileNotFoundError(
        f"Could not load input map: {INPUT_PATH}"
    )

original_height, original_width = (
    image_bgr.shape[:2]
)

print(
    "Original image size:",
    f"{original_width}x{original_height}",
)

if original_width > MAX_TEST_WIDTH:
    scale = (
        MAX_TEST_WIDTH
        / original_width
    )

    new_width = int(
        round(
            original_width
            * scale
        )
    )

    new_height = int(
        round(
            original_height
            * scale
        )
    )

    image_bgr = cv2.resize(
        image_bgr,
        (
            new_width,
            new_height,
        ),
        interpolation=cv2.INTER_AREA,
    )

    print(
        "Resized:",
        f"{original_width}x{original_height}",
        "→",
        f"{new_width}x{new_height}",
    )

image_rgb = cv2.cvtColor(
    image_bgr,
    cv2.COLOR_BGR2RGB,
)

height, width = (
    image_rgb.shape[:2]
)

print(
    "Working image shape:",
    image_rgb.shape,
)


# ============================================================
# CREATE PROCESSING MASK
# ============================================================

ignore_mask = create_processing_mask(
    height,
    width,
)

valid_map_mask = (
    ~ignore_mask
)

processing_preview = np.full(
    (
        height,
        width,
        3,
    ),
    255,
    dtype=np.uint8,
)

processing_preview[
    valid_map_mask
] = [
    0,
    0,
    0,
]

save_bgr(
    PROCESSING_MASK_PATH,
    processing_preview,
)


# ============================================================
# CARTOGRAPHIC TEXTURE SUPPRESSION
# ============================================================

print(
    "Suppressing small cartographic texture..."
)

(
    cleaned_colour_bgr,
    cartographic_noise_mask,
    chroma_gradient,
) = suppress_cartographic_texture(
    image_bgr=image_bgr,
    valid_mask=valid_map_mask,
)

save_bgr(
    CARTOGRAPHIC_MASK_PATH,
    cartographic_noise_mask,
)

save_bgr(
    CLEANED_COLOUR_INPUT_PATH,
    cleaned_colour_bgr,
)

gradient_preview = cv2.normalize(
    chroma_gradient,
    None,
    0,
    255,
    cv2.NORM_MINMAX,
).astype(
    np.uint8
)

save_bgr(
    CHROMA_GRADIENT_PATH,
    gradient_preview,
)


# ============================================================
# EDGE-PRESERVING SMOOTHING
# ============================================================

smoothed_bgr = cv2.bilateralFilter(
    cleaned_colour_bgr,
    d=7,
    sigmaColor=35,
    sigmaSpace=35,
)

smoothed_bgr = cv2.medianBlur(
    smoothed_bgr,
    5,
)

save_bgr(
    SMOOTHED_IMAGE_PATH,
    smoothed_bgr,
)


# ============================================================
# COLOUR MASKS
# ============================================================

hsv = cv2.cvtColor(
    smoothed_bgr,
    cv2.COLOR_BGR2HSV,
)

value = hsv[
    :,
    :,
    2,
]

saturation = hsv[
    :,
    :,
    1,
]

dark_mask = (
    value
    < DARK_VALUE_THRESHOLD
)

white_background = (
    (
        value
        >= WHITE_VALUE_THRESHOLD
    )
    & (
        saturation
        <= WHITE_SATURATION_THRESHOLD
    )
)

image_lab = cv2.cvtColor(
    smoothed_bgr,
    cv2.COLOR_BGR2LAB,
).astype(
    np.float32
)


# ============================================================
# ADAPTIVE KMEANS CLASSIFICATION
# ============================================================

colour_pixel_mask = (
    (~dark_mask)
    & (~white_background)
    & (~ignore_mask)
    & (
        saturation
        >= MINIMUM_SATURATION
    )
)

valid_pixel_count = int(
    colour_pixel_mask.sum()
)

print(
    "Valid colour pixels:",
    valid_pixel_count,
)

if (
    valid_pixel_count
    < ADAPTIVE_CLASS_COUNT
):
    raise RuntimeError(
        "Not enough valid colour pixels for adaptive palette."
    )

lab_pixels = image_lab[
    colour_pixel_mask
].reshape(
    -1,
    3,
)

sample_size = min(
    KMEANS_SAMPLE_SIZE,
    len(
        lab_pixels
    ),
)

rng = np.random.default_rng(
    42
)

sample_indices = rng.choice(
    len(
        lab_pixels
    ),
    size=sample_size,
    replace=False,
)

training_pixels = lab_pixels[
    sample_indices
]

print(
    "Training adaptive KMeans palette..."
)

kmeans = KMeans(
    n_clusters=ADAPTIVE_CLASS_COUNT,
    random_state=42,
    n_init=10,
)

kmeans.fit(
    training_pixels
)

nearest_class_flat = kmeans.predict(
    lab_pixels
).astype(
    np.uint8
)

labels = np.full(
    (
        height,
        width,
    ),
    255,
    dtype=np.uint8,
)

labels[
    colour_pixel_mask
] = nearest_class_flat


# ============================================================
# LEARN DISPLAY PALETTE
# ============================================================

learned_palette_lab = (
    kmeans.cluster_centers_
    .astype(
        np.uint8
    )
    .reshape(
        1,
        -1,
        3,
    )
)

palette_rgb = cv2.cvtColor(
    learned_palette_lab,
    cv2.COLOR_LAB2RGB,
).reshape(
    -1,
    3,
).astype(
    np.uint8
)

class_count = len(
    palette_rgb
)

np.save(
    PALETTE_OUTPUT_PATH,
    palette_rgb,
)

print(
    "Learned palette RGB:"
)

print(
    palette_rgb
)


# ============================================================
# FILL DARK LINES AND SMALL GAPS
# ============================================================

dark_fill_mask = (
    dark_mask
    & (~ignore_mask)
    & (~white_background)
)

labels = fill_from_nearest_class(
    labels,
    fill_mask=dark_fill_mask,
    max_distance=MAX_DARK_FILL_DISTANCE,
)

edge_candidates = (
    (labels == 255)
    & (~white_background)
    & (~ignore_mask)
)

labels = fill_from_nearest_class(
    labels,
    fill_mask=edge_candidates,
    max_distance=MAX_EDGE_FILL_DISTANCE,
)


# ============================================================
# CLEAN LABELS
# ============================================================

print(
    "Removing tiny class components..."
)

labels = remove_tiny_components(
    labels,
    class_count=class_count,
    minimum_size=MIN_CLASS_COMPONENT_SIZE,
)

print(
    "Filling small internal holes..."
)

labels = fill_internal_holes(
    labels,
    ignore_mask=ignore_mask,
    maximum_size=MAX_INTERNAL_HOLE_SIZE,
)

print(
    "Applying conservative majority filtering..."
)

for pass_number in range(
    MAJORITY_FILTER_PASSES
):
    labels = conservative_majority_filter(
        labels,
        class_count,
    )

    print(
        f"Majority pass "
        f"{pass_number + 1}/"
        f"{MAJORITY_FILTER_PASSES}"
    )

labels[
    ignore_mask
] = 255

labels[
    white_background
    & (~ignore_mask)
] = 255

labels = remove_tiny_components(
    labels,
    class_count=class_count,
    minimum_size=MIN_CLASS_COMPONENT_SIZE,
)

labels[
    ignore_mask
] = 255


# ============================================================
# CREATE BOUNDARIES
# ============================================================

print(
    "Creating stable class-transition boundaries..."
)

(
    internal_boundary,
    outer_boundary,
    all_boundaries,
) = create_boundaries(
    labels,
    ignore_mask,
)


# ============================================================
# SAVE LABELS AND CLASSIFICATION
# ============================================================

np.save(
    LABELS_PATH,
    labels,
)

classification_preview = np.full_like(
    image_rgb,
    255,
)

for class_id, colour in enumerate(
    palette_rgb
):
    classification_preview[
        labels == class_id
    ] = colour

save_rgb(
    CLASS_PREVIEW_PATH,
    classification_preview,
)


# ============================================================
# SAVE BOUNDARY OUTPUTS
# ============================================================

save_boundary_image(
    INTERNAL_BOUNDARY_PATH,
    internal_boundary,
    image_rgb,
)

save_boundary_image(
    OUTER_BOUNDARY_PATH,
    outer_boundary,
    image_rgb,
)

save_boundary_image(
    BOUNDARY_ONLY_PATH,
    all_boundaries,
    image_rgb,
)


# ============================================================
# SAVE OVERLAY
# ============================================================

overlay_rgb = create_antialiased_overlay(
    image_rgb,
    all_boundaries,
)

save_rgb(
    OVERLAY_PATH,
    overlay_rgb,
)

large_image_rgb = cv2.resize(
    image_rgb,
    (
        width
        * DISPLAY_SCALE,
        height
        * DISPLAY_SCALE,
    ),
    interpolation=cv2.INTER_CUBIC,
)

large_boundary = cv2.resize(
    all_boundaries,
    (
        width
        * DISPLAY_SCALE,
        height
        * DISPLAY_SCALE,
    ),
    interpolation=cv2.INTER_NEAREST,
)

large_overlay_rgb = create_antialiased_overlay(
    large_image_rgb,
    large_boundary,
)

save_rgb(
    SMOOTH_OVERLAY_PATH,
    large_overlay_rgb,
)


# ============================================================
# SUMMARY
# ============================================================

valid_labels = labels[
    labels != 255
]

if valid_labels.size > 0:
    unique_classes, class_counts = np.unique(
        valid_labels,
        return_counts=True,
    )

    print()
    print(
        "Detected class pixel counts:"
    )

    for class_id, count in zip(
        unique_classes,
        class_counts,
    ):
        print(
            f"Class {int(class_id)}: "
            f"{int(count)} pixels"
        )

print()
print(
    "Saved processing mask:",
    PROCESSING_MASK_PATH,
)

print(
    "Saved cartographic mask:",
    CARTOGRAPHIC_MASK_PATH,
)

print(
    "Saved cleaned colour input:",
    CLEANED_COLOUR_INPUT_PATH,
)

print(
    "Saved chroma gradient:",
    CHROMA_GRADIENT_PATH,
)

print(
    "Saved smoothed input:",
    SMOOTHED_IMAGE_PATH,
)

print(
    "Saved learned palette:",
    PALETTE_OUTPUT_PATH,
)

print(
    "Saved class labels:",
    LABELS_PATH,
)

print(
    "Saved classified preview:",
    CLASS_PREVIEW_PATH,
)

print(
    "Saved internal boundaries:",
    INTERNAL_BOUNDARY_PATH,
)

print(
    "Saved outer boundary:",
    OUTER_BOUNDARY_PATH,
)

print(
    "Saved all boundaries:",
    BOUNDARY_ONLY_PATH,
)

print(
    "Saved overlay:",
    OVERLAY_PATH,
)

print(
    "Saved smooth 4x overlay:",
    SMOOTH_OVERLAY_PATH,
)