\# V1 — Classical Computer Vision Baseline



\## Status



Preserved working baseline.



This version represents the first end-to-end geological map digitization

workflow developed before the learned/hybrid V2 research.



The implementation is preserved because it produced a meaningful final result

and remains useful as a deterministic baseline for comparison.



\---



\## What V1 Does



V1 uses classical image-processing and geometry-processing techniques to:



\- segment geological colour regions

\- reconstruct geological units

\- extract internal geological contacts

\- extract the outer map boundary

\- clean small islands and holes

\- identify elongated dark vein-like structures

\- generate cleaned raster outputs for later GIS/vector processing



The workflow relies primarily on:



\- LAB/colour-space processing

\- K-Means clustering

\- morphological cleanup

\- connected-component analysis

\- boundary extraction

\- skeletonization/thinning

\- deterministic geometric rules



\---



\## Folder Structure



```text

v1/

├── data/

│   └── raw\_maps/

├── outputs/

│   ├── palette\_boundary/

│   ├── clean\_final/

│   └── v1\_tests/

├── palette\_boundary\_pipeline.py

├── clean\_units\_and\_veins.py

└── run\_v1\_batch.py

