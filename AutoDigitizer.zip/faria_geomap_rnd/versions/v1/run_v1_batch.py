from __future__ import annotations

from pathlib import Path
import shutil
import subprocess
import sys
import time


BASE_DIR = Path(__file__).resolve().parent

INPUT_DIR = BASE_DIR / "data" / "raw_maps"
OUTPUT_ROOT = BASE_DIR / "outputs" / "v1_tests"

PALETTE_SCRIPT = BASE_DIR / "palette_boundary_pipeline.py"
CLEAN_SCRIPT = BASE_DIR / "clean_units_and_veins.py"

TEMP_INPUT_NAME = "current_test_map.tif"
TEMP_INPUT_PATH = INPUT_DIR / TEMP_INPUT_NAME


def find_tif_files() -> list[Path]:
    return sorted(
        path
        for path in INPUT_DIR.iterdir()
        if path.is_file()
        and path.suffix.lower() in {".tif", ".tiff"}
        and path.name != TEMP_INPUT_NAME
    )


def run_script(script_path: Path) -> None:
    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=BASE_DIR,
        check=False,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"{script_path.name} failed with exit code "
            f"{result.returncode}"
        )


def copy_stage_outputs(
    source_dir: Path,
    destination_dir: Path,
) -> None:
    if not source_dir.exists():
        raise FileNotFoundError(
            f"Expected output folder not found: {source_dir}"
        )

    if destination_dir.exists():
        shutil.rmtree(destination_dir)

    shutil.copytree(
        source_dir,
        destination_dir,
    )


def main() -> None:
    tif_files = find_tif_files()

    if not tif_files:
        raise RuntimeError(
            f"No TIFF files found in {INPUT_DIR}"
        )

    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    print(f"Found {len(tif_files)} TIFF maps.")

    for index, tif_path in enumerate(
        tif_files,
        start=1,
    ):
        map_name = tif_path.stem

        print()
        print("=" * 70)
        print(
            f"[{index}/{len(tif_files)}] "
            f"Processing: {tif_path.name}"
        )
        print("=" * 70)

        map_output_dir = (
            OUTPUT_ROOT
            / map_name
        )

        map_output_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        started = time.perf_counter()

        try:
            shutil.copy2(
                tif_path,
                TEMP_INPUT_PATH,
            )

            run_script(
                PALETTE_SCRIPT
            )

            copy_stage_outputs(
                BASE_DIR
                / "outputs"
                / "palette_boundary",
                map_output_dir
                / "palette_boundary",
            )

            run_script(
                CLEAN_SCRIPT
            )

            copy_stage_outputs(
                BASE_DIR
                / "outputs"
                / "clean_final",
                map_output_dir
                / "clean_final",
            )

            elapsed = (
                time.perf_counter()
                - started
            )

            report_path = (
                map_output_dir
                / "run_report.txt"
            )

            report_path.write_text(
                "\n".join(
                    [
                        f"map={tif_path.name}",
                        "status=success",
                        f"runtime_seconds={elapsed:.3f}",
                    ]
                ),
                encoding="utf-8",
            )

            print(
                f"Completed in {elapsed:.2f} seconds."
            )

        except Exception as exc:
            elapsed = (
                time.perf_counter()
                - started
            )

            report_path = (
                map_output_dir
                / "run_report.txt"
            )

            report_path.write_text(
                "\n".join(
                    [
                        f"map={tif_path.name}",
                        "status=failed",
                        f"runtime_seconds={elapsed:.3f}",
                        f"error={exc}",
                    ]
                ),
                encoding="utf-8",
            )

            print(
                f"FAILED: {exc}"
            )

        finally:
            if TEMP_INPUT_PATH.exists():
                TEMP_INPUT_PATH.unlink()

    print()
    print("Batch test finished.")
    print("Results:", OUTPUT_ROOT)


if __name__ == "__main__":
    main()