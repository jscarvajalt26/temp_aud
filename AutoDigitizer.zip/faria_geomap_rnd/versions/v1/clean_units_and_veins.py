from pathlib import Path

import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.morphology import skeletonize, thin


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).parent

ORIGINAL_PATH = (
    BASE_DIR
    / "data"
    / "raw_maps"
    / "current_test_map.tif"
)

LABELS_PATH = (
    BASE_DIR
    / "outputs"
    / "palette_boundary"
    / "class_labels.npy"
)

PALETTE_PATH = (
    BASE_DIR
    / "outputs"
    / "palette_boundary"
    / "learned_palette_rgb.npy"
)

OUTPUT_DIR = BASE_DIR / "outputs" / "clean_final"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

CLEAN_LABELS_PATH = OUTPUT_DIR / "clean_labels.npy"

CLEAN_UNITS_PATH = OUTPUT_DIR / "clean_units_only.png"
CONTACTS_ONLY_PATH = OUTPUT_DIR / "clean_contacts_only.png"
UNITS_CONTACTS_PATH = OUTPUT_DIR / "clean_units_with_contacts.png"

VEINS_ONLY_PATH = OUTPUT_DIR / "detected_veins_only.png"
FINAL_PATH = OUTPUT_DIR / "clean_units_contacts_veins.png"
FINAL_LAYOUT_PATH = OUTPUT_DIR / "clean_map_with_layout.png"


# ============================================================
# SETTINGS
# ============================================================

MAX_TEST_WIDTH = 2200

MAX_INTERNAL_ISLAND_AREA = 220
ISLAND_DOMINANCE_REQUIRED = 0.84
MAX_INTERNAL_HOLE_AREA = 1800
ISLAND_CLEANING_PASSES = 3

VEIN_DARK_THRESHOLD = 72
CONTACT_EXCLUSION_RADIUS = 4

MIN_VEIN_AREA = 18
MAX_VEIN_AREA = 5000
MIN_VEIN_SKELETON_LENGTH = 16

MAX_VEIN_THICKNESS = 4.8
MIN_VEIN_ELONGATION = 3.3
MIN_VEIN_ASPECT_RATIO = 2.2

VEIN_BOLD_RADIUS = 1


# ============================================================
# PALETTE
# ============================================================

if not PALETTE_PATH.exists():
    raise FileNotFoundError(
        f"Could not find learned palette: {PALETTE_PATH}\n"
        "Run palette_boundary_pipeline.py first."
    )

PALETTE_RGB = np.load(PALETTE_PATH).astype(np.uint8)
CLASS_COUNT = len(PALETTE_RGB)

print("Loaded learned palette:", PALETTE_PATH)
print(PALETTE_RGB)


# ============================================================
# HELPERS
# ============================================================

def remove_enclosed_islands(
    labels: np.ndarray,
    layout_mask: np.ndarray,
) -> np.ndarray:
    result = labels.copy()
    structure = np.ones((3, 3), dtype=np.uint8)

    for cleaning_pass in range(ISLAND_CLEANING_PASSES):
        changed_pixels = 0

        for class_id in range(CLASS_COUNT):
            class_mask = result == class_id

            components, component_count = ndi.label(
                class_mask,
                structure=structure,
            )

            if component_count == 0:
                continue

            component_sizes = np.bincount(components.ravel())

            for component_id in range(1, component_count + 1):
                area = int(component_sizes[component_id])

                if area == 0 or area > MAX_INTERNAL_ISLAND_AREA:
                    continue

                region = components == component_id

                expanded = ndi.binary_dilation(
                    region,
                    iterations=2,
                )

                neighbor_ring = (
                    expanded
                    & (~region)
                    & (~layout_mask)
                )

                neighbor_values = result[neighbor_ring]

                neighbor_values = neighbor_values[
                    (neighbor_values != 255)
                    & (neighbor_values != class_id)
                ]

                if len(neighbor_values) == 0:
                    continue

                counts = np.bincount(
                    neighbor_values,
                    minlength=CLASS_COUNT,
                )

                dominant_class = int(np.argmax(counts))
                dominant_count = int(counts[dominant_class])
                dominance = dominant_count / len(neighbor_values)

                if dominance >= ISLAND_DOMINANCE_REQUIRED:
                    result[region] = dominant_class
                    changed_pixels += area

        print(
            f"Island cleaning pass {cleaning_pass + 1}: "
            f"changed {changed_pixels} pixels"
        )

        if changed_pixels == 0:
            break

    return result


def fill_small_holes(
    labels: np.ndarray,
    layout_mask: np.ndarray,
) -> np.ndarray:
    result = labels.copy()

    invalid = (
        (result == 255)
        & (~layout_mask)
    )

    structure = np.ones((3, 3), dtype=np.uint8)

    components, component_count = ndi.label(
        invalid,
        structure=structure,
    )

    height, width = result.shape

    for component_id in range(1, component_count + 1):
        region = components == component_id
        area = int(region.sum())

        if area == 0 or area > MAX_INTERNAL_HOLE_AREA:
            continue

        ys, xs = np.where(region)

        touches_image_border = (
            ys.min() == 0
            or xs.min() == 0
            or ys.max() == height - 1
            or xs.max() == width - 1
        )

        if touches_image_border:
            continue

        expanded = ndi.binary_dilation(
            region,
            iterations=2,
        )

        neighbor_ring = (
            expanded
            & (~region)
            & (~layout_mask)
        )

        neighbor_values = result[neighbor_ring]
        neighbor_values = neighbor_values[neighbor_values != 255]

        if len(neighbor_values) == 0:
            continue

        counts = np.bincount(
            neighbor_values,
            minlength=CLASS_COUNT,
        )

        dominant_class = int(np.argmax(counts))
        dominant_count = int(counts[dominant_class])
        dominance = dominant_count / len(neighbor_values)

        if dominance >= 0.65:
            result[region] = dominant_class

    return result


def create_clean_contacts(
    labels: np.ndarray,
    layout_mask: np.ndarray,
) -> np.ndarray:
    valid = (
        (labels != 255)
        & (~layout_mask)
    )

    boundary = np.zeros(labels.shape, dtype=np.uint8)

    horizontal = (
        valid[:, :-1]
        & valid[:, 1:]
        & (labels[:, :-1] != labels[:, 1:])
    )

    ys, xs = np.where(horizontal)
    boundary[ys, xs + 1] = 255

    vertical = (
        valid[:-1, :]
        & valid[1:, :]
        & (labels[:-1, :] != labels[1:, :])
    )

    ys, xs = np.where(vertical)
    boundary[ys + 1, xs] = 255

    left_valid = valid[:, :-1]
    right_valid = valid[:, 1:]

    outer_horizontal = left_valid ^ right_valid

    ys, xs = np.where(outer_horizontal & left_valid)
    boundary[ys, xs] = 255

    ys, xs = np.where(outer_horizontal & right_valid)
    boundary[ys, xs + 1] = 255

    upper_valid = valid[:-1, :]
    lower_valid = valid[1:, :]

    outer_vertical = upper_valid ^ lower_valid

    ys, xs = np.where(outer_vertical & upper_valid)
    boundary[ys, xs] = 255

    ys, xs = np.where(outer_vertical & lower_valid)
    boundary[ys + 1, xs] = 255

    boundary[0, valid[0, :]] = 255
    boundary[-1, valid[-1, :]] = 255
    boundary[valid[:, 0], 0] = 255
    boundary[valid[:, -1], -1] = 255

    cross_kernel = np.array(
        [
            [0, 1, 0],
            [1, 1, 1],
            [0, 1, 0],
        ],
        dtype=np.uint8,
    )

    boundary = cv2.morphologyEx(
        boundary,
        cv2.MORPH_CLOSE,
        cross_kernel,
        iterations=1,
    )

    return thin(boundary > 0).astype(np.uint8) * 255


def extract_veins(
    original_bgr: np.ndarray,
    labels: np.ndarray,
    contacts: np.ndarray,
    layout_mask: np.ndarray,
) -> np.ndarray:
    gray = cv2.cvtColor(
        original_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    dark = gray < VEIN_DARK_THRESHOLD

    valid_geology = (
        (labels != 255)
        & (~layout_mask)
    )

    contact_kernel_size = CONTACT_EXCLUSION_RADIUS * 2 + 1

    contact_kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (
            contact_kernel_size,
            contact_kernel_size,
        ),
    )

    contact_buffer = cv2.dilate(
        contacts,
        contact_kernel,
        iterations=1,
    ) > 0

    candidates = (
        dark
        & valid_geology
        & (~contact_buffer)
    )

    candidate_image = candidates.astype(np.uint8) * 255

    candidate_image = cv2.morphologyEx(
        candidate_image,
        cv2.MORPH_OPEN,
        np.ones((2, 2), dtype=np.uint8),
        iterations=1,
    )

    component_count, component_labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            candidate_image,
            connectivity=8,
        )
    )

    retained = np.zeros_like(
        candidate_image,
        dtype=bool,
    )

    for component_id in range(1, component_count):
        area = int(stats[component_id, cv2.CC_STAT_AREA])
        width = int(stats[component_id, cv2.CC_STAT_WIDTH])
        height = int(stats[component_id, cv2.CC_STAT_HEIGHT])

        if area < MIN_VEIN_AREA or area > MAX_VEIN_AREA:
            continue

        region = component_labels == component_id

        component_skeleton = skeletonize(region)
        skeleton_length = int(component_skeleton.sum())

        if skeleton_length < MIN_VEIN_SKELETON_LENGTH:
            continue

        average_thickness = area / max(
            skeleton_length,
            1,
        )

        if average_thickness > MAX_VEIN_THICKNESS:
            continue

        ys, xs = np.where(region)

        if len(xs) < 3:
            continue

        coordinates = np.column_stack(
            [xs, ys]
        ).astype(np.float32)

        centered = coordinates - coordinates.mean(
            axis=0,
            keepdims=True,
        )

        covariance = np.cov(
            centered,
            rowvar=False,
        )

        eigenvalues = np.linalg.eigvalsh(
            covariance
        )

        elongation = (
            float(eigenvalues[-1]) + 1e-6
        ) / (
            float(eigenvalues[0]) + 1e-6
        )

        aspect_ratio = max(
            width / max(height, 1),
            height / max(width, 1),
        )

        line_like = (
            elongation >= MIN_VEIN_ELONGATION
            or aspect_ratio >= MIN_VEIN_ASPECT_RATIO
        )

        if line_like:
            retained |= region

    vein_skeleton = skeletonize(retained)

    bold_size = VEIN_BOLD_RADIUS * 2 + 1

    bold_kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (bold_size, bold_size),
    )

    bold_veins = cv2.dilate(
        vein_skeleton.astype(np.uint8) * 255,
        bold_kernel,
        iterations=1,
    )

    return bold_veins


# ============================================================
# LOAD DATA
# ============================================================

if not LABELS_PATH.exists():
    raise FileNotFoundError(
        f"Could not find labels: {LABELS_PATH}\n"
        "Run palette_boundary_pipeline.py first."
    )

labels = np.load(LABELS_PATH).astype(np.uint8)

height, width = labels.shape

original_bgr = cv2.imread(
    str(ORIGINAL_PATH)
)

if original_bgr is None:
    raise FileNotFoundError(
        f"Could not load original image: {ORIGINAL_PATH}"
    )

original_height, original_width = original_bgr.shape[:2]

# Stage 1 is authoritative for the working image dimensions.
# Resize the original map to exactly match the saved class-label grid.
if (original_height, original_width) != (height, width):
    original_bgr = cv2.resize(
        original_bgr,
        (width, height),
        interpolation=cv2.INTER_AREA,
    )

    print(
        f"Aligned original map to Stage-1 labels: "
        f"{original_width}x{original_height} -> {width}x{height}"
    )

original_rgb = cv2.cvtColor(
    original_bgr,
    cv2.COLOR_BGR2RGB,
)

# ============================================================
# LAYOUT MASK
# ============================================================

# Preserve the original V1 layout exclusions at the
# Stage-1 working resolution.
layout_mask = np.zeros(
    (height, width),
    dtype=bool,
)

# Ignore top title area.
layout_mask[
    : int(height * 0.07),
    :
] = True

# Ignore bottom cross-sections and notes.
layout_mask[
    int(height * 0.83):,
    :
] = True

if original_rgb.shape[:2] != labels.shape:
    raise RuntimeError(
        "Original map and class labels could not be aligned."
    )

# ============================================================
# CLEAN CLASS LABELS
# ============================================================

print("Removing small internal color islands...")

clean_labels = remove_enclosed_islands(
    labels,
    layout_mask,
)

print("Filling small internal holes...")

clean_labels = fill_small_holes(
    clean_labels,
    layout_mask,
)

clean_labels[layout_mask] = 255

np.save(
    CLEAN_LABELS_PATH,
    clean_labels,
)


# ============================================================
# CREATE CLEAN CONTACTS
# ============================================================

print("Creating clean geological contacts...")

contacts = create_clean_contacts(
    clean_labels,
    layout_mask,
)


# ============================================================
# EXTRACT VEINS
# ============================================================

print("Extracting vein candidates...")

veins = np.zeros_like(
    contacts,
    dtype=np.uint8,
)


# ============================================================
# CREATE CLEAN FILLED MAP
# ============================================================

clean_units = np.full_like(
    original_rgb,
    255,
)

for class_id, color in enumerate(PALETTE_RGB):
    clean_units[clean_labels == class_id] = color


contacts_only = np.full_like(
    original_rgb,
    255,
)

contacts_only[contacts > 0] = [
    0,
    0,
    0,
]

units_contacts = clean_units.copy()

units_contacts[contacts > 0] = [
    0,
    0,
    0,
]

veins_only = np.full_like(
    original_rgb,
    255,
)

veins_only[veins > 0] = [
    0,
    0,
    0,
]

final_clean = units_contacts.copy()

final_clean[veins > 0] = [
    0,
    0,
    0,
]

final_with_layout = final_clean.copy()


# ============================================================
# SAVE OUTPUTS
# ============================================================

def save_rgb(path: Path, image: np.ndarray) -> None:
    cv2.imwrite(
        str(path),
        cv2.cvtColor(
            image,
            cv2.COLOR_RGB2BGR,
        ),
    )


save_rgb(CLEAN_UNITS_PATH, clean_units)
save_rgb(CONTACTS_ONLY_PATH, contacts_only)
save_rgb(UNITS_CONTACTS_PATH, units_contacts)
save_rgb(VEINS_ONLY_PATH, veins_only)
save_rgb(FINAL_PATH, final_clean)
save_rgb(FINAL_LAYOUT_PATH, final_with_layout)


# ============================================================
# FINISHED
# ============================================================

print("Saved clean labels:", CLEAN_LABELS_PATH)
print("Saved clean units:", CLEAN_UNITS_PATH)
print("Saved contacts only:", CONTACTS_ONLY_PATH)
print("Saved clean units with contacts:", UNITS_CONTACTS_PATH)
print("Saved detected veins:", VEINS_ONLY_PATH)
print("Saved clean final map:", FINAL_PATH)
print("Saved final map with layout:", FINAL_LAYOUT_PATH)