﻿# GeoMap V2 — Later Research Experiments

## Purpose

This directory preserves experimental research performed after the original
V2 SE-U-Net pipeline and alongside/after the V2.1 refinement work.

These files are retained for engineering traceability, reproducibility,
comparison of successful and unsuccessful approaches, and future model
development.

They should not be interpreted as one single production pipeline.

## Research Areas

### Hybrid / Context Models

Located under:

    models/hybrid/

Experiments include:

- SE-U-Net combined with global/context information
- transformer/context encoders
- multi-scale feature fusion
- multi-head geological/cartographic segmentation
- GeoRegion affinity prediction

### Multi-Head Segmentation

`multihead_geomap_net.py` explored separate prediction heads for overlapping
map features rather than forcing all features into one mutually exclusive
segmentation mask.

Associated training and inference scripts are:

    pipelines/train_supervisor_multihead.py
    pipelines/infer_supervisor_multihead.py

### GeoRegion Affinity

`georegion_affinity_net.py` explored learning local relationships between
neighboring pixels rather than directly predicting geological unit colours.

Associated scripts are:

    pipelines/train_georegion_affinity.py
    pipelines/infer_georegion_affinity.py

### SAM2 Experiments

The refinement package contains experiments using SAM2 for geological-body
proposal and local refinement.

SAM2 was investigated as a supporting/refinement model rather than being
treated as the complete geological-map digitization solution.

### Region and Topology Reconstruction

The refinement package also preserves experiments for:

- colour-region boundary extraction
- geological region reconstruction
- topology-aware vectorization
- alternative topology reconstruction strategies

Backup implementations are intentionally retained because they document
different experimental approaches.

## Datasets

The `datasets/` directory preserves dataset loaders used by the experimental
training pipelines.

These include the Supervisor dataset and GeoRegion affinity dataset.

## Tools

The `tools/` directory contains scripts used to construct, inspect, rasterize,
audit, and verify experimental training targets.

These are preserved because the target-generation process is part of the
experimental methodology and is necessary for reproducibility.

## Relationship to Version History

The high-level development sequence is:

    V1
    Classical image processing
        |
        v
    V2
    SE-U-Net learned segmentation
        |
        +--> V2.1
        |    Refinement, topology and GIS/vectorization
        |
        +--> Later V2 Research
             Hybrid/context models
             Multi-head segmentation
             GeoRegion affinity
             SAM2 refinement
             deterministic topology research
        |
        v
    V3
    Mask2Former investigation

V3 is maintained separately under:

    versions/v3_mask2former/

## Status

ARCHIVED RESEARCH / EXPERIMENTAL

The code in this directory is preserved primarily as an engineering and
research record. Some components may later be reused, adapted, or compared
against newer approaches.
