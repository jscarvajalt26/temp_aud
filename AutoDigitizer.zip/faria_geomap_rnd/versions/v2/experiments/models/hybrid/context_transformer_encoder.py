from __future__ import annotations

from typing import Sequence

import torch
import torch.nn as nn


class StochasticDepth(nn.Module):
    """
    Drop complete residual branches independently for each sample.

    This is used only during training.
    """

    def __init__(self, probability: float = 0.0):
        super().__init__()

        if not 0.0 <= probability < 1.0:
            raise ValueError(
                "Stochastic-depth probability must be in [0, 1)."
            )

        self.probability = probability

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        if (
            not self.training
            or self.probability == 0.0
        ):
            return x

        keep_probability = 1.0 - self.probability

        shape = (
            x.shape[0],
            *([1] * (x.ndim - 1)),
        )

        random_tensor = (
            keep_probability
            + torch.rand(
                shape,
                dtype=x.dtype,
                device=x.device,
            )
        )

        binary_mask = random_tensor.floor()

        return (
            x
            / keep_probability
            * binary_mask
        )


class OverlappingPatchEmbedding(nn.Module):
    """
    Convert an image or feature map into overlapping spatial tokens.
    """

    def __init__(
        self,
        in_channels: int,
        embed_channels: int,
        kernel_size: int,
        stride: int,
    ):
        super().__init__()

        padding = kernel_size // 2

        self.projection = nn.Conv2d(
            in_channels,
            embed_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
        )

        self.normalization = nn.LayerNorm(
            embed_channels
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> tuple[torch.Tensor, int, int]:
        x = self.projection(x)

        height, width = x.shape[-2:]

        tokens = x.flatten(2).transpose(1, 2)
        tokens = self.normalization(tokens)

        return tokens, height, width


class SpatialReductionAttention(nn.Module):
    """
    Multi-head self-attention with reduced-resolution keys and values.
    """

    def __init__(
        self,
        channels: int,
        num_heads: int,
        spatial_reduction_ratio: int = 1,
        attention_dropout: float = 0.0,
        projection_dropout: float = 0.0,
    ):
        super().__init__()

        if channels % num_heads != 0:
            raise ValueError(
                f"channels={channels} must be divisible "
                f"by num_heads={num_heads}."
            )

        if spatial_reduction_ratio < 1:
            raise ValueError(
                "spatial_reduction_ratio must be at least 1."
            )

        self.channels = channels
        self.num_heads = num_heads
        self.head_channels = channels // num_heads
        self.scale = self.head_channels ** -0.5

        self.query = nn.Linear(
            channels,
            channels,
            bias=True,
        )

        self.key_value = nn.Linear(
            channels,
            channels * 2,
            bias=True,
        )

        self.attention_dropout = nn.Dropout(
            attention_dropout
        )

        self.output_projection = nn.Linear(
            channels,
            channels,
        )

        self.output_dropout = nn.Dropout(
            projection_dropout
        )

        self.spatial_reduction_ratio = (
            spatial_reduction_ratio
        )

        if spatial_reduction_ratio > 1:
            self.spatial_reduction = nn.Conv2d(
                channels,
                channels,
                kernel_size=spatial_reduction_ratio,
                stride=spatial_reduction_ratio,
            )

            self.reduction_normalization = nn.LayerNorm(
                channels
            )
        else:
            self.spatial_reduction = None
            self.reduction_normalization = None

    def forward(
        self,
        tokens: torch.Tensor,
        height: int,
        width: int,
    ) -> torch.Tensor:
        batch_size, token_count, channels = (
            tokens.shape
        )

        query = self.query(tokens)

        query = query.reshape(
            batch_size,
            token_count,
            self.num_heads,
            self.head_channels,
        ).permute(
            0,
            2,
            1,
            3,
        )

        if self.spatial_reduction is not None:
            feature_map = tokens.transpose(
                1,
                2,
            ).reshape(
                batch_size,
                channels,
                height,
                width,
            )

            reduced_feature = self.spatial_reduction(
                feature_map
            )

            reduced_tokens = reduced_feature.flatten(
                2
            ).transpose(
                1,
                2,
            )

            reduced_tokens = (
                self.reduction_normalization(
                    reduced_tokens
                )
            )
        else:
            reduced_tokens = tokens

        key_value = self.key_value(
            reduced_tokens
        )

        key_value = key_value.reshape(
            batch_size,
            reduced_tokens.shape[1],
            2,
            self.num_heads,
            self.head_channels,
        ).permute(
            2,
            0,
            3,
            1,
            4,
        )

        key = key_value[0]
        value = key_value[1]

        attention = (
            query
            @ key.transpose(-2, -1)
        ) * self.scale

        attention = attention.softmax(
            dim=-1
        )

        attention = self.attention_dropout(
            attention
        )

        output = (
            attention
            @ value
        ).transpose(
            1,
            2,
        ).reshape(
            batch_size,
            token_count,
            channels,
        )

        output = self.output_projection(
            output
        )

        output = self.output_dropout(
            output
        )

        return output


class MixFeedForward(nn.Module):
    """
    Transformer feed-forward block with depthwise spatial mixing.
    """

    def __init__(
        self,
        channels: int,
        expansion_ratio: float = 4.0,
        dropout: float = 0.0,
    ):
        super().__init__()

        hidden_channels = int(
            channels * expansion_ratio
        )

        self.input_projection = nn.Linear(
            channels,
            hidden_channels,
        )

        self.depthwise_convolution = nn.Conv2d(
            hidden_channels,
            hidden_channels,
            kernel_size=3,
            stride=1,
            padding=1,
            groups=hidden_channels,
        )

        self.activation = nn.GELU()

        self.dropout = nn.Dropout(
            dropout
        )

        self.output_projection = nn.Linear(
            hidden_channels,
            channels,
        )

    def forward(
        self,
        tokens: torch.Tensor,
        height: int,
        width: int,
    ) -> torch.Tensor:
        tokens = self.input_projection(
            tokens
        )

        batch_size, _, hidden_channels = (
            tokens.shape
        )

        feature_map = tokens.transpose(
            1,
            2,
        ).reshape(
            batch_size,
            hidden_channels,
            height,
            width,
        )

        feature_map = self.depthwise_convolution(
            feature_map
        )

        tokens = feature_map.flatten(
            2
        ).transpose(
            1,
            2,
        )

        tokens = self.activation(
            tokens
        )

        tokens = self.dropout(
            tokens
        )

        tokens = self.output_projection(
            tokens
        )

        tokens = self.dropout(
            tokens
        )

        return tokens


class ContextTransformerBlock(nn.Module):
    def __init__(
        self,
        channels: int,
        num_heads: int,
        expansion_ratio: float,
        spatial_reduction_ratio: int,
        drop_path_probability: float = 0.0,
        dropout: float = 0.0,
        attention_dropout: float = 0.0,
    ):
        super().__init__()

        self.attention_normalization = nn.LayerNorm(
            channels,
            eps=1e-6,
        )

        self.attention = SpatialReductionAttention(
            channels=channels,
            num_heads=num_heads,
            spatial_reduction_ratio=(
                spatial_reduction_ratio
            ),
            attention_dropout=attention_dropout,
            projection_dropout=dropout,
        )

        self.feed_forward_normalization = (
            nn.LayerNorm(
                channels,
                eps=1e-6,
            )
        )

        self.feed_forward = MixFeedForward(
            channels=channels,
            expansion_ratio=expansion_ratio,
            dropout=dropout,
        )

        self.drop_path = StochasticDepth(
            drop_path_probability
        )

    def forward(
        self,
        tokens: torch.Tensor,
        height: int,
        width: int,
    ) -> torch.Tensor:
        attention_output = self.attention(
            self.attention_normalization(tokens),
            height,
            width,
        )

        tokens = (
            tokens
            + self.drop_path(attention_output)
        )

        feed_forward_output = self.feed_forward(
            self.feed_forward_normalization(
                tokens
            ),
            height,
            width,
        )

        tokens = (
            tokens
            + self.drop_path(
                feed_forward_output
            )
        )

        return tokens


class ContextTransformerStage(nn.Module):
    def __init__(
        self,
        in_channels: int,
        embed_channels: int,
        patch_kernel_size: int,
        patch_stride: int,
        depth: int,
        num_heads: int,
        expansion_ratio: float,
        spatial_reduction_ratio: int,
        drop_path_probabilities: Sequence[float],
    ):
        super().__init__()

        if len(drop_path_probabilities) != depth:
            raise ValueError(
                "drop_path_probabilities length "
                "must equal stage depth."
            )

        self.patch_embedding = (
            OverlappingPatchEmbedding(
                in_channels=in_channels,
                embed_channels=embed_channels,
                kernel_size=patch_kernel_size,
                stride=patch_stride,
            )
        )

        self.blocks = nn.ModuleList(
            [
                ContextTransformerBlock(
                    channels=embed_channels,
                    num_heads=num_heads,
                    expansion_ratio=expansion_ratio,
                    spatial_reduction_ratio=(
                        spatial_reduction_ratio
                    ),
                    drop_path_probability=(
                        drop_path_probabilities[index]
                    ),
                )
                for index in range(depth)
            ]
        )

        self.output_normalization = nn.LayerNorm(
            embed_channels,
            eps=1e-6,
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:
        tokens, height, width = (
            self.patch_embedding(x)
        )

        for block in self.blocks:
            tokens = block(
                tokens,
                height,
                width,
            )

        tokens = self.output_normalization(
            tokens
        )

        batch_size = tokens.shape[0]

        feature_map = tokens.transpose(
            1,
            2,
        ).reshape(
            batch_size,
            -1,
            height,
            width,
        )

        return feature_map


class ContextTransformerEncoder(nn.Module):
    """
    Lightweight four-stage transformer context encoder.

    Default configuration is inspired by the hierarchical B0 layout:
    channels [32, 64, 160, 256]
    depths   [2, 2, 2, 2]
    heads    [1, 2, 5, 8]
    """

    def __init__(
        self,
        in_channels: int = 3,
        embed_channels: Sequence[int] = (
            32,
            64,
            160,
            256,
        ),
        depths: Sequence[int] = (
            2,
            2,
            2,
            2,
        ),
        num_heads: Sequence[int] = (
            1,
            2,
            5,
            8,
        ),
        expansion_ratios: Sequence[float] = (
            4.0,
            4.0,
            4.0,
            4.0,
        ),
        spatial_reduction_ratios: Sequence[int] = (
            8,
            4,
            2,
            1,
        ),
        drop_path_rate: float = 0.1,
    ):
        super().__init__()

        stage_count = 4

        parameter_groups = (
            embed_channels,
            depths,
            num_heads,
            expansion_ratios,
            spatial_reduction_ratios,
        )

        if any(
            len(values) != stage_count
            for values in parameter_groups
        ):
            raise ValueError(
                "All stage configuration sequences "
                "must contain four values."
            )

        total_blocks = sum(depths)

        drop_path_values = torch.linspace(
            0.0,
            drop_path_rate,
            total_blocks,
        ).tolist()

        stage_drop_paths: list[list[float]] = []

        offset = 0

        for depth in depths:
            stage_drop_paths.append(
                drop_path_values[
                    offset:
                    offset + depth
                ]
            )

            offset += depth

        self.stage1 = ContextTransformerStage(
            in_channels=in_channels,
            embed_channels=embed_channels[0],
            patch_kernel_size=7,
            patch_stride=4,
            depth=depths[0],
            num_heads=num_heads[0],
            expansion_ratio=expansion_ratios[0],
            spatial_reduction_ratio=(
                spatial_reduction_ratios[0]
            ),
            drop_path_probabilities=(
                stage_drop_paths[0]
            ),
        )

        self.stage2 = ContextTransformerStage(
            in_channels=embed_channels[0],
            embed_channels=embed_channels[1],
            patch_kernel_size=3,
            patch_stride=2,
            depth=depths[1],
            num_heads=num_heads[1],
            expansion_ratio=expansion_ratios[1],
            spatial_reduction_ratio=(
                spatial_reduction_ratios[1]
            ),
            drop_path_probabilities=(
                stage_drop_paths[1]
            ),
        )

        self.stage3 = ContextTransformerStage(
            in_channels=embed_channels[1],
            embed_channels=embed_channels[2],
            patch_kernel_size=3,
            patch_stride=2,
            depth=depths[2],
            num_heads=num_heads[2],
            expansion_ratio=expansion_ratios[2],
            spatial_reduction_ratio=(
                spatial_reduction_ratios[2]
            ),
            drop_path_probabilities=(
                stage_drop_paths[2]
            ),
        )

        self.stage4 = ContextTransformerStage(
            in_channels=embed_channels[2],
            embed_channels=embed_channels[3],
            patch_kernel_size=3,
            patch_stride=2,
            depth=depths[3],
            num_heads=num_heads[3],
            expansion_ratio=expansion_ratios[3],
            spatial_reduction_ratio=(
                spatial_reduction_ratios[3]
            ),
            drop_path_probabilities=(
                stage_drop_paths[3]
            ),
        )

        self.out_channels = tuple(
            embed_channels
        )

        self.apply(
            self._initialize_weights
        )

    @staticmethod
    def _initialize_weights(
        module: nn.Module,
    ) -> None:
        if isinstance(module, nn.Linear):
            nn.init.trunc_normal_(
                module.weight,
                std=0.02,
            )

            if module.bias is not None:
                nn.init.zeros_(
                    module.bias
                )

        elif isinstance(module, nn.LayerNorm):
            nn.init.ones_(
                module.weight
            )

            nn.init.zeros_(
                module.bias
            )

        elif isinstance(module, nn.Conv2d):
            nn.init.kaiming_normal_(
                module.weight,
                mode="fan_out",
                nonlinearity="relu",
            )

            if module.bias is not None:
                nn.init.zeros_(
                    module.bias
                )

    def forward(
        self,
        x: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        stage1 = self.stage1(x)
        stage2 = self.stage2(stage1)
        stage3 = self.stage3(stage2)
        stage4 = self.stage4(stage3)

        return {
            "stage1": stage1,
            "stage2": stage2,
            "stage3": stage3,
            "stage4": stage4,
        }


if __name__ == "__main__":
    encoder = ContextTransformerEncoder()

    encoder.eval()

    test_input = torch.randn(
        1,
        3,
        512,
        512,
    )

    with torch.inference_mode():
        features = encoder(
            test_input
        )

    print(
        "Input:",
        tuple(test_input.shape),
    )

    for name, feature in features.items():
        print(
            f"{name:8s}",
            tuple(feature.shape),
        )