from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np


# ============================================================
# DEFAULTS
# ============================================================

PROJECT_ROOT = Path(
    r"C:\PROJECT\GeoMapPrototype\V2"
)

DEFAULT_INPUT_DIR = (
    PROJECT_ROOT
    / "outputs"
    / "compare_map0103"
    / "georegion"
    / "map_0103_color"
)

DEFAULT_OUTPUT_DIR = (
    PROJECT_ROOT
    / "outputs"
    / "georegion_vectorized"
    / "map_0103_color"
)


# ============================================================
# SETTINGS
# ============================================================

# Direct boundary head remains the primary source.
DIRECT_WEIGHT = 0.72
AFFINITY_WEIGHT = 0.28

# Hysteresis thresholds.
# Strong pixels start real boundary chains.
# Weak pixels survive only when connected to strong evidence.
STRONG_THRESHOLD = 0.48
WEAK_THRESHOLD = 0.25

# Remove very tiny isolated detections.
MIN_COMPONENT_AREA = 20

# Small-gap repair.
MAX_GAP_DISTANCE = 9

# Evidence required along a proposed gap.
MIN_GAP_SUPPORT = 0.32

# Direction consistency for endpoint joining.
MIN_DIRECTION_COSINE = 0.30

# Vector smoothing.
SMOOTH_WINDOW = 5
SMOOTH_PASSES = 2

# A smoothed point cannot move farther than this from
# its original chain point.
MAX_SMOOTH_MOVEMENT = 2.5

# Don't simplify tiny chains.
MIN_CHAIN_LENGTH = 6


# ============================================================
# FILE HELPERS
# ============================================================

def read_probability(path: Path) -> np.ndarray:
    image = cv2.imread(
        str(path),
        cv2.IMREAD_GRAYSCALE,
    )

    if image is None:
        raise FileNotFoundError(
            f"Could not read probability image: {path}"
        )

    return (
        image.astype(np.float32)
        / 255.0
    )


def read_bgr(path: Path) -> np.ndarray:
    image = cv2.imread(
        str(path),
        cv2.IMREAD_COLOR,
    )

    if image is None:
        raise FileNotFoundError(
            f"Could not read image: {path}"
        )

    return image


def save_probability(
    path: Path,
    probability: np.ndarray,
) -> None:

    image = np.clip(
        probability * 255.0,
        0,
        255,
    ).astype(np.uint8)

    if not cv2.imwrite(
        str(path),
        image,
    ):
        raise RuntimeError(
            f"Could not write {path}"
        )


def save_mask(
    path: Path,
    mask: np.ndarray,
) -> None:

    image = (
        (mask > 0)
        .astype(np.uint8)
        * 255
    )

    if not cv2.imwrite(
        str(path),
        image,
    ):
        raise RuntimeError(
            f"Could not write {path}"
        )


# ============================================================
# AFFINITY EVIDENCE
# ============================================================

def build_affinity_boundary(
    h_difference: np.ndarray,
    v_difference: np.ndarray,
) -> np.ndarray:

    result = np.zeros_like(
        h_difference,
        dtype=np.float32,
    )

    # Right relation.
    result = np.maximum(
        result,
        h_difference,
    )

    # Left relation.
    shifted = np.zeros_like(
        h_difference
    )

    shifted[:, 1:] = (
        h_difference[:, :-1]
    )

    result = np.maximum(
        result,
        shifted,
    )

    # Bottom relation.
    result = np.maximum(
        result,
        v_difference,
    )

    # Top relation.
    shifted = np.zeros_like(
        v_difference
    )

    shifted[1:, :] = (
        v_difference[:-1, :]
    )

    result = np.maximum(
        result,
        shifted,
    )

    return result


def build_supported_evidence(
    direct: np.ndarray,
    affinity: np.ndarray,
) -> np.ndarray:
    """
    Direct boundary is primary.

    Affinity can strengthen a weak direct signal,
    but cannot completely dominate it.
    """

    weighted = (
        DIRECT_WEIGHT * direct
        + AFFINITY_WEIGHT * affinity
    )

    # Allow strong affinity to rescue a weak direct contact,
    # but only partially.
    affinity_rescue = (
        0.60 * direct
        + 0.40 * affinity
    )

    result = np.maximum(
        weighted,
        affinity_rescue,
    )

    return np.clip(
        result,
        0.0,
        1.0,
    )


# ============================================================
# HYSTERESIS
# ============================================================

def hysteresis_boundary(
    evidence: np.ndarray,
) -> np.ndarray:
    """
    Strong evidence seeds boundary components.

    Weak evidence survives only when connected to a strong seed.
    This is similar in spirit to Canny hysteresis.
    """

    strong = (
        evidence >= STRONG_THRESHOLD
    ).astype(np.uint8)

    weak = (
        evidence >= WEAK_THRESHOLD
    ).astype(np.uint8)

    n, labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            weak,
            connectivity=8,
        )
    )

    output = np.zeros_like(
        weak,
        dtype=np.uint8,
    )

    for component in range(
        1,
        n,
    ):

        component_mask = (
            labels == component
        )

        area = int(
            stats[
                component,
                cv2.CC_STAT_AREA,
            ]
        )

        if area < MIN_COMPONENT_AREA:
            continue

        touches_strong = np.any(
            strong[component_mask] > 0
        )

        if not touches_strong:
            continue

        output[
            component_mask
        ] = 1

    return output


# ============================================================
# THINNING
# ============================================================

def zhang_suen_thinning(
    binary: np.ndarray,
) -> np.ndarray:

    img = (
        binary > 0
    ).astype(np.uint8)

    img = img.copy()

    changed = True

    while changed:

        changed = False

        for step in (
            0,
            1,
        ):

            p2 = np.roll(
                img,
                -1,
                axis=0,
            )

            p3 = np.roll(
                p2,
                -1,
                axis=1,
            )

            p4 = np.roll(
                img,
                -1,
                axis=1,
            )

            p5 = np.roll(
                np.roll(
                    img,
                    1,
                    axis=0,
                ),
                -1,
                axis=1,
            )

            p6 = np.roll(
                img,
                1,
                axis=0,
            )

            p7 = np.roll(
                p6,
                1,
                axis=1,
            )

            p8 = np.roll(
                img,
                1,
                axis=1,
            )

            p9 = np.roll(
                np.roll(
                    img,
                    -1,
                    axis=0,
                ),
                1,
                axis=1,
            )

            neighbors = (
                p2 + p3 + p4 + p5
                + p6 + p7 + p8 + p9
            )

            transitions = (
                ((p2 == 0) & (p3 == 1))
                + ((p3 == 0) & (p4 == 1))
                + ((p4 == 0) & (p5 == 1))
                + ((p5 == 0) & (p6 == 1))
                + ((p6 == 0) & (p7 == 1))
                + ((p7 == 0) & (p8 == 1))
                + ((p8 == 0) & (p9 == 1))
                + ((p9 == 0) & (p2 == 1))
            )

            if step == 0:

                c1 = (
                    p2 * p4 * p6
                ) == 0

                c2 = (
                    p4 * p6 * p8
                ) == 0

            else:

                c1 = (
                    p2 * p4 * p8
                ) == 0

                c2 = (
                    p2 * p6 * p8
                ) == 0

            remove = (
                (img == 1)
                & (neighbors >= 2)
                & (neighbors <= 6)
                & (transitions == 1)
                & c1
                & c2
            )

            remove[0, :] = False
            remove[-1, :] = False
            remove[:, 0] = False
            remove[:, -1] = False

            if np.any(remove):

                img[
                    remove
                ] = 0

                changed = True

    return img


# ============================================================
# GRAPH HELPERS
# ============================================================

NEIGHBOR_OFFSETS = (
    (-1, -1),
    (0, -1),
    (1, -1),

    (-1, 0),
    (1, 0),

    (-1, 1),
    (0, 1),
    (1, 1),
)


def skeleton_neighbors(
    skeleton: np.ndarray,
    x: int,
    y: int,
) -> list[tuple[int, int]]:

    h, w = skeleton.shape

    result = []

    for dx, dy in NEIGHBOR_OFFSETS:

        nx = x + dx
        ny = y + dy

        if (
            0 <= nx < w
            and 0 <= ny < h
            and skeleton[ny, nx] > 0
        ):
            result.append(
                (nx, ny)
            )

    return result


def degree_map(
    skeleton: np.ndarray,
) -> np.ndarray:

    kernel = np.ones(
        (3, 3),
        dtype=np.uint8,
    )

    count = cv2.filter2D(
        skeleton.astype(np.uint8),
        cv2.CV_16U,
        kernel,
        borderType=cv2.BORDER_CONSTANT,
    )

    count = (
        count
        - skeleton.astype(np.uint16)
    )

    return count


def endpoint_mask(
    skeleton: np.ndarray,
) -> np.ndarray:

    degree = degree_map(
        skeleton
    )

    return (
        (skeleton > 0)
        & (degree == 1)
    ).astype(np.uint8)


def junction_mask(
    skeleton: np.ndarray,
) -> np.ndarray:

    degree = degree_map(
        skeleton
    )

    return (
        (skeleton > 0)
        & (degree >= 3)
    ).astype(np.uint8)


# ============================================================
# ENDPOINT DIRECTION
# ============================================================

def endpoint_direction(
    skeleton: np.ndarray,
    point: tuple[int, int],
    max_steps: int = 6,
) -> np.ndarray | None:

    x0, y0 = point

    current = point
    previous = None

    path = [
        point
    ]

    for _ in range(
        max_steps
    ):

        neighbors = (
            skeleton_neighbors(
                skeleton,
                current[0],
                current[1],
            )
        )

        if previous is not None:

            neighbors = [
                p
                for p in neighbors
                if p != previous
            ]

        if len(neighbors) != 1:
            break

        next_point = (
            neighbors[0]
        )

        path.append(
            next_point
        )

        previous = current
        current = next_point

    if len(path) < 2:
        return None

    x1, y1 = path[-1]

    vector = np.array(
        [
            float(x0 - x1),
            float(y0 - y1),
        ],
        dtype=np.float32,
    )

    norm = float(
        np.linalg.norm(vector)
    )

    if norm < 1e-6:
        return None

    return (
        vector / norm
    )


# ============================================================
# GAP SUPPORT
# ============================================================

def sample_line(
    p1: tuple[int, int],
    p2: tuple[int, int],
) -> tuple[np.ndarray, np.ndarray]:

    x1, y1 = p1
    x2, y2 = p2

    count = (
        max(
            abs(x2 - x1),
            abs(y2 - y1),
        )
        + 1
    )

    xs = np.rint(
        np.linspace(
            x1,
            x2,
            count,
        )
    ).astype(np.int32)

    ys = np.rint(
        np.linspace(
            y1,
            y2,
            count,
        )
    ).astype(np.int32)

    return xs, ys


def line_support(
    evidence: np.ndarray,
    p1: tuple[int, int],
    p2: tuple[int, int],
) -> float:

    xs, ys = sample_line(
        p1,
        p2,
    )

    h, w = evidence.shape

    values = []

    for x, y in zip(
        xs,
        ys,
    ):

        x0 = max(
            0,
            x - 1,
        )

        x1 = min(
            w,
            x + 2,
        )

        y0 = max(
            0,
            y - 1,
        )

        y1 = min(
            h,
            y + 2,
        )

        values.append(
            float(
                evidence[
                    y0:y1,
                    x0:x1,
                ].max()
            )
        )

    if not values:
        return 0.0

    return float(
        np.mean(values)
    )


# ============================================================
# GAP REPAIR
# ============================================================

def repair_supported_gaps(
    skeleton: np.ndarray,
    evidence: np.ndarray,
) -> tuple[np.ndarray, list[dict]]:

    result = skeleton.copy()

    endpoints = endpoint_mask(
        skeleton
    )

    ys, xs = np.where(
        endpoints > 0
    )

    points = [
        (
            int(x),
            int(y),
        )
        for x, y in zip(
            xs,
            ys,
        )
    ]

    proposals = []

    max_distance_sq = (
        MAX_GAP_DISTANCE
        * MAX_GAP_DISTANCE
    )

    for i in range(
        len(points)
    ):

        p1 = points[i]

        d1 = endpoint_direction(
            skeleton,
            p1,
        )

        if d1 is None:
            continue

        for j in range(
            i + 1,
            len(points),
        ):

            p2 = points[j]

            dx = (
                p2[0]
                - p1[0]
            )

            dy = (
                p2[1]
                - p1[1]
            )

            distance_sq = (
                dx * dx
                + dy * dy
            )

            if (
                distance_sq <= 1
                or distance_sq
                > max_distance_sq
            ):
                continue

            vector = np.array(
                [
                    float(dx),
                    float(dy),
                ],
                dtype=np.float32,
            )

            distance = float(
                np.linalg.norm(
                    vector
                )
            )

            if distance < 1e-6:
                continue

            direction = (
                vector
                / distance
            )

            d2 = endpoint_direction(
                skeleton,
                p2,
            )

            if d2 is None:
                continue

            alignment_1 = float(
                np.dot(
                    d1,
                    direction,
                )
            )

            alignment_2 = float(
                np.dot(
                    d2,
                    -direction,
                )
            )

            if (
                alignment_1
                < MIN_DIRECTION_COSINE
                or alignment_2
                < MIN_DIRECTION_COSINE
            ):
                continue

            support = line_support(
                evidence,
                p1,
                p2,
            )

            if (
                support
                < MIN_GAP_SUPPORT
            ):
                continue

            proposals.append(
                {
                    "i": i,
                    "j": j,
                    "p1": p1,
                    "p2": p2,
                    "distance": distance,
                    "support": support,
                    "alignment_1": (
                        alignment_1
                    ),
                    "alignment_2": (
                        alignment_2
                    ),
                }
            )

    proposals.sort(
        key=lambda item: (
            -item[
                "support"
            ],
            item[
                "distance"
            ],
        )
    )

    used = set()
    accepted = []

    for proposal in proposals:

        i = proposal[
            "i"
        ]

        j = proposal[
            "j"
        ]

        if (
            i in used
            or j in used
        ):
            continue

        cv2.line(
            result,
            proposal[
                "p1"
            ],
            proposal[
                "p2"
            ],
            1,
            thickness=1,
            lineType=cv2.LINE_8,
        )

        used.add(
            i
        )

        used.add(
            j
        )

        accepted.append(
            proposal
        )

    result = zhang_suen_thinning(
        result
    )

    return (
        result,
        accepted,
    )


# ============================================================
# CHAIN TRACING
# ============================================================

def canonical_edge(
    a: tuple[int, int],
    b: tuple[int, int],
):
    return (
        (a, b)
        if a <= b
        else (b, a)
    )


def trace_chains(
    skeleton: np.ndarray,
) -> list[list[tuple[int, int]]]:

    degree = degree_map(
        skeleton
    )

    ys, xs = np.where(
        skeleton > 0
    )

    pixels = set(
        (
            int(x),
            int(y),
        )
        for x, y in zip(
            xs,
            ys,
        )
    )

    nodes = {
        point
        for point in pixels
        if degree[
            point[1],
            point[0],
        ] != 2
    }

    visited_edges = set()

    chains = []

    # --------------------------------------------------------
    # Chains starting at endpoints / junctions
    # --------------------------------------------------------

    for start in nodes:

        for neighbor in skeleton_neighbors(
            skeleton,
            start[0],
            start[1],
        ):

            edge = canonical_edge(
                start,
                neighbor,
            )

            if edge in visited_edges:
                continue

            chain = [
                start,
            ]

            previous = start
            current = neighbor

            visited_edges.add(
                edge
            )

            while True:

                chain.append(
                    current
                )

                if (
                    current in nodes
                    and current != start
                ):
                    break

                neighbors = (
                    skeleton_neighbors(
                        skeleton,
                        current[0],
                        current[1],
                    )
                )

                neighbors = [
                    point
                    for point in neighbors
                    if point != previous
                ]

                next_point = None

                for candidate in neighbors:

                    candidate_edge = (
                        canonical_edge(
                            current,
                            candidate,
                        )
                    )

                    if (
                        candidate_edge
                        not in visited_edges
                    ):
                        next_point = (
                            candidate
                        )
                        break

                if next_point is None:
                    break

                visited_edges.add(
                    canonical_edge(
                        current,
                        next_point,
                    )
                )

                previous = current
                current = next_point

            if (
                len(chain)
                >= MIN_CHAIN_LENGTH
            ):
                chains.append(
                    chain
                )

    # --------------------------------------------------------
    # Closed loops with no endpoint/junction
    # --------------------------------------------------------

    for start in pixels:

        neighbors = (
            skeleton_neighbors(
                skeleton,
                start[0],
                start[1],
            )
        )

        for neighbor in neighbors:

            edge = canonical_edge(
                start,
                neighbor,
            )

            if edge in visited_edges:
                continue

            chain = [
                start,
            ]

            previous = start
            current = neighbor

            visited_edges.add(
                edge
            )

            while True:

                chain.append(
                    current
                )

                neighbors_current = (
                    skeleton_neighbors(
                        skeleton,
                        current[0],
                        current[1],
                    )
                )

                neighbors_current = [
                    point
                    for point
                    in neighbors_current
                    if point != previous
                ]

                next_point = None

                for candidate in neighbors_current:

                    candidate_edge = (
                        canonical_edge(
                            current,
                            candidate,
                        )
                    )

                    if (
                        candidate_edge
                        not in visited_edges
                    ):
                        next_point = (
                            candidate
                        )
                        break

                if next_point is None:
                    break

                visited_edges.add(
                    canonical_edge(
                        current,
                        next_point,
                    )
                )

                previous = current
                current = next_point

                if current == start:
                    chain.append(
                        start
                    )
                    break

            if (
                len(chain)
                >= MIN_CHAIN_LENGTH
            ):
                chains.append(
                    chain
                )

    return chains


# ============================================================
# CONSTRAINED SMOOTHING
# ============================================================

def moving_average_points(
    points: np.ndarray,
    window: int,
) -> np.ndarray:

    if (
        len(points)
        < window
        or window < 3
    ):
        return (
            points.copy()
        )

    half = (
        window // 2
    )

    result = (
        points.copy()
    )

    for i in range(
        half,
        len(points) - half,
    ):

        neighborhood = points[
            i - half:
            i + half + 1
        ]

        result[i] = (
            neighborhood.mean(
                axis=0
            )
        )

    return result


def constrained_smooth_chain(
    chain: list[
        tuple[int, int]
    ],
) -> np.ndarray:

    original = np.asarray(
        chain,
        dtype=np.float32,
    )

    smoothed = (
        original.copy()
    )

    for _ in range(
        SMOOTH_PASSES
    ):

        candidate = (
            moving_average_points(
                smoothed,
                SMOOTH_WINDOW,
            )
        )

        displacement = (
            candidate
            - original
        )

        distance = np.linalg.norm(
            displacement,
            axis=1,
            keepdims=True,
        )

        scale = np.minimum(
            1.0,
            MAX_SMOOTH_MOVEMENT
            / np.maximum(
                distance,
                1e-6,
            ),
        )

        smoothed = (
            original
            + displacement
            * scale
        )

        # Preserve chain endpoints exactly.
        smoothed[0] = (
            original[0]
        )

        smoothed[-1] = (
            original[-1]
        )

    return smoothed


# ============================================================
# RASTERIZE SMOOTH CHAINS
# ============================================================

def rasterize_chains(
    chains: list[
        list[
            tuple[int, int]
        ]
    ],
    shape: tuple[int, int],
) -> tuple[
    np.ndarray,
    list[np.ndarray],
]:

    output = np.zeros(
        shape,
        dtype=np.uint8,
    )

    smoothed_chains = []

    for chain in chains:

        smoothed = (
            constrained_smooth_chain(
                chain
            )
        )

        smoothed_chains.append(
            smoothed
        )

        points = np.rint(
            smoothed
        ).astype(
            np.int32
        )

        if (
            len(points)
            < 2
        ):
            continue

        cv2.polylines(
            output,
            [
                points.reshape(
                    -1,
                    1,
                    2,
                )
            ],
            isClosed=False,
            color=1,
            thickness=1,
            lineType=cv2.LINE_AA,
        )

    # LINE_AA can create intensity >1.
    output = (
        output > 0
    ).astype(np.uint8)

    output = (
        zhang_suen_thinning(
            output
        )
    )

    return (
        output,
        smoothed_chains,
    )


# ============================================================
# OVERLAYS
# ============================================================

def make_overlay(
    original: np.ndarray,
    boundary: np.ndarray,
    junctions: np.ndarray | None = None,
) -> np.ndarray:

    overlay = (
        original.copy()
    )

    # Final geological contact = green.
    overlay[
        boundary > 0
    ] = (
        0,
        255,
        0,
    )

    # Junctions = red dots only.
    #
    # Red is deliberately NOT used as the geological
    # boundary itself.
    if junctions is not None:

        ys, xs = np.where(
            junctions > 0
        )

        for x, y in zip(
            xs,
            ys,
        ):

            cv2.circle(
                overlay,
                (
                    int(x),
                    int(y),
                ),
                2,
                (
                    0,
                    0,
                    255,
                ),
                -1,
            )

    return overlay


# ============================================================
# GEOJSON
# ============================================================

def save_geojson(
    path: Path,
    chains: list[np.ndarray],
) -> None:

    features = []

    for index, chain in enumerate(
        chains,
        start=1,
    ):

        if len(chain) < 2:
            continue

        coordinates = [
            [
                float(point[0]),
                float(point[1]),
            ]
            for point in chain
        ]

        feature = {
            "type": "Feature",
            "properties": {
                "id": int(index),
                "type": (
                    "geological_contact"
                ),
            },
            "geometry": {
                "type": "LineString",
                "coordinates": (
                    coordinates
                ),
            },
        }

        features.append(
            feature
        )

    collection = {
        "type": "FeatureCollection",
        "features": features,
    }

    path.write_text(
        json.dumps(
            collection,
            indent=2,
        ),
        encoding="utf-8",
    )


# ============================================================
# MAIN
# ============================================================

def main() -> None:

    parser = argparse.ArgumentParser(
        description=(
            "Convert GeoRegion probability maps into "
            "continuous, constrained, smoothed geological "
            "boundary vectors."
        )
    )

    parser.add_argument(
        "--input-dir",
        type=Path,
        default=DEFAULT_INPUT_DIR,
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
    )

    args = parser.parse_args()

    input_dir = (
        args.input_dir
    )

    output_dir = (
        args.output_dir
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    original = read_bgr(
        input_dir
        / "original.png"
    )

    direct_probability = (
        read_probability(
            input_dir
            / "boundary_probability.png"
        )
    )

    h_difference = (
        read_probability(
            input_dir
            / "affinity_h_different_probability.png"
        )
    )

    v_difference = (
        read_probability(
            input_dir
            / "affinity_v_different_probability.png"
        )
    )

    if not (
        direct_probability.shape
        == h_difference.shape
        == v_difference.shape
        == original.shape[:2]
    ):
        raise RuntimeError(
            "Input probability/image dimensions do not match."
        )

    print("=" * 72)
    print("GeoRegion topology/vector smoothing")
    print("Input:", input_dir)
    print("Shape:", direct_probability.shape)
    print("Strong threshold:", STRONG_THRESHOLD)
    print("Weak threshold:", WEAK_THRESHOLD)
    print("Maximum supported gap:", MAX_GAP_DISTANCE)
    print("Maximum smoothing movement:", MAX_SMOOTH_MOVEMENT)
    print("=" * 72)

    # ========================================================
    # 01 AFFINITY BOUNDARY
    # ========================================================

    affinity_boundary = (
        build_affinity_boundary(
            h_difference,
            v_difference,
        )
    )

    save_probability(
        output_dir
        / "01_affinity_boundary_probability.png",
        affinity_boundary,
    )

    # ========================================================
    # 02 FUSED EVIDENCE
    # ========================================================

    evidence = (
        build_supported_evidence(
            direct_probability,
            affinity_boundary,
        )
    )

    save_probability(
        output_dir
        / "02_supported_evidence.png",
        evidence,
    )

    # ========================================================
    # 03 HYSTERESIS BOUNDARY
    # ========================================================

    supported = (
        hysteresis_boundary(
            evidence
        )
    )

    save_mask(
        output_dir
        / "03_supported_boundary.png",
        supported,
    )

    # ========================================================
    # 04 ONE-PIXEL TOPOLOGY
    # ========================================================

    skeleton = (
        zhang_suen_thinning(
            supported
        )
    )

    save_mask(
        output_dir
        / "04_skeleton_before_gap_repair.png",
        skeleton,
    )

    # ========================================================
    # 05 SUPPORTED GAP REPAIR
    # ========================================================

    (
        connected,
        accepted_connections,
    ) = repair_supported_gaps(
        skeleton,
        evidence,
    )

    save_mask(
        output_dir
        / "05_connected_boundary.png",
        connected,
    )

    # ========================================================
    # 06 TOPOLOGY BEFORE SMOOTHING
    # ========================================================

    junctions_before = (
        junction_mask(
            connected
        )
    )

    endpoints_before = (
        endpoint_mask(
            connected
        )
    )

    save_mask(
        output_dir
        / "06_junctions_before_smoothing.png",
        junctions_before,
    )

    save_mask(
        output_dir
        / "07_endpoints_before_smoothing.png",
        endpoints_before,
    )

    # ========================================================
    # 07 TRACE + SMOOTH CHAINS
    # ========================================================

    chains = trace_chains(
        connected
    )

    (
        smoothed_boundary,
        smoothed_chains,
    ) = rasterize_chains(
        chains,
        connected.shape,
    )

    save_mask(
        output_dir
        / "08_smoothed_boundary.png",
        smoothed_boundary,
    )

    # ========================================================
    # 08 FINAL TOPOLOGY
    # ========================================================

    final_junctions = (
        junction_mask(
            smoothed_boundary
        )
    )

    final_endpoints = (
        endpoint_mask(
            smoothed_boundary
        )
    )

    save_mask(
        output_dir
        / "09_final_junctions.png",
        final_junctions,
    )

    save_mask(
        output_dir
        / "10_final_endpoints.png",
        final_endpoints,
    )

    # ========================================================
    # 09 OVERLAYS
    # ========================================================

    connected_overlay = (
        make_overlay(
            original,
            connected,
            junctions_before,
        )
    )

    cv2.imwrite(
        str(
            output_dir
            / "11_connected_overlay.png"
        ),
        connected_overlay,
    )

    final_overlay = (
        make_overlay(
            original,
            smoothed_boundary,
            final_junctions,
        )
    )

    cv2.imwrite(
        str(
            output_dir
            / "12_smoothed_overlay.png"
        ),
        final_overlay,
    )

    # ========================================================
    # GEOJSON
    # ========================================================

    save_geojson(
        output_dir
        / "boundaries.geojson",
        smoothed_chains,
    )

    # ========================================================
    # REPORT
    # ========================================================

    report = {
        "input_directory": (
            str(input_dir)
        ),

        "shape": [
            int(
                direct_probability.shape[0]
            ),
            int(
                direct_probability.shape[1]
            ),
        ],

        "settings": {
            "direct_weight": DIRECT_WEIGHT,
            "affinity_weight": AFFINITY_WEIGHT,

            "strong_threshold": STRONG_THRESHOLD,
            "weak_threshold": WEAK_THRESHOLD,

            "minimum_component_area": MIN_COMPONENT_AREA,

            "maximum_gap_distance": MAX_GAP_DISTANCE,
            "minimum_gap_support": MIN_GAP_SUPPORT,

            "smooth_window": SMOOTH_WINDOW,
            "smooth_passes": SMOOTH_PASSES,

            "maximum_smooth_movement": (
                MAX_SMOOTH_MOVEMENT
            ),
        },

        "supported_boundary_pixels": int(
            supported.sum()
        ),

        "skeleton_pixels": int(
            skeleton.sum()
        ),

        "connected_boundary_pixels": int(
            connected.sum()
        ),

        "smoothed_boundary_pixels": int(
            smoothed_boundary.sum()
        ),

        "endpoints_before": int(
            endpoints_before.sum()
        ),

        "junction_pixels_before": int(
            junctions_before.sum()
        ),

        "final_endpoints": int(
            final_endpoints.sum()
        ),

        "final_junction_pixels": int(
            final_junctions.sum()
        ),

        "chains": int(
            len(chains)
        ),

        "accepted_gap_connections": [
            {
                "p1": list(
                    item["p1"]
                ),

                "p2": list(
                    item["p2"]
                ),

                "distance": float(
                    item["distance"]
                ),

                "support": float(
                    item["support"]
                ),

                "alignment_1": float(
                    item["alignment_1"]
                ),

                "alignment_2": float(
                    item["alignment_2"]
                ),
            }

            for item
            in accepted_connections
        ],
    }

    (
        output_dir
        / "run_report.json"
    ).write_text(
        json.dumps(
            report,
            indent=2,
        ),
        encoding="utf-8",
    )

    print()
    print(
        "Supported boundary pixels:",
        int(
            supported.sum()
        ),
    )

    print(
        "Endpoints before repair:",
        int(
            endpoint_mask(
                skeleton
            ).sum()
        ),
    )

    print(
        "Accepted gap connections:",
        len(
            accepted_connections
        ),
    )

    print(
        "Chains traced:",
        len(
            chains
        ),
    )

    print(
        "Final endpoints:",
        int(
            final_endpoints.sum()
        ),
    )

    print(
        "Final junction pixels:",
        int(
            final_junctions.sum()
        ),
    )

    print()
    print(
        "GeoJSON:",
        output_dir
        / "boundaries.geojson",
    )

    print(
        "Output:",
        output_dir,
    )

    print("=" * 72)


if __name__ == "__main__":
    main()