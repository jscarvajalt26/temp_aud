"""
GeoRegion exact label-interface topology vectorizer.

Builds geological boundaries directly on pixel-cell interfaces from region_labels.npy.
No raster contact-band skeletonization is used for geometry.

Internal contacts:
    neighboring valid pixels with different labels -> exact shared cell edge.

Outer boundary:
    valid map pixel next to invalid/outside -> exact cell edge.

The resulting edge graph is assembled into label-pair-aware polylines. Junctions are
preserved exactly. Optional Douglas-Peucker simplification is constrained by a maximum
distance from the original exact interface, so smoothing cannot wander into units.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np


Point = tuple[int, int]       # doubled pixel-corner coordinates
Edge = tuple[Point, Point]
Pair = tuple[int, int]


def read_gray(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return img


def read_color(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return img


def save_binary(path: Path, mask: np.ndarray) -> None:
    cv2.imwrite(str(path), mask.astype(np.uint8) * 255)


def edge_key(a: Point, b: Point) -> Edge:
    return (a, b) if a <= b else (b, a)


def euclidean(a, b) -> float:
    return math.hypot(float(a[0] - b[0]), float(a[1] - b[1]))


def doubled_to_xy(points: list[Point] | np.ndarray) -> np.ndarray:
    arr = np.asarray(points, dtype=np.float32)
    return arr / 2.0


def polyline_length(points: np.ndarray) -> float:
    if len(points) < 2:
        return 0.0
    d = np.diff(points, axis=0)
    return float(np.sqrt((d * d).sum(axis=1)).sum())


# ---------------------------------------------------------------------
# 1. EXACT CELL-INTERFACE EDGES
# ---------------------------------------------------------------------

def build_exact_edges(
    labels: np.ndarray,
    map_mask: np.ndarray,
):
    """
    Return:
      internal_by_pair: {(label_a,label_b): set((p0,p1), ...)}
      outer_edges: set((p0,p1), ...)

    Coordinates are stored at 2x scale so half-pixel cell interfaces are exact
    integers. A pixel centered at (x,y) occupies:
        x-0.5 .. x+0.5
        y-0.5 .. y+0.5
    """

    if labels.shape != map_mask.shape:
        raise ValueError("labels and map_mask shapes differ")

    h, w = labels.shape
    valid = labels >= 0
    invalid = (~valid).astype(np.uint8)

    _, bg_labels = cv2.connectedComponents(
        invalid,
        connectivity=8,
    )

    border_ids = set()
    border_ids.update(np.unique(bg_labels[0, :]).tolist())
    border_ids.update(np.unique(bg_labels[-1, :]).tolist())
    border_ids.update(np.unique(bg_labels[:, 0]).tolist())
    border_ids.update(np.unique(bg_labels[:, -1]).tolist())
    border_ids.discard(0)

    exterior = np.isin(bg_labels, list(border_ids))

    internal_by_pair: dict[Pair, set[Edge]] = defaultdict(set)
    outer_edges: set[Edge] = set()

    # Internal vertical interfaces: left/right neighboring pixels differ.
    ys, xs = np.nonzero(
        valid[:, :-1]
        & valid[:, 1:]
        & (labels[:, :-1] != labels[:, 1:])
    )
    for y, x in zip(ys.tolist(), xs.tolist()):
        a = int(labels[y, x])
        b = int(labels[y, x + 1])
        pair = (a, b) if a < b else (b, a)

        # x+0.5, from y-0.5 to y+0.5, doubled.
        p0 = (2 * x + 1, 2 * y - 1)
        p1 = (2 * x + 1, 2 * y + 1)
        internal_by_pair[pair].add(edge_key(p0, p1))

    # Internal horizontal interfaces: upper/lower neighboring pixels differ.
    ys, xs = np.nonzero(
        valid[:-1, :]
        & valid[1:, :]
        & (labels[:-1, :] != labels[1:, :])
    )
    for y, x in zip(ys.tolist(), xs.tolist()):
        a = int(labels[y, x])
        b = int(labels[y + 1, x])
        pair = (a, b) if a < b else (b, a)

        # y+0.5, from x-0.5 to x+0.5, doubled.
        p0 = (2 * x - 1, 2 * y + 1)
        p1 = (2 * x + 1, 2 * y + 1)
        internal_by_pair[pair].add(edge_key(p0, p1))

    # Outer cell edges. These are derived from valid-vs-invalid adjacency,
    # including the image border itself.
    ys, xs = np.nonzero(valid)
    for y, x in zip(ys.tolist(), xs.tolist()):
        left_invalid = (
            x == 0
            or exterior[y, x - 1]
        )

        right_invalid = (
            x == w - 1
            or exterior[y, x + 1]
        )

        up_invalid = (
            y == 0
            or exterior[y - 1, x]
        )

        down_invalid = (
            y == h - 1
            or exterior[y + 1, x]
        )

        if left_invalid:
            outer_edges.add(edge_key(
                (2 * x - 1, 2 * y - 1),
                (2 * x - 1, 2 * y + 1),
            ))
        if right_invalid:
            outer_edges.add(edge_key(
                (2 * x + 1, 2 * y - 1),
                (2 * x + 1, 2 * y + 1),
            ))
        if up_invalid:
            outer_edges.add(edge_key(
                (2 * x - 1, 2 * y - 1),
                (2 * x + 1, 2 * y - 1),
            ))
        if down_invalid:
            outer_edges.add(edge_key(
                (2 * x - 1, 2 * y + 1),
                (2 * x + 1, 2 * y + 1),
            ))

    return internal_by_pair, outer_edges


# ---------------------------------------------------------------------
# 2. EDGE GRAPH -> CONTINUOUS CHAINS
# ---------------------------------------------------------------------

def build_adjacency(edges: set[Edge]):
    adj: dict[Point, set[Point]] = defaultdict(set)
    for a, b in edges:
        adj[a].add(b)
        adj[b].add(a)
    return adj


def trace_edge_graph(edges: set[Edge]) -> list[list[Point]]:
    """
    Trace every graph edge exactly once.

    Chains start at degree != 2 vertices, preserving endpoints and junctions.
    Remaining degree-2 components are closed loops.
    """
    if not edges:
        return []

    adj = build_adjacency(edges)
    used: set[Edge] = set()
    chains: list[list[Point]] = []

    def walk(start: Point, nxt: Point) -> list[Point]:
        chain = [start, nxt]
        used.add(edge_key(start, nxt))
        prev, cur = start, nxt

        while True:
            if len(adj[cur]) != 2:
                break

            candidates = [
                q for q in adj[cur]
                if q != prev and edge_key(cur, q) not in used
            ]
            if len(candidates) != 1:
                break

            q = candidates[0]
            used.add(edge_key(cur, q))
            chain.append(q)
            prev, cur = cur, q

            if cur == start:
                break

        return chain

    # Open chains and junction branches.
    for node in sorted(adj):
        if len(adj[node]) == 2:
            continue
        for nxt in sorted(adj[node]):
            e = edge_key(node, nxt)
            if e not in used:
                chains.append(walk(node, nxt))

    # Closed loops.
    for a, b in sorted(edges):
        e = edge_key(a, b)
        if e not in used:
            chains.append(walk(a, b))

    return [c for c in chains if len(c) >= 2]


def graph_nodes(edges: set[Edge]) -> set[Point]:
    adj = build_adjacency(edges)
    return {p for p, n in adj.items() if len(n) != 2}


# ---------------------------------------------------------------------
# 3. CONSTRAINED VECTOR SIMPLIFICATION
# ---------------------------------------------------------------------

def point_segment_distance(p, a, b) -> float:
    p = np.asarray(p, dtype=np.float64)
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    ab = b - a
    denom = float(np.dot(ab, ab))
    if denom <= 1e-12:
        return float(np.linalg.norm(p - a))
    t = float(np.dot(p - a, ab) / denom)
    t = max(0.0, min(1.0, t))
    q = a + t * ab
    return float(np.linalg.norm(p - q))


def directed_polyline_distance(samples: np.ndarray, candidate: np.ndarray) -> float:
    """
    Maximum distance from exact sample points to candidate polyline.
    Conservative and intentionally one-sided: candidate must represent all exact
    interface support without cutting substantially across it.
    """
    if len(samples) == 0 or len(candidate) < 2:
        return float("inf")

    max_d = 0.0
    for p in samples:
        d = min(
            point_segment_distance(p, candidate[i], candidate[i + 1])
            for i in range(len(candidate) - 1)
        )
        max_d = max(max_d, d)
    return max_d


def simplify_constrained(
    exact_points: np.ndarray,
    epsilon: float,
    max_deviation: float,
) -> np.ndarray:
    """
    Douglas-Peucker simplification accepted only if it remains within a strict
    corridor around the exact interface. Endpoints are never moved.
    """
    if len(exact_points) <= 2 or epsilon <= 0:
        return exact_points.copy()

    contour = exact_points.reshape(-1, 1, 2).astype(np.float32)
    approx = cv2.approxPolyDP(contour, float(epsilon), closed=False).reshape(-1, 2)

    if len(approx) < 2:
        return exact_points.copy()

    approx[0] = exact_points[0]
    approx[-1] = exact_points[-1]

    if directed_polyline_distance(exact_points, approx) <= max_deviation:
        return approx

    # Back off progressively instead of accepting geometry that cuts corners.
    eps = float(epsilon) * 0.5
    while eps >= 0.05:
        candidate = cv2.approxPolyDP(
            contour, eps, closed=False
        ).reshape(-1, 2)
        candidate[0] = exact_points[0]
        candidate[-1] = exact_points[-1]

        if directed_polyline_distance(exact_points, candidate) <= max_deviation:
            return candidate
        eps *= 0.5

    return exact_points.copy()


def process_chain(
    chain: list[Point],
    simplify_epsilon: float,
    max_deviation: float,
    min_simplify_length: float,
) -> np.ndarray:
    exact = doubled_to_xy(chain)

    # Closed loops: preserve closure exactly.
    closed = len(chain) >= 3 and chain[0] == chain[-1]

    if polyline_length(exact) < min_simplify_length:
        return exact

    out = simplify_constrained(
        exact,
        epsilon=simplify_epsilon,
        max_deviation=max_deviation,
    )

    out[0] = exact[0]
    out[-1] = exact[-1]

    if closed:
        out[-1] = out[0]

    return out


# ---------------------------------------------------------------------
# 4. RASTER PREVIEWS
# ---------------------------------------------------------------------

def rasterize_polylines(shape, polylines, thickness=1) -> np.ndarray:
    canvas = np.zeros(shape, dtype=np.uint8)
    for points in polylines:
        if len(points) < 2:
            continue

        # shift=1 means integer coordinates represent halves of pixels.
        pts2 = np.round(points * 2.0).astype(np.int32)
        cv2.polylines(
            canvas,
            [pts2.reshape(-1, 1, 2)],
            isClosed=False,
            color=255,
            thickness=thickness,
            lineType=cv2.LINE_8,
            shift=1,
        )
    return canvas > 0


def make_overlay(
    original: np.ndarray,
    internal: np.ndarray,
    outer: np.ndarray,
) -> np.ndarray:
    overlay = original.copy()
    overlay[internal] = (0, 255, 0)       # internal: green
    overlay[outer] = (255, 255, 0)       # outer: cyan
    return overlay


# ---------------------------------------------------------------------
# 5. GEOJSON
# ---------------------------------------------------------------------

def feature_for_polyline(
    points: np.ndarray,
    boundary_id: int,
    boundary_type: str,
    label_pair=None,
):
    props = {
        "boundary_id": int(boundary_id),
        "boundary_type": boundary_type,
        "coordinate_space": "pixel",
    }
    if label_pair is not None:
        props["label_a"] = int(label_pair[0])
        props["label_b"] = int(label_pair[1])

    return {
        "type": "Feature",
        "properties": props,
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [float(x), float(y)] for x, y in points
            ],
        },
    }


# ---------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------

def run(
    input_dir: Path,
    output_dir: Path,
    original_path: Path | None = None,
    simplify_epsilon: float = 0.65,
    max_deviation: float = 0.75,
    min_simplify_length: float = 8.0,
):
    output_dir.mkdir(parents=True, exist_ok=True)

    labels_path = input_dir / "region_labels.npy"
    topology_mask_path = input_dir / "03b_topology_map_mask.png"
    legacy_mask_path = input_dir / "03_map_mask.png"

    if topology_mask_path.exists():
        mask_path = topology_mask_path
    elif legacy_mask_path.exists():
        mask_path = legacy_mask_path
    else:
        raise FileNotFoundError(
            "Could not find geological map mask. Expected either "
            f"{topology_mask_path.name} or {legacy_mask_path.name} "
            f"in {input_dir}"
        )
    if original_path is None:
        original_path = input_dir / "01_original.png"

    print("=" * 72)
    print("GeoRegion exact label-interface vectorizer")
    print("Input:", input_dir)
    print("Output:", output_dir)
    print("=" * 72)

    labels = np.load(labels_path)
    map_mask = read_gray(mask_path) > 0
    original = read_color(original_path)

    if labels.shape != map_mask.shape:
        raise ValueError(
            f"labels shape {labels.shape} != mask shape {map_mask.shape}"
        )
    if original.shape[:2] != labels.shape:
        raise ValueError(
            f"original shape {original.shape[:2]} != labels shape {labels.shape}"
        )

    valid = labels >= 0

    print("Shape:", labels.shape)
    print("Valid labels:", np.unique(labels[valid]).tolist())

    internal_by_pair, outer_edges = build_exact_edges(labels, map_mask)

    all_internal_edges: set[Edge] = set()
    for edges in internal_by_pair.values():
        all_internal_edges.update(edges)

    print("Internal label pairs:", len(internal_by_pair))
    print("Exact internal edges:", len(all_internal_edges))
    print("Exact outer edges:", len(outer_edges))

    # Diagnostic exact raster.
    exact_internal_chains = trace_edge_graph(all_internal_edges)
    exact_internal_xy = [doubled_to_xy(c) for c in exact_internal_chains]
    exact_internal_raster = rasterize_polylines(
        labels.shape, exact_internal_xy, thickness=1
    )
    save_binary(output_dir / "01_exact_internal_interfaces.png", exact_internal_raster)

    exact_outer_chains = trace_edge_graph(outer_edges)
    exact_outer_xy = [doubled_to_xy(c) for c in exact_outer_chains]
    exact_outer_raster = rasterize_polylines(
        labels.shape, exact_outer_xy, thickness=1
    )
    save_binary(output_dir / "02_exact_outer_boundary.png", exact_outer_raster)

    # Pair-aware tracing is critical: contacts belonging to different geological
    # unit pairs are never accidentally merged at crossings/junctions.
    internal_records = []
    internal_polylines = []

    for pair in sorted(internal_by_pair):
        pair_edges = internal_by_pair[pair]
        chains = trace_edge_graph(pair_edges)

        for chain in chains:
            points = process_chain(
                chain,
                simplify_epsilon=simplify_epsilon,
                max_deviation=max_deviation,
                min_simplify_length=min_simplify_length,
            )
            if len(points) >= 2:
                internal_records.append((pair, points))
                internal_polylines.append(points)

    # Outer boundary is simplified under the same strict corridor.
    outer_polylines = []
    for chain in exact_outer_chains:
        points = process_chain(
            chain,
            simplify_epsilon=simplify_epsilon,
            max_deviation=max_deviation,
            min_simplify_length=min_simplify_length,
        )
        if len(points) >= 2:
            outer_polylines.append(points)

    internal_raster = rasterize_polylines(
        labels.shape, internal_polylines, thickness=1
    )
    outer_raster = rasterize_polylines(
        labels.shape, outer_polylines, thickness=1
    )

    save_binary(output_dir / "03_vector_internal_boundary.png", internal_raster)
    save_binary(output_dir / "04_vector_outer_boundary.png", outer_raster)

    final_boundary = internal_raster | outer_raster
    save_binary(output_dir / "05_final_boundary.png", final_boundary)

    overlay = make_overlay(original, internal_raster, outer_raster)
    cv2.imwrite(str(output_dir / "06_overlay.png"), overlay)

    # GeoJSON includes BOTH internal and outer boundaries.
    features = []
    boundary_id = 0

    for pair, points in internal_records:
        features.append(feature_for_polyline(
            points,
            boundary_id=boundary_id,
            boundary_type="internal_contact",
            label_pair=pair,
        ))
        boundary_id += 1

    for points in outer_polylines:
        features.append(feature_for_polyline(
            points,
            boundary_id=boundary_id,
            boundary_type="outer_map_boundary",
        ))
        boundary_id += 1

    geojson = {
        "type": "FeatureCollection",
        "features": features,
    }

    geojson_path = output_dir / "boundaries.geojson"
    geojson_path.write_text(
        json.dumps(geojson, indent=2),
        encoding="utf-8",
    )

    # Junction diagnostics from the exact global graph.
    internal_nodes = graph_nodes(all_internal_edges)
    junctions = [p for p in internal_nodes if len(build_adjacency(all_internal_edges)[p]) >= 3]
    junction_canvas = np.zeros(labels.shape, dtype=np.uint8)
    for p in junctions:
        x, y = p[0] / 2.0, p[1] / 2.0
        cv2.circle(
            junction_canvas,
            (int(round(x)), int(round(y))),
            2,
            255,
            -1,
        )
    save_binary(output_dir / "07_exact_junctions.png", junction_canvas > 0)

    report = {
        "shape": [int(labels.shape[0]), int(labels.shape[1])],
        "region_labels": [int(x) for x in np.unique(labels[valid])],
        "internal_label_pairs": int(len(internal_by_pair)),
        "exact_internal_edges": int(len(all_internal_edges)),
        "exact_outer_edges": int(len(outer_edges)),
        "exact_internal_global_chains": int(len(exact_internal_chains)),
        "pair_aware_internal_polylines": int(len(internal_polylines)),
        "outer_polylines": int(len(outer_polylines)),
        "exact_junction_vertices": int(len(junctions)),
        "final_boundary_pixels": int(final_boundary.sum()),
        "parameters": {
            "simplify_epsilon": float(simplify_epsilon),
            "max_deviation": float(max_deviation),
            "min_simplify_length": float(min_simplify_length),
            "geometry_source": "exact_pixel_cell_interfaces",
            "skeletonization_used": False,
        },
    }

    report_path = output_dir / "run_report.json"
    report_path.write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("Pair-aware internal polylines:", len(internal_polylines))
    print("Outer polylines:", len(outer_polylines))
    print("Exact junction vertices:", len(junctions))
    print()
    print("=" * 72)
    print("Complete")
    print("Final:", output_dir / "05_final_boundary.png")
    print("Overlay:", output_dir / "06_overlay.png")
    print("GeoJSON:", geojson_path)
    print("Report:", report_path)
    print("=" * 72)


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Build exact topology-preserving geological boundaries directly "
            "from region_labels.npy using pixel-cell interfaces."
        )
    )
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--original", type=Path, default=None)

    parser.add_argument(
        "--simplify-epsilon",
        type=float,
        default=0.65,
        help="Douglas-Peucker epsilon in pixels. Default: 0.65",
    )
    parser.add_argument(
        "--max-deviation",
        type=float,
        default=0.75,
        help="Maximum allowed deviation from exact interface in pixels. Default: 0.75",
    )
    parser.add_argument(
        "--min-simplify-length",
        type=float,
        default=8.0,
        help="Chains shorter than this remain exact. Default: 8",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        original_path=args.original,
        simplify_epsilon=args.simplify_epsilon,
        max_deviation=args.max_deviation,
        min_simplify_length=args.min_simplify_length,
    )