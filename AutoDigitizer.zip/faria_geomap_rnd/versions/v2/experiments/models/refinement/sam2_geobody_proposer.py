from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

s


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(r"C:\PROJECT\GeoMapPrototype\V2")

IMAGE_PATH = Path(
    r"C:\PROJECT\GeoMapPrototype\DataResearch"
    r"\Supervisor150\map_0103\map_0103_color.png"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "outputs"
    / "sam2_geobody_test"
    / "map_0103"
)


# ============================================================
# SETTINGS
# ============================================================

# Ignore nearly-white page background.
WHITE_THRESHOLD = 242

# Ignore tiny colour regions such as text / isolated noise.
MIN_REGION_AREA = 500

# Avoid treating the entire page/map frame as an object.
MAX_REGION_FRACTION = 0.30

# Morphology is ONLY used to create seed regions.
# It does NOT become the final geological boundary.
SEED_CLOSE_SIZE = 5

# Interior point must be comfortably inside a region.
DISTANCE_MINIMUM = 3.0

# Number of candidate geological bodies to test.
MAX_CANDIDATES = 20


# ============================================================
# IMAGE HELPERS
# ============================================================

def load_image() -> np.ndarray:
    image = cv2.imread(str(IMAGE_PATH), cv2.IMREAD_COLOR)

    if image is None:
        raise RuntimeError(
            f"Could not load image:\n{IMAGE_PATH}"
        )

    return image


def make_coloured_map_mask(image: np.ndarray) -> np.ndarray:
    """
    Find pixels likely belonging to coloured geological bodies.

    This is deliberately permissive. It only creates SAM2 prompts.
    SAM2 will determine the final object mask.
    """

    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]

    not_white = value < WHITE_THRESHOLD

    # Geological fills in Supervisor150 are generally coloured.
    coloured = saturation > 22

    mask = (
        not_white
        & coloured
    ).astype(np.uint8)

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (SEED_CLOSE_SIZE, SEED_CLOSE_SIZE),
    )

    mask = cv2.morphologyEx(
        mask,
        cv2.MORPH_CLOSE,
        kernel,
    )

    return mask


# ============================================================
# CANDIDATE DISCOVERY
# ============================================================

def find_candidates(mask: np.ndarray):
    count, labels, stats, _ = cv2.connectedComponentsWithStats(
        mask,
        connectivity=8,
    )

    image_area = mask.shape[0] * mask.shape[1]

    candidates = []

    for component_id in range(1, count):
        area = int(
            stats[component_id, cv2.CC_STAT_AREA]
        )

        if area < MIN_REGION_AREA:
            continue

        fraction = area / image_area

        if fraction > MAX_REGION_FRACTION:
            continue

        component = (
            labels == component_id
        ).astype(np.uint8)

        distance = cv2.distanceTransform(
            component,
            cv2.DIST_L2,
            5,
        )

        _, max_distance, _, max_location = cv2.minMaxLoc(
            distance
        )

        if max_distance < DISTANCE_MINIMUM:
            continue

        x = int(
            stats[component_id, cv2.CC_STAT_LEFT]
        )
        y = int(
            stats[component_id, cv2.CC_STAT_TOP]
        )
        w = int(
            stats[component_id, cv2.CC_STAT_WIDTH]
        )
        h = int(
            stats[component_id, cv2.CC_STAT_HEIGHT]
        )

        candidates.append(
            {
                "component_id": component_id,
                "area": area,
                "box": (x, y, x + w, y + h),
                "point": (
                    int(max_location[0]),
                    int(max_location[1]),
                ),
                "distance": float(max_distance),
            }
        )

    # Large, well-defined bodies first.
    candidates.sort(
        key=lambda item: (
            item["distance"],
            item["area"],
        ),
        reverse=True,
    )

    return candidates[:MAX_CANDIDATES]


# ============================================================
# PREVIEW
# ============================================================

def save_candidate_preview(
    image: np.ndarray,
    candidates,
):
    preview = image.copy()

    for index, candidate in enumerate(
        candidates,
        start=1,
    ):
        x1, y1, x2, y2 = candidate["box"]
        px, py = candidate["point"]

        cv2.rectangle(
            preview,
            (x1, y1),
            (x2, y2),
            (0, 0, 255),
            2,
        )

        cv2.circle(
            preview,
            (px, py),
            7,
            (0, 255, 0),
            -1,
        )

        cv2.putText(
            preview,
            str(index),
            (px + 10, py - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 0, 255),
            2,
            cv2.LINE_AA,
        )

    path = OUTPUT_DIR / "geobody_candidates.png"

    cv2.imwrite(str(path), preview)

    return path


# ============================================================
# MAIN
# ============================================================

def main():
    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    image = load_image()

    print("Image:", IMAGE_PATH)
    print("Shape:", image.shape)

    seed_mask = make_coloured_map_mask(image)

    cv2.imwrite(
        str(OUTPUT_DIR / "colour_seed_mask.png"),
        seed_mask * 255,
    )

    candidates = find_candidates(seed_mask)

    print()
    print(
        "Candidate geological bodies:",
        len(candidates),
    )

    for index, candidate in enumerate(
        candidates,
        start=1,
    ):
        print(
            f"{index:02d} "
            f"point={candidate['point']} "
            f"box={candidate['box']} "
            f"area={candidate['area']} "
            f"interior_distance="
            f"{candidate['distance']:.1f}"
        )

    preview = save_candidate_preview(
        image,
        candidates,
    )

    print()
    print("Candidate preview:")
    print(preview)

    print()
    print(
        "NOTE: SAM2 inference is intentionally NOT run yet."
    )
    print(
        "First inspect whether these points are actually "
        "inside geological bodies."
    )


if __name__ == "__main__":
    main()