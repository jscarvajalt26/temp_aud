from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np


PROJECT_ROOT = Path(r"C:\PROJECT\GeoMapPrototype\V2")

DEFAULT_INPUT_DIR = (
    PROJECT_ROOT
    / "outputs"
    / "color_region_boundaries_map0103"
)

DEFAULT_OUTPUT_DIR = (
    PROJECT_ROOT
    / "outputs"
    / "georegion_smoothed"
    / "map_0103_color"
)

MIN_CHAIN_POINTS = 12
SMOOTH_WINDOW = 5
SMOOTH_PASSES = 1
MAX_POINT_MOVEMENT = 1.25
JUNCTION_PROTECTION_RADIUS = 5
OUTER_PROTECTION_RADIUS = 3


NEIGHBORS = (
    (-1, -1), (0, -1), (1, -1),
    (-1, 0),           (1, 0),
    (-1, 1),  (0, 1),  (1, 1),
)


def read_mask(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)

    if img is None:
        raise FileNotFoundError(path)

    return (img > 0).astype(np.uint8)


def read_bgr(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)

    if img is None:
        raise FileNotFoundError(path)

    return img


def save_mask(path: Path, mask: np.ndarray) -> None:
    cv2.imwrite(
        str(path),
        (mask > 0).astype(np.uint8) * 255,
    )


def degree_map(mask: np.ndarray) -> np.ndarray:
    kernel = np.ones((3, 3), dtype=np.uint8)

    count = cv2.filter2D(
        mask.astype(np.uint8),
        cv2.CV_16U,
        kernel,
        borderType=cv2.BORDER_CONSTANT,
    )

    return count - mask.astype(np.uint16)


def get_neighbors(
    mask: np.ndarray,
    point: tuple[int, int],
) -> list[tuple[int, int]]:

    x, y = point
    h, w = mask.shape

    result = []

    for dx, dy in NEIGHBORS:
        nx = x + dx
        ny = y + dy

        if (
            0 <= nx < w
            and 0 <= ny < h
            and mask[ny, nx] > 0
        ):
            result.append((nx, ny))

    return result


def canonical_edge(
    a: tuple[int, int],
    b: tuple[int, int],
):
    return (a, b) if a <= b else (b, a)


def trace_chains(mask: np.ndarray) -> list[list[tuple[int, int]]]:
    degree = degree_map(mask)

    ys, xs = np.where(mask > 0)

    pixels = {
        (int(x), int(y))
        for x, y in zip(xs, ys)
    }

    nodes = {
        p
        for p in pixels
        if degree[p[1], p[0]] != 2
    }

    visited_edges = set()
    chains = []

    for start in nodes:
        for nxt in get_neighbors(mask, start):
            edge = canonical_edge(start, nxt)

            if edge in visited_edges:
                continue

            chain = [start]

            prev = start
            cur = nxt

            visited_edges.add(edge)

            while True:
                chain.append(cur)

                if cur in nodes and cur != start:
                    break

                candidates = [
                    p
                    for p in get_neighbors(mask, cur)
                    if p != prev
                ]

                next_point = None

                for candidate in candidates:
                    ce = canonical_edge(cur, candidate)

                    if ce not in visited_edges:
                        next_point = candidate
                        break

                if next_point is None:
                    break

                visited_edges.add(
                    canonical_edge(cur, next_point)
                )

                prev = cur
                cur = next_point

            if len(chain) >= MIN_CHAIN_POINTS:
                chains.append(chain)

    # closed loops
    for start in pixels:
        for nxt in get_neighbors(mask, start):
            edge = canonical_edge(start, nxt)

            if edge in visited_edges:
                continue

            chain = [start]

            prev = start
            cur = nxt

            visited_edges.add(edge)

            while True:
                chain.append(cur)

                candidates = [
                    p
                    for p in get_neighbors(mask, cur)
                    if p != prev
                ]

                next_point = None

                for candidate in candidates:
                    ce = canonical_edge(cur, candidate)

                    if ce not in visited_edges:
                        next_point = candidate
                        break

                if next_point is None:
                    break

                visited_edges.add(
                    canonical_edge(cur, next_point)
                )

                prev = cur
                cur = next_point

                if cur == start:
                    chain.append(start)
                    break

            if len(chain) >= MIN_CHAIN_POINTS:
                chains.append(chain)

    return chains


def dilate_mask(
    mask: np.ndarray,
    radius: int,
) -> np.ndarray:

    size = radius * 2 + 1

    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (size, size),
    )

    return cv2.dilate(
        mask.astype(np.uint8),
        kernel,
        iterations=1,
    )


def moving_average(
    points: np.ndarray,
    window: int,
) -> np.ndarray:

    if len(points) < window:
        return points.copy()

    half = window // 2

    out = points.copy()

    for i in range(half, len(points) - half):
        out[i] = points[
            i - half:i + half + 1
        ].mean(axis=0)

    return out


def smooth_chain(
    chain: list[tuple[int, int]],
    protected_mask: np.ndarray,
) -> np.ndarray:

    original = np.asarray(
        chain,
        dtype=np.float32,
    )

    result = original.copy()

    protected = np.array(
        [
            protected_mask[
                int(round(p[1])),
                int(round(p[0])),
            ] > 0
            for p in original
        ],
        dtype=bool,
    )

    for _ in range(SMOOTH_PASSES):
        candidate = moving_average(
            result,
            SMOOTH_WINDOW,
        )

        movement = candidate - original

        dist = np.linalg.norm(
            movement,
            axis=1,
            keepdims=True,
        )

        scale = np.minimum(
            1.0,
            MAX_POINT_MOVEMENT
            / np.maximum(dist, 1e-6),
        )

        candidate = (
            original
            + movement * scale
        )

        candidate[protected] = (
            original[protected]
        )

        candidate[0] = original[0]
        candidate[-1] = original[-1]

        result = candidate

    return result


def rasterize_chains(
    chains: list[np.ndarray],
    shape: tuple[int, int],
) -> np.ndarray:

    out = np.zeros(
        shape,
        dtype=np.uint8,
    )

    for chain in chains:
        if len(chain) < 2:
            continue

        pts = np.rint(
            chain
        ).astype(np.int32)

        cv2.polylines(
            out,
            [pts.reshape(-1, 1, 2)],
            isClosed=False,
            color=1,
            thickness=1,
            lineType=cv2.LINE_8,
        )

    return out


def make_overlay(
    original: np.ndarray,
    internal: np.ndarray,
    outer: np.ndarray,
    junctions: np.ndarray,
) -> np.ndarray:

    overlay = original.copy()

    overlay[internal > 0] = (
        0,
        255,
        0,
    )

    overlay[outer > 0] = (
        255,
        255,
        0,
    )

    ys, xs = np.where(
        junctions > 0
    )

    for x, y in zip(xs, ys):
        cv2.circle(
            overlay,
            (int(x), int(y)),
            2,
            (0, 0, 255),
            -1,
        )

    return overlay


def save_geojson(
    path: Path,
    chains: list[np.ndarray],
) -> None:

    features = []

    for idx, chain in enumerate(
        chains,
        start=1,
    ):
        if len(chain) < 2:
            continue

        coords = [
            [
                float(p[0]),
                float(p[1]),
            ]
            for p in chain
        ]

        features.append(
            {
                "type": "Feature",
                "properties": {
                    "id": idx,
                    "type": "geological_contact",
                },
                "geometry": {
                    "type": "LineString",
                    "coordinates": coords,
                },
            }
        )

    collection = {
        "type": "FeatureCollection",
        "features": features,
    }

    path.write_text(
        json.dumps(
            collection,
            indent=2,
        ),
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Geometry-preserving smoother for "
            "accepted geological region boundaries."
        )
    )

    parser.add_argument(
        "--input-dir",
        type=Path,
        default=DEFAULT_INPUT_DIR,
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
    )

    args = parser.parse_args()

    input_dir = args.input_dir
    output_dir = args.output_dir

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    original = read_bgr(
        input_dir / "01_original.png"
    )

    internal = read_mask(
        input_dir / "06a_internal_boundaries.png"
    )

    shared = read_mask(
        input_dir / "06_shared_boundaries.png"
    )

    outer = read_mask(
        input_dir / "06b_outer_map_boundary.png"
    )

    junctions = read_mask(
        input_dir / "07_region_junctions.png"
    )

    region_labels = np.load(
        input_dir / "region_labels.npy"
    )

    if internal.shape != outer.shape:
        raise RuntimeError(
            "Boundary layer dimensions do not match."
        )

    print("=" * 72)
    print("Geometry-preserving geological boundary smoothing")
    print("Input:", input_dir)
    print("Shape:", internal.shape)
    print("Smooth window:", SMOOTH_WINDOW)
    print("Smooth passes:", SMOOTH_PASSES)
    print("Max movement:", MAX_POINT_MOVEMENT)
    print("=" * 72)

    # Protect junctions and map perimeter.
    protected_junctions = dilate_mask(
        junctions,
        JUNCTION_PROTECTION_RADIUS,
    )

    protected_outer = dilate_mask(
        outer,
        OUTER_PROTECTION_RADIUS,
    )

    protected = np.maximum(
        protected_junctions,
        protected_outer,
    )

    # Use internal boundary geometry for chain smoothing.
    chains = trace_chains(
        internal
    )

    print("Chains traced:", len(chains))

    smoothed_chains = []

    for chain in chains:
        smoothed = smooth_chain(
            chain,
            protected,
        )

        smoothed_chains.append(
            smoothed
        )

    smoothed_from_chains = rasterize_chains(
        smoothed_chains,
        internal.shape,
    )

    # ------------------------------------------------------------
    # NEVER DROP ORIGINAL ACCEPTED BOUNDARY GEOMETRY
    # ------------------------------------------------------------

    # Slightly expand the smoothed result so we can identify which
    # original pixels were successfully represented by a smoothed chain.
    smoothed_support = cv2.dilate(
        smoothed_from_chains.astype(np.uint8),
        np.ones((3, 3), dtype=np.uint8),
        iterations=1,
    )

    # Original pixels not represented by any smoothed chain.
    unrepresented_original = (
        (internal > 0)
        & (smoothed_support == 0)
    ).astype(np.uint8)

    # Keep those pixels exactly as they were.
    smoothed_internal = np.maximum(
        smoothed_from_chains,
        unrepresented_original,
    )

    # ------------------------------------------------------------
    # PROTECT COMPLEX / JUNCTION AREAS EXACTLY
    # ------------------------------------------------------------

    junction_protection = dilate_mask(
        junctions,
        JUNCTION_PROTECTION_RADIUS,
    )

    smoothed_internal[
        junction_protection > 0
    ] = internal[
        junction_protection > 0
    ]

    # ------------------------------------------------------------
    # FINAL SAFETY:
    # anything genuinely lost farther than one pixel from the
    # smoothed geometry is restored.
    # ------------------------------------------------------------

    coverage = cv2.dilate(
        smoothed_internal.astype(np.uint8),
        np.ones((3, 3), dtype=np.uint8),
        iterations=1,
    )

    lost = (
        (internal > 0)
        & (coverage == 0)
    )

    smoothed_internal[
        lost
    ] = 1

    # Final combined geological edge layer.
    final_boundary = np.maximum(
        smoothed_internal,
        outer,
    )

    save_mask(
        output_dir / "01_original_internal.png",
        internal,
    )

    save_mask(
        output_dir / "02_protected_junctions.png",
        protected_junctions,
    )

    save_mask(
        output_dir / "03_smoothed_internal.png",
        smoothed_internal,
    )

    save_mask(
        output_dir / "04_outer_boundary.png",
        outer,
    )

    save_mask(
        output_dir / "05_final_boundary.png",
        final_boundary,
    )

    overlay = make_overlay(
        original,
        smoothed_internal,
        outer,
        junctions,
    )

    cv2.imwrite(
        str(
            output_dir / "06_smoothed_overlay.png"
        ),
        overlay,
    )

    save_geojson(
        output_dir / "boundaries.geojson",
        smoothed_chains,
    )

    report = {
        "input": str(input_dir),
        "shape": [
            int(internal.shape[0]),
            int(internal.shape[1]),
        ],
        "chains_traced": len(chains),
        "original_internal_pixels": int(
            internal.sum()
        ),
        "smoothed_internal_pixels": int(
            smoothed_internal.sum()
        ),
        "outer_boundary_pixels": int(
            outer.sum()
        ),
        "junction_pixels": int(
            junctions.sum()
        ),
        "region_count": int(
            len(np.unique(region_labels))
        ),
        "settings": {
            "smooth_window": SMOOTH_WINDOW,
            "smooth_passes": SMOOTH_PASSES,
            "max_point_movement": MAX_POINT_MOVEMENT,
            "junction_protection_radius": (
                JUNCTION_PROTECTION_RADIUS
            ),
            "outer_protection_radius": (
                OUTER_PROTECTION_RADIUS
            ),
        },
    }

    (
        output_dir / "run_report.json"
    ).write_text(
        json.dumps(
            report,
            indent=2,
        ),
        encoding="utf-8",
    )

    print("Original internal pixels:", int(internal.sum()))
    print("Smoothed internal pixels:", int(smoothed_internal.sum()))
    print("Outer boundary pixels:", int(outer.sum()))
    print("Junction pixels:", int(junctions.sum()))
    print("Output:", output_dir)
    print("=" * 72)


if __name__ == "__main__":
    main()