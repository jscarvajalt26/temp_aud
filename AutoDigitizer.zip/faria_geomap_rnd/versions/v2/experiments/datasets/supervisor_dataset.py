from __future__ import annotations

import json
import random
from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset


class SupervisorMapDataset(Dataset):
    VARIANTS = ("color", "grayscale", "bw", "aged")

    MASKS = (
        "contact",
        "fault",
        "road",
        "river",
        "lake",
        "strike_dip",
        "clutter",
    )

    FEATURE_SAMPLING_WEIGHTS = {
        "contact": 0.24,
        "fault": 0.16,
        "road": 0.10,
        "river": 0.12,
        "lake": 0.10,
        "strike_dip": 0.18,
        "clutter": 0.10,
    }

    def __init__(
        self,
        dataset_root,
        split_path,
        target_root,
        split_name,
        crop_size=512,
        random_variant=None,
        fixed_variant="color",
        augment=None,
        samples_per_map=8,
        feature_crop_probability=0.65,
        hard_negative_crop_probability=0.20,
        validation_grid_size=3,
        footprint_close_kernel=41,
        hard_negative_min_gray=245,
        hard_negative_min_distance=24,
    ):
        self.dataset_root = Path(dataset_root)
        self.target_root = Path(target_root)
        self.crop_size = int(crop_size)
        self.split_name = split_name
        self.fixed_variant = fixed_variant

        self.random_variant = (
            split_name == "train"
            if random_variant is None
            else bool(random_variant)
        )

        self.augment = (
            split_name == "train"
            if augment is None
            else bool(augment)
        )

        self.samples_per_map = max(int(samples_per_map), 1)
        self.feature_crop_probability = float(feature_crop_probability)
        self.hard_negative_crop_probability = float(
            hard_negative_crop_probability
        )
        self.validation_grid_size = max(int(validation_grid_size), 1)

        self.footprint_close_kernel = max(
            int(footprint_close_kernel),
            3,
        )
        if self.footprint_close_kernel % 2 == 0:
            self.footprint_close_kernel += 1

        self.hard_negative_min_gray = int(hard_negative_min_gray)
        self.hard_negative_min_distance = max(
            int(hard_negative_min_distance),
            0,
        )

        if split_name not in {"train", "validation", "test"}:
            raise ValueError(
                "split_name must be train, validation, or test"
            )

        if fixed_variant not in self.VARIANTS:
            raise ValueError(
                f"Unsupported variant: {fixed_variant}"
            )

        if not 0.0 <= self.feature_crop_probability <= 1.0:
            raise ValueError(
                "feature_crop_probability must be between 0 and 1"
            )

        if not 0.0 <= self.hard_negative_crop_probability <= 1.0:
            raise ValueError(
                "hard_negative_crop_probability must be between 0 and 1"
            )

        if (
            self.feature_crop_probability
            + self.hard_negative_crop_probability
            > 1.0
        ):
            raise ValueError(
                "feature_crop_probability + "
                "hard_negative_crop_probability must be <= 1"
            )

        data = json.loads(
            Path(split_path).read_text(
                encoding="utf-8"
            )
        )

        self.map_ids = list(
            data[split_name]
        )

        self._validate()

    # ============================================================
    # VALIDATION / INDEXING
    # ============================================================

    def _validate(self):
        missing = []

        for map_id in self.map_ids:
            map_directory = (
                self.dataset_root
                / map_id
            )

            for variant in self.VARIANTS:
                path = (
                    map_directory
                    / f"{map_id}_{variant}_control.png"
                )
                if not path.exists():
                    missing.append(str(path))

            target_directory = (
                self.target_root
                / map_id
            )

            required = (
                "unit_labels.npy",
                *[
                    f"{name}_mask.png"
                    for name in self.MASKS
                ],
            )

            for filename in required:
                path = (
                    target_directory
                    / filename
                )
                if not path.exists():
                    missing.append(str(path))

        if missing:
            raise FileNotFoundError(
                "Missing files:\n"
                + "\n".join(missing[:30])
            )

    def __len__(self):
        if self.split_name == "train":
            return (
                len(self.map_ids)
                * self.samples_per_map
            )

        return (
            len(self.map_ids)
            * self.validation_grid_size
            * self.validation_grid_size
        )

    def _resolve_index(self, index):
        if self.split_name == "train":
            return (
                self.map_ids[
                    index // self.samples_per_map
                ],
                index % self.samples_per_map,
            )

        crops_per_map = (
            self.validation_grid_size
            * self.validation_grid_size
        )

        return (
            self.map_ids[
                index // crops_per_map
            ],
            index % crops_per_map,
        )

    # ============================================================
    # LOAD
    # ============================================================

    def _variant(self):
        if self.random_variant:
            return random.choice(
                self.VARIANTS
            )

        return self.fixed_variant

    def _load(self, map_id, variant):
        image_path = (
            self.dataset_root
            / map_id
            / f"{map_id}_{variant}_control.png"
        )

        image = cv2.imread(
            str(image_path),
            cv2.IMREAD_COLOR,
        )

        if image is None:
            raise RuntimeError(
                f"Could not read {image_path}"
            )

        image = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2RGB,
        )

        target_directory = (
            self.target_root
            / map_id
        )

        units = np.load(
            target_directory
            / "unit_labels.npy"
        ).astype(np.int64)

        masks = {}

        for name in self.MASKS:
            mask_path = (
                target_directory
                / f"{name}_mask.png"
            )

            mask = cv2.imread(
                str(mask_path),
                cv2.IMREAD_GRAYSCALE,
            )

            if mask is None:
                raise RuntimeError(
                    f"Could not read {mask_path}"
                )

            masks[name] = (
                mask > 0
            ).astype(np.uint8)

        if image.shape[:2] != units.shape:
            raise ValueError(
                f"{map_id}: image/units mismatch "
                f"{image.shape[:2]} vs {units.shape}"
            )

        for name, mask in masks.items():
            if mask.shape != units.shape:
                raise ValueError(
                    f"{map_id}: {name} mismatch "
                    f"{mask.shape} vs {units.shape}"
                )

        return image, units, masks

    # ============================================================
    # MAP FOOTPRINT
    # ============================================================

    def _build_map_footprint(
        self,
        units: np.ndarray,
    ) -> np.ndarray:
        """
        Build a page-level geological-map footprint.

        IMPORTANT:
        unit_labels < 0 is NOT automatically page background.
        It also includes linework/gaps/symbol pixels inside the map.

        We therefore:
        1. start from valid geological unit pixels;
        2. morphologically close internal line/gap interruptions;
        3. take the largest external map component;
        4. fill its contour so internal linework remains INSIDE the map.
        """

        valid = (
            units >= 0
        ).astype(np.uint8) * 255

        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (
                self.footprint_close_kernel,
                self.footprint_close_kernel,
            ),
        )

        closed = cv2.morphologyEx(
            valid,
            cv2.MORPH_CLOSE,
            kernel,
            iterations=2,
        )

        contours, _ = cv2.findContours(
            closed,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE,
        )

        if not contours:
            return (
                valid > 0
            )

        largest = max(
            contours,
            key=cv2.contourArea,
        )

        footprint = np.zeros_like(
            valid,
            dtype=np.uint8,
        )

        cv2.drawContours(
            footprint,
            [largest],
            contourIdx=-1,
            color=255,
            thickness=cv2.FILLED,
        )

        return (
            footprint > 0
        )

    # ============================================================
    # PADDING
    # ============================================================

    def _pad_if_needed(
        self,
        image,
        units,
        masks,
    ):
        h, w = units.shape

        pad_h = max(
            self.crop_size - h,
            0,
        )

        pad_w = max(
            self.crop_size - w,
            0,
        )

        if not (
            pad_h
            or pad_w
        ):
            return (
                image,
                units,
                masks,
            )

        image = cv2.copyMakeBorder(
            image,
            0,
            pad_h,
            0,
            pad_w,
            cv2.BORDER_REFLECT_101,
        )

        units = cv2.copyMakeBorder(
            units,
            0,
            pad_h,
            0,
            pad_w,
            cv2.BORDER_CONSTANT,
            value=-1,
        )

        masks = {
            key: cv2.copyMakeBorder(
                value,
                0,
                pad_h,
                0,
                pad_w,
                cv2.BORDER_CONSTANT,
                value=0,
            )
            for key, value in masks.items()
        }

        return (
            image,
            units,
            masks,
        )

    # ============================================================
    # CROP ORIGINS
    # ============================================================

    def _random_origin(
        self,
        height,
        width,
    ):
        return (
            random.randint(
                0,
                height - self.crop_size,
            ),
            random.randint(
                0,
                width - self.crop_size,
            ),
        )

    def _feature_origin(
        self,
        masks,
        height,
        width,
    ):
        available = []
        weights = []

        for name in self.MASKS:
            if np.any(
                masks[name] > 0
            ):
                available.append(name)
                weights.append(
                    self.FEATURE_SAMPLING_WEIGHTS[
                        name
                    ]
                )

        if not available:
            y, x = self._random_origin(
                height,
                width,
            )

            return (
                y,
                x,
                None,
            )

        name = random.choices(
            available,
            weights=weights,
            k=1,
        )[0]

        ys, xs = np.where(
            masks[name] > 0
        )

        index = random.randrange(
            len(xs)
        )

        center_y = int(
            ys[index]
        )

        center_x = int(
            xs[index]
        )

        jitter = max(
            self.crop_size // 4,
            1,
        )

        center_y += random.randint(
            -jitter,
            jitter,
        )

        center_x += random.randint(
            -jitter,
            jitter,
        )

        y = int(
            np.clip(
                center_y
                - self.crop_size // 2,
                0,
                height - self.crop_size,
            )
        )

        x = int(
            np.clip(
                center_x
                - self.crop_size // 2,
                0,
                width - self.crop_size,
            )
        )

        return (
            y,
            x,
            name,
        )

    def _hard_negative_candidates(
        self,
        image_rgb,
        footprint,
    ):
        outside = (
            ~footprint
        ).astype(np.uint8)

        if not np.any(
            outside
        ):
            return np.zeros_like(
                outside,
                dtype=bool,
            )

        gray = cv2.cvtColor(
            image_rgb,
            cv2.COLOR_RGB2GRAY,
        )

        edges = cv2.Canny(
            gray,
            40,
            120,
        )

        structured = (
            (gray < self.hard_negative_min_gray)
            | (edges > 0)
        )

        if (
            self.hard_negative_min_distance
            > 0
        ):
            distance = cv2.distanceTransform(
                outside,
                cv2.DIST_L2,
                3,
            )

            safely_outside = (
                distance
                >= self.hard_negative_min_distance
            )

        else:
            safely_outside = (
                outside > 0
            )

        candidates = (
            (outside > 0)
            & structured
            & safely_outside
        )

        if np.any(candidates):
            return candidates

        candidates = (
            (outside > 0)
            & structured
        )

        if np.any(candidates):
            return candidates

        return (
            outside > 0
        )

    def _hard_negative_origin(
        self,
        image,
        footprint,
        height,
        width,
    ):
        candidates = self._hard_negative_candidates(
            image,
            footprint,
        )

        ys, xs = np.where(candidates)

        if len(xs) == 0:
            y, x = self._random_origin(
                height,
                width,
            )

            return (
                y,
                x,
                False,
            )

        best_y = None
        best_x = None
        best_outside_fraction = -1.0

        # Try multiple candidate page/background points.
        for _ in range(30):
            index = random.randrange(
                len(xs)
            )

            center_y = int(
                ys[index]
            )

            center_x = int(
                xs[index]
            )

            jitter = max(
                self.crop_size // 8,
                1,
            )

            center_y += random.randint(
                -jitter,
                jitter,
            )

            center_x += random.randint(
                -jitter,
                jitter,
            )

            y = int(
                np.clip(
                    center_y
                    - self.crop_size // 2,
                    0,
                    height - self.crop_size,
                )
            )

            x = int(
                np.clip(
                    center_x
                    - self.crop_size // 2,
                    0,
                    width - self.crop_size,
                )
            )

            crop_footprint = footprint[
                y:y + self.crop_size,
                x:x + self.crop_size,
            ]

            outside_fraction = float(
                np.mean(
                    ~crop_footprint
                )
            )

            if outside_fraction > best_outside_fraction:
                best_outside_fraction = outside_fraction

                best_y = y
                best_x = x

            if outside_fraction >= 0.50:
                return (
                    y,
                    x,
                    True,
                )

        # If this map simply has no useful page-margin crop,
        # treat it as a normal random sample instead.
        if best_outside_fraction < 0.25:
            y, x = self._random_origin(
                height,
                width,
            )

            return (
                y,
                x,
                False,
            )

        return (
            best_y,
            best_x,
            True,
        )

    def _grid_origin(
        self,
        height,
        width,
        sample_index,
    ):
        grid_size = (
            self.validation_grid_size
        )

        grid_y, grid_x = divmod(
            sample_index,
            grid_size,
        )

        maximum_y = max(
            height - self.crop_size,
            0,
        )

        maximum_x = max(
            width - self.crop_size,
            0,
        )

        if grid_size == 1:
            return (
                maximum_y // 2,
                maximum_x // 2,
            )

        y_positions = np.linspace(
            0,
            maximum_y,
            grid_size,
        ).round().astype(int)

        x_positions = np.linspace(
            0,
            maximum_x,
            grid_size,
        ).round().astype(int)

        return (
            int(
                y_positions[grid_y]
            ),
            int(
                x_positions[grid_x]
            ),
        )

    # ============================================================
    # AUGMENTATION
    # ============================================================

    def _augment(
        self,
        image,
        units,
        masks,
        footprint,
    ):
        if random.random() < 0.5:
            image = np.flip(
                image,
                1,
            )
            units = np.flip(
                units,
                1,
            )
            footprint = np.flip(
                footprint,
                1,
            )
            masks = {
                key: np.flip(
                    value,
                    1,
                )
                for key, value in masks.items()
            }

        if random.random() < 0.5:
            image = np.flip(
                image,
                0,
            )
            units = np.flip(
                units,
                0,
            )
            footprint = np.flip(
                footprint,
                0,
            )
            masks = {
                key: np.flip(
                    value,
                    0,
                )
                for key, value in masks.items()
            }

        rotation = random.randint(
            0,
            3,
        )

        if rotation:
            image = np.rot90(
                image,
                rotation,
            )
            units = np.rot90(
                units,
                rotation,
            )
            footprint = np.rot90(
                footprint,
                rotation,
            )
            masks = {
                key: np.rot90(
                    value,
                    rotation,
                )
                for key, value in masks.items()
            }

        return (
            image,
            units,
            masks,
            footprint,
        )

    # ============================================================
    # CROP
    # ============================================================

    def _crop_and_augment(
        self,
        image,
        units,
        masks,
        sample_index,
    ):
        (
            image,
            units,
            masks,
        ) = self._pad_if_needed(
            image,
            units,
            masks,
        )

        footprint = (
            self._build_map_footprint(
                units
            )
        )

        height, width = (
            units.shape
        )

        if self.split_name == "train":
            draw = random.random()

            feature_limit = (
                self.feature_crop_probability
            )

            hard_negative_limit = (
                self.feature_crop_probability
                + self.hard_negative_crop_probability
            )

            if draw < feature_limit:
                (
                    y,
                    x,
                    feature,
                ) = self._feature_origin(
                    masks,
                    height,
                    width,
                )

                sample_mode = (
                    "feature"
                    if feature is not None
                    else "random"
                )

                sampled_feature = (
                    feature
                    if feature is not None
                    else "random"
                )

            elif draw < hard_negative_limit:
                (
                    y,
                    x,
                    is_hard_negative,
                ) = self._hard_negative_origin(
                    image,
                    footprint,
                    height,
                    width,
                )

                if is_hard_negative:
                    sample_mode = "hard_negative"
                    sampled_feature = "hard_negative"
                else:
                    sample_mode = "random"
                    sampled_feature = "random"

            else:
                (
                    y,
                    x,
                ) = self._random_origin(
                    height,
                    width,
                )

                sample_mode = "random"
                sampled_feature = "random"

        else:
            (
                y,
                x,
            ) = self._grid_origin(
                height,
                width,
                sample_index,
            )

            sample_mode = "grid"
            sampled_feature = (
                "validation_grid"
            )

        image = image[
            y:y + self.crop_size,
            x:x + self.crop_size,
        ]

        units = units[
            y:y + self.crop_size,
            x:x + self.crop_size,
        ]

        footprint = footprint[
            y:y + self.crop_size,
            x:x + self.crop_size,
        ]

        masks = {
            key: value[
                y:y + self.crop_size,
                x:x + self.crop_size,
            ]
            for key, value in masks.items()
        }

        if self.augment:
            (
                image,
                units,
                masks,
                footprint,
            ) = self._augment(
                image,
                units,
                masks,
                footprint,
            )

        outside_fraction = float(
            np.mean(
                ~footprint
            )
        )

        return (
            np.ascontiguousarray(
                image
            ),
            np.ascontiguousarray(
                units
            ),
            {
                key: np.ascontiguousarray(
                    value
                )
                for key, value in masks.items()
            },
            np.ascontiguousarray(
                footprint.astype(
                    np.uint8
                )
            ),
            sampled_feature,
            sample_mode,
            outside_fraction,
            y,
            x,
        )

    def __getitem__(
        self,
        index,
    ):
        (
            map_id,
            sample_index,
        ) = self._resolve_index(
            index
        )

        variant = self._variant()

        (
            image,
            units,
            masks,
        ) = self._load(
            map_id,
            variant,
        )

        (
            image,
            units,
            masks,
            footprint,
            sampled_feature,
            sample_mode,
            outside_fraction,
            crop_y,
            crop_x,
        ) = self._crop_and_augment(
            image,
            units,
            masks,
            sample_index,
        )

        sample = {
            "image": (
                torch.from_numpy(
                    image.transpose(
                        2,
                        0,
                        1,
                    )
                ).float()
                / 255.0
            ),
            "units": torch.from_numpy(
                units
            ).long(),
            "map_footprint": (
                torch.from_numpy(
                    footprint.astype(
                        np.float32
                    )
                ).unsqueeze(0)
            ),
            "map_id": map_id,
            "variant": variant,
            "sampled_feature": (
                sampled_feature
            ),
            "sample_mode": (
                sample_mode
            ),
            "outside_fraction": float(
                outside_fraction
            ),
            "crop_y": int(
                crop_y
            ),
            "crop_x": int(
                crop_x
            ),
        }

        sample.update({
            name: (
                torch.from_numpy(
                    mask.astype(
                        np.float32
                    )
                ).unsqueeze(0)
            )
            for name, mask in masks.items()
        })

        return sample


if __name__ == "__main__":
    ds = SupervisorMapDataset(
        dataset_root=(
            r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150"
        ),
        split_path=(
            r"C:\PROJECT\GeoMapPrototype\V2"
            r"\outputs\dataset_splits"
            r"\supervisor150_split.json"
        ),
        target_root=(
            r"C:\PROJECT\GeoMapPrototype\V2"
            r"\data\supervisor_multilayer_targets"
        ),
        split_name="train",
        crop_size=256,
        samples_per_map=8,
        feature_crop_probability=0.65,
        hard_negative_crop_probability=0.20,
    )

    print(
        "Dataset samples:",
        len(ds),
    )

    counts = {}

    for index in range(
        min(
            32,
            len(ds),
        )
    ):
        sample = ds[index]

        mode = sample[
            "sample_mode"
        ]

        counts[mode] = (
            counts.get(
                mode,
                0,
            )
            + 1
        )

        print(
            index,
            sample[
                "map_id"
            ],
            sample[
                "variant"
            ],
            "mode:",
            mode,
            "target:",
            sample[
                "sampled_feature"
            ],
            "outside_fraction:",
            f"{sample['outside_fraction']:.3f}",
        )

    print(
        "Observed sample modes:",
        counts,
    )