from __future__ import annotations

import json
import random
from collections import Counter
from pathlib import Path
from typing import Sequence

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(r"C:\PROJECT\GeoMapPrototype\V2")

DEFAULT_DATASET_ROOT = Path(
    r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150"
)

DEFAULT_SUPERVISOR_TARGET_ROOT = (
    PROJECT_ROOT
    / "data"
    / "supervisor_multilayer_targets"
)

DEFAULT_AFFINITY_TARGET_ROOT = (
    PROJECT_ROOT
    / "data"
    / "georegion_affinity_targets"
)

DEFAULT_SPLIT_PATH = (
    PROJECT_ROOT
    / "outputs"
    / "dataset_splits"
    / "supervisor150_split.json"
)


# ============================================================
# INPUT APPEARANCE MODES
# ============================================================

CONTROL_SUFFIXES = {
    "color": "_color_control.png",
    "aged": "_aged_control.png",
    "grayscale": "_grayscale_control.png",
    "bw": "_bw_control.png",
}


# ============================================================
# TARGET CONSTRUCTION
# ============================================================

def build_affinity_targets(
    labels: np.ndarray,
) -> dict[str, np.ndarray]:
    """
    Build palette-independent GeoRegion targets from an HxW
    unit-label raster.

    labels >= 0
        valid geological unit

    labels == -1
        unknown / linework / ignored pixel

    Outputs are HxW so they remain easy to batch.
    """

    if labels.ndim != 2:
        raise ValueError(
            f"labels must be HxW, got {labels.shape}"
        )

    labels = labels.astype(
        np.int32,
        copy=False,
    )

    h, w = labels.shape

    # --------------------------------------------------------
    # Valid pixels
    # --------------------------------------------------------

    valid_pixel = labels >= 0

    # --------------------------------------------------------
    # Horizontal edges
    #
    # affinity_h[y, x] refers to:
    #
    # (y, x) <-> (y, x+1)
    # --------------------------------------------------------

    affinity_h = np.zeros(
        (h, w),
        dtype=np.float32,
    )

    valid_h = np.zeros(
        (h, w),
        dtype=np.float32,
    )

    left = labels[:, :-1]
    right = labels[:, 1:]

    pair_valid_h = (
        (left >= 0)
        & (right >= 0)
    )

    same_h = (
        pair_valid_h
        & (left == right)
    )

    valid_h[:, :-1] = (
        pair_valid_h.astype(np.float32)
    )

    affinity_h[:, :-1] = (
        same_h.astype(np.float32)
    )

    # --------------------------------------------------------
    # Vertical edges
    #
    # affinity_v[y, x] refers to:
    #
    # (y, x) <-> (y+1, x)
    # --------------------------------------------------------

    affinity_v = np.zeros(
        (h, w),
        dtype=np.float32,
    )

    valid_v = np.zeros(
        (h, w),
        dtype=np.float32,
    )

    top = labels[:-1, :]
    bottom = labels[1:, :]

    pair_valid_v = (
        (top >= 0)
        & (bottom >= 0)
    )

    same_v = (
        pair_valid_v
        & (top == bottom)
    )

    valid_v[:-1, :] = (
        pair_valid_v.astype(np.float32)
    )

    affinity_v[:-1, :] = (
        same_v.astype(np.float32)
    )

    # --------------------------------------------------------
    # Boundary
    # --------------------------------------------------------

    boundary = np.zeros(
        (h, w),
        dtype=np.float32,
    )

    different_h = (
        pair_valid_h
        & (left != right)
    )

    different_v = (
        pair_valid_v
        & (top != bottom)
    )

    boundary[:, :-1][
        different_h
    ] = 1.0

    boundary[:-1, :][
        different_v
    ] = 1.0

    # --------------------------------------------------------
    # Boundary-valid supervision
    # --------------------------------------------------------

    boundary_valid = np.zeros(
        (h, w),
        dtype=bool,
    )

    vh = valid_h > 0
    vv = valid_v > 0

    boundary_valid |= vh
    boundary_valid |= vv

    shifted_h = np.zeros_like(vh)
    shifted_h[:, 1:] = vh[:, :-1]
    boundary_valid |= shifted_h

    shifted_v = np.zeros_like(vv)
    shifted_v[1:, :] = vv[:-1, :]
    boundary_valid |= shifted_v

    return {
        "valid_pixel": (
            valid_pixel.astype(np.float32)
        ),
        "affinity_h": affinity_h,
        "affinity_h_valid": valid_h,
        "affinity_v": affinity_v,
        "affinity_v_valid": valid_v,
        "boundary": boundary,
        "boundary_valid": (
            boundary_valid.astype(np.float32)
        ),
    }


# ============================================================
# IMAGE HELPERS
# ============================================================

def read_rgb(path: Path) -> np.ndarray:

    bgr = cv2.imread(
        str(path),
        cv2.IMREAD_COLOR,
    )

    if bgr is None:
        raise FileNotFoundError(
            f"Could not read image: {path}"
        )

    return cv2.cvtColor(
        bgr,
        cv2.COLOR_BGR2RGB,
    )


def clamp_crop_origin(
    center_x: int,
    center_y: int,
    crop_size: int,
    width: int,
    height: int,
) -> tuple[int, int]:

    half = crop_size // 2

    x0 = center_x - half
    y0 = center_y - half

    x0 = max(
        0,
        min(
            x0,
            width - crop_size,
        ),
    )

    y0 = max(
        0,
        min(
            y0,
            height - crop_size,
        ),
    )

    return x0, y0


# ============================================================
# PHOTOMETRIC AUGMENTATION
# ============================================================

def random_brightness_contrast(
    image: np.ndarray,
    rng: random.Random,
) -> np.ndarray:

    image_f = image.astype(
        np.float32
    )

    contrast = rng.uniform(
        0.75,
        1.30,
    )

    brightness = rng.uniform(
        -28.0,
        28.0,
    )

    image_f = (
        image_f * contrast
        + brightness
    )

    return np.clip(
        image_f,
        0,
        255,
    ).astype(np.uint8)


def random_saturation(
    image: np.ndarray,
    rng: random.Random,
) -> np.ndarray:

    hsv = cv2.cvtColor(
        image,
        cv2.COLOR_RGB2HSV,
    ).astype(np.float32)

    scale = rng.uniform(
        0.45,
        1.55,
    )

    hsv[..., 1] *= scale

    hsv[..., 1] = np.clip(
        hsv[..., 1],
        0,
        255,
    )

    hsv = hsv.astype(
        np.uint8
    )

    return cv2.cvtColor(
        hsv,
        cv2.COLOR_HSV2RGB,
    )


def random_gamma(
    image: np.ndarray,
    rng: random.Random,
) -> np.ndarray:

    gamma = rng.uniform(
        0.75,
        1.35,
    )

    table = (
        np.linspace(
            0,
            1,
            256,
        )
        ** gamma
        * 255.0
    ).astype(np.uint8)

    return table[image]


def random_blur(
    image: np.ndarray,
    rng: random.Random,
) -> np.ndarray:

    if rng.random() < 0.50:
        return cv2.GaussianBlur(
            image,
            (3, 3),
            sigmaX=rng.uniform(
                0.2,
                1.1,
            ),
        )

    return image


def random_noise(
    image: np.ndarray,
    rng: random.Random,
) -> np.ndarray:

    sigma = rng.uniform(
        1.0,
        8.0,
    )

    noise = np.random.normal(
        0.0,
        sigma,
        image.shape,
    ).astype(np.float32)

    out = (
        image.astype(np.float32)
        + noise
    )

    return np.clip(
        out,
        0,
        255,
    ).astype(np.uint8)


# ============================================================
# PALETTE RANDOMIZATION
# ============================================================

def random_geological_palette(
    image: np.ndarray,
    labels: np.ndarray,
    rng: random.Random,
) -> np.ndarray:
    """
    Recolor geological-unit interiors using randomized colors.

    Invalid pixels (-1) retain the original image so linework,
    symbols, contacts, faults, etc. are preserved.

    This deliberately prevents the network from memorizing:
        "teal means this unit"
        "pink means that unit"

    It must instead learn region continuity and transitions.
    """

    output = image.astype(
        np.float32
    ).copy()

    unit_ids = [
        int(value)
        for value in np.unique(labels)
        if value >= 0
    ]

    for unit_id in unit_ids:

        hue = rng.randint(
            0,
            179,
        )

        saturation = rng.randint(
            55,
            190,
        )

        value = rng.randint(
            125,
            235,
        )

        hsv_color = np.uint8(
            [[[hue, saturation, value]]]
        )

        rgb_color = cv2.cvtColor(
            hsv_color,
            cv2.COLOR_HSV2RGB,
        )[0, 0].astype(
            np.float32
        )

        unit_mask = (
            labels == unit_id
        )

        # Slight blend preserves some scan/texture information.
        alpha = rng.uniform(
            0.78,
            0.96,
        )

        output[unit_mask] = (
            alpha * rgb_color
            + (1.0 - alpha)
            * output[unit_mask]
        )

    return np.clip(
        output,
        0,
        255,
    ).astype(np.uint8)


# ============================================================
# GEOMETRIC AUGMENTATION
# ============================================================

def geometric_augment(
    image: np.ndarray,
    labels: np.ndarray,
    rng: random.Random,
) -> tuple[np.ndarray, np.ndarray]:

    # Horizontal flip
    if rng.random() < 0.50:

        image = np.fliplr(
            image
        ).copy()

        labels = np.fliplr(
            labels
        ).copy()

    # Vertical flip
    if rng.random() < 0.50:

        image = np.flipud(
            image
        ).copy()

        labels = np.flipud(
            labels
        ).copy()

    # 0 / 90 / 180 / 270 degrees
    k = rng.randint(
        0,
        3,
    )

    if k:

        image = np.rot90(
            image,
            k=k,
        ).copy()

        labels = np.rot90(
            labels,
            k=k,
        ).copy()

    return image, labels


# ============================================================
# DATASET
# ============================================================

class GeoRegionDataset(Dataset):

    def __init__(
        self,
        map_ids: Sequence[str],
        dataset_root: Path = DEFAULT_DATASET_ROOT,
        supervisor_target_root: Path = DEFAULT_SUPERVISOR_TARGET_ROOT,
        affinity_target_root: Path = DEFAULT_AFFINITY_TARGET_ROOT,
        crop_size: int = 256,
        samples_per_map: int = 8,
        boundary_crop_probability: float = 0.65,
        random_crop_probability: float = 0.25,
        interior_crop_probability: float = 0.10,
        augment: bool = True,
        palette_randomization_probability: float = 0.35,
        seed: int = 42,
    ) -> None:

        super().__init__()

        self.map_ids = list(
            map_ids
        )

        self.dataset_root = Path(
            dataset_root
        )

        self.supervisor_target_root = Path(
            supervisor_target_root
        )

        self.affinity_target_root = Path(
            affinity_target_root
        )

        self.crop_size = int(
            crop_size
        )

        self.samples_per_map = int(
            samples_per_map
        )

        self.boundary_crop_probability = float(
            boundary_crop_probability
        )

        self.random_crop_probability = float(
            random_crop_probability
        )

        self.interior_crop_probability = float(
            interior_crop_probability
        )

        self.augment = bool(
            augment
        )

        self.palette_randomization_probability = float(
            palette_randomization_probability
        )

        self.seed = int(seed)

        total_probability = (
            self.boundary_crop_probability
            + self.random_crop_probability
            + self.interior_crop_probability
        )

        if abs(
            total_probability - 1.0
        ) > 1e-6:
            raise ValueError(
                "Crop probabilities must sum to 1.0. "
                f"Got {total_probability}"
            )

        if self.crop_size <= 0:
            raise ValueError(
                "crop_size must be positive."
            )

        self._validate_maps()

    # --------------------------------------------------------
    # Validation
    # --------------------------------------------------------

    def _validate_maps(self) -> None:

        missing = []

        for map_id in self.map_ids:

            dataset_dir = (
                self.dataset_root
                / map_id
            )

            supervisor_dir = (
                self.supervisor_target_root
                / map_id
            )

            affinity_dir = (
                self.affinity_target_root
                / map_id
            )

            labels_path = (
                supervisor_dir
                / "unit_labels.npy"
            )

            boundary_path = (
                affinity_dir
                / "boundary.npy"
            )

            if not labels_path.exists():
                missing.append(
                    str(labels_path)
                )

            if not boundary_path.exists():
                missing.append(
                    str(boundary_path)
                )

            found_control = False

            for suffix in CONTROL_SUFFIXES.values():

                image_path = (
                    dataset_dir
                    / f"{map_id}{suffix}"
                )

                if image_path.exists():
                    found_control = True
                    break

            if not found_control:
                missing.append(
                    f"No *_control.png image for {map_id}"
                )

        if missing:

            preview = "\n".join(
                missing[:20]
            )

            raise FileNotFoundError(
                "Dataset validation failed:\n"
                + preview
            )

    # --------------------------------------------------------
    # Length
    # --------------------------------------------------------

    def __len__(self) -> int:

        return (
            len(self.map_ids)
            * self.samples_per_map
        )

    # --------------------------------------------------------
    # Deterministic worker-compatible RNG
    # --------------------------------------------------------

    def _make_rng(
        self,
        index: int,
    ) -> random.Random:

        worker_info = (
            torch.utils.data.get_worker_info()
        )

        worker_id = (
            0
            if worker_info is None
            else worker_info.id
        )

        derived_seed = (
            self.seed
            + index * 104729
            + worker_id * 1000003
            + random.randint(
                0,
                2**20,
            )
        )

        return random.Random(
            derived_seed
        )

    # --------------------------------------------------------
    # Appearance mode
    # --------------------------------------------------------

    def _choose_input_image(
        self,
        map_id: str,
        rng: random.Random,
    ) -> tuple[np.ndarray, str]:

        dataset_dir = (
            self.dataset_root
            / map_id
        )

        available = []

        for mode, suffix in (
            CONTROL_SUFFIXES.items()
        ):

            path = (
                dataset_dir
                / f"{map_id}{suffix}"
            )

            if path.exists():

                available.append(
                    (mode, path)
                )

        if not available:
            raise RuntimeError(
                f"No control images found for {map_id}"
            )

        mode, path = rng.choice(
            available
        )

        return (
            read_rgb(path),
            mode,
        )

    # --------------------------------------------------------
    # Sampling locations
    # --------------------------------------------------------

    def _boundary_center(
        self,
        boundary: np.ndarray,
        rng: random.Random,
    ) -> tuple[int, int] | None:

        ys, xs = np.where(
            boundary > 0
        )

        if len(xs) == 0:
            return None

        index = rng.randrange(
            len(xs)
        )

        return (
            int(xs[index]),
            int(ys[index]),
        )

    def _random_center(
        self,
        labels: np.ndarray,
        rng: random.Random,
        min_valid_fraction: float = 0.20,
        max_attempts: int = 50,
    ) -> tuple[int, int]:
        """
        Choose a random crop location while avoiding crops with
        essentially no valid geological supervision.

        Random crops are still allowed to contain unknown/clutter
        areas. We only reject crops that are mostly unusable.
        """

        h, w = labels.shape
        crop = self.crop_size

        max_x0 = max(0, w - crop)
        max_y0 = max(0, h - crop)

        best_center = None
        best_valid_fraction = -1.0

        for _ in range(max_attempts):

            x0 = rng.randint(0, max_x0)
            y0 = rng.randint(0, max_y0)

            patch = labels[
                y0:y0 + crop,
                x0:x0 + crop,
            ]

            valid_fraction = float(
                np.mean(patch >= 0)
            )

            if valid_fraction > best_valid_fraction:
                best_valid_fraction = valid_fraction

                best_center = (
                    x0 + crop // 2,
                    y0 + crop // 2,
                )

            if valid_fraction >= min_valid_fraction:

                return (
                    x0 + crop // 2,
                    y0 + crop // 2,
                )

        # Fall back to the best location encountered rather than
        # returning a completely unsupervised crop.
        if best_center is not None:
            return best_center

        return (
            w // 2,
            h // 2,
        )

    def _interior_center(
        self,
        labels: np.ndarray,
        boundary: np.ndarray,
        rng: random.Random,
        max_attempts: int = 40,
    ) -> tuple[int, int] | None:
        """
        Try to choose a crop centered in a geological region but
        away from a true contact.

        This teaches strong same-region affinity and gives the
        model negative boundary examples.
        """

        h, w = labels.shape

        valid_y, valid_x = np.where(
            labels >= 0
        )

        if len(valid_x) == 0:
            return None

        half_window = max(
            12,
            self.crop_size // 8,
        )

        for _ in range(
            max_attempts
        ):

            idx = rng.randrange(
                len(valid_x)
            )

            x = int(
                valid_x[idx]
            )

            y = int(
                valid_y[idx]
            )

            x0 = max(
                0,
                x - half_window,
            )

            x1 = min(
                w,
                x + half_window + 1,
            )

            y0 = max(
                0,
                y - half_window,
            )

            y1 = min(
                h,
                y + half_window + 1,
            )

            local_boundary = (
                boundary[
                    y0:y1,
                    x0:x1,
                ]
            )

            if not np.any(
                local_boundary > 0
            ):
                return x, y

        return None

    # --------------------------------------------------------
    # Crop selection
    # --------------------------------------------------------

    def _choose_crop(
        self,
        labels: np.ndarray,
        boundary: np.ndarray,
        rng: random.Random,
    ) -> tuple[int, int, str]:

        h, w = labels.shape

        p = rng.random()

        if (
            p
            < self.boundary_crop_probability
        ):

            crop_mode = "boundary"

            center = self._boundary_center(
                boundary,
                rng,
            )

        elif (
            p
            < self.boundary_crop_probability
            + self.random_crop_probability
        ):

            crop_mode = "random"

            center = self._random_center(
                labels,
                rng,
            )

        else:

            crop_mode = "interior"

            center = self._interior_center(
                labels,
                boundary,
                rng,
            )

        if center is None:

            crop_mode = "random"

            center = self._random_center(
                labels,
                rng,
            )

        center_x, center_y = center

        x0, y0 = clamp_crop_origin(
            center_x=center_x,
            center_y=center_y,
            crop_size=self.crop_size,
            width=w,
            height=h,
        )

        return (
            x0,
            y0,
            crop_mode,
        )

    # --------------------------------------------------------
    # Item
    # --------------------------------------------------------

    def __getitem__(
        self,
        index: int,
    ) -> dict:

        map_index = (
            index
            // self.samples_per_map
        )

        map_id = self.map_ids[
            map_index
        ]

        rng = self._make_rng(
            index
        )

        # ----------------------------------------------------
        # Load input appearance
        # ----------------------------------------------------

        image, image_mode = (
            self._choose_input_image(
                map_id,
                rng,
            )
        )

        # ----------------------------------------------------
        # Load authoritative unit labels
        # ----------------------------------------------------

        labels_path = (
            self.supervisor_target_root
            / map_id
            / "unit_labels.npy"
        )

        labels = np.load(
            labels_path
        ).astype(
            np.int32,
            copy=False,
        )

        # ----------------------------------------------------
        # Load prebuilt boundary only for crop sampling.
        # Final target is recomputed AFTER geometric transforms.
        # ----------------------------------------------------

        boundary_path = (
            self.affinity_target_root
            / map_id
            / "boundary.npy"
        )

        boundary_sampling = np.load(
            boundary_path
        )

        # ----------------------------------------------------
        # Strict alignment check
        # ----------------------------------------------------

        if (
            image.shape[:2]
            != labels.shape
        ):
            raise RuntimeError(
                f"Alignment error for {map_id}: "
                f"image={image.shape[:2]}, "
                f"labels={labels.shape}. "
                "GeoRegion training must use *_control.png."
            )

        if (
            boundary_sampling.shape
            != labels.shape
        ):
            raise RuntimeError(
                f"Boundary alignment error for {map_id}: "
                f"boundary={boundary_sampling.shape}, "
                f"labels={labels.shape}"
            )

        h, w = labels.shape

        if (
            h < self.crop_size
            or w < self.crop_size
        ):
            raise RuntimeError(
                f"{map_id} is smaller than crop size "
                f"{self.crop_size}: {labels.shape}"
            )

        # ----------------------------------------------------
        # Choose crop
        # ----------------------------------------------------

        x0, y0, crop_mode = (
            self._choose_crop(
                labels,
                boundary_sampling,
                rng,
            )
        )

        x1 = (
            x0
            + self.crop_size
        )

        y1 = (
            y0
            + self.crop_size
        )

        image_crop = image[
            y0:y1,
            x0:x1,
        ].copy()

        labels_crop = labels[
            y0:y1,
            x0:x1,
        ].copy()

        # ----------------------------------------------------
        # Geometry FIRST.
        #
        # We transform labels with the image and then recompute
        # affinity targets. Therefore H/V semantics can never
        # become incorrect after 90-degree rotations.
        # ----------------------------------------------------

        if self.augment:

            image_crop, labels_crop = (
                geometric_augment(
                    image_crop,
                    labels_crop,
                    rng,
                )
            )

        # ----------------------------------------------------
        # Palette randomization
        # ----------------------------------------------------

        palette_randomized = False

        if (
            self.augment
            and rng.random()
            < self.palette_randomization_probability
        ):

            image_crop = (
                random_geological_palette(
                    image_crop,
                    labels_crop,
                    rng,
                )
            )

            palette_randomized = True

        # ----------------------------------------------------
        # Additional appearance augmentation
        # ----------------------------------------------------

        if self.augment:

            if rng.random() < 0.65:
                image_crop = (
                    random_brightness_contrast(
                        image_crop,
                        rng,
                    )
                )

            if rng.random() < 0.45:
                image_crop = (
                    random_saturation(
                        image_crop,
                        rng,
                    )
                )

            if rng.random() < 0.30:
                image_crop = (
                    random_gamma(
                        image_crop,
                        rng,
                    )
                )

            if rng.random() < 0.20:
                image_crop = (
                    random_blur(
                        image_crop,
                        rng,
                    )
                )

            if rng.random() < 0.20:
                image_crop = (
                    random_noise(
                        image_crop,
                        rng,
                    )
                )

        # ----------------------------------------------------
        # Recompute targets AFTER geometry.
        # ----------------------------------------------------

        targets = build_affinity_targets(
            labels_crop
        )

        # ----------------------------------------------------
        # Convert image to CHW float tensor [0,1]
        # ----------------------------------------------------

        image_tensor = torch.from_numpy(
            np.ascontiguousarray(
                image_crop.transpose(
                    2,
                    0,
                    1,
                )
            )
        ).float() / 255.0

        # ----------------------------------------------------
        # Convert targets to 1xHxW
        # ----------------------------------------------------

        def target_tensor(
            name: str,
        ) -> torch.Tensor:

            array = np.ascontiguousarray(
                targets[name][
                    None,
                    ...
                ]
            )

            return torch.from_numpy(
                array
            ).float()

        # ----------------------------------------------------
        # Debug statistics
        # ----------------------------------------------------

        valid_fraction = float(
            targets[
                "valid_pixel"
            ].mean()
        )

        boundary_fraction = float(
            targets[
                "boundary"
            ].mean()
        )

        h_valid = (
            targets[
                "affinity_h_valid"
            ] > 0
        )

        v_valid = (
            targets[
                "affinity_v_valid"
            ] > 0
        )

        if h_valid.any():

            h_same_fraction = float(
                targets[
                    "affinity_h"
                ][h_valid].mean()
            )

        else:

            h_same_fraction = 0.0

        if v_valid.any():

            v_same_fraction = float(
                targets[
                    "affinity_v"
                ][v_valid].mean()
            )

        else:

            v_same_fraction = 0.0

        return {
            "image": image_tensor,

            "valid_pixel": target_tensor(
                "valid_pixel"
            ),

            "affinity_h": target_tensor(
                "affinity_h"
            ),

            "affinity_h_valid": target_tensor(
                "affinity_h_valid"
            ),

            "affinity_v": target_tensor(
                "affinity_v"
            ),

            "affinity_v_valid": target_tensor(
                "affinity_v_valid"
            ),

            "boundary": target_tensor(
                "boundary"
            ),

            "boundary_valid": target_tensor(
                "boundary_valid"
            ),

            "map_id": map_id,

            "image_mode": image_mode,

            "crop_mode": crop_mode,

            "palette_randomized": (
                palette_randomized
            ),

            "crop_xy": torch.tensor(
                [x0, y0],
                dtype=torch.int64,
            ),

            "valid_fraction": torch.tensor(
                valid_fraction,
                dtype=torch.float32,
            ),

            "boundary_fraction": torch.tensor(
                boundary_fraction,
                dtype=torch.float32,
            ),

            "h_same_fraction": torch.tensor(
                h_same_fraction,
                dtype=torch.float32,
            ),

            "v_same_fraction": torch.tensor(
                v_same_fraction,
                dtype=torch.float32,
            ),
        }


# ============================================================
# SPLIT LOADING
# ============================================================

def load_split_map_ids(
    split_path: Path,
    split_name: str,
) -> list[str]:

    data = json.loads(
        Path(split_path).read_text(
            encoding="utf-8"
        )
    )

    # Supports:
    #
    # {
    #   "train": [...]
    # }
    #
    # or:
    #
    # {
    #   "train_maps": [...]
    # }

    candidate_keys = [
        split_name,
        f"{split_name}_maps",
    ]

    for key in candidate_keys:

        if key in data:

            values = data[key]

            return [
                str(value)
                for value in values
            ]

    raise KeyError(
        f"Could not find split '{split_name}' "
        f"in {split_path}. "
        f"Keys: {list(data.keys())}"
    )


# ============================================================
# DEBUG TEST
# ============================================================

if __name__ == "__main__":

    train_map_ids = load_split_map_ids(
        DEFAULT_SPLIT_PATH,
        "train",
    )

    dataset = GeoRegionDataset(
        map_ids=train_map_ids,
        crop_size=256,
        samples_per_map=8,
        augment=True,
        seed=42,
    )

    print(
        "GeoRegion dataset samples:",
        len(dataset),
    )

    mode_counter = Counter()
    crop_counter = Counter()
    palette_counter = Counter()

    sample_count = min(
        32,
        len(dataset),
    )

    for index in range(
        sample_count
    ):

        sample = dataset[index]

        mode = sample[
            "image_mode"
        ]

        crop_mode = sample[
            "crop_mode"
        ]

        palette = bool(
            sample[
                "palette_randomized"
            ]
        )

        mode_counter[
            mode
        ] += 1

        crop_counter[
            crop_mode
        ] += 1

        palette_counter[
            palette
        ] += 1

        print(
            f"{index:02d}",
            sample["map_id"],
            f"image={mode:9s}",
            f"crop={crop_mode:8s}",
            f"palette={palette}",
            f"valid={float(sample['valid_fraction']):.3f}",
            f"boundary={float(sample['boundary_fraction']):.4f}",
            f"h_same={float(sample['h_same_fraction']):.3f}",
            f"v_same={float(sample['v_same_fraction']):.3f}",
            "shape=",
            tuple(sample["image"].shape),
        )

    print()
    print(
        "Input modes:",
        dict(mode_counter),
    )

    print(
        "Crop modes:",
        dict(crop_counter),
    )

    print(
        "Palette randomized:",
        dict(palette_counter),
    )