from __future__ import annotations
import json, random
from pathlib import Path
import cv2, numpy as np, torch
from torch.utils.data import Dataset

class SupervisorMapDataset(Dataset):
    VARIANTS = ("color", "grayscale", "bw", "aged")
    MASKS = ("contact", "fault", "road", "river", "lake", "strike_dip", "clutter")

    def __init__(self, dataset_root, split_path, target_root, split_name,
                 crop_size=512, random_variant=None, fixed_variant="color",
                 augment=None):
        self.dataset_root = Path(dataset_root)
        self.target_root = Path(target_root)
        self.crop_size = int(crop_size)
        self.split_name = split_name
        self.fixed_variant = fixed_variant
        self.random_variant = (split_name == "train") if random_variant is None else random_variant
        self.augment = (split_name == "train") if augment is None else augment

        if split_name not in {"train", "validation", "test"}:
            raise ValueError("split_name must be train, validation, or test")
        if fixed_variant not in self.VARIANTS:
            raise ValueError(f"Unsupported variant: {fixed_variant}")

        data = json.loads(Path(split_path).read_text(encoding="utf-8"))
        self.map_ids = list(data[split_name])
        self._validate()

    def _validate(self):
        missing = []
        for map_id in self.map_ids:
            d = self.dataset_root / map_id
            for variant in self.VARIANTS:
                p = d / f"{map_id}_{variant}_control.png"
                if not p.exists():
                    missing.append(str(p))
            td = self.target_root / map_id
            for name in ("unit_labels.npy", *[f"{m}_mask.png" for m in self.MASKS]):
                p = td / name
                if not p.exists():
                    missing.append(str(p))
        if missing:
            raise FileNotFoundError("Missing files:\n" + "\n".join(missing[:30]))

    def __len__(self):
        return len(self.map_ids)

    def _variant(self):
        return random.choice(self.VARIANTS) if self.random_variant else self.fixed_variant

    def _load(self, map_id, variant):
        image_path = self.dataset_root / map_id / f"{map_id}_{variant}_control.png"
        image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if image is None:
            raise RuntimeError(f"Could not read {image_path}")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        td = self.target_root / map_id
        units = np.load(td / "unit_labels.npy").astype(np.int64)
        masks = {}
        for name in self.MASKS:
            m = cv2.imread(str(td / f"{name}_mask.png"), cv2.IMREAD_GRAYSCALE)
            if m is None:
                raise RuntimeError(f"Could not read {td / f'{name}_mask.png'}")
            masks[name] = (m > 0).astype(np.uint8)

        if image.shape[:2] != units.shape:
            raise ValueError(f"{map_id}: image/units mismatch {image.shape[:2]} vs {units.shape}")
        for name, mask in masks.items():
            if mask.shape != units.shape:
                raise ValueError(f"{map_id}: {name} mismatch {mask.shape} vs {units.shape}")
        return image, units, masks

    def _crop_and_augment(self, image, units, masks):
        h, w = units.shape
        pad_h, pad_w = max(self.crop_size-h, 0), max(self.crop_size-w, 0)
        if pad_h or pad_w:
            image = cv2.copyMakeBorder(image, 0, pad_h, 0, pad_w, cv2.BORDER_REFLECT_101)
            units = cv2.copyMakeBorder(units, 0, pad_h, 0, pad_w, cv2.BORDER_CONSTANT, value=-1)
            masks = {k: cv2.copyMakeBorder(v, 0, pad_h, 0, pad_w, cv2.BORDER_CONSTANT, value=0)
                     for k, v in masks.items()}

        h, w = units.shape
        if self.split_name == "train":
            y, x = random.randint(0, h-self.crop_size), random.randint(0, w-self.crop_size)
        else:
            y, x = (h-self.crop_size)//2, (w-self.crop_size)//2

        image = image[y:y+self.crop_size, x:x+self.crop_size]
        units = units[y:y+self.crop_size, x:x+self.crop_size]
        masks = {k: v[y:y+self.crop_size, x:x+self.crop_size] for k, v in masks.items()}

        if self.augment:
            if random.random() < 0.5:
                image, units = np.flip(image, 1), np.flip(units, 1)
                masks = {k: np.flip(v, 1) for k, v in masks.items()}
            if random.random() < 0.5:
                image, units = np.flip(image, 0), np.flip(units, 0)
                masks = {k: np.flip(v, 0) for k, v in masks.items()}
            k = random.randint(0, 3)
            if k:
                image, units = np.rot90(image, k), np.rot90(units, k)
                masks = {n: np.rot90(v, k) for n, v in masks.items()}

        return np.ascontiguousarray(image), np.ascontiguousarray(units), {
            k: np.ascontiguousarray(v) for k, v in masks.items()
        }

    def __getitem__(self, index):
        map_id = self.map_ids[index]
        variant = self._variant()
        image, units, masks = self._load(map_id, variant)
        image, units, masks = self._crop_and_augment(image, units, masks)

        sample = {
            "image": torch.from_numpy(image.transpose(2, 0, 1)).float() / 255.0,
            "units": torch.from_numpy(units).long(),
            "map_id": map_id,
            "variant": variant,
        }
        sample.update({
            name: torch.from_numpy(mask.astype(np.float32)).unsqueeze(0)
            for name, mask in masks.items()
        })
        return sample

if __name__ == "__main__":
    ds = SupervisorMapDataset(
        dataset_root=r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150",
        split_path=r"C:\PROJECT\GeoMapPrototype\V2\outputs\dataset_splits\supervisor150_split.json",
        target_root=r"C:\PROJECT\GeoMapPrototype\V2\data\supervisor_multilayer_targets",
        split_name="train",
    )
    s = ds[0]
    print("Dataset size:", len(ds))
    print("Map:", s["map_id"], "Variant:", s["variant"])
    print("Image:", tuple(s["image"].shape))
    print("Units:", tuple(s["units"].shape), torch.unique(s["units"]).tolist())
    for name in SupervisorMapDataset.MASKS:
        print(name, tuple(s[name].shape), float(s[name].sum()))