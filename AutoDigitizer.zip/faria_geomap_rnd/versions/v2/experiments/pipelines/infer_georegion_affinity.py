from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import torch


# ============================================================
# PROJECT IMPORTS
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[1]

if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from models.hybrid.georegion_affinity_net import (
    GeoRegionAffinityNet,
)


# ============================================================
# DEFAULTS
# ============================================================

DEFAULT_CHECKPOINT = (
    BASE_DIR
    / "outputs"
    / "checkpoints_georegion_affinity"
    / "georegion_affinity_best.pth"
)

DEFAULT_OUTPUT = (
    BASE_DIR
    / "outputs"
    / "georegion_affinity_inference"
)

HEAD_NAMES = (
    "affinity_h",
    "affinity_v",
    "boundary",
)


# ============================================================
# DEVICE
# ============================================================

def resolve_device(name: str) -> torch.device:

    if name == "cpu":
        return torch.device("cpu")

    if name == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError(
                "CUDA requested but torch.cuda.is_available() is False."
            )

        return torch.device("cuda")

    if name == "auto":
        return torch.device(
            "cuda"
            if torch.cuda.is_available()
            else "cpu"
        )

    raise ValueError(
        f"Unsupported device: {name}"
    )


# ============================================================
# IMAGE LOADING
# ============================================================

def load_rgb(path: Path) -> np.ndarray:

    bgr = cv2.imread(
        str(path),
        cv2.IMREAD_COLOR,
    )

    if bgr is None:
        raise FileNotFoundError(
            f"Could not read image: {path}"
        )

    return cv2.cvtColor(
        bgr,
        cv2.COLOR_BGR2RGB,
    )


# ============================================================
# TILE POSITIONS
# ============================================================

def tile_positions(
    length: int,
    tile_size: int,
    stride: int,
) -> list[int]:

    if length <= tile_size:
        return [0]

    positions = list(
        range(
            0,
            max(
                length - tile_size + 1,
                1,
            ),
            stride,
        )
    )

    final_position = (
        length - tile_size
    )

    if positions[-1] != final_position:
        positions.append(
            final_position
        )

    return positions


# ============================================================
# BLENDING WINDOW
# ============================================================

def make_blending_window(
    tile_size: int,
) -> np.ndarray:
    """
    Smooth overlap blending.

    Uses a 2D Hann-like window but keeps a nonzero floor so
    outer image borders are never given zero weight.
    """

    one_d = np.hanning(
        tile_size
    ).astype(
        np.float32
    )

    one_d = np.maximum(
        one_d,
        0.10,
    )

    window = np.outer(
        one_d,
        one_d,
    )

    return window.astype(
        np.float32
    )


# ============================================================
# PAD TILE
# ============================================================

def pad_tile(
    tile: np.ndarray,
    tile_size: int,
) -> tuple[np.ndarray, int, int]:

    h, w = tile.shape[:2]

    pad_h = max(
        0,
        tile_size - h,
    )

    pad_w = max(
        0,
        tile_size - w,
    )

    if pad_h == 0 and pad_w == 0:
        return tile, h, w

    padded = cv2.copyMakeBorder(
        tile,
        0,
        pad_h,
        0,
        pad_w,
        borderType=cv2.BORDER_REFLECT_101,
    )

    return padded, h, w


# ============================================================
# TILED INFERENCE
# ============================================================

@torch.inference_mode()
def predict_tiled(
    model: torch.nn.Module,
    image_rgb: np.ndarray,
    device: torch.device,
    tile_size: int,
    overlap: int,
) -> dict[str, np.ndarray]:

    h, w = image_rgb.shape[:2]

    if overlap < 0:
        raise ValueError(
            "overlap must be >= 0"
        )

    if overlap >= tile_size:
        raise ValueError(
            "overlap must be smaller than tile_size"
        )

    stride = (
        tile_size - overlap
    )

    y_positions = tile_positions(
        h,
        tile_size,
        stride,
    )

    x_positions = tile_positions(
        w,
        tile_size,
        stride,
    )

    total_tiles = (
        len(y_positions)
        * len(x_positions)
    )

    accumulators = {
        name: np.zeros(
            (h, w),
            dtype=np.float32,
        )
        for name in HEAD_NAMES
    }

    weight_sum = np.zeros(
        (h, w),
        dtype=np.float32,
    )

    blend_window = make_blending_window(
        tile_size
    )

    tile_counter = 0

    for y0 in y_positions:

        for x0 in x_positions:

            y1 = min(
                h,
                y0 + tile_size,
            )

            x1 = min(
                w,
                x0 + tile_size,
            )

            tile = image_rgb[
                y0:y1,
                x0:x1,
            ]

            padded_tile, valid_h, valid_w = (
                pad_tile(
                    tile,
                    tile_size,
                )
            )

            tensor = torch.from_numpy(
                np.ascontiguousarray(
                    padded_tile.transpose(
                        2,
                        0,
                        1,
                    )
                )
            ).float() / 255.0

            tensor = (
                tensor
                .unsqueeze(0)
                .to(device)
            )

            outputs = model(
                tensor
            )

            local_window = blend_window[
                :valid_h,
                :valid_w,
            ]

            for name in HEAD_NAMES:

                probability = torch.sigmoid(
                    outputs[name]
                )[0, 0].detach().cpu().numpy()

                probability = probability[
                    :valid_h,
                    :valid_w,
                ]

                accumulators[name][
                    y0:y1,
                    x0:x1,
                ] += (
                    probability
                    * local_window
                )

            weight_sum[
                y0:y1,
                x0:x1,
            ] += local_window

            tile_counter += 1

            if (
                tile_counter % 10 == 0
                or tile_counter == total_tiles
            ):
                print(
                    f"Tiles: "
                    f"{tile_counter}/"
                    f"{total_tiles}"
                )

    safe_weight = np.maximum(
        weight_sum,
        1e-6,
    )

    probabilities = {
        name: (
            accumulators[name]
            / safe_weight
        )
        for name in HEAD_NAMES
    }

    return probabilities


# ============================================================
# AFFINITY -> DIFFERENCE
# ============================================================

def build_difference_probability(
    probabilities: dict[str, np.ndarray],
) -> tuple[np.ndarray, np.ndarray]:

    h_same = probabilities[
        "affinity_h"
    ]

    v_same = probabilities[
        "affinity_v"
    ]

    h_different = (
        1.0 - h_same
    )

    v_different = (
        1.0 - v_same
    )

    return (
        h_different.astype(
            np.float32
        ),
        v_different.astype(
            np.float32
        ),
    )


# ============================================================
# AFFINITY-DERIVED BOUNDARY
# ============================================================

def build_affinity_boundary_probability(
    h_different: np.ndarray,
    v_different: np.ndarray,
) -> np.ndarray:
    """
    Convert directional difference probabilities into one HxW
    geological-boundary probability.

    A pixel receives evidence from:
      - its right neighbor relationship
      - its left neighbor relationship
      - its bottom neighbor relationship
      - its top neighbor relationship
    """

    h, w = h_different.shape

    result = np.zeros(
        (h, w),
        dtype=np.float32,
    )

    result = np.maximum(
        result,
        h_different,
    )

    shifted = np.zeros_like(
        h_different
    )

    shifted[:, 1:] = (
        h_different[:, :-1]
    )

    result = np.maximum(
        result,
        shifted,
    )

    result = np.maximum(
        result,
        v_different,
    )

    shifted = np.zeros_like(
        v_different
    )

    shifted[1:, :] = (
        v_different[:-1, :]
    )

    result = np.maximum(
        result,
        shifted,
    )

    return result


# ============================================================
# COMBINED BOUNDARY
# ============================================================

def combine_boundary_evidence(
    direct_boundary: np.ndarray,
    affinity_boundary: np.ndarray,
    direct_weight: float,
) -> np.ndarray:

    direct_weight = float(
        direct_weight
    )

    affinity_weight = (
        1.0 - direct_weight
    )

    combined = (
        direct_weight
        * direct_boundary
        + affinity_weight
        * affinity_boundary
    )

    return np.clip(
        combined,
        0.0,
        1.0,
    ).astype(
        np.float32
    )


# ============================================================
# SAVING
# ============================================================

def save_probability(
    path: Path,
    probability: np.ndarray,
) -> None:

    image = np.clip(
        probability * 255.0,
        0,
        255,
    ).astype(
        np.uint8
    )

    if not cv2.imwrite(
        str(path),
        image,
    ):
        raise RuntimeError(
            f"Could not write {path}"
        )


def save_binary(
    path: Path,
    probability: np.ndarray,
    threshold: float,
) -> np.ndarray:

    mask = (
        probability >= threshold
    ).astype(
        np.uint8
    )

    if not cv2.imwrite(
        str(path),
        mask * 255,
    ):
        raise RuntimeError(
            f"Could not write {path}"
        )

    return mask


# ============================================================
# OVERLAY
# ============================================================

def make_overlay(
    image_rgb: np.ndarray,
    mask: np.ndarray,
) -> np.ndarray:

    image_bgr = cv2.cvtColor(
        image_rgb,
        cv2.COLOR_RGB2BGR,
    )

    overlay = image_bgr.copy()

    # Red boundary.
    overlay[
        mask > 0
    ] = (
        0,
        0,
        255,
    )

    return overlay


# ============================================================
# MAIN
# ============================================================

def main() -> None:

    parser = argparse.ArgumentParser(
        description=(
            "Run tiled full-map inference with "
            "GeoRegionAffinityNet."
        )
    )

    parser.add_argument(
        "--input",
        type=Path,
        required=True,
    )

    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=DEFAULT_CHECKPOINT,
    )

    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
    )

    parser.add_argument(
        "--device",
        choices=[
            "auto",
            "cpu",
            "cuda",
        ],
        default="auto",
    )

    parser.add_argument(
        "--tile-size",
        type=int,
        default=None,
        help=(
            "Defaults to the training crop size "
            "stored in the checkpoint."
        ),
    )

    parser.add_argument(
        "--overlap",
        type=int,
        default=64,
    )

    parser.add_argument(
        "--boundary-threshold",
        type=float,
        default=0.50,
    )

    parser.add_argument(
        "--affinity-threshold",
        type=float,
        default=0.50,
    )

    parser.add_argument(
        "--combined-threshold",
        type=float,
        default=0.50,
    )

    parser.add_argument(
        "--direct-boundary-weight",
        type=float,
        default=0.60,
    )

    args = parser.parse_args()

    device = resolve_device(
        args.device
    )

    checkpoint = torch.load(
        args.checkpoint,
        map_location=device,
        weights_only=False,
    )

    base_channels = int(
        checkpoint.get(
            "base_channels",
            16,
        )
    )

    training_crop_size = int(
        checkpoint.get(
            "crop_size",
            256,
        )
    )

    tile_size = (
        training_crop_size
        if args.tile_size is None
        else int(
            args.tile_size
        )
    )

    model = GeoRegionAffinityNet(
        base_channels=base_channels
    ).to(device)

    model.load_state_dict(
        checkpoint[
            "model_state_dict"
        ]
    )

    model.eval()

    image_rgb = load_rgb(
        args.input
    )

    stem = args.input.stem

    output_dir = (
        args.output
        / stem
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    cv2.imwrite(
        str(
            output_dir
            / "original.png"
        ),
        cv2.cvtColor(
            image_rgb,
            cv2.COLOR_RGB2BGR,
        ),
    )

    print(
        "Device:",
        device,
    )

    print(
        "Checkpoint:",
        args.checkpoint,
    )

    print(
        "Checkpoint epoch:",
        checkpoint.get(
            "epoch"
        ),
    )

    print(
        "Checkpoint validation score:",
        checkpoint.get(
            "validation_score"
        ),
    )

    print(
        "Base channels:",
        base_channels,
    )

    print(
        "Training crop size:",
        training_crop_size,
    )

    print(
        "Input:",
        args.input,
    )

    print(
        "Shape:",
        image_rgb.shape,
    )

    print(
        "Tile size:",
        tile_size,
    )

    print(
        "Overlap:",
        args.overlap,
    )

    print(
        "Boundary threshold:",
        args.boundary_threshold,
    )

    print(
        "Affinity threshold:",
        args.affinity_threshold,
    )

    print(
        "Combined threshold:",
        args.combined_threshold,
    )

    print()

    start_time = time.time()

    probabilities = predict_tiled(
        model=model,
        image_rgb=image_rgb,
        device=device,
        tile_size=tile_size,
        overlap=args.overlap,
    )

    runtime = (
        time.time()
        - start_time
    )

    boundary_probability = (
        probabilities[
            "boundary"
        ]
    )

    (
        h_different_probability,
        v_different_probability,
    ) = build_difference_probability(
        probabilities
    )

    affinity_boundary_probability = (
        build_affinity_boundary_probability(
            h_different_probability,
            v_different_probability,
        )
    )

    combined_probability = (
        combine_boundary_evidence(
            direct_boundary=(
                boundary_probability
            ),
            affinity_boundary=(
                affinity_boundary_probability
            ),
            direct_weight=(
                args.direct_boundary_weight
            ),
        )
    )

    # --------------------------------------------------------
    # SAVE RAW PROBABILITY OUTPUTS
    # --------------------------------------------------------

    save_probability(
        output_dir
        / "boundary_probability.png",
        boundary_probability,
    )

    save_probability(
        output_dir
        / "affinity_h_different_probability.png",
        h_different_probability,
    )

    save_probability(
        output_dir
        / "affinity_v_different_probability.png",
        v_different_probability,
    )

    save_probability(
        output_dir
        / "affinity_boundary_probability.png",
        affinity_boundary_probability,
    )

    save_probability(
        output_dir
        / "combined_boundary_probability.png",
        combined_probability,
    )

    # --------------------------------------------------------
    # SAVE RAW THRESHOLDED OUTPUTS
    # --------------------------------------------------------

    boundary_mask = save_binary(
        output_dir
        / "boundary_binary.png",
        boundary_probability,
        args.boundary_threshold,
    )

    affinity_boundary_mask = (
        save_binary(
            output_dir
            / "affinity_boundary_binary.png",
            affinity_boundary_probability,
            args.affinity_threshold,
        )
    )

    combined_mask = save_binary(
        output_dir
        / "combined_boundary_binary.png",
        combined_probability,
        args.combined_threshold,
    )

    # --------------------------------------------------------
    # OVERLAYS
    # --------------------------------------------------------

    boundary_overlay = make_overlay(
        image_rgb,
        boundary_mask,
    )

    cv2.imwrite(
        str(
            output_dir
            / "overlay_boundary_only.png"
        ),
        boundary_overlay,
    )

    affinity_overlay = make_overlay(
        image_rgb,
        affinity_boundary_mask,
    )

    cv2.imwrite(
        str(
            output_dir
            / "overlay_affinity_only.png"
        ),
        affinity_overlay,
    )

    combined_overlay = make_overlay(
        image_rgb,
        combined_mask,
    )

    cv2.imwrite(
        str(
            output_dir
            / "overlay_combined.png"
        ),
        combined_overlay,
    )

    # --------------------------------------------------------
    # REPORT
    # --------------------------------------------------------

    report = {
        "input": str(
            args.input
        ),

        "checkpoint": str(
            args.checkpoint
        ),

        "checkpoint_epoch": (
            checkpoint.get(
                "epoch"
            )
        ),

        "checkpoint_validation_score": (
            checkpoint.get(
                "validation_score"
            )
        ),

        "image_shape": [
            int(
                image_rgb.shape[0]
            ),
            int(
                image_rgb.shape[1]
            ),
            int(
                image_rgb.shape[2]
            ),
        ],

        "tile_size": int(
            tile_size
        ),

        "overlap": int(
            args.overlap
        ),

        "runtime_seconds": float(
            runtime
        ),

        "thresholds": {
            "boundary": float(
                args.boundary_threshold
            ),
            "affinity": float(
                args.affinity_threshold
            ),
            "combined": float(
                args.combined_threshold
            ),
        },

        "direct_boundary_weight": float(
            args.direct_boundary_weight
        ),

        "mean_probabilities": {
            "boundary": float(
                boundary_probability.mean()
            ),
            "affinity_h_different": float(
                h_different_probability.mean()
            ),
            "affinity_v_different": float(
                v_different_probability.mean()
            ),
            "affinity_boundary": float(
                affinity_boundary_probability.mean()
            ),
            "combined": float(
                combined_probability.mean()
            ),
        },

        "foreground_fractions": {
            "boundary": float(
                boundary_mask.mean()
            ),
            "affinity_boundary": float(
                affinity_boundary_mask.mean()
            ),
            "combined": float(
                combined_mask.mean()
            ),
        },
    }

    (
        output_dir
        / "run_report.json"
    ).write_text(
        json.dumps(
            report,
            indent=2,
        ),
        encoding="utf-8",
    )

    print()
    print(
        f"Completed in "
        f"{runtime:.1f}s"
    )

    print(
        "Boundary fraction:",
        f"{boundary_mask.mean():.3%}"
    )

    print(
        "Affinity-boundary fraction:",
        f"{affinity_boundary_mask.mean():.3%}"
    )

    print(
        "Combined fraction:",
        f"{combined_mask.mean():.3%}"
    )

    print(
        "Output:",
        output_dir,
    )


if __name__ == "__main__":
    main()