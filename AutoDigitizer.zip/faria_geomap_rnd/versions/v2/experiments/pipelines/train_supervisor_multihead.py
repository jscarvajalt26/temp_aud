from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

BASE_DIR = Path(__file__).resolve().parents[1]

if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from datasets.supervisor_dataset import SupervisorMapDataset
from models.hybrid.multihead_geomap_net import HEAD_NAMES, MultiHeadGeoMapNet

DEFAULT_DATASET_ROOT = Path(r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150")
DEFAULT_TARGET_ROOT = BASE_DIR / "data" / "supervisor_multilayer_targets"
DEFAULT_SPLIT_PATH = BASE_DIR / "outputs" / "dataset_splits" / "supervisor150_split.json"
DEFAULT_CHECKPOINT_DIR = BASE_DIR / "outputs" / "checkpoints_supervisor_multihead_v3"
SEED = 42


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def choose_device(requested: str) -> torch.device:
    requested = requested.lower().strip()
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but no CUDA device is available.")
        return torch.device("cuda")
    if requested == "cpu":
        return torch.device("cpu")
    raise ValueError("device must be one of: auto, cpu, cuda")


class BinaryDiceLoss(nn.Module):
    def __init__(self, smooth: float = 1.0) -> None:
        super().__init__()
        self.smooth = smooth

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        probabilities = torch.sigmoid(logits)
        dims = (0, 2, 3)
        intersection = (probabilities * targets).sum(dim=dims)
        denominator = probabilities.sum(dim=dims) + targets.sum(dim=dims)
        dice = (2.0 * intersection + self.smooth) / (denominator + self.smooth)
        return 1.0 - dice.mean()


class MultiHeadLoss(nn.Module):
    def __init__(
        self,
        pos_weights: dict[str, float],
        bce_weight: float = 0.35,
        dice_weight: float = 0.65,
        hard_negative_loss_scale: float = 0.35,
    ) -> None:
        super().__init__()

        self.bce_weight = float(bce_weight)
        self.dice_weight = float(dice_weight)
        self.hard_negative_loss_scale = float(hard_negative_loss_scale)

        self.dice = BinaryDiceLoss()

        self.bce = nn.ModuleDict({
            head: nn.BCEWithLogitsLoss(
                pos_weight=torch.tensor(
                    [float(pos_weights.get(head, 1.0))],
                    dtype=torch.float32,
                )
            )
            for head in HEAD_NAMES
        })

    def forward(
        self,
        outputs: dict[str, torch.Tensor],
        batch: dict[str, object],
    ):
        device = next(iter(outputs.values())).device

        total_loss = torch.zeros((), device=device)
        details = {}

        for head in HEAD_NAMES:
            logits = outputs[head]
            targets = batch[head]

            if not isinstance(targets, torch.Tensor):
                raise TypeError(
                    f"Batch target {head} is not a tensor."
                )

            bce_loss = self.bce[head](
                logits,
                targets,
            )

            dice_loss = self.dice(
                logits,
                targets,
            )

            head_loss = (
                self.bce_weight * bce_loss
                + self.dice_weight * dice_loss
            )

            total_loss = total_loss + head_loss

            details[f"{head}_loss"] = float(
                head_loss.detach().item()
            )

        total_loss = total_loss / len(HEAD_NAMES)

        # ----------------------------------------------------
        # V3: reduce the influence of page-layout hard negatives
        # ----------------------------------------------------
        sample_modes = batch.get("sample_mode")

        if sample_modes is not None:
            if isinstance(sample_modes, str):
                sample_modes = [sample_modes]

            hard_negative_count = sum(
                str(mode) == "hard_negative"
                for mode in sample_modes
            )

            if hard_negative_count == len(sample_modes):
                total_loss = (
                    total_loss
                    * self.hard_negative_loss_scale
                )

        details["total_loss"] = float(
            total_loss.detach().item()
        )

        return total_loss, details

@torch.no_grad()
def estimate_pos_weights_from_full_masks(target_root: Path, split_path: Path, split_name: str = "train") -> dict[str, float]:
    split_data = json.loads(split_path.read_text(encoding="utf-8"))
    map_ids = list(split_data[split_name])

    positives = {head: 0 for head in HEAD_NAMES}
    totals = {head: 0 for head in HEAD_NAMES}

    print("Estimating positive-class weights from full training masks...")

    for map_index, map_id in enumerate(map_ids, start=1):
        target_directory = target_root / map_id

        for head in HEAD_NAMES:
            mask_path = target_directory / f"{head}_mask.png"
            mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
            if mask is None:
                raise RuntimeError(f"Could not read {mask_path}")

            binary = mask > 0
            positives[head] += int(binary.sum())
            totals[head] += int(binary.size)

        if map_index == len(map_ids) or map_index % 25 == 0:
            print(f"  masks: {map_index}/{len(map_ids)}")

    weights = {}

    for head in HEAD_NAMES:
        positive = float(positives[head])
        total = float(totals[head])
        negative = max(total - positive, 1.0)
        ratio = negative / max(positive, 1.0)
        weight = float(np.clip(ratio ** 0.25, 1.0, 8.0))
        weights[head] = weight
        fraction = positive / max(total, 1.0)
        print(f"{head:12s} positive_fraction={fraction:.6f} pos_weight={weight:.3f}")

    return weights


def move_batch_to_device(batch, device):
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


def create_metric_accumulator():
    return {
        head: {"tp": 0, "fp": 0, "fn": 0, "tn": 0}
        for head in HEAD_NAMES
    }


@torch.no_grad()
def accumulate_binary_metrics(accumulator, logits, targets, head, threshold=0.5):
    predictions = torch.sigmoid(logits) >= threshold
    truth = targets >= 0.5

    accumulator[head]["tp"] += int((predictions & truth).sum().item())
    accumulator[head]["fp"] += int((predictions & (~truth)).sum().item())
    accumulator[head]["fn"] += int(((~predictions) & truth).sum().item())
    accumulator[head]["tn"] += int(((~predictions) & (~truth)).sum().item())


def finalize_metrics(accumulator):
    results = {}

    for head in HEAD_NAMES:
        tp = accumulator[head]["tp"]
        fp = accumulator[head]["fp"]
        fn = accumulator[head]["fn"]
        tn = accumulator[head]["tn"]

        iou_denom = tp + fp + fn
        dice_denom = 2 * tp + fp + fn
        precision_denom = tp + fp
        recall_denom = tp + fn

        iou = float("nan") if iou_denom == 0 else tp / iou_denom
        dice = float("nan") if dice_denom == 0 else 2 * tp / dice_denom
        precision = float("nan") if precision_denom == 0 else tp / precision_denom
        recall = float("nan") if recall_denom == 0 else tp / recall_denom
        pred_fg = (tp + fp) / max(tp + fp + fn + tn, 1)

        results[head] = {
            "iou": float(iou),
            "dice": float(dice),
            "precision": float(precision),
            "recall": float(recall),
            "predicted_foreground_fraction": float(pred_fg),
        }

    return results


def mean_head_iou(metrics) -> float:
    values = [
        metrics[head]["iou"]
        for head in HEAD_NAMES
        if not np.isnan(metrics[head]["iou"])
    ]
    return 0.0 if not values else float(np.mean(values))


def run_epoch(model, loader, criterion, device, optimizer, scaler, progress_label):
    training = optimizer is not None
    model.train() if training else model.eval()

    total_loss = 0.0
    batch_count = 0
    metrics_acc = create_metric_accumulator()
    sample_mode_counts = {}

    context = torch.enable_grad() if training else torch.no_grad()

    with context:
        for batch_index, batch in enumerate(loader, start=1):
            raw_modes = batch.get("sample_mode")
            if raw_modes is not None:
                if isinstance(raw_modes, str):
                    raw_modes = [raw_modes]
                for mode in raw_modes:
                    mode = str(mode)
                    sample_mode_counts[mode] = sample_mode_counts.get(mode, 0) + 1

            batch = move_batch_to_device(batch, device)
            images = batch["image"]

            if not isinstance(images, torch.Tensor):
                raise TypeError("batch['image'] is not a tensor")

            if training:
                optimizer.zero_grad(set_to_none=True)

            use_amp = device.type == "cuda"

            with torch.amp.autocast(device_type=device.type, enabled=use_amp):
                outputs = model(images)
                loss, _ = criterion(outputs, batch)

            if training:
                if scaler is not None and use_amp:
                    scaler.scale(loss).backward()
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    optimizer.step()

            total_loss += float(loss.detach().item())
            batch_count += 1

            with torch.no_grad():
                for head in HEAD_NAMES:
                    accumulate_binary_metrics(
                        metrics_acc,
                        outputs[head],
                        batch[head],
                        head,
                    )

            if batch_index == len(loader) or batch_index % 100 == 0:
                print(f"  {progress_label}: {batch_index}/{len(loader)}")

    metrics = finalize_metrics(metrics_acc)
    metrics["_sample_mode_counts"] = sample_mode_counts
    return total_loss / max(batch_count, 1), metrics


def save_checkpoint(path, model, optimizer, epoch, validation_loss, validation_metrics, pos_weights, args):
    payload = {
        "schema_version": "1.2.0",
        "model_name": "multihead_geomap_net",
        "experiment": "hard_negative_sampling",
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "epoch": int(epoch),
        "validation_loss": float(validation_loss),
        "validation_mean_head_iou": float(mean_head_iou(validation_metrics)),
        "validation_metrics": validation_metrics,
        "pos_weights": pos_weights,
        "head_names": list(HEAD_NAMES),
        "base_channels": int(args.base_channels),
        "crop_size": int(args.crop_size),
        "samples_per_map": int(args.samples_per_map),
        "feature_crop_probability": float(args.feature_crop_probability),
        "hard_negative_crop_probability": float(args.hard_negative_crop_probability),
        "validation_grid_size": int(args.validation_grid_size),
    }
    torch.save(payload, path)


def build_parser():
    parser = argparse.ArgumentParser(
        description=(
            "Train Supervisor150 multi-head geological map segmentation "
            "with feature-aware and hard-negative page-layout sampling."
        )
    )

    parser.add_argument("--dataset-root", type=Path, default=DEFAULT_DATASET_ROOT)
    parser.add_argument("--target-root", type=Path, default=DEFAULT_TARGET_ROOT)
    parser.add_argument("--split-path", type=Path, default=DEFAULT_SPLIT_PATH)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_CHECKPOINT_DIR)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--crop-size", type=int, default=256)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--learning-rate", type=float, default=3e-5)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--base-channels", type=int, default=16)
    parser.add_argument("--patience", type=int, default=5)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--samples-per-map", type=int, default=8)
    parser.add_argument("--feature-crop-probability", type=float, default=0.70)
    parser.add_argument("--hard-negative-crop-probability", type=float, default=0.10)
    parser.add_argument(
    "--hard-negative-loss-scale",
    type=float,
    default=0.35,
)

    parser.add_argument(
    "--init-checkpoint",
    type=Path,
    default=None,
)
    parser.add_argument("--validation-grid-size", type=int, default=3)

    return parser


def main():
    args = build_parser().parse_args()

    if args.samples_per_map < 1:
        raise ValueError("samples-per-map must be >= 1")

    if args.validation_grid_size < 1:
        raise ValueError("validation-grid-size must be >= 1")

    if not 0.0 <= args.feature_crop_probability <= 1.0:
        raise ValueError("feature-crop-probability must be between 0 and 1")

    if not 0.0 <= args.hard_negative_crop_probability <= 1.0:
        raise ValueError("hard-negative-crop-probability must be between 0 and 1")

    if args.feature_crop_probability + args.hard_negative_crop_probability > 1.0:
        raise ValueError(
            "feature-crop-probability + hard-negative-crop-probability must be <= 1"
        )

    set_seed(SEED)

    device = choose_device(args.device)
    dataset_root = args.dataset_root.resolve()
    target_root = args.target_root.resolve()
    split_path = args.split_path.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    print("Device:", device)
    print("Dataset root:", dataset_root)
    print("Target root:", target_root)
    print("Split path:", split_path)
    print("Feature crop probability:", args.feature_crop_probability)
    print("Hard-negative crop probability:", args.hard_negative_crop_probability)
    print(
        "Random crop probability:",
        1.0
        - args.feature_crop_probability
        - args.hard_negative_crop_probability,
    )

    train_dataset = SupervisorMapDataset(
        dataset_root=dataset_root,
        split_path=split_path,
        target_root=target_root,
        split_name="train",
        crop_size=args.crop_size,
        random_variant=True,
        fixed_variant="color",
        augment=True,
        samples_per_map=args.samples_per_map,
        feature_crop_probability=args.feature_crop_probability,
        hard_negative_crop_probability=args.hard_negative_crop_probability,
        validation_grid_size=args.validation_grid_size,
    )

    validation_dataset = SupervisorMapDataset(
        dataset_root=dataset_root,
        split_path=split_path,
        target_root=target_root,
        split_name="validation",
        crop_size=args.crop_size,
        random_variant=False,
        fixed_variant="color",
        augment=False,
        samples_per_map=1,
        feature_crop_probability=0.0,
        hard_negative_crop_probability=0.0,
        validation_grid_size=args.validation_grid_size,
    )

    print("Train maps:", len(train_dataset.map_ids))
    print("Train samples/epoch:", len(train_dataset))
    print("Validation maps:", len(validation_dataset.map_ids))
    print("Validation samples:", len(validation_dataset))

    pos_weights = estimate_pos_weights_from_full_masks(
        target_root=target_root,
        split_path=split_path,
        split_name="train",
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=(device.type == "cuda"),
    )

    validation_loader = DataLoader(
        validation_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=(device.type == "cuda"),
    )

    model = MultiHeadGeoMapNet(
        in_channels=3,
        base_channels=args.base_channels,
    ).to(device)

    # ============================================================
# V3 WARM START
# ============================================================

    if args.init_checkpoint is not None:
     init_checkpoint = args.init_checkpoint.resolve()

    if not init_checkpoint.exists():
        raise FileNotFoundError(
            f"Initial checkpoint does not exist: "
            f"{init_checkpoint}"
        )

    print()
    print("Loading initial checkpoint:")
    print(init_checkpoint)

    checkpoint = torch.load(
        init_checkpoint,
        map_location=device,
        weights_only=False,
    )

    checkpoint_base_channels = checkpoint.get(
        "base_channels"
    )

    if (
        checkpoint_base_channels is not None
        and int(checkpoint_base_channels)
        != int(args.base_channels)
    ):
        raise ValueError(
            "Checkpoint architecture mismatch: "
            f"checkpoint base_channels="
            f"{checkpoint_base_channels}, "
            f"requested base_channels="
            f"{args.base_channels}"
        )

    model.load_state_dict(
        checkpoint["model_state_dict"],
        strict=True,
    )

    print(
        "Loaded checkpoint epoch:",
        checkpoint.get("epoch", "unknown"),
    )

    print(
        "Checkpoint validation mean IoU:",
        checkpoint.get(
            "validation_mean_head_iou",
            "unknown",
        ),
    )

    print(
        "Warm start complete. "
        "Optimizer will start fresh."
    )

    criterion = MultiHeadLoss(
    pos_weights=pos_weights,
    hard_negative_loss_scale=args.hard_negative_loss_scale,
).to(device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
    )

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=0.5,
        patience=2,
    )

    scaler = (
        torch.amp.GradScaler("cuda")
        if device.type == "cuda"
        else None
    )

    best_iou = -1.0
    epochs_without_improvement = 0

    best_path = output_dir / "multihead_geomap_best.pth"
    last_path = output_dir / "multihead_geomap_last.pth"

    for epoch in range(1, args.epochs + 1):
        epoch_start = time.perf_counter()

        print()
        print("=" * 72)
        print(f"Epoch {epoch:03d}/{args.epochs}")

        train_loss, train_metrics = run_epoch(
            model=model,
            loader=train_loader,
            criterion=criterion,
            device=device,
            optimizer=optimizer,
            scaler=scaler,
            progress_label="train",
        )

        validation_loss, validation_metrics = run_epoch(
            model=model,
            loader=validation_loader,
            criterion=criterion,
            device=device,
            optimizer=None,
            scaler=None,
            progress_label="validation",
        )

        validation_mean_iou = mean_head_iou(validation_metrics)
        scheduler.step(validation_mean_iou)

        elapsed = time.perf_counter() - epoch_start

        print(
            "Train sample modes:",
            train_metrics.get(
                "_sample_mode_counts",
                {},
            ),
        )
        print(f"Train loss: {train_loss:.5f}")
        print(f"Validation loss: {validation_loss:.5f}")
        print(
            "Validation mean head IoU: "
            f"{validation_mean_iou:.5f}"
        )

        for head in HEAD_NAMES:
            metric = validation_metrics[head]
            print(
                f"  {head:12s} "
                f"IoU={metric['iou']:.4f} "
                f"Dice={metric['dice']:.4f} "
                f"P={metric['precision']:.4f} "
                f"R={metric['recall']:.4f} "
                f"pred_fg={metric['predicted_foreground_fraction']:.3%}"
            )

        print(
            f"Epoch runtime: "
            f"{elapsed:.1f}s"
        )

        save_checkpoint(
            path=last_path,
            model=model,
            optimizer=optimizer,
            epoch=epoch,
            validation_loss=validation_loss,
            validation_metrics=validation_metrics,
            pos_weights=pos_weights,
            args=args,
        )

        if validation_mean_iou > best_iou:
            best_iou = validation_mean_iou
            epochs_without_improvement = 0

            save_checkpoint(
                path=best_path,
                model=model,
                optimizer=optimizer,
                epoch=epoch,
                validation_loss=validation_loss,
                validation_metrics=validation_metrics,
                pos_weights=pos_weights,
                args=args,
            )

            print(
                "Saved best checkpoint:",
                best_path,
            )

        else:
            epochs_without_improvement += 1
            print(
                "No improvement:",
                epochs_without_improvement,
                "epoch(s)",
            )

        if epochs_without_improvement >= args.patience:
            print(
                "Early stopping."
            )
            break

    print()
    print(
        "Training complete."
    )
    print(
        "Best checkpoint:",
        best_path,
    )
    print(
        "Best validation mean head IoU:",
        best_iou,
    )


if __name__ == "__main__":
    main()