from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import rasterio
import shapefile
from rasterio.transform import rowcol


MAP_ID = "map_0000"

DATASET_ROOT = Path(
    r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150"
)

ALIGNMENT_ROOT = Path(
    r"C:\PROJECT\GeoMapPrototype\V2\outputs\alignment_debug"
)

OUTPUT_ROOT = Path(
    r"C:\PROJECT\GeoMapPrototype\V2\outputs\alignment_vector_check"
)


def split_shape_parts(
    shape: shapefile.Shape,
) -> list[list[tuple[float, float]]]:
    if not shape.points:
        return []

    starts = list(shape.parts)

    if not starts:
        starts = [0]

    starts.append(len(shape.points))

    parts = []

    for index in range(len(starts) - 1):
        start = starts[index]
        end = starts[index + 1]

        points = shape.points[start:end]

        if points:
            parts.append(points)

    return parts


def world_points_to_pixels(
    points: list[tuple[float, float]],
    transform,
) -> np.ndarray:
    pixel_points = []

    for world_x, world_y in points:
        row, column = rowcol(
            transform,
            world_x,
            world_y,
        )

        pixel_points.append(
            [
                int(column),
                int(row),
            ]
        )

    return np.asarray(
        pixel_points,
        dtype=np.int32,
    ).reshape(-1, 1, 2)


def draw_vector_layer(
    image: np.ndarray,
    shapefile_path: Path,
    transform,
    color: tuple[int, int, int],
    thickness: int,
    close_polygon: bool,
) -> int:
    reader = shapefile.Reader(
        str(shapefile_path)
    )

    count = 0

    for shape in reader.shapes():
        for part in split_shape_parts(shape):
            pixels = world_points_to_pixels(
                part,
                transform,
            )

            minimum_points = (
                3 if close_polygon else 2
            )

            if len(pixels) < minimum_points:
                continue

            cv2.polylines(
                image,
                [pixels],
                isClosed=close_polygon,
                color=color,
                thickness=thickness,
                lineType=cv2.LINE_AA,
            )

        count += 1

    reader.close()

    return count


def main() -> None:
    map_directory = (
        DATASET_ROOT
        / MAP_ID
    )

    aligned_path = (
        ALIGNMENT_ROOT
        / MAP_ID
        / "aligned.png"
    )

    geotiff_path = (
        map_directory
        / f"{MAP_ID}_color.tif"
    )

    polygon_path = (
        map_directory
        / f"{MAP_ID}_polygons.shp"
    )

    fault_path = (
        map_directory
        / f"{MAP_ID}_faults.shp"
    )

    aligned = cv2.imread(
        str(aligned_path),
        cv2.IMREAD_COLOR,
    )

    if aligned is None:
        raise FileNotFoundError(
            f"Could not read aligned image: {aligned_path}"
        )

    with rasterio.open(
        geotiff_path
    ) as dataset:
        transform = dataset.transform

        expected_shape = (
            dataset.height,
            dataset.width,
        )

    if aligned.shape[:2] != expected_shape:
        raise ValueError(
            "Aligned image shape does not match GeoTIFF grid: "
            f"{aligned.shape[:2]} versus {expected_shape}"
        )

    overlay = aligned.copy()

    polygon_count = draw_vector_layer(
        image=overlay,
        shapefile_path=polygon_path,
        transform=transform,
        color=(0, 255, 0),
        thickness=2,
        close_polygon=True,
    )

    fault_count = draw_vector_layer(
        image=overlay,
        shapefile_path=fault_path,
        transform=transform,
        color=(0, 0, 255),
        thickness=3,
        close_polygon=False,
    )

    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_path = (
        OUTPUT_ROOT
        / f"{MAP_ID}_alignment_vectors.png"
    )

    cv2.imwrite(
        str(output_path),
        overlay,
    )

    print("Map:", MAP_ID)
    print("Aligned shape:", aligned.shape)
    print("Polygon features:", polygon_count)
    print("Fault features:", fault_count)
    print("Saved:", output_path)

if __name__ == "__main__":
    main()