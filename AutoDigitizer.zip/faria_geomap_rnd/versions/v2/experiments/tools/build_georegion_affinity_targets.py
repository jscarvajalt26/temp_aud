from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np


# ============================================================
# DEFAULT PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"C:\PROJECT\GeoMapPrototype\V2"
)

DEFAULT_SOURCE_ROOT = (
    PROJECT_ROOT
    / "data"
    / "supervisor_multilayer_targets"
)

DEFAULT_OUTPUT_ROOT = (
    PROJECT_ROOT
    / "data"
    / "georegion_affinity_targets"
)


# ============================================================
# HELPERS
# ============================================================

def save_binary(
    path: Path,
    array: np.ndarray,
) -> None:

    image = (
        (array > 0)
        .astype(np.uint8)
        * 255
    )

    if not cv2.imwrite(
        str(path),
        image,
    ):
        raise RuntimeError(
            f"Could not write {path}"
        )


def save_tristate_affinity(
    path: Path,
    affinity: np.ndarray,
    valid: np.ndarray,
) -> None:
    """
    Debug preview only.

    255 = same geological region
      0 = different geological region
    127 = ignore / unknown pair
    """

    preview = np.full(
        affinity.shape,
        127,
        dtype=np.uint8,
    )

    preview[
        valid & (affinity == 1)
    ] = 255

    preview[
        valid & (affinity == 0)
    ] = 0

    if not cv2.imwrite(
        str(path),
        preview,
    ):
        raise RuntimeError(
            f"Could not write {path}"
        )


# ============================================================
# TARGET GENERATION
# ============================================================

def build_targets(
    unit_labels: np.ndarray,
) -> dict[str, np.ndarray]:

    if unit_labels.ndim != 2:
        raise ValueError(
            "unit_labels must be HxW."
        )

    labels = unit_labels.astype(
        np.int32,
        copy=False,
    )

    h, w = labels.shape

    # --------------------------------------------------------
    # Valid geological-unit pixels
    # --------------------------------------------------------

    valid_pixel = (
        labels >= 0
    )

    # --------------------------------------------------------
    # Horizontal affinity
    #
    # affinity_h[y, x] describes:
    #
    #     labels[y, x]  <->  labels[y, x + 1]
    #
    # Last column has no right neighbor and is invalid.
    # --------------------------------------------------------

    affinity_h = np.zeros(
        (h, w),
        dtype=np.uint8,
    )

    valid_h = np.zeros(
        (h, w),
        dtype=bool,
    )

    left = labels[:, :-1]
    right = labels[:, 1:]

    pair_valid_h = (
        (left >= 0)
        & (right >= 0)
    )

    same_h = (
        pair_valid_h
        & (left == right)
    )

    valid_h[:, :-1] = (
        pair_valid_h
    )

    affinity_h[:, :-1] = (
        same_h.astype(
            np.uint8
        )
    )

    # --------------------------------------------------------
    # Vertical affinity
    #
    # affinity_v[y, x] describes:
    #
    #     labels[y, x]
    #          |
    #          v
    #     labels[y + 1, x]
    #
    # Last row has no lower neighbor.
    # --------------------------------------------------------

    affinity_v = np.zeros(
        (h, w),
        dtype=np.uint8,
    )

    valid_v = np.zeros(
        (h, w),
        dtype=bool,
    )

    top = labels[:-1, :]
    bottom = labels[1:, :]

    pair_valid_v = (
        (top >= 0)
        & (bottom >= 0)
    )

    same_v = (
        pair_valid_v
        & (top == bottom)
    )

    valid_v[:-1, :] = (
        pair_valid_v
    )

    affinity_v[:-1, :] = (
        same_v.astype(
            np.uint8
        )
    )

    # --------------------------------------------------------
    # Boundary target
    #
    # A geological contact exists when two TRUSTED neighboring
    # pixels belong to DIFFERENT geological units.
    #
    # Invalid/-1 pixels do not automatically become boundaries.
    # --------------------------------------------------------

    boundary = np.zeros(
        (h, w),
        dtype=np.uint8,
    )

    different_h = (
        pair_valid_h
        & (left != right)
    )

    different_v = (
        pair_valid_v
        & (top != bottom)
    )

    # Put the shared contact on one pixel only.
    boundary[:, :-1][
        different_h
    ] = 1

    boundary[:-1, :][
        different_v
    ] = 1

    # --------------------------------------------------------
    # Boundary supervision-valid mask
    #
    # Pixel is valid for boundary supervision if at least one
    # horizontal or vertical pair involving it is trustworthy.
    # --------------------------------------------------------

    boundary_valid = np.zeros(
        (h, w),
        dtype=bool,
    )

    boundary_valid |= valid_h
    boundary_valid |= valid_v

    shifted_h = np.zeros_like(
        valid_h
    )

    shifted_h[:, 1:] = (
        valid_h[:, :-1]
    )

    boundary_valid |= shifted_h

    shifted_v = np.zeros_like(
        valid_v
    )

    shifted_v[1:, :] = (
        valid_v[:-1, :]
    )

    boundary_valid |= shifted_v

    return {
        "valid_pixel": (
            valid_pixel.astype(
                np.uint8
            )
        ),
        "affinity_h": affinity_h,
        "affinity_h_valid": (
            valid_h.astype(
                np.uint8
            )
        ),
        "affinity_v": affinity_v,
        "affinity_v_valid": (
            valid_v.astype(
                np.uint8
            )
        ),
        "boundary": boundary,
        "boundary_valid": (
            boundary_valid.astype(
                np.uint8
            )
        ),
    }


# ============================================================
# ONE MAP
# ============================================================

def process_map(
    map_directory: Path,
    output_root: Path,
) -> dict:

    map_id = map_directory.name

    labels_path = (
        map_directory
        / "unit_labels.npy"
    )

    if not labels_path.exists():
        raise FileNotFoundError(
            f"Missing: {labels_path}"
        )

    labels = np.load(
        labels_path
    )

    targets = build_targets(
        labels
    )

    output_directory = (
        output_root
        / map_id
    )

    output_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    # --------------------------------------------------------
    # Save loss-ready arrays
    # --------------------------------------------------------

    np.save(
        output_directory
        / "valid_pixel.npy",
        targets[
            "valid_pixel"
        ],
    )

    np.save(
        output_directory
        / "affinity_h.npy",
        targets[
            "affinity_h"
        ],
    )

    np.save(
        output_directory
        / "affinity_h_valid.npy",
        targets[
            "affinity_h_valid"
        ],
    )

    np.save(
        output_directory
        / "affinity_v.npy",
        targets[
            "affinity_v"
        ],
    )

    np.save(
        output_directory
        / "affinity_v_valid.npy",
        targets[
            "affinity_v_valid"
        ],
    )

    np.save(
        output_directory
        / "boundary.npy",
        targets[
            "boundary"
        ],
    )

    np.save(
        output_directory
        / "boundary_valid.npy",
        targets[
            "boundary_valid"
        ],
    )

    # --------------------------------------------------------
    # Save visual previews
    # --------------------------------------------------------

    save_binary(
        output_directory
        / "valid_pixel.png",
        targets[
            "valid_pixel"
        ],
    )

    save_tristate_affinity(
        output_directory
        / "affinity_h_preview.png",
        targets[
            "affinity_h"
        ],
        targets[
            "affinity_h_valid"
        ].astype(bool),
    )

    save_tristate_affinity(
        output_directory
        / "affinity_v_preview.png",
        targets[
            "affinity_v"
        ],
        targets[
            "affinity_v_valid"
        ].astype(bool),
    )

    save_binary(
        output_directory
        / "boundary.png",
        targets[
            "boundary"
        ],
    )

    save_binary(
        output_directory
        / "boundary_valid.png",
        targets[
            "boundary_valid"
        ],
    )

    # --------------------------------------------------------
    # Statistics
    # --------------------------------------------------------

    valid_pixels = int(
        targets[
            "valid_pixel"
        ].sum()
    )

    total_pixels = int(
        labels.size
    )

    horizontal_valid = int(
        targets[
            "affinity_h_valid"
        ].sum()
    )

    horizontal_same = int(
        (
            targets[
                "affinity_h"
            ]
            * targets[
                "affinity_h_valid"
            ]
        ).sum()
    )

    vertical_valid = int(
        targets[
            "affinity_v_valid"
        ].sum()
    )

    vertical_same = int(
        (
            targets[
                "affinity_v"
            ]
            * targets[
                "affinity_v_valid"
            ]
        ).sum()
    )

    boundary_pixels = int(
        targets[
            "boundary"
        ].sum()
    )

    unique_labels = sorted(
        int(value)
        for value in np.unique(
            labels
        )
        if value >= 0
    )

    report = {
        "map_id": map_id,
        "shape": [
            int(labels.shape[0]),
            int(labels.shape[1]),
        ],
        "geological_unit_count": (
            len(unique_labels)
        ),
        "geological_unit_ids": (
            unique_labels
        ),
        "total_pixels": (
            total_pixels
        ),
        "valid_pixels": (
            valid_pixels
        ),
        "valid_fraction": float(
            valid_pixels
            / max(
                total_pixels,
                1,
            )
        ),
        "horizontal_valid_pairs": (
            horizontal_valid
        ),
        "horizontal_same_pairs": (
            horizontal_same
        ),
        "horizontal_different_pairs": int(
            horizontal_valid
            - horizontal_same
        ),
        "vertical_valid_pairs": (
            vertical_valid
        ),
        "vertical_same_pairs": (
            vertical_same
        ),
        "vertical_different_pairs": int(
            vertical_valid
            - vertical_same
        ),
        "boundary_pixels": (
            boundary_pixels
        ),
    }

    (
        output_directory
        / "target_report.json"
    ).write_text(
        json.dumps(
            report,
            indent=2,
        ),
        encoding="utf-8",
    )

    return report


# ============================================================
# MAIN
# ============================================================

def main() -> None:

    parser = argparse.ArgumentParser(
        description=(
            "Generate palette-independent geological-region "
            "affinity targets from unit_labels.npy."
        )
    )

    parser.add_argument(
        "--source-root",
        type=Path,
        default=DEFAULT_SOURCE_ROOT,
    )

    parser.add_argument(
        "--output-root",
        type=Path,
        default=DEFAULT_OUTPUT_ROOT,
    )

    parser.add_argument(
        "--map-id",
        type=str,
        default=None,
        help=(
            "Optional single map such as map_0103. "
            "If omitted, process every available map."
        ),
    )

    args = parser.parse_args()

    source_root = (
        args.source_root.resolve()
    )

    output_root = (
        args.output_root.resolve()
    )

    output_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    if args.map_id is not None:

        map_directories = [
            source_root
            / args.map_id
        ]

    else:

        map_directories = sorted(
            directory
            for directory
            in source_root.glob(
                "map_*"
            )
            if directory.is_dir()
            and (
                directory
                / "unit_labels.npy"
            ).exists()
        )

    if not map_directories:
        raise RuntimeError(
            "No maps with unit_labels.npy found."
        )

    print("=" * 72)
    print(
        "GeoRegion affinity-target builder"
    )
    print(
        "Source:",
        source_root,
    )
    print(
        "Output:",
        output_root,
    )
    print(
        "Maps:",
        len(map_directories),
    )
    print("=" * 72)

    reports = []

    for index, map_directory in enumerate(
        map_directories,
        start=1,
    ):

        report = process_map(
            map_directory,
            output_root,
        )

        reports.append(
            report
        )

        print(
            f"[{index:03d}/"
            f"{len(map_directories):03d}] "
            f"{report['map_id']} "
            f"units="
            f"{report['geological_unit_count']} "
            f"valid="
            f"{report['valid_fraction']:.1%} "
            f"boundary="
            f"{report['boundary_pixels']}"
        )

    (
        output_root
        / "dataset_report.json"
    ).write_text(
        json.dumps(
            reports,
            indent=2,
        ),
        encoding="utf-8",
    )

    print()
    print(
        "Affinity-target generation complete."
    )

    print(
        "Dataset report:",
        output_root
        / "dataset_report.json",
    )


if __name__ == "__main__":
    main()