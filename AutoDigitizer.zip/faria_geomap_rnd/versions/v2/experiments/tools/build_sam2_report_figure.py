from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(r"C:\PROJECT\GeoMapPrototype\V2")
BASE = ROOT / "outputs" / "sam2_geobody_validated_map0103"
OUT = ROOT / "docs" / "report_figures"
OUT.mkdir(parents=True, exist_ok=True)


def bbox_from_mask(mask_path: Path, padding=120):
    mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)

    ys, xs = np.where(mask > 0)

    if len(xs) == 0:
        raise RuntimeError(f"No foreground found in {mask_path}")

    x1 = max(0, xs.min() - padding)
    y1 = max(0, ys.min() - padding)
    x2 = min(mask.shape[1], xs.max() + padding)
    y2 = min(mask.shape[0], ys.max() + padding)

    return x1, y1, x2, y2


def crop(path: Path, bbox):
    img = Image.open(path).convert("RGB")
    return img.crop(bbox)


def fit(img, width=650, height=480):
    img = img.copy()
    img.thumbnail((width, height))
    return img


def add_panel(canvas, img, x, y, label):
    img = fit(img)

    draw = ImageDraw.Draw(canvas)
    draw.text((x, y), label, fill="black")

    y_img = y + 35
    canvas.paste(img, (x, y_img))


def make_candidate(candidate, status, metrics, filename):
    folder = BASE / f"candidate_{candidate}"

    bbox = bbox_from_mask(folder / "01_lab_candidate.png")

    original = crop(BASE / "original_map.png", bbox)
    proposal = crop(folder / "01_lab_candidate.png", bbox)
    sam2 = crop(folder / "02_raw_sam2.png", bbox)
    validated = crop(folder / "07_validated_overlay.png", bbox)

    canvas = Image.new("RGB", (2850, 1250), "white")
    draw = ImageDraw.Draw(canvas)

    title = f"SAM2 Local Geological-Body Refinement — Candidate {candidate}"
    draw.text((40, 25), title, fill="black")

    add_panel(canvas, original, 40, 90, "(a) Original map crop")
    add_panel(canvas, proposal, 740, 90, "(b) Initial LAB proposal")
    add_panel(canvas, sam2, 1440, 90, "(c) Raw SAM2 prediction")
    add_panel(canvas, validated, 2140, 90, "(d) Validation overlay")

    metric_y = 760

    draw.text(
        (40, metric_y),
        f"Result: {status}",
        fill="black",
    )

    draw.text(
        (40, metric_y + 55),
        metrics,
        fill="black",
    )

    if status == "ACCEPTED":
        explanation = (
            "Interpretation: SAM2 remained close to the proposed geological body "
            "and produced a locally useful refinement."
        )
    else:
        explanation = (
            "Interpretation: SAM2 expanded beyond the intended geological body. "
            "This failure motivated using SAM2 only as a validated local refinement module."
        )

    draw.text(
        (40, metric_y + 120),
        explanation,
        fill="black",
    )

    path = OUT / filename
    canvas.save(path)

    print(f"Saved: {path}")


make_candidate(
    candidate=13,
    status="ACCEPTED",
    metrics="IoU = 0.989 | Area ratio = 1.009 | Centroid shift = 0.37 px",
    filename="fig05_sam2_success_clear.png",
)

make_candidate(
    candidate=26,
    status="REJECTED",
    metrics="IoU = 0.318 | Area ratio = 3.149 | Centroid shift = 47.62 px",
    filename="fig06_sam2_failure_clear.png",
)

print("Done.")