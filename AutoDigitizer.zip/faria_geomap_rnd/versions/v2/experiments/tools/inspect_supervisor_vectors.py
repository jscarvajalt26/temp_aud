from __future__ import annotations

from pathlib import Path

try:
    import shapefile
except ImportError as exc:
    raise SystemExit(
        "pyshp is required. Install it with:\n"
        "python -m pip install pyshp"
    ) from exc


DATASET_ROOT = Path(
    r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150"
)

MAP_ID = "map_0000"

LAYERS = [
    "polygons",
    "faults",
    "roads",
    "rivers",
    "lakes",
    "strike_dip",
]


def inspect_layer(layer_name: str) -> None:
    shp_path = (
        DATASET_ROOT
        / MAP_ID
        / f"{MAP_ID}_{layer_name}.shp"
    )

    print()
    print("=" * 70)
    print(layer_name.upper())
    print("=" * 70)
    print("Path:", shp_path)

    if not shp_path.exists():
        print("Missing shapefile.")
        return

    reader = shapefile.Reader(str(shp_path))

    field_names = [
        field[0]
        for field in reader.fields
        if field[0] != "DeletionFlag"
    ]

    print("Shape type:", reader.shapeTypeName)
    print("Feature count:", len(reader))
    print("Fields:", field_names)

    print("\nFirst records:")

    for index, shape_record in enumerate(
        reader.iterShapeRecords()
    ):
        if index >= 5:
            break

        record = dict(
            zip(
                field_names,
                list(shape_record.record),
            )
        )

        shape = shape_record.shape

        print(f"\nFeature {index}")
        print("Attributes:", record)
        print("Point count:", len(shape.points))
        print("Bounding box:", getattr(shape, "bbox", None))


def main() -> None:
    for layer in LAYERS:
        inspect_layer(layer)


if __name__ == "__main__":
    main()