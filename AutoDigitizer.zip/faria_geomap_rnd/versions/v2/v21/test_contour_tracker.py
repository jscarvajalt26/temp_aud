from pathlib import Path

import cv2
import numpy as np

from contour_tracker import (
    compute_gradient,
    compute_orientation,
    detect_seeds,
)

# ----------------------------------------------------
# INPUT
# ----------------------------------------------------

INPUT = r"outputs/predictions/map004_probabilities.npy"

OUTPUT = Path("outputs/v21_debug")
OUTPUT.mkdir(parents=True, exist_ok=True)

# ----------------------------------------------------

probability = np.load(INPUT)

print(probability.shape)
print(probability.dtype)
print(probability.min(), probability.max())

# ----------------------------------------------------

gradient = compute_gradient(probability)

orientation = compute_orientation(
    gradient,
)

seeds = detect_seeds(
    probability,
    orientation,
)

# ----------------------------------------------------
# SAVE
# ----------------------------------------------------

cv2.imwrite(
    str(OUTPUT / "01_probability.png"),
    np.clip(probability * 255, 0, 255).astype(np.uint8),
)

cv2.imwrite(
    str(OUTPUT / "02_gradient.png"),
    np.clip(
        gradient["magnitude"] * 255,
        0,
        255,
    ).astype(np.uint8),
)

cv2.imwrite(
    str(OUTPUT / "03_coherence.png"),
    np.clip(
        orientation["coherence"] * 255,
        0,
        255,
    ).astype(np.uint8),
)

cv2.imwrite(
    str(OUTPUT / "04_seeds.png"),
    np.clip(
        seeds * 255,
        0,
        255,
    ).astype(np.uint8),
)

print("Finished.")