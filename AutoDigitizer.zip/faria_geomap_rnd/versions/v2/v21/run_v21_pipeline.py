"""
Example runner.
"""

import cv2

from pipeline import GeoMapPipeline


def main():

    probability = cv2.imread(
        "outputs/probability/probability.png",
        cv2.IMREAD_GRAYSCALE,
    )

    probability = probability.astype(float) / 255.0

    pipeline = GeoMapPipeline()

    pipeline.run(
        probability,
        "outputs/final",
    )


if __name__ == "__main__":
    main()