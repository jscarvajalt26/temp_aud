"""
geometry.py

Geometry models used throughout GeoMapPrototype V2.1.

These classes represent GIS geometries independently from any
specific GIS library (GeoPandas, Shapely, QGIS, ArcGIS, etc.).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import numpy as np


# ==========================================================
# Base Geometry
# ==========================================================

@dataclass
class Geometry:
    """
    Base class for all geometries.
    """

    geometry_type: str


# ==========================================================
# Point
# ==========================================================

@dataclass
class Point(Geometry):

    coordinates: np.ndarray

    def __init__(self, coordinates: np.ndarray):

        super().__init__("Point")
        self.coordinates = np.asarray(coordinates, dtype=float)


# ==========================================================
# LineString
# ==========================================================

@dataclass
class LineString(Geometry):

    coordinates: np.ndarray

    def __init__(self, coordinates: np.ndarray):

        super().__init__("LineString")
        self.coordinates = np.asarray(coordinates, dtype=float)


# ==========================================================
# Polygon
# ==========================================================

@dataclass
class Polygon(Geometry):

    coordinates: np.ndarray

    def __init__(self, coordinates: np.ndarray):

        super().__init__("Polygon")
        self.coordinates = np.asarray(coordinates, dtype=float)


# ==========================================================
# MultiLineString
# ==========================================================

@dataclass
class MultiLineString(Geometry):

    lines: List[np.ndarray] = field(default_factory=list)

    def __init__(self, lines: List[np.ndarray]):

        super().__init__("MultiLineString")

        self.lines = [
            np.asarray(line, dtype=float)
            for line in lines
        ]


# ==========================================================
# MultiPolygon
# ==========================================================

@dataclass
class MultiPolygon(Geometry):

    polygons: List[np.ndarray] = field(default_factory=list)

    def __init__(self, polygons: List[np.ndarray]):

        super().__init__("MultiPolygon")

        self.polygons = [
            np.asarray(poly, dtype=float)
            for poly in polygons
        ]


# ==========================================================
# Geometry Collection
# ==========================================================

@dataclass
class GeometryCollection(Geometry):

    geometries: List[Geometry] = field(default_factory=list)

    def __init__(self, geometries: List[Geometry]):

        super().__init__("GeometryCollection")

        self.geometries = geometries