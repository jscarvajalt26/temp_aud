"""
feature.py

Core data models used throughout GeoMapPrototype V2.1.

Every stage after raster processing should operate on Feature objects
instead of raw dictionaries.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np
from shapely import LineString


@dataclass
class BoundingBox:
    """Bounding box of a feature."""

    min_x: float
    min_y: float
    max_x: float
    max_y: float


@dataclass
class Feature:
    """
    Generic GIS feature.
    """

    # ---------- Identity ----------
    feature_id: int
    feature_type: str

    # ---------- Geometry ----------
    from models.geometry import Geometry

    geometry: Geometry | None = None
    coordinates: Optional[np.ndarray] = None

    # ---------- Measurements ----------
    length: float = 0.0
    area: float = 0.0
    perimeter: float = 0.0

    centroid_x: float = 0.0
    centroid_y: float = 0.0

    bbox: Optional[BoundingBox] = None

    # ---------- AI Confidence ----------
    mean_probability: float = 0.0
    max_probability: float = 0.0
    min_probability: float = 0.0

    # ---------- Graph Properties ----------
    junction_count: int = 0
    connected_component: int = -1
    closed_loop: bool = False

    # ---------- Classification ----------
    geological_unit: str = ""
    source: str = "CNN"

    # ---------- Metadata ----------
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class GeologicalContact(LineString):

    contact_type: str = "Unknown"

    left_unit: str = ""

    right_unit: str = ""

    confidence: float = 1.0
    
@dataclass
class FeatureCollection:
    """
    Container holding all extracted GIS features.
    """

    features: List[Feature] = field(default_factory=list)

    def add(self, feature: Feature) -> None:
        self.features.append(feature)

    def __len__(self) -> int:
        return len(self.features)

    def __iter__(self):
        return iter(self.features)