"""
geometry_utils.py

Common geometry utilities for GeoMapPrototype V2.1.

These functions operate on raster-derived geometries and are shared by
the vectorizer, attribute table, graph refinement, and GIS export modules.
"""

from __future__ import annotations

from math import atan2, degrees
from typing import Iterable, Optional, Tuple

import numpy as np

from models.feature import BoundingBox


# ==========================================================
# Basic Measurements
# ==========================================================

def calculate_length(points: np.ndarray) -> float:
    """
    Calculate polyline length.
    """

    if points is None or len(points) < 2:
        return 0.0

    diffs = np.diff(points.astype(float), axis=0)
    segment_lengths = np.linalg.norm(diffs, axis=1)

    return float(segment_lengths.sum())


def calculate_area(points: np.ndarray) -> float:
    """
    Polygon area using the Shoelace Formula.
    """

    if points is None or len(points) < 3:
        return 0.0

    x = points[:, 0]
    y = points[:, 1]

    return float(
        0.5 * abs(
            np.dot(x, np.roll(y, -1))
            - np.dot(y, np.roll(x, -1))
        )
    )


def calculate_perimeter(points: np.ndarray) -> float:
    """
    Polygon perimeter.
    """

    if points is None or len(points) < 3:
        return 0.0

    closed = np.vstack([points, points[0]])

    return calculate_length(closed)


# ==========================================================
# Centroid
# ==========================================================

def calculate_centroid(points: np.ndarray) -> Tuple[float, float]:

    if points is None or len(points) == 0:
        return 0.0, 0.0

    center = np.mean(points, axis=0)

    return float(center[0]), float(center[1])


# ==========================================================
# Bounding Box
# ==========================================================

def calculate_bbox(points: np.ndarray) -> Optional[BoundingBox]:

    if points is None or len(points) == 0:
        return None

    return BoundingBox(
        min_x=float(points[:, 0].min()),
        min_y=float(points[:, 1].min()),
        max_x=float(points[:, 0].max()),
        max_y=float(points[:, 1].max()),
    )


# ==========================================================
# Orientation
# ==========================================================

def calculate_orientation(points: np.ndarray) -> float:
    """
    Overall line orientation in degrees.
    """

    if points is None or len(points) < 2:
        return 0.0

    dx = points[-1, 0] - points[0, 0]
    dy = points[-1, 1] - points[0, 1]

    return float(degrees(atan2(dy, dx)))


# ==========================================================
# Curvature
# ==========================================================

def calculate_curvature(points: np.ndarray) -> float:
    """
    Mean change in direction (degrees).
    """

    if points is None or len(points) < 3:
        return 0.0

    angles = []

    for i in range(1, len(points) - 1):

        a = points[i] - points[i - 1]
        b = points[i + 1] - points[i]

        angle1 = atan2(a[1], a[0])
        angle2 = atan2(b[1], b[0])

        diff = abs(degrees(angle2 - angle1))

        if diff > 180:
            diff = 360 - diff

        angles.append(diff)

    return float(np.mean(angles)) if angles else 0.0


# ==========================================================
# Bounding Box Tests
# ==========================================================

def bbox_overlap(box1: BoundingBox, box2: BoundingBox) -> bool:

    return not (
        box1.max_x < box2.min_x
        or box1.min_x > box2.max_x
        or box1.max_y < box2.min_y
        or box1.min_y > box2.max_y
    )


# ==========================================================
# Distance
# ==========================================================

def euclidean_distance(
    point1: Tuple[float, float],
    point2: Tuple[float, float],
) -> float:

    return float(np.linalg.norm(np.array(point1) - np.array(point2)))


# ==========================================================
# Line Angle
# ==========================================================

def line_angle(
    p1: Tuple[float, float],
    p2: Tuple[float, float],
) -> float:

    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]

    return float(degrees(atan2(dy, dx)))


# ==========================================================
# Simplification
# ==========================================================

def simplify_geometry(
    points: np.ndarray,
    tolerance: float = 1.0,
) -> np.ndarray:
    """
    Placeholder.

    Later this will become a Douglas-Peucker simplifier.
    """

    return points


# ==========================================================
# Validation
# ==========================================================

def is_closed(points: np.ndarray, tolerance: float = 1.0) -> bool:

    if points is None or len(points) < 3:
        return False

    return (
        euclidean_distance(points[0], points[-1])
        <= tolerance
    )