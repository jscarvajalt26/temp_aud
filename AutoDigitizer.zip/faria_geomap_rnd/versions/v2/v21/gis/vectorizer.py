"""
vectorizer.py

Converts raster outputs into GIS Feature objects.
"""

from __future__ import annotations

from typing import List

import cv2
import numpy as np

from models.feature import Feature
from models.feature import FeatureCollection

from gis.geometry_utils import (
    calculate_area,
    calculate_bbox,
    calculate_centroid,
    calculate_length,
    calculate_perimeter,
    is_closed,
)

from config.settings import settings


class Vectorizer:
    """
    Converts binary masks into Feature objects.
    """

    def __init__(self):

        self.settings = settings.vectorizer

    # ------------------------------------------------------
    # Public Interface
    # ------------------------------------------------------

    def vectorize(
        self,
        binary_mask: np.ndarray,
        probability_map: np.ndarray | None = None,
    ) -> FeatureCollection:

        collection = FeatureCollection()

        contours = self._extract_contours(binary_mask)

        feature_id = 1

        for contour in contours:

            feature = self._create_feature(
                feature_id,
                contour,
                probability_map,
            )

            if feature is not None:
                collection.add(feature)
                feature_id += 1

        return collection

    # ------------------------------------------------------
    # Contours
    # ------------------------------------------------------

    def _extract_contours(
        self,
        binary_mask: np.ndarray,
    ) -> List[np.ndarray]:

        contours, _ = cv2.findContours(
            binary_mask.astype(np.uint8),
            cv2.RETR_LIST,
            cv2.CHAIN_APPROX_NONE,
        )

        return [c[:, 0, :] for c in contours]

    # ------------------------------------------------------
    # Feature Creation
    # ------------------------------------------------------

    def _create_feature(
        self,
        feature_id: int,
        contour: np.ndarray,
        probability_map: np.ndarray | None,
    ) -> Feature | None:

        if len(contour) < 2:
            return None

        contour = contour.astype(float)

        closed = is_closed(contour)

        if closed:

            feature_type = "polygon"

            area = calculate_area(contour)
            perimeter = calculate_perimeter(contour)
            length = perimeter

            if area < self.settings.minimum_polygon_area:
                return None

        else:

            feature_type = "line"

            area = 0.0
            perimeter = 0.0
            length = calculate_length(contour)

            if length < self.settings.minimum_line_length:
                return None

        cx, cy = calculate_centroid(contour)

        bbox = calculate_bbox(contour)

        confidence = self._calculate_confidence(
            contour,
            probability_map,
        )

        feature = Feature(

            feature_id=feature_id,

            feature_type=feature_type,

            coordinates=contour,

            length=length,

            area=area,

            perimeter=perimeter,

            centroid_x=cx,

            centroid_y=cy,

            bbox=bbox,

            mean_probability=confidence,

            max_probability=confidence,

            min_probability=confidence,

            metadata={}
        )

        return feature

    # ------------------------------------------------------
    # Confidence
    # ------------------------------------------------------

    def _calculate_confidence(
        self,
        contour: np.ndarray,
        probability_map: np.ndarray | None,
    ) -> float:

        if probability_map is None:
            return 1.0

        values = []

        h, w = probability_map.shape

        for x, y in contour.astype(int):

            if 0 <= y < h and 0 <= x < w:

                values.append(probability_map[y, x])

        if len(values) == 0:
            return 0.0

        return float(np.mean(values))