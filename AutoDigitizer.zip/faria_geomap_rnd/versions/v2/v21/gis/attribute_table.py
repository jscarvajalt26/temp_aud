"""
attribute_table.py

Creates GIS attribute tables from FeatureCollection objects.
"""

from __future__ import annotations

from typing import Dict, List

import pandas as pd

from models.feature import Feature
from models.feature import FeatureCollection


class AttributeTable:
    """
    Converts FeatureCollection into a GIS-style attribute table.
    """

    def __init__(self):
        pass

    # ----------------------------------------------------------
    # Public API
    # ----------------------------------------------------------

    def create_table(
        self,
        collection: FeatureCollection,
    ) -> pd.DataFrame:

        rows = []

        for feature in collection:

            rows.append(self._feature_to_dict(feature))

        return pd.DataFrame(rows)

    # ----------------------------------------------------------
    # Single Feature
    # ----------------------------------------------------------

    def _feature_to_dict(
        self,
        feature: Feature,
    ) -> Dict:

        bbox = feature.bbox

        return {

            # Identity
            "Feature_ID": feature.feature_id,
            "Feature_Type": feature.feature_type,

            # Geometry
            "Length": feature.length,
            "Area": feature.area,
            "Perimeter": feature.perimeter,

            # Location
            "Centroid_X": feature.centroid_x,
            "Centroid_Y": feature.centroid_y,

            "BBox_Min_X": bbox.min_x if bbox else None,
            "BBox_Min_Y": bbox.min_y if bbox else None,
            "BBox_Max_X": bbox.max_x if bbox else None,
            "BBox_Max_Y": bbox.max_y if bbox else None,

            # AI Confidence
            "Mean_Probability": feature.mean_probability,
            "Max_Probability": feature.max_probability,
            "Min_Probability": feature.min_probability,

            # Graph Information
            "Connected_Component": feature.connected_component,
            "Junction_Count": feature.junction_count,
            "Closed_Loop": feature.closed_loop,

            # Classification
            "Geological_Unit": feature.geological_unit,
            "Source": feature.source,

            # Metadata
            "Metadata": feature.metadata,
        }

    # ----------------------------------------------------------
    # CSV
    # ----------------------------------------------------------

    def save_csv(
        self,
        dataframe: pd.DataFrame,
        output_path: str,
    ) -> None:

        dataframe.to_csv(
            output_path,
            index=False,
        )

    # ----------------------------------------------------------
    # Excel
    # ----------------------------------------------------------

    def save_excel(
        self,
        dataframe: pd.DataFrame,
        output_path: str,
    ) -> None:

        dataframe.to_excel(
            output_path,
            index=False,
        )