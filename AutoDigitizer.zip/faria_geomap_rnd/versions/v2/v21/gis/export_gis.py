"""
export_gis.py

Export FeatureCollection objects to GIS formats.
"""

from __future__ import annotations

from pathlib import Path

import geopandas as gpd
from shapely.geometry import LineString, Polygon

from models.feature import FeatureCollection


class GISExporter:

    def __init__(self):
        pass

    # -----------------------------------------------------
    # Public
    # -----------------------------------------------------

    def export(
        self,
        collection: FeatureCollection,
        output_folder: str,
        layer_name: str = "geology",
    ):

        output_folder = Path(output_folder)
        output_folder.mkdir(parents=True, exist_ok=True)

        gdf = self._build_geodataframe(collection)

        gdf.to_file(
            output_folder / f"{layer_name}.geojson",
            driver="GeoJSON",
        )

        gdf.to_file(
            output_folder / f"{layer_name}.shp",
            driver="ESRI Shapefile",
        )

        gdf.to_file(
            output_folder / f"{layer_name}.gpkg",
            driver="GPKG",
        )

        gdf.to_csv(
            output_folder / f"{layer_name}.csv",
            index=False,
        )

        gdf.to_excel(
            output_folder / f"{layer_name}.xlsx",
            index=False,
        )

        print(f"Exported {len(gdf)} GIS features.")

    # -----------------------------------------------------
    # Internal
    # -----------------------------------------------------

    def _build_geodataframe(
        self,
        collection: FeatureCollection,
    ) -> gpd.GeoDataFrame:

        rows = []

        for feature in collection:

            if feature.coordinates is None:
                continue

            if feature.feature_type.lower() == "polygon":

                geometry = Polygon(feature.coordinates)

            else:

                geometry = LineString(feature.coordinates)

            rows.append({

                "Feature_ID": feature.feature_id,

                "Type": feature.feature_type,

                "Length": feature.length,

                "Area": feature.area,

                "Confidence": feature.mean_probability,

                "Junctions": feature.junction_count,

                "Closed": feature.closed_loop,

                "Unit": feature.geological_unit,

                "geometry": geometry,
            })

        return gpd.GeoDataFrame(
            rows,
            geometry="geometry",
            crs="EPSG:4326",
        )