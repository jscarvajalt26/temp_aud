"""
pipeline.py

Main pipeline controller for GeoMapPrototype V2.1.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from probability_recovery import ProbabilityRecovery
from contour_tracker import ContourTracker
from adaptive_threshold import AdaptiveThreshold
from junction_recovery import JunctionRecovery
from topology_cleanup import TopologyCleanup
from graph_refinement_v21 import GraphRefinement

from gis.vectorizer import Vectorizer
from gis.attribute_table import AttributeTable
from gis.export_gis import GISExporter


class GeoMapPipeline:

    def __init__(self):

        self.probability = ProbabilityRecovery()

        self.contour = ContourTracker()

        self.threshold = AdaptiveThreshold()

        self.junction = JunctionRecovery()

        self.topology = TopologyCleanup()

        self.graph = GraphRefinement()

        self.vectorizer = Vectorizer()

        self.attribute_table = AttributeTable()

        self.exporter = GISExporter()

    # ---------------------------------------------------------
    # Main Pipeline
    # ---------------------------------------------------------

    def run(
        self,
        probability_map: np.ndarray,
        output_folder: str,
    ):

        print("=" * 60)
        print("GeoMapPrototype V2.1")
        print("=" * 60)

        # -----------------------------------
        # Stage 1
        # -----------------------------------

        recovered = self.probability.process(
            probability_map
        )

        # -----------------------------------
        # Stage 2
        # -----------------------------------

        tracked = self.contour.process(
            recovered
        )

        # -----------------------------------
        # Stage 3
        # -----------------------------------

        binary = self.threshold.process(
            tracked
        )

        # -----------------------------------
        # Stage 4
        # -----------------------------------

        binary = self.junction.process(
            binary
        )

        # -----------------------------------
        # Stage 5
        # -----------------------------------

        binary = self.topology.process(
            binary
        )

        # -----------------------------------
        # Stage 6
        # -----------------------------------

        refined = self.graph.process(
            binary
        )

        # -----------------------------------
        # Stage 7
        # -----------------------------------

        features = self.vectorizer.vectorize(
            refined,
            recovered,
        )

        # -----------------------------------
        # Stage 8
        # -----------------------------------

        dataframe = self.attribute_table.create_table(
            features
        )

        # -----------------------------------
        # Stage 9
        # -----------------------------------

        self.exporter.export(
            features,
            output_folder,
        )

        dataframe.to_csv(
            Path(output_folder) / "attribute_table.csv",
            index=False,
        )

        print()
        print("Pipeline completed successfully.")

        return {
            "probability": recovered,
            "tracked": tracked,
            "binary": binary,
            "refined": refined,
            "features": features,
            "table": dataframe,
        }