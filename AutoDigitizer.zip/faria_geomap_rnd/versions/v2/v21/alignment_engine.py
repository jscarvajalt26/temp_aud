from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np


@dataclass
class AlignmentResult:
    aligned_image: np.ndarray

    # Maps source-image coordinates into reference-image coordinates.
    forward_matrix: np.ndarray

    # Maps reference-image coordinates back into source-image coordinates.
    inverse_matrix: np.ndarray

    confidence: float
    method: str

    source_shape: tuple[int, int]
    target_shape: tuple[int, int]

    match_count: int
    inlier_count: int
    inlier_ratio: float

    reprojection_error: float | None


class AlignmentError(RuntimeError):
    pass


def read_color_image(
    image_path: str | Path,
) -> np.ndarray:
    image_path = Path(image_path)

    image = cv2.imread(
        str(image_path),
        cv2.IMREAD_COLOR,
    )

    if image is None:
        raise FileNotFoundError(
            f"Could not read image: {image_path}"
        )

    return image


def read_reference_image(
    reference_path: str | Path,
) -> np.ndarray:
    reference_path = Path(reference_path)

    reference = cv2.imread(
        str(reference_path),
        cv2.IMREAD_COLOR,
    )

    if reference is None:
        raise FileNotFoundError(
            f"Could not read reference image: {reference_path}"
        )

    return reference


def prepare_registration_gray(
    image_bgr: np.ndarray,
    maximum_dimension: int = 1800,
) -> tuple[np.ndarray, float]:
    """
    Convert to grayscale and optionally downscale.

    Returns
    -------
    gray:
        Registration image.

    scale:
        gray coordinates = original coordinates * scale
    """

    gray = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    height, width = gray.shape

    largest_dimension = max(
        height,
        width,
    )

    if largest_dimension <= maximum_dimension:
        scale = 1.0
        resized = gray
    else:
        scale = (
            maximum_dimension
            / float(largest_dimension)
        )

        resized = cv2.resize(
            gray,
            None,
            fx=scale,
            fy=scale,
            interpolation=cv2.INTER_AREA,
        )

    resized = cv2.createCLAHE(
        clipLimit=2.0,
        tileGridSize=(8, 8),
    ).apply(resized)

    return resized, scale


def create_feature_detector():
    """
    Prefer SIFT when available.

    SIFT is usually more reliable for map registration than ORB.
    """

    if hasattr(cv2, "SIFT_create"):
        detector = cv2.SIFT_create(
            nfeatures=10000,
            contrastThreshold=0.02,
            edgeThreshold=10,
        )

        matcher = cv2.BFMatcher(
            cv2.NORM_L2,
            crossCheck=False,
        )

        detector_name = "SIFT"

    else:
        detector = cv2.ORB_create(
            nfeatures=15000,
            scaleFactor=1.2,
            nlevels=8,
            edgeThreshold=15,
            fastThreshold=10,
        )

        matcher = cv2.BFMatcher(
            cv2.NORM_HAMMING,
            crossCheck=False,
        )

        detector_name = "ORB"

    return detector, matcher, detector_name


def detect_and_match_features(
    source_gray: np.ndarray,
    reference_gray: np.ndarray,
    ratio_threshold: float = 0.75,
) -> tuple[
    np.ndarray,
    np.ndarray,
    int,
    str,
]:
    detector, matcher, detector_name = (
        create_feature_detector()
    )

    source_keypoints, source_descriptors = (
        detector.detectAndCompute(
            source_gray,
            None,
        )
    )

    reference_keypoints, reference_descriptors = (
        detector.detectAndCompute(
            reference_gray,
            None,
        )
    )

    if (
        source_descriptors is None
        or reference_descriptors is None
    ):
        raise AlignmentError(
            "Could not compute registration descriptors."
        )

    nearest_matches = matcher.knnMatch(
        source_descriptors,
        reference_descriptors,
        k=2,
    )

    good_matches = []

    for match_pair in nearest_matches:
        if len(match_pair) < 2:
            continue

        best_match, second_match = match_pair

        if (
            best_match.distance
            < ratio_threshold * second_match.distance
        ):
            good_matches.append(
                best_match
            )

    if len(good_matches) < 4:
        raise AlignmentError(
            f"Only {len(good_matches)} reliable feature "
            "matches were found."
        )

    source_points = np.float32(
        [
            source_keypoints[match.queryIdx].pt
            for match in good_matches
        ]
    ).reshape(-1, 1, 2)

    reference_points = np.float32(
        [
            reference_keypoints[match.trainIdx].pt
            for match in good_matches
        ]
    ).reshape(-1, 1, 2)

    return (
        source_points,
        reference_points,
        len(good_matches),
        detector_name,
    )


def scale_homography_to_original_coordinates(
    scaled_homography: np.ndarray,
    source_scale: float,
    reference_scale: float,
) -> np.ndarray:
    """
    Convert a homography estimated on resized images back to the
    original source/reference coordinate systems.
    """

    source_scaling = np.asarray(
        [
            [source_scale, 0.0, 0.0],
            [0.0, source_scale, 0.0],
            [0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )

    reference_scaling = np.asarray(
        [
            [reference_scale, 0.0, 0.0],
            [0.0, reference_scale, 0.0],
            [0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )

    return (
        np.linalg.inv(reference_scaling)
        @ scaled_homography
        @ source_scaling
    )


def calculate_reprojection_error(
    source_points: np.ndarray,
    reference_points: np.ndarray,
    homography: np.ndarray,
    inlier_mask: np.ndarray,
) -> float | None:
    inliers = inlier_mask.reshape(-1).astype(bool)

    if not np.any(inliers):
        return None

    transformed_points = cv2.perspectiveTransform(
        source_points[inliers],
        homography,
    )

    errors = np.linalg.norm(
        transformed_points.reshape(-1, 2)
        - reference_points[inliers].reshape(-1, 2),
        axis=1,
    )

    return float(
        np.mean(errors)
    )


def validate_homography(
    homography: np.ndarray,
    source_shape: tuple[int, int],
    target_shape: tuple[int, int],
) -> None:
    if homography.shape != (3, 3):
        raise AlignmentError(
            "Homography must have shape 3x3."
        )

    if not np.isfinite(homography).all():
        raise AlignmentError(
            "Homography contains non-finite values."
        )

    determinant = np.linalg.det(
        homography
    )

    if abs(determinant) < 1e-10:
        raise AlignmentError(
            "Homography is singular."
        )

    source_height, source_width = source_shape
    target_height, target_width = target_shape

    source_corners = np.float32(
        [
            [0, 0],
            [source_width - 1, 0],
            [source_width - 1, source_height - 1],
            [0, source_height - 1],
        ]
    ).reshape(-1, 1, 2)

    transformed_corners = cv2.perspectiveTransform(
        source_corners,
        homography.astype(np.float64),
    ).reshape(-1, 2)

    if not np.isfinite(
        transformed_corners
    ).all():
        raise AlignmentError(
            "Transformed corners are invalid."
        )

    transformed_area = abs(
        cv2.contourArea(
            transformed_corners.astype(np.float32)
        )
    )

    target_area = float(
        target_height * target_width
    )

    area_ratio = (
        transformed_area
        / max(target_area, 1.0)
    )

    if not 0.15 <= area_ratio <= 5.0:
        raise AlignmentError(
            "Estimated transform has an implausible area ratio: "
            f"{area_ratio:.4f}"
        )


def estimate_homography_alignment(
    source_bgr: np.ndarray,
    reference_bgr: np.ndarray,
    maximum_registration_dimension: int = 1800,
    ransac_threshold: float = 4.0,
    minimum_inliers: int = 20,
    minimum_inlier_ratio: float = 0.20,
) -> AlignmentResult:
    source_gray, source_scale = (
        prepare_registration_gray(
            source_bgr,
            maximum_dimension=(
                maximum_registration_dimension
            ),
        )
    )

    reference_gray, reference_scale = (
        prepare_registration_gray(
            reference_bgr,
            maximum_dimension=(
                maximum_registration_dimension
            ),
        )
    )

    (
        source_points,
        reference_points,
        match_count,
        detector_name,
    ) = detect_and_match_features(
        source_gray,
        reference_gray,
    )

    scaled_homography, inlier_mask = (
        cv2.findHomography(
            source_points,
            reference_points,
            method=cv2.RANSAC,
            ransacReprojThreshold=ransac_threshold,
            maxIters=10000,
            confidence=0.999,
        )
    )

    if (
        scaled_homography is None
        or inlier_mask is None
    ):
        raise AlignmentError(
            "Homography estimation failed."
        )

    inlier_count = int(
        inlier_mask.sum()
    )

    inlier_ratio = (
        inlier_count
        / max(match_count, 1)
    )

    if inlier_count < minimum_inliers:
        raise AlignmentError(
            f"Only {inlier_count} homography inliers were found."
        )

    if inlier_ratio < minimum_inlier_ratio:
        raise AlignmentError(
            f"Homography inlier ratio is too low: "
            f"{inlier_ratio:.3f}"
        )

    reprojection_error = (
        calculate_reprojection_error(
            source_points,
            reference_points,
            scaled_homography,
            inlier_mask,
        )
    )

    homography = (
        scale_homography_to_original_coordinates(
            scaled_homography,
            source_scale=source_scale,
            reference_scale=reference_scale,
        )
    )

    validate_homography(
        homography,
        source_shape=source_bgr.shape[:2],
        target_shape=reference_bgr.shape[:2],
    )

    inverse_homography = np.linalg.inv(
        homography
    )

    target_height, target_width = (
        reference_bgr.shape[:2]
    )

    aligned = cv2.warpPerspective(
        source_bgr,
        homography,
        dsize=(
            target_width,
            target_height,
        ),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(255, 255, 255),
    )

    error_score = 0.0

    if reprojection_error is not None:
        error_score = float(
            np.exp(
                -reprojection_error
                / max(ransac_threshold * 2.0, 1e-6)
            )
        )

    confidence = float(
        np.clip(
            0.65 * inlier_ratio
            + 0.35 * error_score,
            0.0,
            1.0,
        )
    )

    return AlignmentResult(
        aligned_image=aligned,
        forward_matrix=homography.astype(
            np.float64
        ),
        inverse_matrix=inverse_homography.astype(
            np.float64
        ),
        confidence=confidence,
        method=f"{detector_name}_HOMOGRAPHY_RANSAC",
        source_shape=source_bgr.shape[:2],
        target_shape=reference_bgr.shape[:2],
        match_count=match_count,
        inlier_count=inlier_count,
        inlier_ratio=float(inlier_ratio),
        reprojection_error=reprojection_error,
    )


def estimate_ecc_affine_alignment(
    source_bgr: np.ndarray,
    reference_bgr: np.ndarray,
    maximum_registration_dimension: int = 1200,
) -> AlignmentResult:
    """
    Fallback for mostly affine changes:
    translation, rotation, scale and shear.
    """

    source_gray, source_scale = (
        prepare_registration_gray(
            source_bgr,
            maximum_dimension=(
                maximum_registration_dimension
            ),
        )
    )

    reference_gray, reference_scale = (
        prepare_registration_gray(
            reference_bgr,
            maximum_dimension=(
                maximum_registration_dimension
            ),
        )
    )

    reference_height, reference_width = (
        reference_gray.shape
    )

    source_resized = cv2.resize(
        source_gray,
        (
            reference_width,
            reference_height,
        ),
        interpolation=cv2.INTER_AREA,
    )

    source_float = (
        source_resized.astype(np.float32)
        / 255.0
    )

    reference_float = (
        reference_gray.astype(np.float32)
        / 255.0
    )

    affine_matrix = np.eye(
        2,
        3,
        dtype=np.float32,
    )

    termination_criteria = (
        cv2.TERM_CRITERIA_EPS
        | cv2.TERM_CRITERIA_COUNT,
        300,
        1e-7,
    )

    correlation, affine_matrix = (
        cv2.findTransformECC(
            reference_float,
            source_float,
            affine_matrix,
            motionType=cv2.MOTION_AFFINE,
            criteria=termination_criteria,
            inputMask=None,
            gaussFiltSize=5,
        )
    )

    resized_source_to_reference = np.asarray(
        [
            [
                reference_width
                / source_bgr.shape[1],
                0.0,
                0.0,
            ],
            [
                0.0,
                reference_height
                / source_bgr.shape[0],
                0.0,
            ],
            [0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )

    ecc_affine_homography = np.vstack(
        [
            affine_matrix,
            [0.0, 0.0, 1.0],
        ]
    ).astype(np.float64)

    # findTransformECC returns a warp used with WARP_INVERSE_MAP.
    # Invert it to obtain source -> reference coordinates.
    homography = (
        np.linalg.inv(
            ecc_affine_homography
        )
        @ resized_source_to_reference
    )

    validate_homography(
        homography,
        source_shape=source_bgr.shape[:2],
        target_shape=reference_bgr.shape[:2],
    )

    inverse_homography = np.linalg.inv(
        homography
    )

    target_height, target_width = (
        reference_bgr.shape[:2]
    )

    aligned = cv2.warpPerspective(
        source_bgr,
        homography,
        (
            target_width,
            target_height,
        ),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(255, 255, 255),
    )

    confidence = float(
        np.clip(
            correlation,
            0.0,
            1.0,
        )
    )

    return AlignmentResult(
        aligned_image=aligned,
        forward_matrix=homography,
        inverse_matrix=inverse_homography,
        confidence=confidence,
        method="ECC_AFFINE",
        source_shape=source_bgr.shape[:2],
        target_shape=reference_bgr.shape[:2],
        match_count=0,
        inlier_count=0,
        inlier_ratio=0.0,
        reprojection_error=None,
    )


def align_map(
    source_image_path: str | Path,
    reference_image_path: str | Path,
    minimum_confidence: float = 0.25,
    allow_ecc_fallback: bool = True,
) -> AlignmentResult:
    """
    Automatically align a raw/decorated map image to a canonical
    reference raster.

    Parameters
    ----------
    source_image_path:
        Shifted, rotated, resized or perspective-distorted input.

    reference_image_path:
        Canonical aligned raster, normally the GeoTIFF variant.

    minimum_confidence:
        Results below this value are rejected.

    allow_ecc_fallback:
        Try affine ECC alignment when feature homography fails.
    """

    source_bgr = read_color_image(
        source_image_path
    )

    reference_bgr = read_reference_image(
        reference_image_path
    )

    homography_error: Exception | None = None

    try:
        result = estimate_homography_alignment(
            source_bgr,
            reference_bgr,
        )

    except Exception as error:
        homography_error = error

        if not allow_ecc_fallback:
            raise

        result = estimate_ecc_affine_alignment(
            source_bgr,
            reference_bgr,
        )

    if result.confidence < minimum_confidence:
        message = (
            "Automatic alignment confidence is too low: "
            f"{result.confidence:.3f}. "
            f"Method: {result.method}."
        )

        if homography_error is not None:
            message += (
                " Homography error: "
                f"{type(homography_error).__name__}: "
                f"{homography_error}"
            )

        raise AlignmentError(
            message
        )

    return result


def save_alignment_debug(
    result: AlignmentResult,
    reference_image_path: str | Path,
    output_directory: str | Path,
) -> None:
    output_directory = Path(
        output_directory
    )

    output_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    reference_bgr = read_reference_image(
        reference_image_path
    )

    difference = cv2.absdiff(
        result.aligned_image,
        reference_bgr,
    )

    blend = cv2.addWeighted(
        result.aligned_image,
        0.5,
        reference_bgr,
        0.5,
        0.0,
    )

    cv2.imwrite(
        str(
            output_directory
            / "aligned.png"
        ),
        result.aligned_image,
    )

    cv2.imwrite(
        str(
            output_directory
            / "alignment_blend.png"
        ),
        blend,
    )

    cv2.imwrite(
        str(
            output_directory
            / "alignment_difference.png"
        ),
        difference,
    )

    np.save(
        output_directory
        / "forward_matrix.npy",
        result.forward_matrix,
    )

    np.save(
        output_directory
        / "inverse_matrix.npy",
        result.inverse_matrix,
    )

    report = (
        f"method={result.method}\n"
        f"confidence={result.confidence:.6f}\n"
        f"source_shape={result.source_shape}\n"
        f"target_shape={result.target_shape}\n"
        f"match_count={result.match_count}\n"
        f"inlier_count={result.inlier_count}\n"
        f"inlier_ratio={result.inlier_ratio:.6f}\n"
        f"reprojection_error={result.reprojection_error}\n"
        f"forward_matrix=\n{result.forward_matrix}\n"
        f"inverse_matrix=\n{result.inverse_matrix}\n"
    )

    (
        output_directory
        / "alignment_report.txt"
    ).write_text(
        report,
        encoding="utf-8",
    )


if __name__ == "__main__":
    source_path = Path(
        r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150"
        r"\map_0000\map_0000_color.png"
    )

    reference_path = Path(
        r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150"
        r"\map_0000\map_0000_color.tif"
    )

    output_path = Path(
        r"C:\PROJECT\GeoMapPrototype\V2"
        r"\outputs\alignment_debug\map_0000"
    )

    alignment = align_map(
        source_image_path=source_path,
        reference_image_path=reference_path,
        minimum_confidence=0.20,
    )

    save_alignment_debug(
        alignment,
        reference_image_path=reference_path,
        output_directory=output_path,
    )

    print("Alignment completed")
    print("Method:", alignment.method)
    print("Confidence:", alignment.confidence)
    print("Source shape:", alignment.source_shape)
    print("Target shape:", alignment.target_shape)
    print("Matches:", alignment.match_count)
    print("Inliers:", alignment.inlier_count)
    print("Inlier ratio:", alignment.inlier_ratio)
    print(
        "Reprojection error:",
        alignment.reprojection_error,
    )
    print("Saved:", output_path)