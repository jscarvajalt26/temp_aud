"""
============================================================
GeoMapPrototype V2.1

Probability Recovery Module

Author:
Faria Samanta Akbar

Purpose
-------
Improve the raw contact probability map before thresholding.

Pipeline

Raw Probability
        │
        ▼
Noise Reduction
        │
        ▼
Confidence Enhancement
        │
        ▼
Directional Smoothing
        │
        ▼
Gap Recovery
        │
        ▼
Recovered Probability
============================================================
"""

from __future__ import annotations

import cv2
import numpy as np
from config.settings import (
    ProbabilityRecoverySettings,
    settings as global_settings,
)


# ============================================================
# VALIDATION
# ============================================================

def validate_probability(
    probability: np.ndarray,
) -> None:
    """
    Validate the incoming probability map.
    """

    if probability.ndim != 2:
        raise ValueError(
            "Probability map must have shape [H,W]."
        )

    if probability.dtype not in (
        np.float32,
        np.float64,
    ):
        raise ValueError(
            "Probability map must be float32 or float64."
        )

    minimum = float(np.min(probability))
    maximum = float(np.max(probability))

    if minimum < -1e-6 or maximum > 1.000001:
        raise ValueError(
            "Probability values must lie between 0 and 1."
        )


# ============================================================
# BASIC FILTERS
# ============================================================

def gaussian_cleanup(
    probability: np.ndarray,
    sigma: float,
) -> np.ndarray:
    """
    Remove isolated CNN prediction noise.
    """

    return cv2.GaussianBlur(
        probability,
        (0, 0),
        sigmaX=sigma,
        sigmaY=sigma,
    )


def bilateral_cleanup(
    probability: np.ndarray,
    settings: ProbabilityRecoverySettings,
) -> np.ndarray:
    """
    Edge-preserving smoothing.

    Unlike Gaussian smoothing,
    bilateral filtering preserves sharp geological contacts.
    """

    return cv2.bilateralFilter(
        probability.astype(np.float32),
        d=settings.bilateral_diameter,
        sigmaColor=settings.bilateral_sigma_color,
        sigmaSpace=settings.bilateral_sigma_space,
    )


# ============================================================
# CONFIDENCE ENHANCEMENT
# ============================================================

def enhance_confidence(
    probability: np.ndarray,
    gamma: float,
) -> np.ndarray:
    """
    Boost confident predictions.

    gamma < 1

    increases stronger probabilities while
    leaving weak predictions nearly unchanged.
    """

    probability = np.clip(
        probability,
        0.0,
        1.0,
    )

    enhanced = np.power(
        probability,
        gamma,
    )

    return enhanced.astype(np.float32)

# ============================================================
# MORPHOLOGICAL RECOVERY
# ============================================================

def _elliptical_kernel(
    radius: int,
) -> np.ndarray:
    """
    Create an elliptical structuring element.

    Radius = 2 -> 5x5 kernel
    """

    radius = max(int(radius), 1)

    return cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (
            radius * 2 + 1,
            radius * 2 + 1,
        ),
    )


def probability_closing(
    probability: np.ndarray,
    radius: int,
) -> np.ndarray:
    """
    Fill tiny gaps inside thick contacts.

    This is much gentler than binary closing because it
    operates directly on floating-point probabilities.
    """

    kernel = _elliptical_kernel(radius)

    return cv2.morphologyEx(
        probability,
        cv2.MORPH_CLOSE,
        kernel,
    )


def probability_opening(
    probability: np.ndarray,
    radius: int,
) -> np.ndarray:
    """
    Remove isolated probability speckles.
    """

    kernel = _elliptical_kernel(radius)

    return cv2.morphologyEx(
        probability,
        cv2.MORPH_OPEN,
        kernel,
    )


# ============================================================
# LOCAL CONTRAST ENHANCEMENT
# ============================================================

def local_contrast_enhancement(
    probability: np.ndarray,
) -> np.ndarray:
    """
    Increase local contrast while preserving probabilities.

    This helps separate contacts from surrounding weak noise.
    """

    probability_u8 = np.clip(
        probability * 255.0,
        0,
        255,
    ).astype(np.uint8)

    clahe = cv2.createCLAHE(
        clipLimit=2.0,
        tileGridSize=(8, 8),
    )

    enhanced = clahe.apply(
        probability_u8
    )

    return (
        enhanced.astype(np.float32)
        / 255.0
    )


# ============================================================
# RIDGE ENHANCEMENT
# ============================================================

def ridge_enhancement(
    probability: np.ndarray,
) -> np.ndarray:
    """
    Enhance elongated geological structures.

    This uses a Laplacian response to reinforce ridges
    without strongly affecting flat regions.
    """

    laplacian = cv2.Laplacian(
        probability,
        cv2.CV_32F,
        ksize=3,
    )

    enhanced = probability - 0.20 * laplacian

    return np.clip(
        enhanced,
        0.0,
        1.0,
    )


# ============================================================
# MULTI-SCALE SMOOTHING
# ============================================================

def multiscale_smoothing(
    probability: np.ndarray,
) -> np.ndarray:
    """
    Blend fine-scale and coarse-scale information.

    Thin contacts survive because of the small sigma.

    Thick spiral contacts survive because of the
    larger sigma.
    """

    fine = cv2.GaussianBlur(
        probability,
        (0, 0),
        sigmaX=0.8,
    )

    medium = cv2.GaussianBlur(
        probability,
        (0, 0),
        sigmaX=1.8,
    )

    coarse = cv2.GaussianBlur(
        probability,
        (0, 0),
        sigmaX=3.2,
    )

    blended = (
        0.45 * fine
        + 0.35 * medium
        + 0.20 * coarse
    )

    return blended.astype(
        np.float32
    )

# ============================================================
# NORMALIZATION
# ============================================================

def normalize_probability(
    probability: np.ndarray,
) -> np.ndarray:
    """
    Normalize probability map to [0,1].

    This prevents filters from drifting outside
    the expected probability range.
    """

    minimum = float(np.min(probability))
    maximum = float(np.max(probability))

    if maximum - minimum < 1e-8:
        return np.clip(
            probability,
            0.0,
            1.0,
        ).astype(np.float32)

    probability = (
        probability - minimum
    ) / (
        maximum - minimum
    )

    return np.clip(
        probability,
        0.0,
        1.0,
    ).astype(np.float32)


# ============================================================
# SHARPENING
# ============================================================

def unsharp_probability(
    probability: np.ndarray,
    amount: float = 0.30,
) -> np.ndarray:
    """
    Mild unsharp masking.

    Restores edge sharpness after smoothing.
    """

    blurred = cv2.GaussianBlur(
        probability,
        (0, 0),
        sigmaX=1.0,
    )

    sharpened = (
        probability
        + amount * (
            probability - blurred
        )
    )

    return np.clip(
        sharpened,
        0.0,
        1.0,
    ).astype(np.float32)


# ============================================================
# FINAL CLEANUP
# ============================================================

def final_cleanup(
    probability: np.ndarray,
    settings: ProbabilityRecoverySettings,
) -> np.ndarray:
    """
    Final clipping and normalization.
    """

    probability = normalize_probability(
        probability
    )

    probability = np.clip(
        probability,
        settings.clip_min,
        settings.clip_max,
    )

    return probability.astype(
        np.float32
    )


# ============================================================
# DEBUG OUTPUTS
# ============================================================

def build_debug_dictionary(
    raw: np.ndarray,
    gaussian: np.ndarray,
    bilateral: np.ndarray,
    enhanced: np.ndarray,
    morph: np.ndarray,
    ridge: np.ndarray,
    multiscale: np.ndarray,
    sharpened: np.ndarray,
    final: np.ndarray,
) -> dict[str, np.ndarray]:
    """
    Return every intermediate stage.

    The pipeline can later save these
    automatically for debugging.
    """

    return {

        "raw": raw,

        "gaussian": gaussian,

        "bilateral": bilateral,

        "confidence": enhanced,

        "morphology": morph,

        "ridge": ridge,

        "multiscale": multiscale,

        "sharpened": sharpened,

        "final": final,

    }

# ============================================================
# MAIN PIPELINE
# ============================================================

def recover_probability(
    contact_probability: np.ndarray,
    settings: ProbabilityRecoverySettings | None = None,
    return_debug: bool = False,
):
    """
    Recover and enhance a raw contact probability map.
    """

    validate_probability(contact_probability)

    if settings is None:
        settings = global_settings.probability

    raw = contact_probability.astype(np.float32)

    gaussian = gaussian_cleanup(
        raw,
        settings.gaussian_sigma,
    )

    bilateral = bilateral_cleanup(
        gaussian,
        settings,
    )

    confidence = enhance_confidence(
        bilateral,
        settings.confidence_gamma,
    )

    closed = probability_closing(
        confidence,
        settings.closing_radius,
    )

    opened = probability_opening(
        closed,
        settings.opening_radius,
    )

    contrast = local_contrast_enhancement(opened)

    ridge = ridge_enhancement(contrast)

    multiscale = multiscale_smoothing(ridge)

    sharpened = unsharp_probability(
        multiscale,
        amount=0.30,
    )

    final = final_cleanup(
        sharpened,
        settings,
    )

    if not return_debug:
        return final

    debug = build_debug_dictionary(
        raw=raw,
        gaussian=gaussian,
        bilateral=bilateral,
        enhanced=confidence,
        morph=opened,
        ridge=ridge,
        multiscale=multiscale,
        sharpened=sharpened,
        final=final,
    )

    return final, debug

# ============================================================
# MODULE TEST
# ============================================================

if __name__ == "__main__":

    print()

    print("=" * 60)
    print("GeoMapPrototype V2.1")
    print("Probability Recovery Module")
    print("=" * 60)

    dummy = np.random.rand(
        256,
        256,
    ).astype(
        np.float32
    )

    recovered, debug = recover_probability(
        dummy,
        return_debug=True,
    )

    print()

    print("Recovered probability shape:")
    print(recovered.shape)

    print()

    print("Available debug stages:")

    for name in debug.keys():
        print(" -", name)

    print()

    print("Module OK.")