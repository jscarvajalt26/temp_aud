﻿# GeoMap V2.1 — Refinement, Topology and GIS Pipeline

## Overview

V2.1 is an extension of the V2 SE-U-Net pipeline.

The goal of V2.1 was not to replace SE-U-Net with another neural network.
Instead, it investigated how the raw segmentation output from V2 could be
converted into cleaner, more continuous and more useful geological geometry.

The main problems being addressed were broken contacts, uncertain boundary
segments, missing junctions, imperfect topology, and conversion from raster
predictions into GIS-compatible vector features.

---

## Relationship to V2

V2 introduced SE-U-Net as the main learned segmentation model.

V2.1 builds on that work by adding additional refinement stages after the
initial prediction.

Conceptually:

    Geological Map
          |
          v
    V2 SE-U-Net Prediction
          |
          v
    V2.1 Refinement
          |
          +-- adaptive thresholding
          +-- alignment
          +-- contour tracking
          +-- probability recovery
          +-- junction recovery
          +-- contact refinement
          +-- graph refinement
          +-- topology cleanup
          |
          v
    GIS / Vector Representation

---

## Main Pipeline

The V2.1 implementation is coordinated through:

    pipeline.py
    run_v21_pipeline.py

These modules connect the individual refinement and reconstruction stages.

---

## Adaptive Thresholding

    adaptive_threshold.py

This stage explores adaptive decision thresholds rather than assuming that
one fixed threshold is appropriate for every map or prediction region.

---

## Alignment

    alignment_engine.py

The alignment stage attempts to better align predicted geological structures
with evidence present in the source map.

---

## Contour Tracking

    contour_tracker.py

Predicted boundary evidence may contain gaps or fragmented sections.

Contour tracking investigates how boundary evidence can be followed and
connected into more coherent geological structures.

---

## Probability Recovery

    probability_recovery.py

Hard class predictions discard much of the information contained in the
model's probability maps.

Probability recovery uses this softer prediction information to investigate
weak or missing sections of geological structures.

---

## Junction Recovery

    junction_recovery.py

Geological contacts frequently meet at junctions.

Segmentation and post-processing can damage these locations, so V2.1 includes
a dedicated stage for recovering and improving junction structure.

---

## Hybrid Contact Refinement

    hybrid_contact_refinement.py

This stage combines multiple forms of evidence to improve predicted
geological contacts instead of relying exclusively on the original binary
boundary prediction.

---

## Graph Refinement

    graph_refinement_v21.py

Geological boundaries can be represented as connected structures rather than
only as independent pixels.

The graph refinement stage investigates connectivity and structural repair.

---

## Topology Cleanup

    topology_cleanup.py

This stage focuses on producing more geologically consistent connectivity
after the preceding refinement operations.

---

## GIS and Vectorization

The `gis/` package contains:

    attribute_table.py
    export_gis.py
    geometry_utils.py
    vectorizer.py

These components investigate the transition from raster/model predictions
toward vector geometry and GIS-compatible representations.

This is an important step toward the long-term goal of producing outputs
that can be opened and edited in GIS software such as QGIS.

---

## Internal Data Structures

The `models/` directory contains representations for:

    feature.py
    geometry.py
    graph.py
    topology.py

These provide structured representations for the refinement and
vectorization pipeline.

---

## Utilities

The `utils/` directory contains support for:

- image operations
- visualization
- debugging

---

## Why V2.1 Was Important

V2.1 demonstrated an important limitation of treating geological-map
digitization as only an image-segmentation problem.

A segmentation model can identify likely geological features, but a useful
digitization system must also reason about:

- continuity,
- connectivity,
- junctions,
- topology,
- geometry,
- and GIS representation.

The experiments in V2.1 therefore helped shift the project toward a system
where machine-learning predictions are followed by geological and geometric
reasoning.

---

## What Came After V2.1

Additional research was later performed inside the broader V2 research
workspace, including:

- hybrid neural architectures,
- multi-head geological segmentation,
- GeoRegion affinity learning,
- SAM2-assisted refinement,
- transformer/context modules,
- and deterministic topology reconstruction.

Those experiments are preserved separately and should not be interpreted as
the original V2.1 implementation.

The next major numbered model integration is V3, which investigates
Mask2Former.
