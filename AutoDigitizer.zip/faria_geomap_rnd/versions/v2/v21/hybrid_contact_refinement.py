"""
============================================================
GeoMapPrototype V2.1

Hybrid Contact Refinement

Author:
Faria Samanta Akbar

Purpose
-------
Use the trained SE-UNet as the primary contact detector, then apply
conservative classical refinement to recover weak connected responses,
remove isolated noise, and prepare a clean raster contact layer for:

    junction recovery
    topology cleanup
    vectorization
    GIS export

The contour tracker is not the primary detector. It may later be used
only as an optional recovery tool for unresolved local gaps.
============================================================
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import cv2
import numpy as np


# ============================================================
# DEFAULT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]

DEFAULT_PROBABILITIES = (
    PROJECT_ROOT
    / "outputs"
    / "predictions"
    / "map004_probabilities.npy"
)

DEFAULT_OUTPUT_DIR = (
    PROJECT_ROOT
    / "outputs"
    / "v21_hybrid"
    / "map004"
)


# ============================================================
# SETTINGS
# ============================================================

@dataclass
class HybridRefinementSettings:
    """
    Configuration for SE-UNet probability refinement.
    """

    # SE-UNet class channel containing contact probability.
    contact_channel: int = 1

    # Probability recovery.
    gaussian_sigma: float = 1.0
    confidence_gamma: float = 0.90

    # Hysteresis thresholds.
    strong_threshold: float = 0.55
    weak_threshold: float = 0.05

    # Connected-component cleanup.
    minimum_component_area: int = 12

    # Conservative gap recovery.
    closing_kernel_size: int = 3
    closing_iterations: int = 1

    # Restrict morphological additions to locations near weak
    # SE-UNet evidence.
    weak_support_dilation_radius: int = 2

    # Preserve probability-supported thick regions.
    thick_region_threshold: float = 0.20

    # Output value.
    foreground_value: int = 255


# ============================================================
# VALIDATION
# ============================================================

def validate_probability_tensor(
    probabilities: np.ndarray,
) -> None:
    """
    Validate a CHW SE-UNet probability tensor.
    """

    if probabilities is None:
        raise ValueError("Probability tensor is None.")

    if probabilities.ndim != 3:
        raise ValueError(
            "Expected probability tensor with shape (classes, height, width). "
            f"Received shape {probabilities.shape}."
        )

    if not np.issubdtype(
        probabilities.dtype,
        np.floating,
    ):
        raise ValueError(
            "Probability tensor must contain floating-point values."
        )

    if not np.all(
        np.isfinite(probabilities)
    ):
        raise ValueError(
            "Probability tensor contains NaN or infinite values."
        )


def validate_probability_map(
    probability: np.ndarray,
) -> None:
    """
    Validate one two-dimensional class probability map.
    """

    if probability.ndim != 2:
        raise ValueError(
            "Contact probability must be two-dimensional."
        )

    if not np.issubdtype(
        probability.dtype,
        np.floating,
    ):
        raise ValueError(
            "Contact probability must be floating point."
        )


# ============================================================
# INPUT
# ============================================================

def load_contact_probability(
    probability_file: str | Path,
    contact_channel: int,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Load the complete SE-UNet probability tensor and select the
    contact-probability channel.

    Returns
    -------
    all_probabilities:
        Array with shape (classes, height, width).

    contact_probability:
        Float32 array with shape (height, width).
    """

    probability_file = Path(
        probability_file
    )

    if not probability_file.exists():
        raise FileNotFoundError(
            f"Probability file not found: {probability_file}"
        )

    all_probabilities = np.load(
        probability_file
    )

    validate_probability_tensor(
        all_probabilities
    )

    class_count = all_probabilities.shape[0]

    if not (
        0 <= contact_channel < class_count
    ):
        raise ValueError(
            f"contact_channel={contact_channel} is invalid for "
            f"{class_count} classes."
        )

    contact_probability = np.asarray(
        all_probabilities[contact_channel],
        dtype=np.float32,
    )

    contact_probability = np.clip(
        contact_probability,
        0.0,
        1.0,
    )

    validate_probability_map(
        contact_probability
    )

    return (
        all_probabilities,
        contact_probability,
    )


# ============================================================
# PROBABILITY RECOVERY
# ============================================================

def recover_probability(
    probability: np.ndarray,
    settings: HybridRefinementSettings,
) -> np.ndarray:
    """
    Smooth weak local variation while retaining the SE-UNet probability
    as the primary source of semantic evidence.
    """

    recovered = np.asarray(
        probability,
        dtype=np.float32,
    ).copy()

    if settings.gaussian_sigma > 0:
        recovered = cv2.GaussianBlur(
            recovered,
            (0, 0),
            settings.gaussian_sigma,
        )

    # Gamma below 1 increases weaker, meaningful probabilities without
    # converting them directly into foreground.
    recovered = np.power(
        np.clip(
            recovered,
            0.0,
            1.0,
        ),
        settings.confidence_gamma,
    )

    recovered = np.clip(
        recovered,
        0.0,
        1.0,
    ).astype(np.float32)

    return recovered


# ============================================================
# HYSTERESIS RECOVERY
# ============================================================

def hysteresis_reconstruction(
    probability: np.ndarray,
    strong_threshold: float,
    weak_threshold: float,
) -> dict[str, np.ndarray]:
    """
    Retain weak probability components only when connected to at least
    one strong SE-UNet response.

    This prevents weak isolated noise from becoming contacts while
    preserving faint continuation pixels connected to confident lines.
    """

    if not (
        0.0 <= weak_threshold <= strong_threshold <= 1.0
    ):
        raise ValueError(
            "Thresholds must satisfy "
            "0 <= weak_threshold <= strong_threshold <= 1."
        )

    strong_mask = (
        probability >= strong_threshold
    ).astype(np.uint8)

    weak_mask = (
        probability >= weak_threshold
    ).astype(np.uint8)

    component_count, component_labels = (
        cv2.connectedComponents(
            weak_mask,
            connectivity=8,
        )
    )

    recovered_mask = np.zeros_like(
        weak_mask,
        dtype=np.uint8,
    )

    strong_component_ids = np.unique(
        component_labels[
            strong_mask > 0
        ]
    )

    strong_component_ids = strong_component_ids[
        strong_component_ids != 0
    ]

    for component_id in strong_component_ids:
        recovered_mask[
            component_labels == component_id
        ] = 1

    weak_only = np.logical_and(
        weak_mask > 0,
        strong_mask == 0,
    ).astype(np.uint8)

    discarded_weak = np.logical_and(
        weak_mask > 0,
        recovered_mask == 0,
    ).astype(np.uint8)

    return {
        "strong_mask": strong_mask,
        "weak_mask": weak_mask,
        "weak_only": weak_only,
        "recovered_mask": recovered_mask,
        "discarded_weak": discarded_weak,
    }


# ============================================================
# COMPONENT CLEANUP
# ============================================================

def remove_small_components(
    binary_mask: np.ndarray,
    minimum_area: int,
) -> np.ndarray:
    """
    Remove isolated connected components smaller than minimum_area.
    """

    mask = (
        np.asarray(binary_mask) > 0
    ).astype(np.uint8)

    component_count, labels, statistics, _ = (
        cv2.connectedComponentsWithStats(
            mask,
            connectivity=8,
        )
    )

    cleaned = np.zeros_like(
        mask,
        dtype=np.uint8,
    )

    for component_id in range(
        1,
        component_count,
    ):
        area = int(
            statistics[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        if area >= minimum_area:
            cleaned[
                labels == component_id
            ] = 1

    return cleaned


# ============================================================
# THICK-REGION PRESERVATION
# ============================================================

def preserve_thick_probability_regions(
    refined_mask: np.ndarray,
    probability: np.ndarray,
    threshold: float,
) -> np.ndarray:
    """
    Preserve all probability-supported thick regions before any later
    centerline or vector operation.

    This avoids discarding spirals or broad contact responses too early.
    """

    thick_support = (
        probability >= threshold
    ).astype(np.uint8)

    preserved = np.logical_or(
        refined_mask > 0,
        thick_support > 0,
    ).astype(np.uint8)

    return preserved


# ============================================================
# CONSERVATIVE GAP RECOVERY
# ============================================================

def disk_kernel(
    radius: int,
) -> np.ndarray:
    """
    Create an elliptical structuring element.
    """

    radius = max(
        0,
        int(radius),
    )

    size = (
        radius * 2 + 1
    )

    return cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (size, size),
    )


def recover_short_gaps(
    binary_mask: np.ndarray,
    probability: np.ndarray,
    settings: HybridRefinementSettings,
) -> dict[str, np.ndarray]:
    """
    Perform conservative short-gap recovery.

    Morphological closing proposes possible connections. Proposed pixels
    are accepted only near weak SE-UNet probability support.

    This prevents closing from freely connecting unrelated map features.
    """

    original = (
        np.asarray(binary_mask) > 0
    ).astype(np.uint8)

    kernel_size = max(
        1,
        int(settings.closing_kernel_size),
    )

    if kernel_size % 2 == 0:
        kernel_size += 1

    closing_kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (
            kernel_size,
            kernel_size,
        ),
    )

    closed_candidate = cv2.morphologyEx(
        original,
        cv2.MORPH_CLOSE,
        closing_kernel,
        iterations=max(
            1,
            int(settings.closing_iterations),
        ),
    )

    proposed_additions = np.logical_and(
        closed_candidate > 0,
        original == 0,
    )

    weak_support = (
        probability >= settings.weak_threshold
    ).astype(np.uint8)

    support_kernel = disk_kernel(
        settings.weak_support_dilation_radius
    )

    expanded_weak_support = cv2.dilate(
        weak_support,
        support_kernel,
        iterations=1,
    )

    accepted_additions = np.logical_and(
        proposed_additions,
        expanded_weak_support > 0,
    ).astype(np.uint8)

    recovered = np.logical_or(
        original > 0,
        accepted_additions > 0,
    ).astype(np.uint8)

    return {
        "closed_candidate": closed_candidate,
        "proposed_additions": proposed_additions.astype(
            np.uint8
        ),
        "accepted_additions": accepted_additions,
        "recovered_mask": recovered,
    }


# ============================================================
# OPTIONAL CONTOUR-TRACKER FUSION
# ============================================================

def fuse_optional_tracker_result(
    refined_mask: np.ndarray,
    tracker_mask: np.ndarray | None,
    probability: np.ndarray,
    weak_threshold: float,
    support_radius: int = 2,
) -> dict[str, np.ndarray]:
    """
    Optionally accept contour-tracker pixels only when they are close to
    weak SE-UNet contact evidence.

    The contour tracker never overrides the neural prediction freely.
    """

    refined = (
        refined_mask > 0
    ).astype(np.uint8)

    if tracker_mask is None:
        empty = np.zeros_like(
            refined,
            dtype=np.uint8,
        )

        return {
            "accepted_tracker_pixels": empty,
            "fused_mask": refined,
        }

    tracker = (
        np.asarray(tracker_mask) > 0
    ).astype(np.uint8)

    if tracker.shape != refined.shape:
        raise ValueError(
            "Tracker mask and refined mask must have the same shape."
        )

    probability_support = (
        probability >= weak_threshold
    ).astype(np.uint8)

    probability_support = cv2.dilate(
        probability_support,
        disk_kernel(support_radius),
        iterations=1,
    )

    new_tracker_pixels = np.logical_and(
        tracker > 0,
        refined == 0,
    )

    accepted_tracker_pixels = np.logical_and(
        new_tracker_pixels,
        probability_support > 0,
    ).astype(np.uint8)

    fused = np.logical_or(
        refined > 0,
        accepted_tracker_pixels > 0,
    ).astype(np.uint8)

    return {
        "accepted_tracker_pixels": accepted_tracker_pixels,
        "fused_mask": fused,
    }


# ============================================================
# MAIN HYBRID REFINEMENT
# ============================================================

def refine_contact_probability(
    probability: np.ndarray,
    settings: HybridRefinementSettings | None = None,
    tracker_mask: np.ndarray | None = None,
    return_debug: bool = False,
):
    """
    Refine one SE-UNet contact-probability map.

    Processing order
    ----------------
    1. Probability recovery
    2. Strong/weak hysteresis
    3. Small-component cleanup
    4. Thick-region preservation
    5. Conservative short-gap recovery
    6. Optional probability-constrained contour-tracker fusion
    """

    if settings is None:
        settings = HybridRefinementSettings()

    validate_probability_map(
        probability
    )

    probability = np.clip(
        np.asarray(
            probability,
            dtype=np.float32,
        ),
        0.0,
        1.0,
    )

    recovered_probability = recover_probability(
        probability,
        settings,
    )

    hysteresis = hysteresis_reconstruction(
        recovered_probability,
        strong_threshold=settings.strong_threshold,
        weak_threshold=settings.weak_threshold,
    )

    component_cleaned = remove_small_components(
        hysteresis["recovered_mask"],
        minimum_area=settings.minimum_component_area,
    )

    thick_preserved = preserve_thick_probability_regions(
        component_cleaned,
        recovered_probability,
        threshold=settings.thick_region_threshold,
    )

    gap_recovery = recover_short_gaps(
        thick_preserved,
        recovered_probability,
        settings,
    )

    tracker_fusion = fuse_optional_tracker_result(
        refined_mask=gap_recovery["recovered_mask"],
        tracker_mask=tracker_mask,
        probability=recovered_probability,
        weak_threshold=settings.weak_threshold,
        support_radius=settings.weak_support_dilation_radius,
    )

    final_mask = remove_small_components(
        tracker_fusion["fused_mask"],
        minimum_area=settings.minimum_component_area,
    )

    final_output = (
        final_mask
        * settings.foreground_value
    ).astype(np.uint8)

    if not return_debug:
        return final_output

    debug = {
        "original_probability": probability,
        "recovered_probability": recovered_probability,
        "strong_mask": hysteresis["strong_mask"],
        "weak_mask": hysteresis["weak_mask"],
        "weak_only": hysteresis["weak_only"],
        "discarded_weak": hysteresis["discarded_weak"],
        "hysteresis_recovered": hysteresis["recovered_mask"],
        "component_cleaned": component_cleaned,
        "thick_preserved": thick_preserved,
        "closed_candidate": gap_recovery["closed_candidate"],
        "proposed_gap_additions": gap_recovery[
            "proposed_additions"
        ],
        "accepted_gap_additions": gap_recovery[
            "accepted_additions"
        ],
        "accepted_tracker_pixels": tracker_fusion[
            "accepted_tracker_pixels"
        ],
        "final_mask": final_mask,
    }

    return final_output, debug


# ============================================================
# OUTPUT
# ============================================================

def save_float_image(
    output_path: Path,
    image: np.ndarray,
) -> None:
    """
    Save a normalized float image as uint8.
    """

    output = np.clip(
        image * 255.0,
        0,
        255,
    ).astype(np.uint8)

    success = cv2.imwrite(
        str(output_path),
        output,
    )

    if not success:
        raise IOError(
            f"Failed to save image: {output_path}"
        )


def save_binary_image(
    output_path: Path,
    image: np.ndarray,
) -> None:
    """
    Save a binary array as a 0/255 PNG.
    """

    output = (
        np.asarray(image) > 0
    ).astype(np.uint8) * 255

    success = cv2.imwrite(
        str(output_path),
        output,
    )

    if not success:
        raise IOError(
            f"Failed to save image: {output_path}"
        )


def save_refinement_outputs(
    output_dir: str | Path,
    refined_contacts: np.ndarray,
    debug: dict[str, np.ndarray],
    settings: HybridRefinementSettings,
    input_file: str | Path,
    runtime_seconds: float,
) -> None:
    """
    Save raster outputs, NumPy output, and a JSON processing report.
    """

    output_dir = Path(
        output_dir
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    save_float_image(
        output_dir / "01_contact_probability.png",
        debug["original_probability"],
    )

    save_float_image(
        output_dir / "02_recovered_probability.png",
        debug["recovered_probability"],
    )

    save_binary_image(
        output_dir / "03_strong_mask.png",
        debug["strong_mask"],
    )

    save_binary_image(
        output_dir / "04_weak_mask.png",
        debug["weak_mask"],
    )

    save_binary_image(
        output_dir / "05_hysteresis_recovered.png",
        debug["hysteresis_recovered"],
    )

    save_binary_image(
        output_dir / "06_component_cleaned.png",
        debug["component_cleaned"],
    )

    save_binary_image(
        output_dir / "07_thick_preserved.png",
        debug["thick_preserved"],
    )

    save_binary_image(
        output_dir / "08_accepted_gap_additions.png",
        debug["accepted_gap_additions"],
    )

    save_binary_image(
        output_dir / "09_accepted_tracker_pixels.png",
        debug["accepted_tracker_pixels"],
    )

    success = cv2.imwrite(
        str(
            output_dir
            / "10_refined_contacts.png"
        ),
        refined_contacts,
    )

    if not success:
        raise IOError(
            "Failed to save refined contact output."
        )

    np.save(
        output_dir / "refined_contacts.npy",
        refined_contacts,
    )

    foreground_pixels = int(
        np.count_nonzero(
            refined_contacts
        )
    )

    report = {
        "schema_version": "1.0.0",
        "module": "hybrid_contact_refinement",
        "input": str(
            Path(input_file).resolve()
        ),
        "shape": [
            int(refined_contacts.shape[0]),
            int(refined_contacts.shape[1]),
        ],
        "foreground_pixels": foreground_pixels,
        "foreground_fraction": float(
            foreground_pixels
            / refined_contacts.size
        ),
        "runtime_seconds": float(
            runtime_seconds
        ),
        "settings": asdict(
            settings
        ),
        "outputs": {
            "refined_png": str(
                (
                    output_dir
                    / "10_refined_contacts.png"
                ).resolve()
            ),
            "refined_npy": str(
                (
                    output_dir
                    / "refined_contacts.npy"
                ).resolve()
            ),
        },
    }

    with open(
        output_dir / "run_report.json",
        "w",
        encoding="utf-8",
    ) as report_file:
        json.dump(
            report,
            report_file,
            indent=2,
        )


# ============================================================
# COMMAND LINE
# ============================================================

def build_argument_parser() -> argparse.ArgumentParser:
    """
    Build command-line argument parser.
    """

    parser = argparse.ArgumentParser(
        description=(
            "Refine SE-UNet geological contact probabilities "
            "using a conservative hybrid pipeline."
        )
    )

    parser.add_argument(
        "--probabilities",
        type=str,
        default=str(DEFAULT_PROBABILITIES),
        help="Path to CHW SE-UNet probabilities.npy.",
    )

    parser.add_argument(
        "--output",
        type=str,
        default=str(DEFAULT_OUTPUT_DIR),
        help="Output directory.",
    )

    parser.add_argument(
        "--contact-channel",
        type=int,
        default=1,
        help="SE-UNet channel containing contact probability.",
    )

    parser.add_argument(
        "--strong-threshold",
        type=float,
        default=0.55,
        help="Strong hysteresis threshold.",
    )

    parser.add_argument(
        "--weak-threshold",
        type=float,
        default=0.05,
        help="Weak hysteresis threshold.",
    )

    parser.add_argument(
        "--minimum-component-area",
        type=int,
        default=12,
        help="Minimum connected-component area.",
    )

    return parser


def main() -> None:
    """
    Run hybrid refinement from the command line.
    """

    parser = build_argument_parser()
    arguments = parser.parse_args()

    settings = HybridRefinementSettings(
        contact_channel=arguments.contact_channel,
        strong_threshold=arguments.strong_threshold,
        weak_threshold=arguments.weak_threshold,
        minimum_component_area=(
            arguments.minimum_component_area
        ),
    )

    start_time = time.perf_counter()

    print("=" * 68)
    print("GeoMapPrototype V2.1 — Hybrid Contact Refinement")
    print("=" * 68)

    print(
        "Loading probabilities:",
        arguments.probabilities,
    )

    all_probabilities, contact_probability = (
        load_contact_probability(
            probability_file=arguments.probabilities,
            contact_channel=settings.contact_channel,
        )
    )

    print(
        "Probability tensor:",
        all_probabilities.shape,
    )

    print(
        "Selected contact channel:",
        settings.contact_channel,
    )

    print(
        "Contact probability shape:",
        contact_probability.shape,
    )

    refined_contacts, debug = (
        refine_contact_probability(
            probability=contact_probability,
            settings=settings,
            tracker_mask=None,
            return_debug=True,
        )
    )

    runtime_seconds = (
        time.perf_counter()
        - start_time
    )

    save_refinement_outputs(
        output_dir=arguments.output,
        refined_contacts=refined_contacts,
        debug=debug,
        settings=settings,
        input_file=arguments.probabilities,
        runtime_seconds=runtime_seconds,
    )

    print(
        "Foreground pixels:",
        int(
            np.count_nonzero(
                refined_contacts
            )
        ),
    )

    print(
        "Runtime:",
        f"{runtime_seconds:.2f} seconds",
    )

    print(
        "Output:",
        Path(arguments.output).resolve(),
    )

    print("=" * 68)


if __name__ == "__main__":
    main()