"""
============================================================
GeoMapPrototype V2.1

Contour Tracking Module

Author:
Faria Samanta Akbar

Purpose
-------
Track geological contacts from the recovered probability map.

Pipeline
--------
Recovered Probability
        │
        ▼
Gradient Estimation
        │
        ▼
Orientation Estimation
        │
        ▼
Seed Detection
        │
        ▼
Directional Tracking
        │
        ▼
Gap Bridging
        │
        ▼
Tracked Contacts
============================================================
"""

from __future__ import annotations

from pathlib import Path

import os
import cv2
import numpy as np

from config.settings import (
    ContourTrackerSettings,
    settings as global_settings,
)
import config.settings

print(config.settings.__file__)
# ============================================================
# VALIDATION
# ============================================================

def validate_probability(
    probability: np.ndarray,
) -> None:

    if probability is None:
        raise ValueError("Probability image is None.")

    if probability.ndim != 2:
        raise ValueError(
            "Probability image must be grayscale."
        )

    if probability.dtype not in (
        np.float32,
        np.float64,
    ):
        raise ValueError(
            "Probability image must be float32."
        )

    # ============================================================
# DEBUG
# ============================================================

def save_debug(
    images: dict[str, np.ndarray],
    folder: str,
):

    folder = Path(folder)

    folder.mkdir(
        parents=True,
        exist_ok=True,
    )

    for name, image in images.items():

        output = np.clip(
            image * 255,
            0,
            255,
        ).astype(np.uint8)

        cv2.imwrite(
            str(folder / f"{name}.png"),
            output,
        )

def clean_probability(
    probability: np.ndarray,
    threshold: float = 0.05,
) -> np.ndarray:
    """
    Suppress very weak CNN responses before gradient/orientation analysis.
    """

    cleaned = np.asarray(
        probability,
        dtype=np.float32,
    ).copy()

    cleaned[cleaned < threshold] = 0.0

    cleaned = cv2.GaussianBlur(
        cleaned,
        (0, 0),
        1.0,
    )

    return cleaned
# ============================================================
# MAIN PIPELINE
# ============================================================

def track_contours(
    probability: np.ndarray,
    settings: ContourTrackerSettings | None = None,
    return_debug: bool = False,
):
    """
    Run the V2.1 contour-tracking pipeline.

    Parameters
    ----------
    probability:
        Two-dimensional contact probability map with values in [0, 1].

    settings:
        Optional contour-tracker settings. If omitted, the global
        V2.1 contour-tracker settings are used.

    return_debug:
        When True, return the tracked result together with
        intermediate debug arrays.

    Returns
    -------
    tracked:
        uint8 binary contact image with values 0 and 255.

    or

    tracked, debug:
        Tracked image plus intermediate processing results.
    """

    validate_probability(probability)

    if settings is None:
        settings = global_settings.contour_tracker

    probability = np.asarray(
        probability,
        dtype=np.float32,
    )

    probability = np.clip(
        probability,
        0.0,
        1.0,
    )

    # --------------------------------------------------------
    # 1. Clean weak probability responses
    # --------------------------------------------------------

    probability_clean = clean_probability(
        probability,
        threshold=settings.min_probability,
    )

    # --------------------------------------------------------
    # 2. Compute gradient and local orientation
    # --------------------------------------------------------

    gradient = compute_gradient(
        probability_clean,
    )

    orientation = compute_orientation(
        gradient,
    )

    # --------------------------------------------------------
    # 3. Build seed mask from confident CNN pixels
    # --------------------------------------------------------

    seeds = detect_seeds(
        probability_clean,
        orientation,
    )

    # --------------------------------------------------------
    # 4. Directional contour tracking
    # --------------------------------------------------------

    tracked = directional_tracking(
        probability,
        orientation,
        seeds,
    )

    # --------------------------------------------------------
    # 5. Gap bridging
    # --------------------------------------------------------

    tracked = bridge_gaps(
        tracked,
    )

    if not return_debug:
        return tracked

    debug = {
        "probability": probability,
        "cleaned_probability": probability_clean,
        "gradient_x": gradient["gx"],
        "gradient_y": gradient["gy"],
        "gradient_magnitude": gradient["magnitude"],
        "orientation": orientation,
        "seeds": seeds,
        "tracked": tracked,
    }

    return tracked, debug

# ============================================================
# STAGES
# ============================================================

# ============================================================
# GRADIENT COMPUTATION
# ============================================================

def compute_gradient(
    probability: np.ndarray,
):
    """
    Compute gradient magnitude and direction.

    Returns
    -------
    dict containing:

        gx
        gy
        magnitude
        angle
    """

    gx = cv2.Sobel(
        probability,
        cv2.CV_32F,
        1,
        0,
        ksize=3,
    )

    gy = cv2.Sobel(
        probability,
        cv2.CV_32F,
        0,
        1,
        ksize=3,
    )

    magnitude = cv2.magnitude(
        gx,
        gy,
    )

    angle = cv2.phase(
        gx,
        gy,
        angleInDegrees=True,
    )

    magnitude = cv2.normalize(
        magnitude,
        None,
        0,
        1,
        cv2.NORM_MINMAX,
    )

    return {

        "gx": gx,

        "gy": gy,

        "magnitude": magnitude,

        "angle": angle,

    }


def compute_orientation(
    gradient: dict,
):
    """
    Estimate local contour orientation using the structure tensor.

    Returns
    -------
    dict containing:

        angle
        coherence
    """

    gx = gradient["gx"]
    gy = gradient["gy"]

    # Structure tensor components
    Jxx = gx * gx
    Jyy = gy * gy
    Jxy = gx * gy

    # Smooth tensor
    sigma = global_settings.contour_tracker.orientation_sigma

    Jxx = cv2.GaussianBlur(Jxx, (0, 0), sigma)
    Jyy = cv2.GaussianBlur(Jyy, (0, 0), sigma)
    Jxy = cv2.GaussianBlur(Jxy, (0, 0), sigma)

    # Dominant orientation
    angle = 0.5 * np.arctan2(
        2.0 * Jxy,
        Jxx - Jyy,
    )

    # Eigenvalue approximation
    numerator = np.sqrt(
        (Jxx - Jyy) ** 2 +
        4.0 * (Jxy ** 2)
    )

    denominator = (
        Jxx +
        Jyy +
        1e-8
    )

    coherence = numerator / denominator

    coherence = np.clip(
        coherence,
        0.0,
        1.0,
    )

    return {

        "angle": angle,

        "coherence": coherence,

    }


def detect_seeds(
    probability: np.ndarray,
    orientation: dict,
) -> np.ndarray:
    """
    Select seed pixels directly from confident CNN contact probabilities.

    Coherence is not used as a hard requirement because dotted contacts
    often have weak or unstable local orientation estimates.
    """

    if probability.ndim != 2:
        raise ValueError(
            "probability must be a two-dimensional array."
        )

    probability_mask = (
        probability
        >= global_settings.contour_tracker.min_probability
    )

    seeds = probability_mask.astype(np.uint8)

    # Remove only truly isolated single-pixel noise.
    neighbour_count = cv2.filter2D(
        seeds,
        ddepth=cv2.CV_16U,
        kernel=np.ones((3, 3), dtype=np.uint8),
        borderType=cv2.BORDER_CONSTANT,
    )

    seeds[
        np.logical_and(
            seeds > 0,
            neighbour_count <= 1,
        )
    ] = 0

    return seeds.astype(np.float32)

def axial_angle_difference(angle_a: float, angle_b: float) -> float:
    """
    Smallest difference between two undirected line orientations.

    Geological contacts have axial orientation, meaning theta and
    theta + pi represent the same line direction.

    Returns a value between 0 and pi / 2.
    """

    difference = abs(angle_a - angle_b) % np.pi

    if difference > np.pi / 2:
        difference = np.pi - difference

    return difference


def directed_angle_difference(angle_a: float, angle_b: float) -> float:
    """
    Smallest difference between two directed movement angles.

    Returns a value between 0 and pi.
    """

    return abs(
        np.arctan2(
            np.sin(angle_a - angle_b),
            np.cos(angle_a - angle_b),
        )
    )


def score_neighbor(
    probability: np.ndarray,
    orientation_angle: np.ndarray,
    coherence: np.ndarray,
    visited: np.ndarray,
    current: tuple[int, int],
    candidate: tuple[int, int],
    previous_heading: float,
    tracker_settings,
) -> float:
    """
    Score a candidate continuation pixel.

    The score combines:

    - CNN contact probability
    - agreement with the local contour orientation
    - structure-tensor coherence
    - change in movement direction
    """

    current_y, current_x = current
    candidate_y, candidate_x = candidate

    height, width = probability.shape

    if not (
        0 <= candidate_y < height
        and 0 <= candidate_x < width
    ):
        return -np.inf

    if visited[candidate_y, candidate_x]:
        return -np.inf

    candidate_probability = float(
        probability[candidate_y, candidate_x]
    )

    if candidate_probability < tracker_settings.min_probability:
        return -np.inf

    candidate_coherence = float(
        coherence[candidate_y, candidate_x]
    )

    movement_angle = np.arctan2(
        candidate_y - current_y,
        candidate_x - current_x,
    )

    turn_angle = directed_angle_difference(
        movement_angle,
        previous_heading,
    )

    maximum_turn = np.deg2rad(
        tracker_settings.max_turn_angle
    )

    if turn_angle > maximum_turn:
        return -np.inf

    # Structure-tensor orientation normally describes the gradient
    # direction. The contour tangent is perpendicular to that gradient.
    contour_tangent = (
        float(orientation_angle[candidate_y, candidate_x])
        + np.pi / 2
    ) % np.pi

    orientation_difference = axial_angle_difference(
        movement_angle % np.pi,
        contour_tangent,
    )

    orientation_score = float(
        np.cos(orientation_difference)
    )

    normalized_turn_penalty = float(
        turn_angle / max(maximum_turn, 1e-8)
    )

    score = (
        tracker_settings.probability_weight
        * candidate_probability
        + tracker_settings.orientation_weight
        * orientation_score
        + tracker_settings.coherence_weight
        * candidate_coherence
        - tracker_settings.turn_penalty_weight
        * normalized_turn_penalty
    )

    return float(score)

def line_points_between(
    start: tuple[int, int],
    end: tuple[int, int],
) -> list[tuple[int, int]]:
    """
    Return integer pixel coordinates along a line from start to end.

    Coordinates use the form:
        (y, x)
    """

    start_y, start_x = start
    end_y, end_x = end

    length = int(
        max(
            abs(end_y - start_y),
            abs(end_x - start_x),
        )
    )

    if length == 0:
        return []

    y_values = np.linspace(
        start_y,
        end_y,
        length + 1,
    )

    x_values = np.linspace(
        start_x,
        end_x,
        length + 1,
    )

    points: list[tuple[int, int]] = []

    for y_value, x_value in zip(y_values[1:], x_values[1:]):
        point = (
            int(round(y_value)),
            int(round(x_value)),
        )

        if not points or point != points[-1]:
            points.append(point)

    return points

def trace_direction(
    probability: np.ndarray,
    orientation_angle: np.ndarray,
    coherence: np.ndarray,
    visited: np.ndarray,
    start: tuple[int, int],
    initial_heading: float,
    tracker_settings,
) -> list[tuple[int, int]]:
    """
    Trace one side of a contour using directional cone look-ahead.

    Instead of moving only to an adjacent pixel, the tracker searches
    a forward cone up to max_tracking_gap pixels away. Candidate
    continuations are scored using:

    - destination probability
    - probability support along the proposed segment
    - local orientation agreement
    - structure-tensor coherence
    - turning angle
    - jump distance

    This permits recovery across dotted and weak contact gaps.
    """

    height, width = probability.shape

    maximum_gap = max(
        1,
        int(tracker_settings.max_tracking_gap),
    )

    maximum_turn = np.deg2rad(
        tracker_settings.max_turn_angle
    )

    # Fine angular search inside the permitted turning cone.
    cone_offsets = np.deg2rad(
        np.linspace(
            -tracker_settings.max_turn_angle,
            tracker_settings.max_turn_angle,
            13,
            dtype=np.float32,
        )
    )

    path: list[tuple[int, int]] = []

    current = start
    heading = float(initial_heading)

    for _ in range(
        tracker_settings.maximum_tracking_steps
    ):
        current_y, current_x = current

        best_candidate: tuple[int, int] | None = None
        best_segment: list[tuple[int, int]] = []
        best_heading = heading
        best_score = -np.inf
        best_connects_to_existing = False

        tested_candidates: set[tuple[int, int]] = set()

        # Search the entire forward cone.
        for distance in range(
            1,
            maximum_gap + 1,
        ):
            for angle_offset in cone_offsets:
                search_heading = (
                    heading + float(angle_offset)
                )

                candidate_y = int(
                    round(
                        current_y
                        + distance
                        * np.sin(search_heading)
                    )
                )

                candidate_x = int(
                    round(
                        current_x
                        + distance
                        * np.cos(search_heading)
                    )
                )

                candidate = (
                    candidate_y,
                    candidate_x,
                )

                if candidate in tested_candidates:
                    continue

                tested_candidates.add(candidate)

                if not (
                    0 <= candidate_y < height
                    and 0 <= candidate_x < width
                ):
                    continue

                if candidate == current:
                    continue

                candidate_is_visited = bool(
                    visited[candidate_y, candidate_x]
                )

                candidate_probability = float(
                    probability[
                        candidate_y,
                        candidate_x,
                    ]
                )

                # A new destination must contain plausible contact
                # evidence. An already tracked destination may be used
                # to merge at an intersection.
                if (
                    not candidate_is_visited
                    and candidate_probability
                    < tracker_settings.min_probability
                ):
                    continue

                movement_heading = float(
                    np.arctan2(
                        candidate_y - current_y,
                        candidate_x - current_x,
                    )
                )

                turn_angle = directed_angle_difference(
                    movement_heading,
                    heading,
                )

                if turn_angle > maximum_turn:
                    continue

                segment = line_points_between(
                    current,
                    candidate,
                )

                if not segment:
                    continue

                valid_segment: list[tuple[int, int]] = []

                segment_probabilities: list[float] = []
                segment_coherences: list[float] = []

                for point_y, point_x in segment:
                    if not (
                        0 <= point_y < height
                        and 0 <= point_x < width
                    ):
                        continue

                    valid_segment.append(
                        (
                            point_y,
                            point_x,
                        )
                    )

                    segment_probabilities.append(
                        float(
                            probability[
                                point_y,
                                point_x,
                            ]
                        )
                    )

                    segment_coherences.append(
                        float(
                            coherence[
                                point_y,
                                point_x,
                            ]
                        )
                    )

                if not valid_segment:
                    continue

                mean_path_probability = float(
                    np.mean(segment_probabilities)
                )

                maximum_path_probability = float(
                    np.max(segment_probabilities)
                )

                mean_path_coherence = float(
                    np.mean(segment_coherences)
                )

                destination_tangent = (
                    float(
                        orientation_angle[
                            candidate_y,
                            candidate_x,
                        ]
                    )
                    + np.pi / 2
                ) % np.pi

                orientation_difference = (
                    axial_angle_difference(
                        movement_heading % np.pi,
                        destination_tangent,
                    )
                )

                orientation_score = float(
                    np.cos(orientation_difference)
                )

                normalized_turn = float(
                    turn_angle
                    / max(maximum_turn, 1e-8)
                )

                normalized_distance = float(
                    (distance - 1)
                    / max(maximum_gap - 1, 1)
                )

                # Reward destinations and paths supported by CNN
                # evidence. Permit low-valued pixels inside dotted gaps.
                probability_score = (
                    0.55 * candidate_probability
                    + 0.25 * mean_path_probability
                    + 0.20 * maximum_path_probability
                )

                score = (
                    tracker_settings.probability_weight
                    * probability_score
                    + tracker_settings.orientation_weight
                    * orientation_score
                    + tracker_settings.coherence_weight
                    * mean_path_coherence
                    - tracker_settings.turn_penalty_weight
                    * normalized_turn
                    - 0.12
                    * normalized_distance
                )

                # Encourage legitimate merging at intersections.
                if candidate_is_visited:
                    score += 0.08

                if score > best_score:
                    best_score = score
                    best_candidate = candidate
                    best_segment = valid_segment
                    best_heading = movement_heading
                    best_connects_to_existing = (
                        candidate_is_visited
                    )

        if (
            best_candidate is None
            or best_score
            < tracker_settings.minimum_tracking_score
        ):
            break

        added_new_pixel = False

        for point_y, point_x in best_segment:
            if visited[point_y, point_x]:
                continue

            visited[point_y, point_x] = True

            path.append(
                (
                    point_y,
                    point_x,
                )
            )

            added_new_pixel = True

        current = best_candidate
        heading = best_heading

        if best_connects_to_existing:
            break

        if not added_new_pixel:
            break

    return path

def directional_tracking(
    probability: np.ndarray,
    orientation: dict[str, np.ndarray],
    seeds: np.ndarray,
) -> np.ndarray:
    """
    Track geological contacts in both directions from reliable seeds.

    Tracking follows the contour tangent estimated from the structure
    tensor while considering probability, coherence and turning angle.
    """

    tracker_settings = global_settings.contour_tracker

    print("Tracker settings:")
    print(vars(tracker_settings))

    print("Probability weight:",
      tracker_settings.probability_weight)

    print("Maximum steps:",
      tracker_settings.maximum_tracking_steps)

    probability = np.asarray(
        probability,
        dtype=np.float32,
    )

    seed_mask = np.asarray(seeds) > 0

    orientation_angle = np.asarray(
        orientation["angle"],
        dtype=np.float32,
    )

    coherence = np.asarray(
        orientation["coherence"],
        dtype=np.float32,
    )

    if probability.ndim != 2:
        raise ValueError(
            "probability must be a two-dimensional array."
        )

    if (
        orientation_angle.shape != probability.shape
        or coherence.shape != probability.shape
        or seed_mask.shape != probability.shape
    ):
        raise ValueError(
            "Probability, orientation, coherence and seeds "
            "must have identical shapes."
        )

    tracked = np.zeros(
        probability.shape,
        dtype=np.uint8,
    )

    visited = np.zeros(
        probability.shape,
        dtype=bool,
    )

    seed_coordinates = np.argwhere(seed_mask)

    if seed_coordinates.size == 0:
        return tracked

    # Process the strongest CNN seeds first.
    seed_probabilities = probability[
        seed_coordinates[:, 0],
        seed_coordinates[:, 1],
    ]

    seed_order = np.argsort(seed_probabilities)[::-1]

    for seed_index in seed_order:
        seed_y, seed_x = seed_coordinates[seed_index]

        if visited[seed_y, seed_x]:
            continue

        seed = (
            int(seed_y),
            int(seed_x),
        )

        visited[seed_y, seed_x] = True
        tracked[seed_y, seed_x] = 255

        # Convert gradient-normal orientation into contour tangent.
        tangent = (
            float(orientation_angle[seed_y, seed_x])
            + np.pi / 2
        ) % np.pi

        forward_path = trace_direction(
            probability=probability,
            orientation_angle=orientation_angle,
            coherence=coherence,
            visited=visited,
            start=seed,
            initial_heading=tangent,
            tracker_settings=tracker_settings,
        )

        backward_path = trace_direction(
            probability=probability,
            orientation_angle=orientation_angle,
            coherence=coherence,
            visited=visited,
            start=seed,
            initial_heading=tangent + np.pi,
            tracker_settings=tracker_settings,
        )

        for point_y, point_x in forward_path:
            tracked[point_y, point_x] = 255

        for point_y, point_x in backward_path:
            tracked[point_y, point_x] = 255

    return tracked

def bridge_gaps(
    tracked: np.ndarray,
):
    return tracked

# ============================================================
# MODULE TEST
# ============================================================

if __name__ == "__main__":

    all_probabilities = np.load(
        "outputs/predictions/map004_probabilities.npy"
    )

    probability = all_probabilities[1].astype(np.float32)

    print("Selected probability shape:", probability.shape)

    tracked, debug = track_contours(
        probability,
        return_debug=True,
    )

    seed_mask = debug["seeds"] > 0
    tracked_mask = tracked > 0

    bridges_only = np.logical_and(
        tracked_mask,
        np.logical_not(seed_mask),
    ).astype(np.uint8) * 255

    cv2.imwrite(
        "outputs/debug_channels/bridges_only.png",
        bridges_only,
    )

    cv2.imwrite(
        "outputs/debug_channels/tracked.png",
        tracked,
    )

    cv2.imwrite(
        "outputs/debug_channels/seeds.png",
        (debug["seeds"] * 255).astype(np.uint8),
    )

    cv2.imwrite(
        "outputs/debug_channels/coherence.png",
        (
            debug["orientation"]["coherence"] * 255
        ).astype(np.uint8),
    )

    cv2.imwrite(
        "outputs/debug_channels/gradient_magnitude.png",
        (
            debug["gradient_magnitude"] * 255
        ).astype(np.uint8),
    )

    cv2.imwrite(
    "outputs/debug_channels/cleaned_probability.png",
    (
        debug["cleaned_probability"] * 255
    ).astype(np.uint8),
)

    print("Saved:")
    print("outputs/debug_channels/tracked.png")
    print("outputs/debug_channels/seeds.png")
    print("outputs/debug_channels/coherence.png")
    print("outputs/debug_channels/gradient_magnitude.png")
    print("outputs/debug_channels/cleaned_probability.png")
    print("outputs/debug_channels/bridges_only.png")