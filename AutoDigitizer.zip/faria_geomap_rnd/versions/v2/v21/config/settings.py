"""
settings.py

Global configuration for GeoMapPrototype V2.1.

Every configurable parameter in the project should live here.
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ==========================================================
# Probability Recovery
# ==========================================================

@dataclass
class ProbabilityRecoverySettings:

    gaussian_sigma: float = 1.2

    bilateral_diameter: int = 7
    bilateral_sigma_color: float = 60.0
    bilateral_sigma_space: float = 60.0

    confidence_gamma: float = 0.90

    closing_radius: int = 2
    opening_radius: int = 1

    clip_min: float = 0.0
    clip_max: float = 1.0


# ==========================================================
# Contour Tracking
# ==========================================================

@dataclass
class ContourTrackerSettings:

    orientation_sigma: float = 2.0

    coherence_threshold: float = 0.10

    max_tracking_gap: int = 12

    max_turn_angle: float = 45.0

    min_probability: float = 0.05

    smoothing_iterations: int = 2

    probability_weight: float = 0.40
    orientation_weight: float = 0.30
    coherence_weight: float = 0.20
    turn_penalty_weight: float = 0.10

    minimum_tracking_score: float = 0.10
    maximum_tracking_steps: int = 10000


# ==========================================================
# Adaptive Threshold
# ==========================================================

@dataclass
class AdaptiveThresholdSettings:

    strong_threshold: float = 0.55

    weak_threshold: float = 0.20

    neighbourhood_size: int = 5

    minimum_component_area: int = 20


# ==========================================================
# Junction Recovery
# ==========================================================

@dataclass
class JunctionRecoverySettings:

    search_radius: int = 8

    endpoint_distance: int = 10

    bridge_distance: int = 15

    angle_threshold: float = 30.0


# ==========================================================
# Topology Cleanup
# ==========================================================

@dataclass
class TopologyCleanupSettings:

    minimum_branch_length: int = 8

    minimum_component_size: int = 20

    preserve_closed_loops: bool = True

    simplify_tolerance: float = 1.5


# ==========================================================
# Graph Refinement
# ==========================================================

@dataclass
class GraphRefinementSettings:

    bridge_iterations: int = 2

    recover_junctions: bool = True

    preserve_endpoints: bool = True

    remove_spurs: bool = True


# ==========================================================
# Vectorization
# ==========================================================

@dataclass
class VectorizerSettings:

    simplify_tolerance: float = 1.5

    minimum_line_length: float = 10.0

    minimum_polygon_area: float = 25.0

    preserve_junctions: bool = True


# ==========================================================
# GIS Export
# ==========================================================

@dataclass
class ExportSettings:

    export_geojson: bool = True

    export_shapefile: bool = True

    export_geopackage: bool = True

    export_csv: bool = True

    export_excel: bool = True


# ==========================================================
# Debug
# ==========================================================

@dataclass
class DebugSettings:

    save_probability_images: bool = True

    save_tracking_images: bool = True

    save_graph_images: bool = True

    save_vector_preview: bool = True

    verbose: bool = True


# ==========================================================
# Master Settings
# ==========================================================



@dataclass
class Settings:

    probability: ProbabilityRecoverySettings = field(
        default_factory=ProbabilityRecoverySettings
    )

    contour_tracker: ContourTrackerSettings = field(
        default_factory=ContourTrackerSettings
    )

    adaptive_threshold: AdaptiveThresholdSettings = field(
        default_factory=AdaptiveThresholdSettings
    )

    junction_recovery: JunctionRecoverySettings = field(
        default_factory=JunctionRecoverySettings
    )

    topology_cleanup: TopologyCleanupSettings = field(
        default_factory=TopologyCleanupSettings
    )

    graph_refinement: GraphRefinementSettings = field(
        default_factory=GraphRefinementSettings
    )

    vectorizer: VectorizerSettings = field(
        default_factory=VectorizerSettings
    )

    export: ExportSettings = field(
        default_factory=ExportSettings
    )

    debug: DebugSettings = field(
        default_factory=DebugSettings
    )


settings = Settings()