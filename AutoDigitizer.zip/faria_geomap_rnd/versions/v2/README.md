﻿# GeoMap V2 — SE-U-Net Machine Learning Pipeline

## Overview

V2 marks the transition from the primarily rule-based and image-processing
approach used in V1 to a machine-learning-based geological map segmentation
pipeline.

The main model introduced in this version is SE-U-Net (Squeeze-and-Excitation
U-Net). The purpose of the model is to learn geological/cartographic features
from training data instead of relying entirely on manually selected colour,
threshold, and morphology rules.

V2 became the main experimental foundation for the later GeoMap research.

---

## Why V2 Was Created

V1 demonstrated that geological units and boundaries could be extracted using
classical image-processing techniques. However, geological maps vary
substantially in colour palettes, printing styles, scanning quality, line
thickness, text, symbols, and map layouts.

Rules that worked well on one map did not necessarily generalize to another.

V2 therefore investigated whether a learned segmentation model could provide
a more general foundation for geological-map digitization.

---

## Main Model

### SE-U-Net

Implementation:

    models/se_unet.py

SE-U-Net combines a U-Net-style encoder/decoder architecture with
Squeeze-and-Excitation blocks.

The U-Net structure provides pixel-level segmentation while the SE blocks
reweight feature channels so the network can emphasize useful learned
features.

The model produces segmentation logits which are converted into class
probabilities during inference.

---

## Prediction Representation

    models/model_prediction.py

V2 introduced a structured prediction representation containing:

- predicted class mask
- per-class probability maps
- confidence map
- uncertainty map
- model metadata

This later became important for the multi-model architecture because models
can be compared using probabilities and uncertainty rather than only their
final masks.

---

## Training Pipeline

Important files include:

    pipelines/create_training_masks_v2.py
    pipelines/create_training_tiles.py
    pipelines/train_se_unet.py

Large geological maps are prepared for model training and divided into
smaller image regions/tiles.

This allows the model to operate on large maps without requiring the complete
map to be processed as one tensor.

---

## Inference Pipeline

Important files:

    pipelines/predict_se_unet.py
    pipelines/inference_core.py

During inference a map can be divided into overlapping tiles.

Each tile is processed by SE-U-Net and the predictions are combined to
reconstruct the prediction over the original map.

The inference system also calculates confidence and uncertainty information.

---

## Post-Processing and Geological Structure Recovery

V2 also investigated methods for converting raw neural-network predictions
into cleaner geological structures.

Relevant files include:

    pipelines/graph_refinement_v2.py
    pipelines/hybrid_refine_prediction.py
    pipelines/ood_sanity_guard.py
    pipelines/postprocess_to_geojson.py

These experiments explored:

- prediction refinement
- graph/topology processing
- out-of-distribution safeguards
- conversion of raster predictions toward vector/GIS representations

---

## Main V2 Pipeline

    run_v2_pipeline.py

This script represents the higher-level V2 workflow and connects the
different processing stages.

---

## Limitations Observed

Although SE-U-Net provided a learned segmentation foundation, segmentation
alone did not completely solve geological-map digitization.

Important remaining problems included:

- broken or disconnected geological contacts
- uncertain predictions around difficult boundaries
- thin structures being lost or fragmented
- clutter being confused with geological structures
- topology requiring additional repair
- conversion from raster predictions into useful GIS geometry
- variation between different map styles

These limitations motivated the V2.1 refinement work.

---

# V2.1

V2.1 is an extension of V2 rather than a completely separate model version.

The implementation is preserved under:

    v21/

V2.1 investigated additional processing after the initial segmentation,
including:

- adaptive thresholding
- alignment
- contour tracking
- probability-based recovery
- junction recovery
- contact refinement
- graph refinement
- topology cleanup
- GIS vectorization
- geometry and attribute handling

See:

    v21/README.md

for the V2.1 implementation.

---

## Later Research

The V2 working environment was also used for additional R&D after the
original V2/V2.1 development.

This included experiments involving:

- hybrid local/context models
- multi-head geological prediction
- geological-region affinity
- SAM2-assisted refinement
- topology/vectorization experiments

These experiments should not be interpreted as the original V2.1
implementation. They represent later research directions that helped inform
subsequent versions of the system.

---

## Evolution

    V1
    Classical image processing
        |
        v
    V2
    SE-U-Net segmentation
        |
        v
    V2.1
    Refinement + topology + GIS processing
        |
        v
    Later R&D experiments
        |
        v
    V3
    Mask2Former integration

V2 therefore represents the first major machine-learning foundation of the
GeoMap digitization research.
