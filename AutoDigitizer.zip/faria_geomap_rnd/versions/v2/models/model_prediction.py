from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np


@dataclass
class ModelPrediction:
    model_name: str
    prediction_type: str
    confidence_type: str

    predicted_classes: np.ndarray
    class_probabilities: np.ndarray
    confidence_map: np.ndarray
    uncertainty_map: np.ndarray

    source_path: Path | None = None
    checkpoint_path: Path | None = None

    metadata: dict[str, Any] = field(
        default_factory=dict
    )

    def validate(self) -> None:
        if self.predicted_classes.ndim != 2:
            raise ValueError(
                "predicted_classes must have shape [H, W]."
            )

        if self.class_probabilities.ndim != 3:
            raise ValueError(
                "class_probabilities must have shape [C, H, W]."
            )

        class_count, height, width = (
            self.class_probabilities.shape
        )

        if self.predicted_classes.shape != (
            height,
            width,
        ):
            raise ValueError(
                "Prediction mask dimensions do not match "
                "class probability dimensions."
            )

        if self.confidence_map.shape != (
            height,
            width,
        ):
            raise ValueError(
                "Confidence map dimensions do not match prediction."
            )

        if self.uncertainty_map.shape != (
            height,
            width,
        ):
            raise ValueError(
                "Uncertainty map dimensions do not match prediction."
            )

        if class_count < 2:
            raise ValueError(
                "At least two classes are required."
            )