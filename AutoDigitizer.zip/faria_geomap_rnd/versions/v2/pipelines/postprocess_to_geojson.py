
from pathlib import Path
import cv2
import numpy as np
import geopandas as gpd
from shapely.geometry import shape, Polygon, MultiPolygon
from shapely.validation import make_valid
from rasterio.features import shapes
from scipy import ndimage

base_dir = Path(__file__).parent

segmented_path = base_dir / "outputs" / "segmented_kmeans.png"
original_path = base_dir / "data" / "raw_maps" / "map001.png"

output_dir = base_dir / "outputs" / "polygonized"
output_dir.mkdir(parents=True, exist_ok=True)

geojson_path = output_dir / "polygonized_units.geojson"
class_raster_path = output_dir / "class_id_raster.png"
filled_raster_path = output_dir / "class_id_raster_contact_filled.png"

seg = cv2.imread(str(segmented_path))
if seg is None:
    raise FileNotFoundError(f"Could not load segmented image: {segmented_path}")

original = cv2.imread(str(original_path))
if original is None:
    raise FileNotFoundError(f"Could not load original image: {original_path}")

seg_rgb = cv2.cvtColor(seg, cv2.COLOR_BGR2RGB)
original_gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)

h, w = seg_rgb.shape[:2]

if original_gray.shape != (h, w):
    original_gray = cv2.resize(
        original_gray,
        (w, h),
        interpolation=cv2.INTER_NEAREST
    )

cluster_colors = [
    [222, 101, 53],   # 0 orange
    [241, 191, 249],  # 1 pink
    [195, 153, 111],  # 2 tan
    [135, 189, 142],  # 3 light green
    [63, 41, 30],     # 4 dark linework/text
    [234, 176, 66],   # 5 yellow
    [104, 140, 104],  # 6 dark green
    [230, 231, 224],  # 7 light grey
    [90, 164, 214],   # 8 blue
]

skip_classes = [4]  # white + dark linework/text

class_raster = np.full((h, w), 255, dtype=np.uint8)

for class_id, color in enumerate(cluster_colors):
    if class_id in skip_classes:
        continue

    color = np.array(color)
    tolerance = 8

    lower = np.maximum(color - tolerance, 0)
    upper = np.minimum(color + tolerance, 255)

    mask = cv2.inRange(seg_rgb, lower, upper)
    class_raster[mask > 0] = class_id

# Optional layout mask: A, B, legend, scale bar, north arrow
layout_mask_path = base_dir / "data" / "masks" / "layout_ignore_mask.png"
layout_mask = cv2.imread(str(layout_mask_path), cv2.IMREAD_GRAYSCALE)

if layout_mask is not None:
    if layout_mask.shape != class_raster.shape:
        layout_mask = cv2.resize(
            layout_mask,
            (w, h),
            interpolation=cv2.INTER_NEAREST
        )

    class_raster[layout_mask > 0] = 255
    print("Applied layout ignore mask")
else:
    print("No layout mask found")

cv2.imwrite(str(class_raster_path), class_raster)

# Remove only thin dark contact-line pixels, not huge dark areas
dark_mask = cv2.inRange(original_gray, 0, 75)

num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(dark_mask)

contact_mask = np.zeros_like(dark_mask)

for i in range(1, num_labels):
    x = stats[i, cv2.CC_STAT_LEFT]
    y = stats[i, cv2.CC_STAT_TOP]
    bw = stats[i, cv2.CC_STAT_WIDTH]
    bh = stats[i, cv2.CC_STAT_HEIGHT]
    area = stats[i, cv2.CC_STAT_AREA]

    # Keep small/medium contact fragments.
    # Avoid removing huge labels or large text blocks.
    if area < 2000 and bw < 250 and bh < 120:
        contact_mask[labels == i] = 255

if layout_mask is not None:
    contact_mask[layout_mask > 0] = 0

# Make contact pixels unclassified so they become boundary gap zones
class_raster[contact_mask > 0] = 255

# Fill only small unclassified gaps using nearest class
invalid = class_raster == 255
valid = class_raster != 255

_, indices = ndimage.distance_transform_edt(
    ~valid,
    return_indices=True
)

labeled_invalid, num_invalid = ndimage.label(invalid)

filled_raster = class_raster.copy()

max_gap_size = 1200

for region_id in range(1, num_invalid + 1):
    region = labeled_invalid == region_id
    size = int(region.sum())

    if size <= max_gap_size:
        filled_raster[region] = class_raster[
            indices[0][region],
            indices[1][region]
        ]

# Majority smoothing to reduce small islands pulling boundaries
#filled_raster = ndimage.median_filter(filled_raster, size=3)

class_raster = filled_raster.astype(np.uint8)
cv2.imwrite(str(filled_raster_path), class_raster)

unique, counts = np.unique(class_raster, return_counts=True)
print("Class raster values:")
for u, c in zip(unique, counts):
    print(u, c)

features = []

valid_pixels = class_raster != 255

for geom, value in shapes(class_raster.astype(np.int16), mask=valid_pixels):
    class_id = int(value)

    if class_id == 255:
        continue

    geom_obj = shape(geom)

    if geom_obj.is_empty:
        continue

    if not geom_obj.is_valid:
        geom_obj = make_valid(geom_obj)

    if geom_obj.is_empty:
        continue

    geoms = []

    if geom_obj.geom_type == "Polygon":
        geoms = [geom_obj]
    elif geom_obj.geom_type == "MultiPolygon":
        geoms = list(geom_obj.geoms)
    elif geom_obj.geom_type == "GeometryCollection":
        geoms = [g for g in geom_obj.geoms if g.geom_type == "Polygon"]

    for poly in geoms:
        if poly.is_empty:
            continue

        if poly.area < 50:
            continue

        # Smooth jagged pixel boundaries but do not destroy topology too much
        try:
          poly = poly.simplify(0.35, preserve_topology=True)
        except Exception:
          pass
        if poly.is_empty:
            continue

        if not poly.is_valid:
            poly = make_valid(poly)

        if poly.is_empty:
            continue

        if poly.area < 50:
            continue

        features.append(
            {
                "class_id": class_id,
                "class_name": f"class_{class_id}",
                "area_px": float(poly.area),
                "geometry": poly,
            }
        )

print("Polygons created:", len(features))

if len(features) == 0:
    raise RuntimeError("No polygons created. Check class colors, masks, and filled raster.")

gdf = gpd.GeoDataFrame(features, geometry="geometry", crs=None)
gdf.to_file(geojson_path, driver="GeoJSON")

print("Saved class raster:", class_raster_path)
print("Saved filled raster:", filled_raster_path)
print("Saved polygonized GeoJSON:", geojson_path)

