from pathlib import Path
import sys

import cv2
import numpy as np
import torch


BASE_DIR = Path(__file__).resolve().parents[1]

sys.path.append(str(BASE_DIR))

from models.se_unet import SEUNet
from pipelines.inference_core import predict_tiled_map


INPUT_PATH = (
    BASE_DIR
    / "data"
    / "validation"
    / "map004.jpg"
)

CHECKPOINT_PATH = (
    BASE_DIR
    / "outputs"
    / "checkpoints_v2"
    / "se_unet_v2_best.pth"
)

OUTPUT_DIR = (
    BASE_DIR
    / "outputs"
    / "predictions"
)

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


IMAGE_SIZE = 512
TILE_OVERLAP = 128
BASE_CHANNELS = 32
CONFIDENCE_ALPHA = 0.5

DEVICE = torch.device(
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)


CLASS_COLORS_RGB = np.array(
    [
        [0, 0, 0],
        [255, 255, 255],
        [255, 215, 0],
        [0, 110, 255],
    ],
    dtype=np.uint8,
)


def load_model() -> tuple[
    SEUNet,
    dict,
]:
    if not CHECKPOINT_PATH.exists():
        raise FileNotFoundError(
            f"Checkpoint not found: {CHECKPOINT_PATH}"
        )

    checkpoint = torch.load(
        CHECKPOINT_PATH,
        map_location=DEVICE,
        weights_only=False,
    )

    num_classes = int(
        checkpoint.get(
            "num_classes",
            4,
        )
    )

    base_channels = int(
        checkpoint.get(
            "base_channels",
            BASE_CHANNELS,
        )
    )

    model = SEUNet(
        in_channels=3,
        num_classes=num_classes,
        base_channels=base_channels,
        use_se=True,
    ).to(DEVICE)

    model.load_state_dict(
        checkpoint["model_state_dict"]
    )

    model.eval()

    return (
        model,
        checkpoint,
    )


def create_preview(
    predicted_classes: np.ndarray,
) -> np.ndarray:
    maximum_class = int(
        predicted_classes.max()
    )

    if maximum_class >= len(CLASS_COLORS_RGB):
        raise ValueError(
            "CLASS_COLORS_RGB does not contain enough colors "
            f"for class {maximum_class}."
        )

    return CLASS_COLORS_RGB[
        predicted_classes
    ].astype(np.uint8)


def create_overlay(
    original_bgr: np.ndarray,
    predicted_classes: np.ndarray,
) -> np.ndarray:
    original_rgb = cv2.cvtColor(
        original_bgr,
        cv2.COLOR_BGR2RGB,
    )

    overlay_rgb = original_rgb.copy()

    overlay_rgb[
        predicted_classes == 1
    ] = [
        255,
        0,
        0,
    ]

    overlay_rgb[
        predicted_classes == 2
    ] = [
        255,
        215,
        0,
    ]

    overlay_rgb[
        predicted_classes == 3
    ] = [
        0,
        110,
        255,
    ]

    return cv2.addWeighted(
        original_rgb,
        0.65,
        overlay_rgb,
        0.35,
        0,
    )


def progress_callback(
    completed: int,
    total: int,
) -> None:
    if (
        completed % 10 == 0
        or completed == total
    ):
        print(
            f"Processed {completed}/{total} tiles"
        )


def main() -> None:
    print(
        "Loading validation image:",
        INPUT_PATH,
    )

    image_bgr = cv2.imread(
        str(INPUT_PATH),
        cv2.IMREAD_COLOR,
    )

    if image_bgr is None:
        raise FileNotFoundError(
            f"Could not load image: {INPUT_PATH}"
        )

    model, checkpoint = load_model()

    print(
        "Model loaded."
    )

    print(
        "Device:",
        DEVICE,
    )

    print(
        "Checkpoint epoch:",
        checkpoint.get(
            "epoch",
            "unknown",
        ),
    )

    print(
        "Checkpoint validation loss:",
        checkpoint.get(
            "validation_loss",
            checkpoint.get(
                "val_loss",
                "unknown",
            ),
        ),
    )

    prediction = predict_tiled_map(
        model=model,
        image_bgr=image_bgr,
        model_name="se_unet",
        device=DEVICE,
        tile_size=IMAGE_SIZE,
        tile_overlap=TILE_OVERLAP,
        confidence_alpha=CONFIDENCE_ALPHA,
        source_path=INPUT_PATH,
        checkpoint_path=CHECKPOINT_PATH,
        progress_callback=progress_callback,
    )

    map_name = INPUT_PATH.stem

    raw_mask_path = (
        OUTPUT_DIR
        / f"{map_name}_predicted_classes.png"
    )

    numpy_mask_path = (
        OUTPUT_DIR
        / f"{map_name}_predicted_classes.npy"
    )

    probabilities_path = (
        OUTPUT_DIR
        / f"{map_name}_probabilities.npy"
    )

    preview_path = (
        OUTPUT_DIR
        / f"{map_name}_prediction_preview.png"
    )

    overlay_path = (
        OUTPUT_DIR
        / f"{map_name}_prediction_overlay.png"
    )

    confidence_path = (
        OUTPUT_DIR
        / f"{map_name}_confidence.png"
    )

    uncertainty_path = (
        OUTPUT_DIR
        / f"{map_name}_uncertainty.png"
    )

    preview_rgb = create_preview(
        prediction.predicted_classes
    )

    overlay_rgb = create_overlay(
        image_bgr,
        prediction.predicted_classes,
    )

    confidence_image = np.clip(
        prediction.confidence_map
        * 255.0,
        0,
        255,
    ).astype(np.uint8)

    uncertainty_image = np.clip(
        prediction.uncertainty_map
        * 255.0,
        0,
        255,
    ).astype(np.uint8)

    np.save(
        numpy_mask_path,
        prediction.predicted_classes,
    )

    np.save(
        probabilities_path,
        prediction.class_probabilities,
    )

    cv2.imwrite(
        str(raw_mask_path),
        prediction.predicted_classes,
    )

    cv2.imwrite(
        str(preview_path),
        cv2.cvtColor(
            preview_rgb,
            cv2.COLOR_RGB2BGR,
        ),
    )

    cv2.imwrite(
        str(overlay_path),
        cv2.cvtColor(
            overlay_rgb,
            cv2.COLOR_RGB2BGR,
        ),
    )

    cv2.imwrite(
        str(confidence_path),
        confidence_image,
    )

    cv2.imwrite(
        str(uncertainty_path),
        uncertainty_image,
    )

    unique_classes, counts = np.unique(
        prediction.predicted_classes,
        return_counts=True,
    )

    print(
        "\nPrediction class counts:"
    )

    for class_id, count in zip(
        unique_classes,
        counts,
    ):
        print(
            f"Class {int(class_id)}: "
            f"{int(count)} pixels"
        )

    print(
        "Mean confidence:",
        prediction.metadata[
            "normalized_confidence_mean"
        ],
    )

    print(
        "Saved raw mask:",
        raw_mask_path,
    )

    print(
        "Saved NumPy mask:",
        numpy_mask_path,
    )

    print(
        "Saved probabilities:",
        probabilities_path,
    )

    print(
        "Saved confidence:",
        confidence_path,
    )

    print(
        "Saved uncertainty:",
        uncertainty_path,
    )


if __name__ == "__main__":
    main()