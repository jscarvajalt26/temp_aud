from pathlib import Path

import cv2
import numpy as np
from skimage.morphology import skeletonize


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[1]

TRAINING_DIR = BASE_DIR / "data" / "training"

DATASETS = [
    {
        "name": "color",
        "image_dir": TRAINING_DIR / "color" / "images",
        "mask_dir": TRAINING_DIR / "color" / "masks_v2",
        "preview_dir": TRAINING_DIR / "color" / "mask_previews_v2",
    },
    {
        "name": "grayscale",
        "image_dir": TRAINING_DIR / "grayscale" / "images",
        "mask_dir": TRAINING_DIR / "grayscale" / "masks_v2",
        "preview_dir": TRAINING_DIR / "grayscale" / "mask_previews_v2",
    },
]


# ============================================================
# MASK CLASSES
# ============================================================

# 0 = background / ignore
# 1 = likely geological contact
# 2 = likely fault / vein / major structural feature
# 3 = likely text / label / printed clutter

BACKGROUND_CLASS = 0
CONTACT_CLASS = 1
VEIN_CLASS = 2
CLUTTER_CLASS = 3

NUM_CLASSES = 4


# ============================================================
# GENERAL SETTINGS
# ============================================================

MIN_COMPONENT_AREA = 8

CONTACT_MIN_COMPONENT_AREA = 10
CONTACT_MAX_COMPONENT_AREA = 30000
CONTACT_MAX_AVERAGE_THICKNESS = 6.0

VEIN_MIN_AREA = 15
VEIN_MAX_AREA = 9000
VEIN_MIN_LENGTH = 20
VEIN_MAX_THICKNESS = 6.0
VEIN_MIN_ELONGATION = 4.2
VEIN_MIN_ASPECT_RATIO = 3.0

COLOR_EDGE_THRESHOLD_LOW = 35
COLOR_EDGE_THRESHOLD_HIGH = 105

GRAYSCALE_BLOCK_SIZE = 41
GRAYSCALE_C = 9


# ============================================================
# STRICT TEXT DETECTION SETTINGS
# ============================================================

TEXT_MIN_WIDTH = 10
TEXT_MAX_WIDTH = 220

TEXT_MIN_HEIGHT = 5
TEXT_MAX_HEIGHT = 38

TEXT_MIN_ASPECT_RATIO = 1.25
TEXT_MAX_ASPECT_RATIO = 18.0

TEXT_MIN_DENSITY = 0.06
TEXT_MAX_DENSITY = 0.70

TEXT_MIN_DARK_PIXELS = 16

# Horizontal grouping joins letters into words.
TEXT_GROUP_KERNEL_WIDTH = 9
TEXT_GROUP_KERNEL_HEIGHT = 3

# Small dilation makes the final text mask cover characters,
# without spreading excessively into nearby map features.
TEXT_FINAL_DILATION_SIZE = 2

# Remove text pixels that touch likely contacts.
TEXT_CONTACT_EXCLUSION_RADIUS = 2


# ============================================================
# MAP TYPE DETECTION
# ============================================================

def is_grayscale_like(image_bgr: np.ndarray) -> bool:
    hsv = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2HSV,
    )

    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]

    valid = (
        (value > 35)
        & (value < 248)
    )

    if not np.any(valid):
        return True

    mean_saturation = float(
        np.mean(saturation[valid])
    )

    high_saturation_ratio = float(
        np.mean(saturation[valid] > 45)
    )

    return not (
        mean_saturation > 25
        and high_saturation_ratio > 0.08
    )


# ============================================================
# BASIC DARK PIXEL MASK
# ============================================================

def create_dark_print_mask(
    gray: np.ndarray,
) -> np.ndarray:
    """
    Detect printed dark objects such as text, numbers and symbols.

    This is only a candidate image. Further geometric filtering is
    applied before anything is assigned to the clutter class.
    """

    clahe = cv2.createCLAHE(
        clipLimit=1.8,
        tileGridSize=(8, 8),
    )

    enhanced = clahe.apply(gray)

    dark_print = cv2.adaptiveThreshold(
        enhanced,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        31,
        11,
    )

    return dark_print


# ============================================================
# STRICT TEXT / LABEL DETECTION
# ============================================================

def detect_text_candidates(
    gray: np.ndarray,
) -> np.ndarray:
    """
    Detect word-like horizontal groups rather than every small dark mark.

    This is deliberately strict so dotted textures, isolated symbols,
    pattern fills and small geological marks are less likely to become
    clutter.
    """

    dark_print = create_dark_print_mask(
        gray
    )

    horizontal_kernel = cv2.getStructuringElement(
        cv2.MORPH_RECT,
        (
            TEXT_GROUP_KERNEL_WIDTH,
            TEXT_GROUP_KERNEL_HEIGHT,
        ),
    )

    grouped = cv2.morphologyEx(
        dark_print,
        cv2.MORPH_CLOSE,
        horizontal_kernel,
        iterations=1,
    )

    component_count, component_labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            grouped,
            connectivity=8,
        )
    )

    text_mask = np.zeros_like(
        gray,
        dtype=np.uint8,
    )

    for component_id in range(1, component_count):
        x = int(
            stats[component_id, cv2.CC_STAT_LEFT]
        )

        y = int(
            stats[component_id, cv2.CC_STAT_TOP]
        )

        width = int(
            stats[component_id, cv2.CC_STAT_WIDTH]
        )

        height = int(
            stats[component_id, cv2.CC_STAT_HEIGHT]
        )

        grouped_area = int(
            stats[component_id, cv2.CC_STAT_AREA]
        )

        if width < TEXT_MIN_WIDTH or width > TEXT_MAX_WIDTH:
            continue

        if height < TEXT_MIN_HEIGHT or height > TEXT_MAX_HEIGHT:
            continue

        aspect_ratio = (
            width / max(height, 1)
        )

        if (
            aspect_ratio < TEXT_MIN_ASPECT_RATIO
            or aspect_ratio > TEXT_MAX_ASPECT_RATIO
        ):
            continue

        bounding_box_area = max(
            width * height,
            1,
        )

        grouped_density = (
            grouped_area
            / bounding_box_area
        )

        if (
            grouped_density < TEXT_MIN_DENSITY
            or grouped_density > TEXT_MAX_DENSITY
        ):
            continue

        roi_dark = dark_print[
            y:y + height,
            x:x + width,
        ]

        dark_pixel_count = int(
            np.count_nonzero(roi_dark)
        )

        if dark_pixel_count < TEXT_MIN_DARK_PIXELS:
            continue

        original_dark_density = (
            dark_pixel_count
            / bounding_box_area
        )

        # Reject extremely sparse dotted textures.
        if original_dark_density < 0.035:
            continue

        # Reject large dense pattern-filled geological regions.
        if original_dark_density > 0.60:
            continue

        # Use the original character pixels, not the entire grouped box.
        text_mask[
            y:y + height,
            x:x + width,
        ][roi_dark > 0] = 255

    if TEXT_FINAL_DILATION_SIZE > 0:
        dilation_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (
                TEXT_FINAL_DILATION_SIZE,
                TEXT_FINAL_DILATION_SIZE,
            ),
        )

        text_mask = cv2.dilate(
            text_mask,
            dilation_kernel,
            iterations=1,
        )

    return text_mask


# ============================================================
# COLOR MAP CONTACT DETECTION
# ============================================================

def detect_color_contacts(
    image_bgr: np.ndarray,
) -> np.ndarray:
    """
    Detect likely geological contacts from transitions in LAB colour.
    """

    smoothed = cv2.bilateralFilter(
        image_bgr,
        d=7,
        sigmaColor=35,
        sigmaSpace=35,
    )

    lab = cv2.cvtColor(
        smoothed,
        cv2.COLOR_BGR2LAB,
    )

    l_channel, a_channel, b_channel = cv2.split(
        lab
    )

    edges_l = cv2.Canny(
        l_channel,
        COLOR_EDGE_THRESHOLD_LOW,
        COLOR_EDGE_THRESHOLD_HIGH,
    )

    edges_a = cv2.Canny(
        a_channel,
        20,
        70,
    )

    edges_b = cv2.Canny(
        b_channel,
        20,
        70,
    )

    combined = cv2.bitwise_or(
        edges_l,
        cv2.bitwise_or(
            edges_a,
            edges_b,
        ),
    )

    hsv = cv2.cvtColor(
        smoothed,
        cv2.COLOR_BGR2HSV,
    )

    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]

    valid_map_colour = (
        (saturation > 15)
        & (value > 30)
        & (value < 252)
    )

    combined[
        ~valid_map_colour
    ] = 0

    combined = cv2.morphologyEx(
        combined,
        cv2.MORPH_CLOSE,
        np.array(
            [
                [0, 1, 0],
                [1, 1, 1],
                [0, 1, 0],
            ],
            dtype=np.uint8,
        ),
        iterations=1,
    )

    combined = skeletonize(
        combined > 0
    ).astype(np.uint8) * 255

    return combined


# ============================================================
# GRAYSCALE MAP CONTACT DETECTION
# ============================================================

def detect_grayscale_contacts(
    image_bgr: np.ndarray,
) -> np.ndarray:
    """
    Detect line-like candidates while rejecting thick regions and most
    isolated scan artifacts.
    """

    gray = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    denoised = cv2.bilateralFilter(
        gray,
        d=7,
        sigmaColor=35,
        sigmaSpace=35,
    )

    clahe = cv2.createCLAHE(
        clipLimit=1.7,
        tileGridSize=(8, 8),
    )

    enhanced = clahe.apply(
        denoised
    )

    dark_lines = cv2.adaptiveThreshold(
        enhanced,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        GRAYSCALE_BLOCK_SIZE,
        GRAYSCALE_C,
    )

    component_count, component_labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            dark_lines,
            connectivity=8,
        )
    )

    retained = np.zeros_like(
        dark_lines,
        dtype=np.uint8,
    )

    for component_id in range(1, component_count):
        area = int(
            stats[component_id, cv2.CC_STAT_AREA]
        )

        width = int(
            stats[component_id, cv2.CC_STAT_WIDTH]
        )

        height = int(
            stats[component_id, cv2.CC_STAT_HEIGHT]
        )

        if area < CONTACT_MIN_COMPONENT_AREA:
            continue

        if area > CONTACT_MAX_COMPONENT_AREA:
            continue

        region = (
            component_labels == component_id
        )

        component_skeleton = skeletonize(
            region
        )

        skeleton_length = int(
            component_skeleton.sum()
        )

        if skeleton_length < 10:
            continue

        average_thickness = (
            area
            / max(skeleton_length, 1)
        )

        if (
            average_thickness
            > CONTACT_MAX_AVERAGE_THICKNESS
        ):
            continue

        aspect_ratio = max(
            width / max(height, 1),
            height / max(width, 1),
        )

        likely_contact = (
            skeleton_length >= 32
            or aspect_ratio >= 1.7
        )

        if likely_contact:
            retained[region] = 255

    retained = cv2.morphologyEx(
        retained,
        cv2.MORPH_CLOSE,
        np.array(
            [
                [0, 1, 0],
                [1, 1, 1],
                [0, 1, 0],
            ],
            dtype=np.uint8,
        ),
        iterations=1,
    )

    retained = skeletonize(
        retained > 0
    ).astype(np.uint8) * 255

    return retained


# ============================================================
# REMOVE TINY COMPONENTS
# ============================================================

def remove_tiny_components(
    binary_mask: np.ndarray,
    minimum_area: int,
) -> np.ndarray:
    component_count, component_labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            binary_mask,
            connectivity=8,
        )
    )

    cleaned = np.zeros_like(
        binary_mask
    )

    for component_id in range(1, component_count):
        area = int(
            stats[component_id, cv2.CC_STAT_AREA]
        )

        if area >= minimum_area:
            cleaned[
                component_labels == component_id
            ] = 255

    return cleaned


# ============================================================
# MAJOR LINEAR FEATURE DETECTION
# ============================================================

def detect_linear_features(
    image_bgr: np.ndarray,
    contact_mask: np.ndarray,
) -> np.ndarray:
    """
    Detect longer, darker and more elongated structural features.
    """

    gray = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    dark = gray < 92

    contact_buffer = cv2.dilate(
        contact_mask,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (5, 5),
        ),
        iterations=1,
    ) > 0

    candidates = (
        dark
        & (~contact_buffer)
    )

    candidate_image = (
        candidates.astype(np.uint8)
        * 255
    )

    component_count, component_labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            candidate_image,
            connectivity=8,
        )
    )

    retained = np.zeros_like(
        candidate_image,
        dtype=bool,
    )

    for component_id in range(1, component_count):
        area = int(
            stats[component_id, cv2.CC_STAT_AREA]
        )

        width = int(
            stats[component_id, cv2.CC_STAT_WIDTH]
        )

        height = int(
            stats[component_id, cv2.CC_STAT_HEIGHT]
        )

        if area < VEIN_MIN_AREA or area > VEIN_MAX_AREA:
            continue

        region = (
            component_labels == component_id
        )

        component_skeleton = skeletonize(
            region
        )

        skeleton_length = int(
            component_skeleton.sum()
        )

        if skeleton_length < VEIN_MIN_LENGTH:
            continue

        average_thickness = (
            area
            / max(skeleton_length, 1)
        )

        if average_thickness > VEIN_MAX_THICKNESS:
            continue

        ys, xs = np.where(
            region
        )

        if len(xs) < 4:
            continue

        coordinates = np.column_stack(
            [xs, ys]
        ).astype(np.float32)

        centered = (
            coordinates
            - coordinates.mean(
                axis=0,
                keepdims=True,
            )
        )

        covariance = np.cov(
            centered,
            rowvar=False,
        )

        eigenvalues = np.linalg.eigvalsh(
            covariance
        )

        elongation = (
            float(eigenvalues[-1]) + 1e-6
        ) / (
            float(eigenvalues[0]) + 1e-6
        )

        aspect_ratio = max(
            width / max(height, 1),
            height / max(width, 1),
        )

        if (
            elongation >= VEIN_MIN_ELONGATION
            or aspect_ratio >= VEIN_MIN_ASPECT_RATIO
        ):
            retained |= region

    return (
        skeletonize(retained).astype(np.uint8)
        * 255
    )


# ============================================================
# PROTECT CONTACTS FROM TEXT MASK
# ============================================================

def remove_contact_overlap_from_text(
    text_mask: np.ndarray,
    contact_mask: np.ndarray,
) -> np.ndarray:
    """
    Prevent blue text labels from erasing nearby geological contacts.
    """

    result = text_mask.copy()

    kernel_size = (
        TEXT_CONTACT_EXCLUSION_RADIUS * 2 + 1
    )

    contact_buffer = cv2.dilate(
        contact_mask,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (
                kernel_size,
                kernel_size,
            ),
        ),
        iterations=1,
    )

    result[
        contact_buffer > 0
    ] = 0

    return result


# ============================================================
# CREATE FINAL TRAINING MASK
# ============================================================

def create_training_mask(
    image_bgr: np.ndarray,
    dataset_name: str,
) -> np.ndarray:
    gray = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    grayscale_map = (
        dataset_name == "grayscale"
        or is_grayscale_like(image_bgr)
    )

    if grayscale_map:
        contacts = detect_grayscale_contacts(
            image_bgr
        )
    else:
        contacts = detect_color_contacts(
            image_bgr
        )

    contacts = remove_tiny_components(
        contacts,
        minimum_area=CONTACT_MIN_COMPONENT_AREA,
    )

    linear_features = detect_linear_features(
        image_bgr,
        contacts,
    )

    linear_features = remove_tiny_components(
        linear_features,
        minimum_area=12,
    )

    text_candidates = detect_text_candidates(
        gray
    )

    text_candidates = remove_contact_overlap_from_text(
        text_candidates,
        contacts,
    )

    # Class priority:
    # vein/fault > geological contact > text > background

    contacts[
        linear_features > 0
    ] = 0

    text_candidates[
        linear_features > 0
    ] = 0

    text_candidates[
        contacts > 0
    ] = 0

    mask = np.zeros(
        gray.shape,
        dtype=np.uint8,
    )

    mask[
        text_candidates > 0
    ] = CLUTTER_CLASS

    mask[
        contacts > 0
    ] = CONTACT_CLASS

    mask[
        linear_features > 0
    ] = VEIN_CLASS

    return mask


# ============================================================
# SAVE PREVIEW
# ============================================================

def save_preview(
    mask: np.ndarray,
    preview_path: Path,
) -> None:
    preview = np.zeros(
        (
            mask.shape[0],
            mask.shape[1],
            3,
        ),
        dtype=np.uint8,
    )

    # BGR colours.
    preview[
        mask == CONTACT_CLASS
    ] = [255, 255, 255]   # white

    preview[
        mask == VEIN_CLASS
    ] = [0, 0, 255]       # red

    preview[
        mask == CLUTTER_CLASS
    ] = [255, 0, 0]       # blue

    cv2.imwrite(
        str(preview_path),
        preview,
    )


# ============================================================
# PROCESS DATASET
# ============================================================

def process_dataset(
    dataset_name: str,
    image_dir: Path,
    mask_dir: Path,
    preview_dir: Path,
) -> None:
    mask_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    preview_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    image_paths = []

    for extension in [
        "*.png",
        "*.jpg",
        "*.jpeg",
        "*.tif",
        "*.tiff",
    ]:
        image_paths.extend(
            image_dir.glob(extension)
        )

    image_paths = sorted(
        image_paths
    )

    if not image_paths:
        print(
            "No images found:",
            image_dir,
        )
        return

    for index, image_path in enumerate(
        image_paths,
        start=1,
    ):
        image_bgr = cv2.imread(
            str(image_path),
            cv2.IMREAD_COLOR,
        )

        if image_bgr is None:
            print(
                "Skipping unreadable image:",
                image_path,
            )
            continue

        mask = create_training_mask(
            image_bgr,
            dataset_name,
        )

        mask_path = (
            mask_dir
            / image_path.name
        )

        preview_path = (
            preview_dir
            / image_path.name
        )

        cv2.imwrite(
            str(mask_path),
            mask,
        )

        save_preview(
            mask,
            preview_path,
        )

        if (
            index % 25 == 0
            or index == len(image_paths)
        ):
            print(
                f"{dataset_name}: "
                f"{index}/{len(image_paths)} masks created"
            )

    print(
        f"Finished {dataset_name} dataset."
    )

    print(
        "Masks:",
        mask_dir,
    )

    print(
        "Previews:",
        preview_dir,
    )


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    for dataset in DATASETS:
        process_dataset(
            dataset_name=dataset["name"],
            image_dir=dataset["image_dir"],
            mask_dir=dataset["mask_dir"],
            preview_dir=dataset["preview_dir"],
        )


if __name__ == "__main__":
    main()