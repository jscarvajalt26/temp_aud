from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from scipy import ndimage as ndi
from scipy.spatial import cKDTree
from skimage.morphology import skeletonize, thin


# ============================================================
# DEFAULT SETTINGS
# ============================================================

CONTACT_STRONG_THRESHOLD = 0.55
CONTACT_WEAK_THRESHOLD = 0.20

MIN_COMPONENT_AREA = 6
MIN_SKELETON_LENGTH = 8

SHORT_GAP_RADIUS = 10.0
MEDIUM_GAP_RADIUS = 40.0

MAX_SHORT_ANGLE_DEGREES = 55.0
MAX_MEDIUM_ANGLE_DEGREES = 35.0

SHORT_GAP_MIN_PROBABILITY = 0.10
MEDIUM_GAP_MIN_PROBABILITY = 0.16

ENDPOINT_DIRECTION_RADIUS = 7

JUNCTION_RECOVERY_RADIUS = 4
JUNCTION_PROBABILITY_THRESHOLD = 0.14

MAX_BRIDGES_PER_ENDPOINT = 1

DISPLAY_THICKNESS = 5


# ============================================================
# DATA STRUCTURES
# ============================================================

@dataclass
class Endpoint:
    index: int
    x: int
    y: int
    direction: np.ndarray | None


@dataclass
class BridgeCandidate:
    first_index: int
    second_index: int

    first_x: int
    first_y: int

    second_x: int
    second_y: int

    distance: float
    first_angle: float
    second_angle: float
    mean_probability: float
    minimum_probability: float
    score: float


# ============================================================
# BASIC CLEANUP
# ============================================================

def remove_small_components(
    binary_mask: np.ndarray,
    minimum_area: int,
) -> np.ndarray:
    binary = (
        binary_mask > 0
    ).astype(np.uint8)

    component_count, labels, stats, _ = (
        cv2.connectedComponentsWithStats(
            binary,
            connectivity=8,
        )
    )

    result = np.zeros_like(
        binary,
        dtype=np.uint8,
    )

    for component_id in range(
        1,
        component_count,
    ):
        area = int(
            stats[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        if area >= minimum_area:
            result[
                labels == component_id
            ] = 255

    return result


def remove_short_skeleton_components(
    skeleton_mask: np.ndarray,
    minimum_length: int,
) -> np.ndarray:
    skeleton = (
        skeleton_mask > 0
    )

    labels, component_count = ndi.label(
        skeleton,
        structure=np.ones(
            (3, 3),
            dtype=np.uint8,
        ),
    )

    result = np.zeros_like(
        skeleton_mask,
        dtype=np.uint8,
    )

    for component_id in range(
        1,
        component_count + 1,
    ):
        region = (
            labels == component_id
        )

        length = int(
            region.sum()
        )

        if length >= minimum_length:
            result[
                region
            ] = 255

    return result


# ============================================================
# HYSTERESIS RECOVERY
# ============================================================

def hysteresis_contact_mask(
    contact_probability: np.ndarray,
    strong_threshold: float,
    weak_threshold: float,
) -> np.ndarray:
    if contact_probability.ndim != 2:
        raise ValueError(
            "contact_probability must have shape [H, W]."
        )

    strong = (
        contact_probability
        >= strong_threshold
    )

    weak = (
        contact_probability
        >= weak_threshold
    )

    weak_labels, weak_component_count = ndi.label(
        weak,
        structure=np.ones(
            (3, 3),
            dtype=np.uint8,
        ),
    )

    result = np.zeros_like(
        contact_probability,
        dtype=np.uint8,
    )

    strong_component_ids = np.unique(
        weak_labels[
            strong
        ]
    )

    strong_component_ids = (
        strong_component_ids[
            strong_component_ids != 0
        ]
    )

    for component_id in strong_component_ids:
        result[
            weak_labels == component_id
        ] = 255

    return result


# ============================================================
# ENDPOINT DETECTION
# ============================================================

def find_endpoints(
    skeleton_mask: np.ndarray,
) -> np.ndarray:
    binary = (
        skeleton_mask > 0
    ).astype(np.uint8)

    neighbor_kernel = np.ones(
        (3, 3),
        dtype=np.uint8,
    )

    neighborhood_sum = cv2.filter2D(
        binary,
        ddepth=cv2.CV_16S,
        kernel=neighbor_kernel,
        borderType=cv2.BORDER_CONSTANT,
    )

    endpoints = (
        (binary > 0)
        & (neighborhood_sum == 2)
    )

    return endpoints.astype(
        np.uint8
    ) * 255


def estimate_endpoint_direction(
    skeleton_mask: np.ndarray,
    x: int,
    y: int,
    radius: int,
) -> np.ndarray | None:
    height, width = skeleton_mask.shape

    x_min = max(
        x - radius,
        0,
    )

    x_max = min(
        x + radius + 1,
        width,
    )

    y_min = max(
        y - radius,
        0,
    )

    y_max = min(
        y + radius + 1,
        height,
    )

    patch = (
        skeleton_mask[
            y_min:y_max,
            x_min:x_max,
        ] > 0
    )

    ys, xs = np.where(
        patch
    )

    if len(xs) < 2:
        return None

    xs = (
        xs.astype(np.float32)
        + float(x_min)
    )

    ys = (
        ys.astype(np.float32)
        + float(y_min)
    )

    dx = xs - float(x)
    dy = ys - float(y)

    distances_squared = (
        dx * dx
        + dy * dy
    )

    valid = (
        distances_squared > 0.0
    )

    if not np.any(
        valid
    ):
        return None

    valid_indices = np.where(
        valid
    )[0]

    farthest_valid_index = valid_indices[
        np.argmax(
            distances_squared[
                valid
            ]
        )
    ]

    interior_vector = np.array(
        [
            dx[
                farthest_valid_index
            ],
            dy[
                farthest_valid_index
            ],
        ],
        dtype=np.float32,
    )

    outward_vector = (
        -interior_vector
    )

    norm = float(
        np.linalg.norm(
            outward_vector
        )
    )

    if norm <= 1e-6:
        return None

    return (
        outward_vector
        / norm
    )


def build_endpoint_list(
    skeleton_mask: np.ndarray,
) -> list[Endpoint]:
    endpoint_mask = find_endpoints(
        skeleton_mask
    )

    ys, xs = np.where(
        endpoint_mask > 0
    )

    endpoints: list[Endpoint] = []

    for index, (
        x,
        y,
    ) in enumerate(
        zip(
            xs.tolist(),
            ys.tolist(),
        )
    ):
        direction = estimate_endpoint_direction(
            skeleton_mask=skeleton_mask,
            x=x,
            y=y,
            radius=ENDPOINT_DIRECTION_RADIUS,
        )

        endpoints.append(
            Endpoint(
                index=index,
                x=x,
                y=y,
                direction=direction,
            )
        )

    return endpoints


# ============================================================
# BRIDGE GEOMETRY
# ============================================================

def angle_between_vectors(
    first: np.ndarray,
    second: np.ndarray,
) -> float:
    denominator = float(
        np.linalg.norm(first)
        * np.linalg.norm(second)
    )

    if denominator <= 1e-6:
        return 180.0

    cosine = float(
        np.dot(
            first,
            second,
        )
        / denominator
    )

    cosine = float(
        np.clip(
            cosine,
            -1.0,
            1.0,
        )
    )

    return float(
        np.degrees(
            np.arccos(
                cosine
            )
        )
    )


def sample_line_coordinates(
    first_x: int,
    first_y: int,
    second_x: int,
    second_y: int,
) -> tuple[np.ndarray, np.ndarray]:
    sample_count = int(
        max(
            abs(
                second_x - first_x
            ),
            abs(
                second_y - first_y
            ),
        )
    ) + 1

    xs = np.rint(
        np.linspace(
            first_x,
            second_x,
            sample_count,
        )
    ).astype(np.int32)

    ys = np.rint(
        np.linspace(
            first_y,
            second_y,
            sample_count,
        )
    ).astype(np.int32)

    return (
        xs,
        ys,
    )


def sample_bridge_probability(
    contact_probability: np.ndarray,
    first_x: int,
    first_y: int,
    second_x: int,
    second_y: int,
) -> tuple[float, float]:
    xs, ys = sample_line_coordinates(
        first_x=first_x,
        first_y=first_y,
        second_x=second_x,
        second_y=second_y,
    )

    height, width = (
        contact_probability.shape
    )

    valid = (
        (xs >= 0)
        & (xs < width)
        & (ys >= 0)
        & (ys < height)
    )

    if not np.any(
        valid
    ):
        return (
            0.0,
            0.0,
        )

    values = contact_probability[
        ys[
            valid
        ],
        xs[
            valid
        ],
    ]

    if values.size == 0:
        return (
            0.0,
            0.0,
        )

    return (
        float(
            np.mean(
                values
            )
        ),
        float(
            np.min(
                values
            )
        ),
    )


def line_crosses_existing_network(
    skeleton_mask: np.ndarray,
    first_x: int,
    first_y: int,
    second_x: int,
    second_y: int,
) -> bool:
    xs, ys = sample_line_coordinates(
        first_x=first_x,
        first_y=first_y,
        second_x=second_x,
        second_y=second_y,
    )

    if len(xs) <= 4:
        return False

    interior_xs = xs[
        2:-2
    ]

    interior_ys = ys[
        2:-2
    ]

    if len(interior_xs) == 0:
        return False

    height, width = (
        skeleton_mask.shape
    )

    valid = (
        (interior_xs >= 0)
        & (interior_xs < width)
        & (interior_ys >= 0)
        & (interior_ys < height)
    )

    if not np.any(
        valid
    ):
        return False

    return bool(
        np.any(
            skeleton_mask[
                interior_ys[
                    valid
                ],
                interior_xs[
                    valid
                ],
            ] > 0
        )
    )


# ============================================================
# FAST ENDPOINT MATCHING
# ============================================================

def create_bridge_candidate(
    first: Endpoint,
    second: Endpoint,
    skeleton_mask: np.ndarray,
    contact_probability: np.ndarray,
) -> BridgeCandidate | None:
    if (
        first.direction is None
        or second.direction is None
    ):
        return None

    dx = float(
        second.x
        - first.x
    )

    dy = float(
        second.y
        - first.y
    )

    distance = float(
        np.hypot(
            dx,
            dy,
        )
    )

    if distance <= 1.0:
        return None

    if distance > MEDIUM_GAP_RADIUS:
        return None

    connection_direction = np.array(
        [
            dx,
            dy,
        ],
        dtype=np.float32,
    )

    connection_direction /= max(
        float(
            np.linalg.norm(
                connection_direction
            )
        ),
        1e-6,
    )

    first_angle = angle_between_vectors(
        first.direction,
        connection_direction,
    )

    second_angle = angle_between_vectors(
        second.direction,
        -connection_direction,
    )

    if distance <= SHORT_GAP_RADIUS:
        maximum_angle = (
            MAX_SHORT_ANGLE_DEGREES
        )

        minimum_mean_probability = (
            SHORT_GAP_MIN_PROBABILITY
        )
    else:
        maximum_angle = (
            MAX_MEDIUM_ANGLE_DEGREES
        )

        minimum_mean_probability = (
            MEDIUM_GAP_MIN_PROBABILITY
        )

    if first_angle > maximum_angle:
        return None

    if second_angle > maximum_angle:
        return None

    if line_crosses_existing_network(
        skeleton_mask=skeleton_mask,
        first_x=first.x,
        first_y=first.y,
        second_x=second.x,
        second_y=second.y,
    ):
        return None

    (
        mean_probability,
        minimum_probability,
    ) = sample_bridge_probability(
        contact_probability=contact_probability,
        first_x=first.x,
        first_y=first.y,
        second_x=second.x,
        second_y=second.y,
    )

    if (
        mean_probability
        < minimum_mean_probability
    ):
        return None

    score = (
        mean_probability * 4.0
        + minimum_probability * 1.0
        - distance * 0.025
        - first_angle * 0.008
        - second_angle * 0.008
    )

    return BridgeCandidate(
        first_index=first.index,
        second_index=second.index,
        first_x=first.x,
        first_y=first.y,
        second_x=second.x,
        second_y=second.y,
        distance=distance,
        first_angle=first_angle,
        second_angle=second_angle,
        mean_probability=mean_probability,
        minimum_probability=minimum_probability,
        score=score,
    )


def find_bridge_candidates(
    skeleton_mask: np.ndarray,
    contact_probability: np.ndarray,
) -> list[BridgeCandidate]:
    endpoints = build_endpoint_list(
        skeleton_mask
    )

    if len(endpoints) < 2:
        return []

    endpoint_coordinates = np.array(
        [
            [
                endpoint.x,
                endpoint.y,
            ]
            for endpoint in endpoints
        ],
        dtype=np.float32,
    )

    tree = cKDTree(
        endpoint_coordinates
    )

    candidate_pairs = tree.query_pairs(
        r=MEDIUM_GAP_RADIUS,
        output_type="set",
    )

    candidates: list[
        BridgeCandidate
    ] = []

    for (
        first_index,
        second_index,
    ) in candidate_pairs:
        candidate = create_bridge_candidate(
            first=endpoints[
                first_index
            ],
            second=endpoints[
                second_index
            ],
            skeleton_mask=skeleton_mask,
            contact_probability=contact_probability,
        )

        if candidate is not None:
            candidates.append(
                candidate
            )

    candidates.sort(
        key=lambda candidate: (
            candidate.score
        ),
        reverse=True,
    )

    return candidates


def apply_bridge_candidates(
    skeleton_mask: np.ndarray,
    candidates: list[BridgeCandidate],
) -> tuple[
    np.ndarray,
    list[BridgeCandidate],
]:
    result = skeleton_mask.copy()

    endpoint_usage: dict[int, int] = {}

    accepted: list[
        BridgeCandidate
    ] = []

    for candidate in candidates:
        first_usage = endpoint_usage.get(
            candidate.first_index,
            0,
        )

        second_usage = endpoint_usage.get(
            candidate.second_index,
            0,
        )

        if (
            first_usage
            >= MAX_BRIDGES_PER_ENDPOINT
        ):
            continue

        if (
            second_usage
            >= MAX_BRIDGES_PER_ENDPOINT
        ):
            continue

        cv2.line(
            result,
            (
                candidate.first_x,
                candidate.first_y,
            ),
            (
                candidate.second_x,
                candidate.second_y,
            ),
            255,
            thickness=1,
            lineType=cv2.LINE_AA,
        )

        endpoint_usage[
            candidate.first_index
        ] = (
            first_usage + 1
        )

        endpoint_usage[
            candidate.second_index
        ] = (
            second_usage + 1
        )

        accepted.append(
            candidate
        )

    return (
        result,
        accepted,
    )


# ============================================================
# JUNCTION RECOVERY
# ============================================================

def recover_local_junction_support(
    original_bgr: np.ndarray,
    skeleton_mask: np.ndarray,
    contact_probability: np.ndarray,
) -> np.ndarray:
    gray = cv2.cvtColor(
        original_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    blurred = cv2.GaussianBlur(
        gray,
        (
            3,
            3,
        ),
        sigmaX=0.6,
    )

    edges = cv2.Canny(
        blurred,
        threshold1=25,
        threshold2=90,
    )

    contact_neighborhood = cv2.dilate(
        skeleton_mask,
        cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (
                JUNCTION_RECOVERY_RADIUS * 2
                + 1,
                JUNCTION_RECOVERY_RADIUS * 2
                + 1,
            ),
        ),
        iterations=1,
    )

    probability_support = (
        contact_probability
        >= JUNCTION_PROBABILITY_THRESHOLD
    )

    candidates = (
        (edges > 0)
        & (contact_neighborhood > 0)
        & probability_support
    )

    candidates = (
        candidates.astype(
            np.uint8
        )
        * 255
    )

    candidates = remove_small_components(
        candidates,
        minimum_area=3,
    )

    candidates = thin(
        candidates > 0
    ).astype(
        np.uint8
    ) * 255

    recovered = cv2.bitwise_or(
        skeleton_mask,
        candidates,
    )

    return recovered


# ============================================================
# MAIN REFINEMENT
# ============================================================

def refine_contact_network_v2(
    original_bgr: np.ndarray,
    contact_probability: np.ndarray,
) -> dict[str, object]:
    if original_bgr.shape[:2] != (
        contact_probability.shape
    ):
        raise ValueError(
            "Original image and contact probability dimensions do not match."
        )

    hysteresis_mask = hysteresis_contact_mask(
        contact_probability=contact_probability,
        strong_threshold=CONTACT_STRONG_THRESHOLD,
        weak_threshold=CONTACT_WEAK_THRESHOLD,
    )

    hysteresis_mask = remove_small_components(
        hysteresis_mask,
        minimum_area=MIN_COMPONENT_AREA,
    )

    skeleton = skeletonize(
        hysteresis_mask > 0
    ).astype(
        np.uint8
    ) * 255

    skeleton = remove_short_skeleton_components(
        skeleton,
        minimum_length=MIN_SKELETON_LENGTH,
    )

    junction_recovered = (
        recover_local_junction_support(
            original_bgr=original_bgr,
            skeleton_mask=skeleton,
            contact_probability=contact_probability,
        )
    )

    junction_recovered = skeletonize(
        junction_recovered > 0
    ).astype(
        np.uint8
    ) * 255

    candidates = find_bridge_candidates(
        skeleton_mask=junction_recovered,
        contact_probability=contact_probability,
    )

    (
        bridged,
        accepted_bridges,
    ) = apply_bridge_candidates(
        skeleton_mask=junction_recovered,
        candidates=candidates,
    )

    final_contacts = thin(
        bridged > 0
    ).astype(
        np.uint8
    ) * 255

    final_contacts = remove_short_skeleton_components(
        final_contacts,
        minimum_length=MIN_SKELETON_LENGTH,
    )

    final_endpoints = find_endpoints(
        final_contacts
    )

    display_kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (
            DISPLAY_THICKNESS,
            DISPLAY_THICKNESS,
        ),
    )

    display_contacts = cv2.dilate(
        final_contacts,
        display_kernel,
        iterations=1,
    )

    bridge_debug = np.zeros_like(
        final_contacts,
        dtype=np.uint8,
    )

    for bridge in accepted_bridges:
        cv2.line(
            bridge_debug,
            (
                bridge.first_x,
                bridge.first_y,
            ),
            (
                bridge.second_x,
                bridge.second_y,
            ),
            255,
            thickness=1,
            lineType=cv2.LINE_AA,
        )

    return {
        "contacts": final_contacts,
        "display_contacts": display_contacts,
        "endpoints": final_endpoints,
        "accepted_bridges": accepted_bridges,
        "bridge_debug": bridge_debug,
        "hysteresis_mask": hysteresis_mask,
        "junction_recovered": junction_recovered,
        "candidate_count": len(
            candidates
        ),
        "accepted_bridge_count": len(
            accepted_bridges
        ),
    }