from pathlib import Path
import random
import sys

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.utils.data import (
    Dataset,
    DataLoader,
    random_split,
)


# ============================================================
# PROJECT IMPORT
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[1]

sys.path.append(
    str(BASE_DIR)
)

from models.se_unet import SEUNet


# ============================================================
# PATHS
# ============================================================

TRAINING_DIR = (
    BASE_DIR
    / "data"
    / "training"
)

IMAGE_DIRS = [
    TRAINING_DIR / "color" / "images",
    TRAINING_DIR / "grayscale" / "images",
]

MASK_DIRS = [
    TRAINING_DIR / "color" / "masks_v2",
    TRAINING_DIR / "grayscale" / "masks_v2",
]

CHECKPOINT_DIR = (
    BASE_DIR
    / "outputs"
    / "checkpoints_v2"
)

CHECKPOINT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

BEST_MODEL_PATH = (
    CHECKPOINT_DIR
    / "se_unet_v2_best.pth"
)

LAST_MODEL_PATH = (
    CHECKPOINT_DIR
    / "se_unet_v2_last.pth"
)


# ============================================================
# SETTINGS
# ============================================================

NUM_CLASSES = 4
IMAGE_SIZE = 512

BASE_CHANNELS = 32

BATCH_SIZE = 2

MAX_EPOCHS = 30

LEARNING_RATE = 1e-4

WEIGHT_DECAY = 1e-4

VALIDATION_RATIO = 0.20

RANDOM_SEED = 42

EARLY_STOPPING_PATIENCE = 8

NUM_WORKERS = 0

DEVICE = (
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)

USE_AMP = (
    DEVICE == "cuda"
)

# Loss weights.
CROSS_ENTROPY_WEIGHT = 0.45
DICE_WEIGHT = 0.35
FOCAL_WEIGHT = 0.20

FOCAL_GAMMA = 2.0


# ============================================================
# RANDOM SEEDS
# ============================================================

def set_random_seeds(
    seed: int,
) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# ============================================================
# DATASET
# ============================================================

class GeologicalMapDataset(Dataset):
    def __init__(
        self,
        image_dirs: list[Path],
        mask_dirs: list[Path],
        augment: bool = False,
    ) -> None:
        self.samples = []
        self.augment = augment

        supported_extensions = [
            "*.png",
            "*.jpg",
            "*.jpeg",
            "*.tif",
            "*.tiff",
        ]

        for image_dir, mask_dir in zip(
            image_dirs,
            mask_dirs,
        ):
            image_paths = []

            for extension in supported_extensions:
                image_paths.extend(
                    image_dir.glob(extension)
                )

            for image_path in image_paths:
                mask_path = (
                    mask_dir
                    / image_path.name
                )

                if mask_path.exists():
                    self.samples.append(
                        (
                            image_path,
                            mask_path,
                        )
                    )

        self.samples.sort(
            key=lambda sample: str(sample[0])
        )

        if not self.samples:
            raise RuntimeError(
                "No matching image/mask pairs found.\n"
                "Check that masks_v2 folders exist and filenames match."
            )

        print(
            f"Found {len(self.samples)} "
            f"image/mask pairs."
        )

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(
        self,
        index: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        image_path, mask_path = (
            self.samples[index]
        )

        image_bgr = cv2.imread(
            str(image_path),
            cv2.IMREAD_COLOR,
        )

        mask = cv2.imread(
            str(mask_path),
            cv2.IMREAD_GRAYSCALE,
        )

        if image_bgr is None:
            raise FileNotFoundError(
                f"Could not read image: {image_path}"
            )

        if mask is None:
            raise FileNotFoundError(
                f"Could not read mask: {mask_path}"
            )

        image_bgr = cv2.resize(
            image_bgr,
            (
                IMAGE_SIZE,
                IMAGE_SIZE,
            ),
            interpolation=cv2.INTER_AREA,
        )

        mask = cv2.resize(
            mask,
            (
                IMAGE_SIZE,
                IMAGE_SIZE,
            ),
            interpolation=cv2.INTER_NEAREST,
        )

        mask = np.clip(
            mask,
            0,
            NUM_CLASSES - 1,
        ).astype(np.int64)

        if self.augment:
            image_bgr, mask = (
                self.apply_augmentation(
                    image_bgr,
                    mask,
                )
            )

        image_rgb = cv2.cvtColor(
            image_bgr,
            cv2.COLOR_BGR2RGB,
        )

        image_float = (
            image_rgb.astype(np.float32)
            / 255.0
        )

        image_chw = np.transpose(
            image_float,
            (
                2,
                0,
                1,
            ),
        )

        image_tensor = torch.from_numpy(
            image_chw.copy()
        ).float()

        mask_tensor = torch.from_numpy(
            mask.copy()
        ).long()

        return (
            image_tensor,
            mask_tensor,
        )

    @staticmethod
    def apply_augmentation(
        image: np.ndarray,
        mask: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:

        # Horizontal flip.
        if random.random() < 0.5:
            image = cv2.flip(
                image,
                1,
            )

            mask = cv2.flip(
                mask,
                1,
            )

        # Vertical flip.
        if random.random() < 0.5:
            image = cv2.flip(
                image,
                0,
            )

            mask = cv2.flip(
                mask,
                0,
            )

        # 90-degree rotations.
        rotation_count = random.choice(
            [
                0,
                1,
                2,
                3,
            ]
        )

        if rotation_count:
            image = np.rot90(
                image,
                rotation_count,
            ).copy()

            mask = np.rot90(
                mask,
                rotation_count,
            ).copy()

        # Brightness and contrast.
        if random.random() < 0.40:
            alpha = random.uniform(
                0.80,
                1.20,
            )

            beta = random.uniform(
                -18,
                18,
            )

            image = cv2.convertScaleAbs(
                image,
                alpha=alpha,
                beta=beta,
            )

        # Gamma adjustment.
        if random.random() < 0.25:
            gamma = random.uniform(
                0.75,
                1.35,
            )

            lookup_table = np.array(
                [
                    (
                        (value / 255.0)
                        ** (1.0 / gamma)
                    ) * 255
                    for value in range(256)
                ],
                dtype=np.uint8,
            )

            image = cv2.LUT(
                image,
                lookup_table,
            )

        # Gaussian blur.
        if random.random() < 0.20:
            image = cv2.GaussianBlur(
                image,
                (
                    3,
                    3,
                ),
                sigmaX=0.6,
            )

        # Gaussian noise.
        if random.random() < 0.25:
            noise = np.random.normal(
                loc=0.0,
                scale=random.uniform(
                    2.0,
                    8.0,
                ),
                size=image.shape,
            )

            image = np.clip(
                image.astype(np.float32)
                + noise,
                0,
                255,
            ).astype(np.uint8)

        return (
            image,
            mask,
        )


# ============================================================
# CLASS WEIGHTS
# ============================================================

def calculate_class_weights(
    dataset: GeologicalMapDataset,
) -> torch.Tensor:
    class_counts = np.zeros(
        NUM_CLASSES,
        dtype=np.int64,
    )

    print(
        "Calculating class frequencies..."
    )

    for _, mask_path in dataset.samples:
        mask = cv2.imread(
            str(mask_path),
            cv2.IMREAD_GRAYSCALE,
        )

        if mask is None:
            continue

        mask = np.clip(
            mask,
            0,
            NUM_CLASSES - 1,
        )

        values, counts = np.unique(
            mask,
            return_counts=True,
        )

        for class_value, count in zip(
            values,
            counts,
        ):
            class_counts[
                int(class_value)
            ] += int(count)

    class_counts = np.maximum(
        class_counts,
        1,
    )

    frequencies = (
        class_counts
        / class_counts.sum()
    )

    # Inverse square-root weighting.
    class_weights = (
        1.0
        / np.sqrt(frequencies)
    )

    class_weights = (
        class_weights
        / class_weights.mean()
    )

    # Stop very small noisy classes from dominating.
    class_weights = np.clip(
        class_weights,
        0.25,
        4.0,
    )

    print(
        "Class pixel counts:",
        class_counts,
    )

    print(
        "Class frequencies:",
        frequencies,
    )

    print(
        "Class weights:",
        class_weights,
    )

    return torch.tensor(
        class_weights,
        dtype=torch.float32,
        device=DEVICE,
    )


# ============================================================
# DICE LOSS
# ============================================================

class MulticlassDiceLoss(nn.Module):
    def __init__(
        self,
        num_classes: int,
        smooth: float = 1.0,
    ) -> None:
        super().__init__()

        self.num_classes = num_classes
        self.smooth = smooth

    def forward(
        self,
        logits: torch.Tensor,
        targets: torch.Tensor,
    ) -> torch.Tensor:
        probabilities = F.softmax(
            logits,
            dim=1,
        )

        one_hot_targets = F.one_hot(
            targets,
            num_classes=self.num_classes,
        )

        one_hot_targets = one_hot_targets.permute(
            0,
            3,
            1,
            2,
        ).float()

        dimensions = (
            0,
            2,
            3,
        )

        intersection = torch.sum(
            probabilities
            * one_hot_targets,
            dim=dimensions,
        )

        denominator = (
            torch.sum(
                probabilities,
                dim=dimensions,
            )
            + torch.sum(
                one_hot_targets,
                dim=dimensions,
            )
        )

        dice_score = (
            2.0 * intersection
            + self.smooth
        ) / (
            denominator
            + self.smooth
        )

        # Focus more on foreground classes.
        foreground_dice = (
            dice_score[1:]
        )

        if foreground_dice.numel() == 0:
            return (
                1.0
                - dice_score.mean()
            )

        return (
            1.0
            - foreground_dice.mean()
        )


# ============================================================
# FOCAL LOSS
# ============================================================

class MulticlassFocalLoss(nn.Module):
    def __init__(
        self,
        class_weights: torch.Tensor,
        gamma: float = 2.0,
    ) -> None:
        super().__init__()

        self.class_weights = class_weights
        self.gamma = gamma

    def forward(
        self,
        logits: torch.Tensor,
        targets: torch.Tensor,
    ) -> torch.Tensor:
        cross_entropy = F.cross_entropy(
            logits,
            targets,
            weight=self.class_weights,
            reduction="none",
        )

        probability_true_class = torch.exp(
            -cross_entropy
        )

        focal_loss = (
            (
                1.0
                - probability_true_class
            )
            ** self.gamma
        ) * cross_entropy

        return focal_loss.mean()


# ============================================================
# COMBINED LOSS
# ============================================================

class CombinedSegmentationLoss(nn.Module):
    def __init__(
        self,
        class_weights: torch.Tensor,
    ) -> None:
        super().__init__()

        self.cross_entropy = (
            nn.CrossEntropyLoss(
                weight=class_weights,
            )
        )

        self.dice = MulticlassDiceLoss(
            num_classes=NUM_CLASSES,
        )

        self.focal = MulticlassFocalLoss(
            class_weights=class_weights,
            gamma=FOCAL_GAMMA,
        )

    def forward(
        self,
        logits: torch.Tensor,
        targets: torch.Tensor,
    ) -> torch.Tensor:
        cross_entropy_loss = (
            self.cross_entropy(
                logits,
                targets,
            )
        )

        dice_loss = self.dice(
            logits,
            targets,
        )

        focal_loss = self.focal(
            logits,
            targets,
        )

        total_loss = (
            CROSS_ENTROPY_WEIGHT
            * cross_entropy_loss
            + DICE_WEIGHT
            * dice_loss
            + FOCAL_WEIGHT
            * focal_loss
        )

        return total_loss


# ============================================================
# METRICS
# ============================================================

def update_confusion_matrix(
    confusion_matrix: np.ndarray,
    predictions: torch.Tensor,
    targets: torch.Tensor,
) -> None:
    predictions_np = (
        predictions.detach()
        .cpu()
        .numpy()
        .reshape(-1)
    )

    targets_np = (
        targets.detach()
        .cpu()
        .numpy()
        .reshape(-1)
    )

    valid = (
        (targets_np >= 0)
        & (targets_np < NUM_CLASSES)
    )

    encoded = (
        NUM_CLASSES
        * targets_np[valid]
        + predictions_np[valid]
    )

    counts = np.bincount(
        encoded,
        minlength=(
            NUM_CLASSES
            * NUM_CLASSES
        ),
    )

    confusion_matrix += counts.reshape(
        NUM_CLASSES,
        NUM_CLASSES,
    )


def calculate_metrics(
    confusion_matrix: np.ndarray,
) -> dict:
    true_positive = np.diag(
        confusion_matrix
    ).astype(np.float64)

    false_positive = (
        confusion_matrix.sum(axis=0)
        - true_positive
    )

    false_negative = (
        confusion_matrix.sum(axis=1)
        - true_positive
    )

    denominator_iou = (
        true_positive
        + false_positive
        + false_negative
    )

    class_iou = np.divide(
        true_positive,
        denominator_iou,
        out=np.zeros_like(
            true_positive
        ),
        where=(
            denominator_iou > 0
        ),
    )

    denominator_dice = (
        2.0 * true_positive
        + false_positive
        + false_negative
    )

    class_dice = np.divide(
        2.0 * true_positive,
        denominator_dice,
        out=np.zeros_like(
            true_positive
        ),
        where=(
            denominator_dice > 0
        ),
    )

    total_pixels = (
        confusion_matrix.sum()
    )

    pixel_accuracy = (
        true_positive.sum()
        / max(total_pixels, 1)
    )

    # Exclude background from foreground metrics.
    foreground_iou = class_iou[1:]
    foreground_dice = class_dice[1:]

    mean_iou = float(
        foreground_iou.mean()
    )

    mean_dice = float(
        foreground_dice.mean()
    )

    return {
        "pixel_accuracy": float(
            pixel_accuracy
        ),
        "mean_iou": mean_iou,
        "mean_dice": mean_dice,
        "class_iou": class_iou,
        "class_dice": class_dice,
    }


# ============================================================
# TRAIN ONE EPOCH
# ============================================================

def train_one_epoch(
    model: nn.Module,
    dataloader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    scaler: torch.amp.GradScaler | None,
) -> tuple[float, dict]:
    model.train()

    total_loss = 0.0

    confusion_matrix = np.zeros(
        (
            NUM_CLASSES,
            NUM_CLASSES,
        ),
        dtype=np.int64,
    )

    for images, masks in dataloader:
        images = images.to(
            DEVICE,
            non_blocking=True,
        )

        masks = masks.to(
            DEVICE,
            non_blocking=True,
        )

        optimizer.zero_grad(
            set_to_none=True
        )

        if USE_AMP:
            with torch.amp.autocast(
                device_type="cuda",
            ):
                logits = model(
                    images
                )

                loss = criterion(
                    logits,
                    masks,
                )

            scaler.scale(
                loss
            ).backward()

            scaler.unscale_(
                optimizer
            )

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=1.0,
            )

            scaler.step(
                optimizer
            )

            scaler.update()

        else:
            logits = model(
                images
            )

            loss = criterion(
                logits,
                masks,
            )

            loss.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=1.0,
            )

            optimizer.step()

        total_loss += float(
            loss.item()
        )

        predictions = torch.argmax(
            logits,
            dim=1,
        )

        update_confusion_matrix(
            confusion_matrix,
            predictions,
            masks,
        )

    metrics = calculate_metrics(
        confusion_matrix
    )

    average_loss = (
        total_loss
        / max(len(dataloader), 1)
    )

    return (
        average_loss,
        metrics,
    )


# ============================================================
# VALIDATION
# ============================================================

def validate_one_epoch(
    model: nn.Module,
    dataloader: DataLoader,
    criterion: nn.Module,
) -> tuple[float, dict]:
    model.eval()

    total_loss = 0.0

    confusion_matrix = np.zeros(
        (
            NUM_CLASSES,
            NUM_CLASSES,
        ),
        dtype=np.int64,
    )

    with torch.no_grad():
        for images, masks in dataloader:
            images = images.to(
                DEVICE,
                non_blocking=True,
            )

            masks = masks.to(
                DEVICE,
                non_blocking=True,
            )

            if USE_AMP:
                with torch.amp.autocast(
                    device_type="cuda",
                ):
                    logits = model(
                        images
                    )

                    loss = criterion(
                        logits,
                        masks,
                    )

            else:
                logits = model(
                    images
                )

                loss = criterion(
                    logits,
                    masks,
                )

            total_loss += float(
                loss.item()
            )

            predictions = torch.argmax(
                logits,
                dim=1,
            )

            update_confusion_matrix(
                confusion_matrix,
                predictions,
                masks,
            )

    metrics = calculate_metrics(
        confusion_matrix
    )

    average_loss = (
        total_loss
        / max(len(dataloader), 1)
    )

    return (
        average_loss,
        metrics,
    )


# ============================================================
# SAVE CHECKPOINT
# ============================================================

def save_checkpoint(
    path: Path,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    validation_loss: float,
    validation_metrics: dict,
    class_weights: torch.Tensor,
) -> None:
    checkpoint = {
        "model_state_dict": (
            model.state_dict()
        ),
        "optimizer_state_dict": (
            optimizer.state_dict()
        ),
        "epoch": epoch,
        "num_classes": NUM_CLASSES,
        "image_size": IMAGE_SIZE,
        "base_channels": BASE_CHANNELS,
        "validation_loss": (
            validation_loss
        ),
        "validation_mean_iou": (
            validation_metrics[
                "mean_iou"
            ]
        ),
        "validation_mean_dice": (
            validation_metrics[
                "mean_dice"
            ]
        ),
        "validation_pixel_accuracy": (
            validation_metrics[
                "pixel_accuracy"
            ]
        ),
        "class_weights": (
            class_weights
            .detach()
            .cpu()
        ),
    }

    torch.save(
        checkpoint,
        path,
    )


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    set_random_seeds(
        RANDOM_SEED
    )

    print(
        "Device:",
        DEVICE,
    )

    print(
        "Mixed precision:",
        USE_AMP,
    )

    full_dataset = GeologicalMapDataset(
        IMAGE_DIRS,
        MASK_DIRS,
        augment=False,
    )

    class_weights = calculate_class_weights(
        full_dataset
    )

    validation_size = max(
        1,
        int(
            len(full_dataset)
            * VALIDATION_RATIO
        ),
    )

    training_size = (
        len(full_dataset)
        - validation_size
    )

    train_subset, validation_subset = (
        random_split(
            full_dataset,
            [
                training_size,
                validation_size,
            ],
            generator=(
                torch.Generator()
                .manual_seed(
                    RANDOM_SEED
                )
            ),
        )
    )

    train_dataset = GeologicalMapDataset(
        IMAGE_DIRS,
        MASK_DIRS,
        augment=True,
    )

    train_dataset.samples = [
        full_dataset.samples[index]
        for index in train_subset.indices
    ]

    validation_dataset = GeologicalMapDataset(
        IMAGE_DIRS,
        MASK_DIRS,
        augment=False,
    )

    validation_dataset.samples = [
        full_dataset.samples[index]
        for index in validation_subset.indices
    ]

    print(
        "Training samples:",
        len(train_dataset),
    )

    print(
        "Validation samples:",
        len(validation_dataset),
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS,
        pin_memory=USE_AMP,
    )

    validation_loader = DataLoader(
        validation_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=USE_AMP,
    )

    model = SEUNet(
        in_channels=3,
        num_classes=NUM_CLASSES,
        base_channels=BASE_CHANNELS,
        use_se=True,
    ).to(
        DEVICE
    )

    criterion = CombinedSegmentationLoss(
        class_weights=class_weights,
    )

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
    )

    scheduler = (
        torch.optim.lr_scheduler
        .ReduceLROnPlateau(
            optimizer,
            mode="max",
            factor=0.5,
            patience=3,
        )
    )

    scaler = None

    if USE_AMP:
        scaler = torch.amp.GradScaler(
            "cuda"
        )

    best_mean_iou = -1.0

    epochs_without_improvement = 0

    for epoch in range(
        1,
        MAX_EPOCHS + 1,
    ):
        train_loss, train_metrics = (
            train_one_epoch(
                model,
                train_loader,
                criterion,
                optimizer,
                scaler,
            )
        )

        validation_loss, validation_metrics = (
            validate_one_epoch(
                model,
                validation_loader,
                criterion,
            )
        )

        validation_mean_iou = (
            validation_metrics[
                "mean_iou"
            ]
        )

        scheduler.step(
            validation_mean_iou
        )

        current_learning_rate = (
            optimizer
            .param_groups[0]["lr"]
        )

        print(
            f"\nEpoch {epoch:03d}/"
            f"{MAX_EPOCHS}"
        )

        print(
            f"Train Loss: "
            f"{train_loss:.4f}"
        )

        print(
            f"Train IoU: "
            f"{train_metrics['mean_iou']:.4f}"
        )

        print(
            f"Train Dice: "
            f"{train_metrics['mean_dice']:.4f}"
        )

        print(
            f"Val Loss: "
            f"{validation_loss:.4f}"
        )

        print(
            f"Val IoU: "
            f"{validation_metrics['mean_iou']:.4f}"
        )

        print(
            f"Val Dice: "
            f"{validation_metrics['mean_dice']:.4f}"
        )

        print(
            f"Val Pixel Accuracy: "
            f"{validation_metrics['pixel_accuracy']:.4f}"
        )

        print(
            f"Learning Rate: "
            f"{current_learning_rate:.8f}"
        )

        print(
            "Class IoU:",
            np.round(
                validation_metrics[
                    "class_iou"
                ],
                4,
            ),
        )

        save_checkpoint(
            LAST_MODEL_PATH,
            model,
            optimizer,
            epoch,
            validation_loss,
            validation_metrics,
            class_weights,
        )

        if (
            validation_mean_iou
            > best_mean_iou
        ):
            best_mean_iou = (
                validation_mean_iou
            )

            epochs_without_improvement = 0

            save_checkpoint(
                BEST_MODEL_PATH,
                model,
                optimizer,
                epoch,
                validation_loss,
                validation_metrics,
                class_weights,
            )

            print(
                "Saved best model:",
                BEST_MODEL_PATH,
            )

            print(
                f"Best validation IoU: "
                f"{best_mean_iou:.4f}"
            )

        else:
            epochs_without_improvement += 1

            print(
                "No improvement for",
                epochs_without_improvement,
                "epoch(s).",
            )

        if (
            epochs_without_improvement
            >= EARLY_STOPPING_PATIENCE
        ):
            print(
                "Early stopping triggered."
            )

            break

    print(
        "\nTraining finished."
    )

    print(
        "Best model:",
        BEST_MODEL_PATH,
    )
    print(
        "Last model:",
        LAST_MODEL_PATH,
    )

    print(
        f"Best validation IoU: "
        f"{best_mean_iou:.4f}"
    )


if __name__ == "__main__":
    main()