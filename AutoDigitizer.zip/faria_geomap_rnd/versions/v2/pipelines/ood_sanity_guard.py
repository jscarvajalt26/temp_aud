from __future__ import annotations

from dataclasses import dataclass

import numpy as np


# Tune these using known-good Supervisor150 runs.
MAX_SANE_STRONG_FRACTION = 0.15
MAX_SANE_WEAK_FRACTION = 0.35

MIN_SANE_STRONG_FRACTION = 1e-5


@dataclass
class OODCheckResult:
    is_suspect: bool
    strong_fraction: float
    weak_fraction: float
    reasons: list[str]


def check_out_of_distribution(
    strong_mask: np.ndarray,
    weak_mask: np.ndarray,
) -> OODCheckResult:
    """
    Sanity-check raw contact masks before refinement.

    This is not a true statistical OOD detector. It detects obviously
    suspicious model responses so bad predictions are not silently
    treated as trustworthy.
    """

    strong_fraction = float(
        (strong_mask > 0).mean()
    )

    weak_fraction = float(
        (weak_mask > 0).mean()
    )

    reasons: list[str] = []

    if weak_fraction < strong_fraction:
        reasons.append(
            f"weak_mask fraction {weak_fraction:.1%} is smaller than "
            f"strong_mask fraction {strong_fraction:.1%}. "
            "Threshold ordering or mask construction may be incorrect."
        )

    if strong_fraction < MIN_SANE_STRONG_FRACTION:
        reasons.append(
            "strong_mask is essentially empty -- the model may have "
            "failed to detect any contacts."
        )

    if strong_fraction > MAX_SANE_STRONG_FRACTION:
        reasons.append(
            f"strong_mask foreground fraction {strong_fraction:.1%} "
            f"exceeds sane cap {MAX_SANE_STRONG_FRACTION:.0%} -- "
            "model may be treating unrelated linework such as grid lines, "
            "contours, flight lines, or text as contacts."
        )

    if weak_fraction > MAX_SANE_WEAK_FRACTION:
        reasons.append(
            f"weak_mask foreground fraction {weak_fraction:.1%} "
            f"exceeds sane cap {MAX_SANE_WEAK_FRACTION:.0%} -- "
            "nearly the whole map is being marked as candidate contact."
        )

    return OODCheckResult(
        is_suspect=bool(reasons),
        strong_fraction=strong_fraction,
        weak_fraction=weak_fraction,
        reasons=reasons,
    )


def annotate_run_report(
    report: dict,
    ood_result: OODCheckResult,
) -> dict:
    """
    Add the sanity-check result to run_report.json.
    """

    report["ood_check"] = {
        "is_suspect": ood_result.is_suspect,
        "strong_fraction": ood_result.strong_fraction,
        "weak_fraction": ood_result.weak_fraction,
        "reasons": ood_result.reasons,
    }

    return report


def print_ood_warning(
    ood_result: OODCheckResult,
) -> None:
    """
    Print a highly visible warning for suspicious runs.
    """

    if not ood_result.is_suspect:
        return

    print("\n" + "!" * 70)
    print(
        "WARNING: CONTACT PREDICTION FAILED SANITY CHECK"
    )

    for reason in ood_result.reasons:
        print(" -", reason)

    print(
        "Output is being saved for inspection "
        "but should NOT be trusted."
    )

    print("!" * 70 + "\n")


if __name__ == "__main__":
    # Smoke test: simulate catastrophic overprediction.
    fake_strong = np.ones(
        (100, 100),
        dtype=np.uint8,
    ) * 255

    fake_weak = np.ones(
        (100, 100),
        dtype=np.uint8,
    ) * 255

    result = check_out_of_distribution(
        fake_strong,
        fake_weak,
    )

    print(
        "is_suspect:",
        result.is_suspect,
    )

    for reason in result.reasons:
        print(
            " -",
            reason,
        )
        