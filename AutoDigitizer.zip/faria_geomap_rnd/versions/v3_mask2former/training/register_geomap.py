﻿from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from PIL import Image


CLASS_NAMES = [
    "background_or_ignore",
    "geological_contact",
    "fault_vein_or_major_structure",
    "text_label_or_printed_clutter",
]


def load_split_file(split_path: str | Path) -> dict:
    split_path = Path(split_path)

    with split_path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    required = {"train", "validation", "test"}
    missing = required - set(data)

    if missing:
        raise ValueError(
            f"Split file missing keys: {sorted(missing)}"
        )

    return data


def build_semantic_records(
    dataset_root: str | Path,
    map_ids: Iterable[str],
) -> list[dict]:

    dataset_root = Path(dataset_root)

    records = []

    for map_id in map_ids:
        map_dir = dataset_root / map_id

        image_path = map_dir / f"{map_id}_color.png"
        mask_path = map_dir / f"{map_id}_mask.png"

        if not image_path.exists():
            raise FileNotFoundError(
                f"Missing image: {image_path}"
            )

        if not mask_path.exists():
            raise FileNotFoundError(
                f"Missing mask: {mask_path}"
            )

        with Image.open(image_path) as image:
            width, height = image.size

        records.append(
            {
                "file_name": str(image_path),
                "sem_seg_file_name": str(mask_path),
                "image_id": map_id,
                "height": height,
                "width": width,
            }
        )

    return records


def register_geomap_datasets(
    dataset_root: str | Path,
    split_path: str | Path,
) -> None:

    try:
        from detectron2.data import (
            DatasetCatalog,
            MetadataCatalog,
        )
    except ImportError as exc:
        raise RuntimeError(
            "Detectron2 is not installed in this environment. "
            "Dataset registration will be completed on the "
            "Mask2Former Linux/VM environment."
        ) from exc

    split = load_split_file(split_path)

    registrations = {
        "geomap_v3_train": split["train"],
        "geomap_v3_val": split["validation"],
        "geomap_v3_test": split["test"],
    }

    for dataset_name, map_ids in registrations.items():

        if dataset_name in DatasetCatalog.list():
            DatasetCatalog.remove(dataset_name)

        ids = tuple(map_ids)

        DatasetCatalog.register(
            dataset_name,
            lambda ids=ids: build_semantic_records(
                dataset_root,
                ids,
            ),
        )

        MetadataCatalog.get(dataset_name).set(
            stuff_classes=CLASS_NAMES,
            evaluator_type="sem_seg",
            ignore_label=255,
        )


if __name__ == "__main__":

    DATASET_ROOT = (
        r"C:\PROJECT\GeoMapPrototype\DataResearch\Supervisor150"
    )

    SPLIT_PATH = (
        r"C:\PROJECT\GeoMapPrototype\V2\outputs"
        r"\dataset_splits\supervisor150_split.json"
    )

    split = load_split_file(SPLIT_PATH)

    print("GeoMap V3 dataset definition")
    print("----------------------------")
    print("Train:", len(split["train"]))
    print("Validation:", len(split["validation"]))
    print("Test:", len(split["test"]))

    for name in ("train", "validation", "test"):
        print(
            name,
            "example:",
            split[name][0] if split[name] else "EMPTY",
        )

    print()
    print("Canonical classes:")

    for index, name in enumerate(CLASS_NAMES):
        print(index, "->", name)

    print()
    print(
        "NOTE: Detectron2 registration is intentionally "
        "not executed by this standalone audit."
    )
