"""
Train the Mask2Former area model on the Supervisor150 targets.

Each connected area in unit_labels.npy is one target mask of class "area",
so the model learns to separate map areas whatever their colours. The best
checkpoint (highest validation boundary F1) is saved as
mask2former_regions_best.pth, which the runner picks up from --models-dir.

    python -m faria_geomap_rnd.versions.v3_mask2former.training.train_mask2former \
        --device cuda --pretrained facebook/mask2former-swin-tiny-ade-semantic

Without --pretrained it trains a light model from scratch (no download).
"""

from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import cv2
import numpy as np
import torch
from faria_geomap_rnd import config
from faria_geomap_rnd.datasets.supervisor_dataset import SupervisorMapDataset
from faria_geomap_rnd.models import mask2former_regions as m2f
from torch.utils.data import DataLoader

DEFAULT_OUTPUT_DIR = config.OUTPUT_DIR / "checkpoints_mask2former"
SEED = 42


def unit_boundary(units: np.ndarray) -> np.ndarray:
    edge = np.zeros(units.shape, dtype=bool)
    diff_h = units[:, 1:] != units[:, :-1]
    diff_v = units[1:, :] != units[:-1, :]
    edge[:, 1:] |= diff_h
    edge[:, :-1] |= diff_h
    edge[1:, :] |= diff_v
    edge[:-1, :] |= diff_v
    edge[units < 0] = False
    return edge


def collate(samples):
    images, mask_labels, class_labels, boundaries = [], [], [], []
    for sample in samples:
        rgb = (sample["image"].numpy().transpose(1, 2, 0) * 255).astype(np.uint8)
        images.append(m2f.to_pixel_values(rgb)[0])
        units = sample["units"].numpy()
        masks, classes = m2f.area_targets(units)
        mask_labels.append(masks)
        class_labels.append(classes)
        boundaries.append(unit_boundary(units))
    return torch.stack(images), mask_labels, class_labels, boundaries


def boundary_counts(predicted: np.ndarray, target: np.ndarray, tolerance: int = 2):
    """Matched and total boundary pixels, both ways, within a tolerance."""
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * tolerance + 1,) * 2)
    target_near = cv2.dilate(target.astype(np.uint8), kernel) > 0
    predicted_near = cv2.dilate(predicted.astype(np.uint8), kernel) > 0
    return np.array(
        [
            (predicted & target_near).sum(),
            predicted.sum(),
            (target & predicted_near).sum(),
            target.sum(),
        ],
        dtype=np.int64,
    )


def run_epoch(model, loader, device, optimizer=None):
    training = optimizer is not None
    model.train(training)
    losses = []
    counts = np.zeros(4, dtype=np.int64)

    for images, mask_labels, class_labels, boundaries in loader:
        images = images.to(device)
        mask_labels = [m.to(device) for m in mask_labels]
        class_labels = [c.to(device) for c in class_labels]

        with torch.set_grad_enabled(training):
            outputs = model(
                pixel_values=images,
                mask_labels=mask_labels,
                class_labels=class_labels,
            )
            if training:
                optimizer.zero_grad(set_to_none=True)
                outputs.loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 0.1)
                optimizer.step()
        losses.append(float(outputs.loss.detach()))

        if not training:
            size = tuple(images.shape[-2:])
            for i, target in enumerate(boundaries):
                single = type(outputs)(
                    class_queries_logits=outputs.class_queries_logits[i : i + 1],
                    masks_queries_logits=outputs.masks_queries_logits[i : i + 1],
                )
                membership = m2f.area_membership(single, size)
                predicted = (m2f.membership_boundary(membership) >= 0.5).cpu().numpy()
                counts += boundary_counts(predicted, target)

    precision = counts[0] / max(counts[1], 1)
    recall = counts[2] / max(counts[3], 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-9)
    metrics = {
        "boundary_precision": float(precision),
        "boundary_recall": float(recall),
        "boundary_f1": float(f1),
    }
    return (float(np.mean(losses)) if losses else 0.0), metrics


def build_parser():
    parser = argparse.ArgumentParser(
        description="Train the Mask2Former area model on Supervisor150."
    )
    parser.add_argument("--dataset-root", type=Path, default=config.SUPERVISOR150_ROOT)
    parser.add_argument(
        "--target-root", type=Path, default=config.SUPERVISOR_MULTILAYER_TARGET_DIR
    )
    parser.add_argument("--split-path", type=Path, default=config.SUPERVISOR_SPLIT_PATH)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument(
        "--pretrained",
        default=None,
        help=f"HuggingFace model id to start from, e.g. {m2f.DEFAULT_PRETRAINED}",
    )
    parser.add_argument("--crop-size", type=int, default=384)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--backbone-lr-scale", type=float, default=0.1)
    parser.add_argument("--weight-decay", type=float, default=0.05)
    parser.add_argument("--samples-per-map", type=int, default=8)
    parser.add_argument("--patience", type=int, default=6)
    parser.add_argument("--num-workers", type=int, default=2)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)

    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    common = dict(
        dataset_root=args.dataset_root,
        split_path=args.split_path,
        target_root=args.target_root,
        crop_size=args.crop_size,
    )
    train_dataset = SupervisorMapDataset(
        split_name="train",
        random_variant=True,
        augment=True,
        samples_per_map=args.samples_per_map,
        **common,
    )
    validation_dataset = SupervisorMapDataset(
        split_name="validation",
        random_variant=False,
        augment=False,
        samples_per_map=1,
        feature_crop_probability=0.0,
        hard_negative_crop_probability=0.0,
        **common,
    )
    loader_args = dict(
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        collate_fn=collate,
    )
    train_loader = DataLoader(train_dataset, shuffle=True, **loader_args)
    validation_loader = DataLoader(validation_dataset, shuffle=False, **loader_args)

    model = m2f.build_region_model(pretrained=args.pretrained).to(device)

    backbone = [p for n, p in model.named_parameters() if ".encoder." in n]
    backbone_ids = {id(p) for p in backbone}
    rest = [p for p in model.parameters() if id(p) not in backbone_ids]
    optimizer = torch.optim.AdamW(
        [
            {"params": backbone, "lr": args.learning_rate * args.backbone_lr_scale},
            {"params": rest, "lr": args.learning_rate},
        ],
        weight_decay=args.weight_decay,
    )

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    best_path = output_dir / m2f.CHECKPOINT_NAME
    print("Device:", device)
    print("Train maps:", len(train_dataset.map_ids))
    print("Validation maps:", len(validation_dataset.map_ids))

    best_f1, stale, history = -1.0, 0, []
    for epoch in range(1, args.epochs + 1):
        start = time.time()
        train_loss, _ = run_epoch(model, train_loader, device, optimizer)
        validation_loss, metrics = run_epoch(model, validation_loader, device)
        history.append(
            {
                "epoch": epoch,
                "train_loss": train_loss,
                "validation_loss": validation_loss,
                **metrics,
            }
        )
        print(
            f"Epoch {epoch}: train {train_loss:.4f} val {validation_loss:.4f} "
            f"boundary F1 {metrics['boundary_f1']:.4f} "
            f"({time.time() - start:.0f}s)"
        )

        if metrics["boundary_f1"] > best_f1:
            best_f1, stale = metrics["boundary_f1"], 0
            torch.save(
                {
                    "model_name": "mask2former_regions",
                    "architecture": "mask2former",
                    "hf_config": model.config.to_dict(),
                    "model_state_dict": model.state_dict(),
                    "epoch": epoch,
                    "crop_size": args.crop_size,
                    "pretrained": args.pretrained,
                    "validation_metrics": metrics,
                },
                best_path,
            )
            print("Saved best checkpoint:", best_path)
        else:
            stale += 1
            if stale >= args.patience:
                print("Early stopping.")
                break

    (output_dir / "mask2former_history.json").write_text(
        json.dumps(history, indent=2), encoding="utf-8"
    )
    print("Best validation boundary F1:", best_f1)


if __name__ == "__main__":
    main()
