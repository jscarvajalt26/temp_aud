from __future__ import annotations

import json
import shutil
from pathlib import Path

import cv2
import numpy as np

BASE_DIR = Path(__file__).resolve().parents[1]
TRAINING_DIR = BASE_DIR / "data" / "training"
VERIFIED_ROOT = BASE_DIR / "data" / "verified_training"
VALIDATION_DIR = BASE_DIR / "data" / "validation"

TRAIN_MAP_IDS = {"map001", "map002"}
VAL_MAP_IDS = {"map003"}
TEST_MAP_IDS = {"map004"}

SOURCE_DATASETS = [
    {
        "name": "color",
        "image_dir": TRAINING_DIR / "color" / "images",
        "mask_dir": TRAINING_DIR / "color" / "masks_v2",
    },
    {
        "name": "grayscale",
        "image_dir": TRAINING_DIR / "grayscale" / "images",
        "mask_dir": TRAINING_DIR / "grayscale" / "masks_v2",
    },
]

CLASS_COLORS_BGR = np.array(
    [
        [0, 0, 0],
        [255, 255, 255],
        [0, 0, 255],
        [255, 0, 0],
    ],
    dtype=np.uint8,
)


def ensure_directories() -> None:
    for split in ("train", "val", "test"):
        (VERIFIED_ROOT / split / "images").mkdir(parents=True, exist_ok=True)
        (VERIFIED_ROOT / split / "masks").mkdir(parents=True, exist_ok=True)
        (VERIFIED_ROOT / "proposals" / split).mkdir(parents=True, exist_ok=True)
        (VERIFIED_ROOT / "review" / split).mkdir(parents=True, exist_ok=True)


def extract_map_id(
    filename: str,
) -> str | None:
    stem = Path(filename).stem

    prefix = stem.split(
        "_",
        1,
    )[0]

    if prefix.startswith("map") and prefix[3:].isdigit():
        return prefix

    return None


def choose_split(map_id: str) -> str | None:
    if map_id in TRAIN_MAP_IDS:
        return "train"
    if map_id in VAL_MAP_IDS:
        return "val"
    if map_id in TEST_MAP_IDS:
        return "test"
    return None


def make_review_image(image_bgr: np.ndarray, proposal_mask: np.ndarray) -> np.ndarray:
    proposal = CLASS_COLORS_BGR[
        np.clip(proposal_mask.astype(np.int64), 0, len(CLASS_COLORS_BGR) - 1)
    ]

    if proposal.shape[:2] != image_bgr.shape[:2]:
        proposal = cv2.resize(
            proposal,
            (image_bgr.shape[1], image_bgr.shape[0]),
            interpolation=cv2.INTER_NEAREST,
        )

    overlay = cv2.addWeighted(image_bgr, 0.68, proposal, 0.32, 0.0)

    panels = [image_bgr.copy(), proposal.copy(), overlay.copy()]
    titles = [
        "ORIGINAL TILE",
        "HEURISTIC PROPOSAL - NOT VERIFIED",
        "OVERLAY FOR REVIEW",
    ]

    for panel, title in zip(panels, titles):
        cv2.rectangle(panel, (0, 0), (panel.shape[1], 34), (0, 0, 0), -1)
        cv2.putText(
            panel,
            title,
            (10, 23),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )

    return np.concatenate(panels, axis=1)


def copy_training_tiles() -> list[dict[str, object]]:
    entries = []

    for dataset in SOURCE_DATASETS:
        image_dir = dataset["image_dir"]
        mask_dir = dataset["mask_dir"]

        if not image_dir.exists():
            print("Skipping missing image directory:", image_dir)
            continue

        for image_path in sorted(image_dir.iterdir()):
            if not image_path.is_file():
                continue
            if image_path.suffix.lower() not in {
                ".png",
                ".jpg",
                ".jpeg",
                ".tif",
                ".tiff",
            }:
                continue

            map_id = extract_map_id(image_path.name)
            if map_id is None:
                continue

            split = choose_split(map_id)
            if split not in {"train", "val"}:
                continue

            proposal_path = mask_dir / image_path.name
            if not proposal_path.exists():
                print("WARNING: proposal missing:", proposal_path)
                continue

            dst_image = VERIFIED_ROOT / split / "images" / image_path.name
            dst_proposal = VERIFIED_ROOT / "proposals" / split / image_path.name
            review_path = VERIFIED_ROOT / "review" / split / image_path.name

            shutil.copy2(image_path, dst_image)
            shutil.copy2(proposal_path, dst_proposal)

            image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
            proposal_mask = cv2.imread(str(proposal_path), cv2.IMREAD_GRAYSCALE)

            if image_bgr is None or proposal_mask is None:
                print("WARNING: could not create review:", image_path.name)
                continue

            review = make_review_image(image_bgr, proposal_mask)
            if not cv2.imwrite(str(review_path), review):
                raise RuntimeError(f"Could not save review image: {review_path}")

            entries.append(
                {
                    "split": split,
                    "map_id": map_id,
                    "dataset": dataset["name"],
                    "filename": image_path.name,
                    "image_path": str(dst_image),
                    "proposal_path": str(dst_proposal),
                    "verified_mask_path": str(
                        VERIFIED_ROOT / split / "masks" / image_path.name
                    ),
                    "review_path": str(review_path),
                    "verification_status": "pending",
                }
            )

    return entries


def copy_test_maps(entries: list[dict[str, object]]) -> None:
    for map_id in sorted(TEST_MAP_IDS):
        candidates = sorted(
            p
            for p in VALIDATION_DIR.glob(f"{map_id}.*")
            if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".tif", ".tiff"}
        )

        if not candidates:
            print(f"WARNING: no test image found for {map_id}")
            continue

        src = candidates[0]
        dst = VERIFIED_ROOT / "test" / "images" / src.name
        shutil.copy2(src, dst)

        entries.append(
            {
                "split": "test",
                "map_id": map_id,
                "dataset": "unseen_validation",
                "filename": src.name,
                "image_path": str(dst),
                "proposal_path": None,
                "verified_mask_path": None,
                "review_path": None,
                "verification_status": "held_out_test",
            }
        )


def write_manifest(entries: list[dict[str, object]]) -> None:
    counts = {
        split: sum(1 for item in entries if item["split"] == split)
        for split in ("train", "val", "test")
    }

    source_map_counts = {}
    for item in entries:
        map_id = str(item["map_id"])
        source_map_counts[map_id] = source_map_counts.get(map_id, 0) + 1

    manifest = {
        "schema_version": "1.0.0",
        "purpose": (
            "Heuristic masks in proposals/ are NOT ground truth. "
            "Only reviewed/corrected masks placed in split/masks/ "
            "should be used for verified training."
        ),
        "class_schema": {
            "0": "background_or_other",
            "1": "geological_contact",
            "2": "geological_structure_fault_vein",
            "3": "cartographic_clutter",
        },
        "source_map_split": {
            "train": sorted(TRAIN_MAP_IDS),
            "val": sorted(VAL_MAP_IDS),
            "test": sorted(TEST_MAP_IDS),
        },
        "counts": counts,
        "source_map_counts": source_map_counts,
        "items": entries,
    }

    path = VERIFIED_ROOT / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("Manifest:", path)
    print("Train items:", counts["train"])
    print("Validation items:", counts["val"])
    print("Test items:", counts["test"])


def main() -> None:
    print("Preparing verified-training workspace")
    print("Train maps:", sorted(TRAIN_MAP_IDS))
    print("Validation maps:", sorted(VAL_MAP_IDS))
    print("Test maps:", sorted(TEST_MAP_IDS))
    print()

    ensure_directories()
    entries = copy_training_tiles()
    copy_test_maps(entries)
    write_manifest(entries)

    print()
    print("IMPORTANT:")
    print(" - proposals/ contains heuristic masks only.")
    print(" - train/masks and val/masks stay empty until labels are verified.")
    print(" - map004 stays held out and must not be used for training.")


if __name__ == "__main__":
    main()
