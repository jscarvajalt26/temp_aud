﻿from __future__ import annotations

import json
from pathlib import Path

import cv2
import pandas as pd

from faria_geomap_rnd import config

# ============================================================
# Paths
# ============================================================

DATASET_ROOT = config.SUPERVISOR150_ROOT
OUTPUT_DIR = config.DATASET_AUDIT_DIR

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

# ============================================================
# Helper
# ============================================================


def image_size(path: Path):
    image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)

    if image is None:
        return None, None

    h, w = image.shape[:2]

    return h, w


# ============================================================
# Audit
# ============================================================

records = []

for folder in sorted(DATASET_ROOT.glob("map_*")):

    if not folder.is_dir():
        continue

    map_id = folder.name

    record = {
        "map": map_id,
    }

    # --------------------------------------------------------
    # Raster files
    # --------------------------------------------------------

    raster_types = [
        "color",
        "grayscale",
        "bw",
        "aged",
        "mask",
    ]

    for raster in raster_types:

        png = folder / f"{map_id}_{raster}.png"

        tif = folder / f"{map_id}_{raster}.tif"

        record[f"{raster}_png"] = png.exists()
        record[f"{raster}_tif"] = tif.exists()

        if png.exists():

            h, w = image_size(png)

            record["height"] = h
            record["width"] = w

    # --------------------------------------------------------
    # Metadata
    # --------------------------------------------------------

    meta = folder / f"{map_id}_meta.json"

    record["meta"] = meta.exists()

    if meta.exists():

        with open(meta, "r") as f:
            data = json.load(f)

        record["style"] = data.get("style")

        record["polygon_count"] = len(data.get("polygons", []))

        record["fault_count"] = len(data.get("faults", []))

        record["strike_dip_count"] = len(data.get("strike_dips", []))

    # --------------------------------------------------------
    # Shape files
    # --------------------------------------------------------

    shape_layers = [
        "faults",
        "polygons",
        "roads",
        "rivers",
        "lakes",
        "strike_dip",
    ]

    for layer in shape_layers:

        shp = folder / f"{map_id}_{layer}.shp"

        record[layer] = shp.exists()

    records.append(record)

# ============================================================
# Save CSV
# ============================================================

df = pd.DataFrame(records)

csv_path = OUTPUT_DIR / "supervisor150_manifest.csv"

df.to_csv(
    csv_path,
    index=False,
)

print(df.head())

print()

print("Maps:", len(df))

print("CSV saved to")

print(csv_path)
