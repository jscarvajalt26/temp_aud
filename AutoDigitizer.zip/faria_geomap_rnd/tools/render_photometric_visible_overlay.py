﻿from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import rasterio

from faria_geomap_rnd import config

MAP_ID = "map_0000"

DATASET_ROOT = config.SUPERVISOR150_ROOT
TARGET_ROOT = config.SUPERVISOR_MULTILAYER_TARGET_DIR
ALIGNMENT_ROOT = config.ALIGNMENT_DEBUG_DIR
OUTPUT_ROOT = config.OUTPUT_DIR / "original_png_overlays"

# BGR colors
CONTACT_COLOR = (0, 255, 0)
FAULT_COLOR = (0, 0, 255)
ROAD_COLOR = (128, 128, 128)
RIVER_COLOR = (255, 100, 0)
LAKE_FILL_COLOR = (255, 0, 0)
LAKE_OUTLINE_COLOR = (180, 70, 0)
STRIKE_DIP_COLOR = (0, 255, 255)

# Visibility tuning.
BASE_COLOR_THRESHOLD = 38.0
EDGE_COLOR_THRESHOLD = 60.0
MIN_COMPONENT_AREA_RATIO = 0.15
MORPHOLOGY_RADIUS = 5


def read_mask(path: Path) -> np.ndarray:
    mask = cv2.imread(
        str(path),
        cv2.IMREAD_GRAYSCALE,
    )

    if mask is None:
        raise FileNotFoundError(f"Could not read mask: {path}")

    return mask


def read_reference_bgr(path: Path) -> np.ndarray:
    with rasterio.open(path) as dataset:
        data = dataset.read([1, 2, 3])

    image_rgb = np.moveaxis(
        data,
        0,
        -1,
    )

    if image_rgb.dtype != np.uint8:
        image_rgb = cv2.normalize(
            image_rgb,
            None,
            0,
            255,
            cv2.NORM_MINMAX,
        ).astype(np.uint8)

    return cv2.cvtColor(
        image_rgb,
        cv2.COLOR_RGB2BGR,
    )


def build_canonical_visibility_mask(
    aligned_source_bgr: np.ndarray,
    reference_bgr: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Determine which canonical pixels are actually visible in the decorated PNG.

    Pixels covered by title bands, legends, margins, or other page-layout
    elements differ strongly from the canonical GeoTIFF and are rejected.
    """

    if aligned_source_bgr.shape != reference_bgr.shape:
        raise ValueError("Aligned source and reference must have identical shapes.")

    aligned_lab = cv2.cvtColor(
        aligned_source_bgr,
        cv2.COLOR_BGR2LAB,
    ).astype(np.float32)

    reference_lab = cv2.cvtColor(
        reference_bgr,
        cv2.COLOR_BGR2LAB,
    ).astype(np.float32)

    color_difference = np.linalg.norm(
        aligned_lab - reference_lab,
        axis=2,
    )

    reference_gray = cv2.cvtColor(
        reference_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    gradient_x = cv2.Sobel(
        reference_gray,
        cv2.CV_32F,
        1,
        0,
        ksize=3,
    )

    gradient_y = cv2.Sobel(
        reference_gray,
        cv2.CV_32F,
        0,
        1,
        ksize=3,
    )

    edge_strength = cv2.magnitude(
        gradient_x,
        gradient_y,
    )

    strong_edges = edge_strength > 50.0

    threshold_map = np.full(
        color_difference.shape,
        BASE_COLOR_THRESHOLD,
        dtype=np.float32,
    )

    threshold_map[strong_edges] = EDGE_COLOR_THRESHOLD

    visible = (color_difference <= threshold_map).astype(np.uint8) * 255

    # Remove white border pixels introduced by the alignment warp.
    aligned_gray = cv2.cvtColor(
        aligned_source_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    near_white = aligned_gray >= 252

    reference_not_white = (
        cv2.cvtColor(
            reference_bgr,
            cv2.COLOR_BGR2GRAY,
        )
        < 248
    )

    visible[near_white & reference_not_white] = 0

    radius = MORPHOLOGY_RADIUS

    close_kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (
            2 * radius + 1,
            2 * radius + 1,
        ),
    )

    visible = cv2.morphologyEx(
        visible,
        cv2.MORPH_CLOSE,
        close_kernel,
        iterations=2,
    )

    visible = cv2.morphologyEx(
        visible,
        cv2.MORPH_OPEN,
        np.ones((3, 3), dtype=np.uint8),
        iterations=1,
    )

    # Retain all substantial connected visible regions, not tiny accidental
    # matches inside legends or text.
    component_count, labels, stats, _ = cv2.connectedComponentsWithStats(
        visible,
        connectivity=8,
    )

    minimum_area = int(visible.size * MIN_COMPONENT_AREA_RATIO)

    cleaned = np.zeros_like(visible)

    for component_id in range(
        1,
        component_count,
    ):
        area = int(
            stats[
                component_id,
                cv2.CC_STAT_AREA,
            ]
        )

        if area >= minimum_area:
            cleaned[labels == component_id] = 255

    # Fill interior holes caused by map linework and symbols.
    flood = cleaned.copy()
    flood_mask = np.zeros(
        (
            flood.shape[0] + 2,
            flood.shape[1] + 2,
        ),
        dtype=np.uint8,
    )

    cv2.floodFill(
        flood,
        flood_mask,
        seedPoint=(0, 0),
        newVal=255,
    )

    holes = cv2.bitwise_not(flood)

    cleaned = cv2.bitwise_or(
        cleaned,
        holes,
    )

    # Slight erosion keeps overlays away from the exact occlusion edge.
    cleaned = cv2.erode(
        cleaned,
        np.ones((3, 3), dtype=np.uint8),
        iterations=1,
    )

    return cleaned, color_difference


def warp_mask_to_source(
    canonical_mask: np.ndarray,
    inverse_matrix: np.ndarray,
    source_width: int,
    source_height: int,
) -> np.ndarray:
    return cv2.warpPerspective(
        canonical_mask,
        inverse_matrix,
        dsize=(
            source_width,
            source_height,
        ),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )


def apply_solid_color(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    color_bgr: tuple[int, int, int],
) -> None:
    image_bgr[mask > 0] = color_bgr


def apply_blended_color(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    color_bgr: tuple[int, int, int],
    alpha: float = 0.72,
) -> None:
    selected = mask > 0

    if not np.any(selected):
        return

    color_image = np.empty_like(image_bgr)

    color_image[:] = color_bgr

    image_bgr[selected] = cv2.addWeighted(
        image_bgr[selected],
        1.0 - alpha,
        color_image[selected],
        alpha,
        0.0,
    )


def main() -> None:
    source_png_path = DATASET_ROOT / MAP_ID / f"{MAP_ID}_color.png"

    reference_tif_path = DATASET_ROOT / MAP_ID / f"{MAP_ID}_color.tif"

    target_directory = TARGET_ROOT / MAP_ID

    alignment_directory = ALIGNMENT_ROOT / MAP_ID

    aligned_source_path = alignment_directory / "aligned.png"

    inverse_matrix_path = alignment_directory / "inverse_matrix.npy"

    source_bgr = cv2.imread(
        str(source_png_path),
        cv2.IMREAD_COLOR,
    )

    aligned_source_bgr = cv2.imread(
        str(aligned_source_path),
        cv2.IMREAD_COLOR,
    )

    if source_bgr is None:
        raise FileNotFoundError(f"Could not read source PNG: {source_png_path}")

    if aligned_source_bgr is None:
        raise FileNotFoundError(f"Could not read aligned source: {aligned_source_path}")

    reference_bgr = read_reference_bgr(reference_tif_path)

    inverse_matrix = np.load(inverse_matrix_path)

    (
        canonical_visibility,
        color_difference,
    ) = build_canonical_visibility_mask(
        aligned_source_bgr,
        reference_bgr,
    )

    canonical_masks = {
        "contact": read_mask(target_directory / "contact_mask.png"),
        "fault": read_mask(target_directory / "fault_mask.png"),
        "road": read_mask(target_directory / "road_mask.png"),
        "river": read_mask(target_directory / "river_mask.png"),
        "lake": read_mask(target_directory / "lake_mask.png"),
        "strike_dip": read_mask(target_directory / "strike_dip_mask.png"),
    }

    for name, mask in canonical_masks.items():
        if mask.shape != canonical_visibility.shape:
            raise ValueError(
                f"Canonical shape mismatch for {name}: "
                f"{mask.shape} vs {canonical_visibility.shape}"
            )

        canonical_masks[name] = cv2.bitwise_and(
            mask,
            canonical_visibility,
        )

    source_height, source_width = source_bgr.shape[:2]

    source_visibility = warp_mask_to_source(
        canonical_visibility,
        inverse_matrix,
        source_width,
        source_height,
    )

    warped_masks = {
        name: warp_mask_to_source(
            mask,
            inverse_matrix,
            source_width,
            source_height,
        )
        for name, mask in canonical_masks.items()
    }

    overlay = source_bgr.copy()

    apply_blended_color(
        overlay,
        warped_masks["contact"],
        CONTACT_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["lake"],
        LAKE_FILL_COLOR,
        alpha=0.88,
    )

    lake_outline = cv2.morphologyEx(
        warped_masks["lake"],
        cv2.MORPH_GRADIENT,
        np.ones((3, 3), dtype=np.uint8),
    )

    apply_solid_color(
        overlay,
        lake_outline,
        LAKE_OUTLINE_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["river"],
        RIVER_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["road"],
        ROAD_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["fault"],
        FAULT_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["strike_dip"],
        STRIKE_DIP_COLOR,
    )

    boundaries = np.full_like(
        source_bgr,
        255,
    )

    apply_solid_color(
        boundaries,
        warped_masks["contact"],
        (0, 0, 0),
    )

    apply_solid_color(
        boundaries,
        warped_masks["lake"],
        LAKE_FILL_COLOR,
    )

    apply_solid_color(
        boundaries,
        lake_outline,
        LAKE_OUTLINE_COLOR,
    )

    apply_solid_color(
        boundaries,
        warped_masks["river"],
        RIVER_COLOR,
    )

    apply_solid_color(
        boundaries,
        warped_masks["road"],
        ROAD_COLOR,
    )

    apply_solid_color(
        boundaries,
        warped_masks["fault"],
        FAULT_COLOR,
    )

    apply_solid_color(
        boundaries,
        warped_masks["strike_dip"],
        (0, 0, 0),
    )

    difference_preview = cv2.normalize(
        color_difference,
        None,
        0,
        255,
        cv2.NORM_MINMAX,
    ).astype(np.uint8)

    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_paths = {
        "overlay": (OUTPUT_ROOT / f"{MAP_ID}_photometric_visible_overlay.png"),
        "boundaries": (OUTPUT_ROOT / f"{MAP_ID}_photometric_visible_boundaries.png"),
        "canonical_visibility": (OUTPUT_ROOT / f"{MAP_ID}_canonical_visibility.png"),
        "source_visibility": (OUTPUT_ROOT / f"{MAP_ID}_source_visibility.png"),
        "difference": (OUTPUT_ROOT / f"{MAP_ID}_alignment_color_difference.png"),
    }

    cv2.imwrite(
        str(output_paths["overlay"]),
        overlay,
    )

    cv2.imwrite(
        str(output_paths["boundaries"]),
        boundaries,
    )

    cv2.imwrite(
        str(output_paths["canonical_visibility"]),
        canonical_visibility,
    )

    cv2.imwrite(
        str(output_paths["source_visibility"]),
        source_visibility,
    )

    cv2.imwrite(
        str(output_paths["difference"]),
        difference_preview,
    )

    print(
        "Canonical visible ratio:",
        f"{np.mean(canonical_visibility > 0):.3%}",
    )

    for path in output_paths.values():
        print("Saved:", path)


if __name__ == "__main__":
    main()
