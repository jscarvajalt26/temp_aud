﻿from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import rasterio

from faria_geomap_rnd import config

MAP_ID = "map_0000"

DATASET_ROOT = config.SUPERVISOR150_ROOT
TARGET_ROOT = config.SUPERVISOR_MULTILAYER_TARGET_DIR
ALIGNMENT_ROOT = config.ALIGNMENT_DEBUG_DIR
OUTPUT_ROOT = config.OUTPUT_DIR / "final_render"

CONTACT_COLOR = (0, 255, 0)
FAULT_COLOR = (0, 0, 255)
ROAD_COLOR = (120, 120, 120)
RIVER_COLOR = (255, 120, 0)
LAKE_FILL_COLOR = (255, 0, 0)
LAKE_OUTLINE_COLOR = (180, 70, 0)
STRIKE_DIP_COLOR = (0, 255, 255)

LAB_DIFFERENCE_THRESHOLD = 38.0
KNOWN_FEATURE_DILATION = 7
OCCLUSION_CLOSE_KERNEL = (31, 21)
MIN_OCCLUSION_AREA_RATIO = 0.002
MIN_RECTANGULARITY = 0.35
VISIBLE_EROSION = 1


def read_mask(path: Path) -> np.ndarray:
    mask = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise FileNotFoundError(f"Could not read mask: {path}")
    return mask


def read_geotiff_bgr(path: Path) -> np.ndarray:
    with rasterio.open(path) as dataset:
        if dataset.count < 3:
            band = dataset.read(1)
            rgb = np.repeat(band[:, :, None], 3, axis=2)
        else:
            rgb = np.moveaxis(dataset.read([1, 2, 3]), 0, -1)

    if rgb.dtype != np.uint8:
        rgb = cv2.normalize(rgb, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def build_known_feature_union(masks: dict[str, np.ndarray]) -> np.ndarray:
    union = np.zeros_like(next(iter(masks.values())))

    for name in ("fault", "road", "river", "lake", "strike_dip"):
        union = cv2.bitwise_or(union, masks[name])

    if KNOWN_FEATURE_DILATION > 0:
        size = 2 * KNOWN_FEATURE_DILATION + 1
        union = cv2.dilate(
            union,
            np.ones((size, size), dtype=np.uint8),
            iterations=1,
        )

    return union


def detect_layout_occlusions(
    aligned_source_bgr: np.ndarray,
    canonical_reference_bgr: np.ndarray,
    known_feature_union: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    if aligned_source_bgr.shape != canonical_reference_bgr.shape:
        raise ValueError("Aligned PNG and canonical GeoTIFF must have the same shape.")

    source_lab = cv2.cvtColor(aligned_source_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
    reference_lab = cv2.cvtColor(canonical_reference_bgr, cv2.COLOR_BGR2LAB).astype(
        np.float32
    )

    difference = np.linalg.norm(source_lab - reference_lab, axis=2)

    high_difference = (difference >= LAB_DIFFERENCE_THRESHOLD).astype(np.uint8) * 255
    high_difference[known_feature_union > 0] = 0

    closed = cv2.morphologyEx(
        high_difference,
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_RECT, OCCLUSION_CLOSE_KERNEL),
        iterations=2,
    )
    closed = cv2.morphologyEx(
        closed,
        cv2.MORPH_OPEN,
        np.ones((5, 5), dtype=np.uint8),
        iterations=1,
    )

    component_count, labels, stats, _ = cv2.connectedComponentsWithStats(
        closed,
        connectivity=8,
    )

    minimum_area = int(closed.size * MIN_OCCLUSION_AREA_RATIO)
    occlusion_mask = np.zeros_like(closed)

    for component_id in range(1, component_count):
        width = int(stats[component_id, cv2.CC_STAT_WIDTH])
        height = int(stats[component_id, cv2.CC_STAT_HEIGHT])
        area = int(stats[component_id, cv2.CC_STAT_AREA])

        if area < minimum_area:
            continue

        rectangularity = area / max(width * height, 1)

        if rectangularity < MIN_RECTANGULARITY:
            continue

        occlusion_mask[labels == component_id] = 255

    occlusion_mask = cv2.dilate(
        occlusion_mask,
        np.ones((5, 5), dtype=np.uint8),
        iterations=1,
    )

    return occlusion_mask, difference


def build_canonical_visible_mask(
    shape: tuple[int, int],
    occlusion_mask: np.ndarray,
) -> np.ndarray:
    visible = np.full(shape, 255, dtype=np.uint8)
    visible[occlusion_mask > 0] = 0

    if VISIBLE_EROSION > 0:
        visible = cv2.erode(
            visible,
            np.ones((3, 3), dtype=np.uint8),
            iterations=VISIBLE_EROSION,
        )

    return visible


def warp_mask_to_source(
    canonical_mask: np.ndarray,
    inverse_matrix: np.ndarray,
    source_width: int,
    source_height: int,
) -> np.ndarray:
    return cv2.warpPerspective(
        canonical_mask,
        inverse_matrix,
        dsize=(source_width, source_height),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )


def apply_blended_color(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    color_bgr: tuple[int, int, int],
    alpha: float,
) -> None:
    selected = mask > 0
    if not np.any(selected):
        return

    color_image = np.empty_like(image_bgr)
    color_image[:] = color_bgr

    image_bgr[selected] = cv2.addWeighted(
        image_bgr[selected],
        1.0 - alpha,
        color_image[selected],
        alpha,
        0.0,
    )


def apply_solid_color(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    color_bgr: tuple[int, int, int],
) -> None:
    image_bgr[mask > 0] = color_bgr


def main() -> None:
    map_directory = DATASET_ROOT / MAP_ID
    target_directory = TARGET_ROOT / MAP_ID
    alignment_directory = ALIGNMENT_ROOT / MAP_ID

    source_png_path = map_directory / f"{MAP_ID}_color.png"
    canonical_tif_path = map_directory / f"{MAP_ID}_color.tif"
    aligned_png_path = alignment_directory / "aligned.png"
    inverse_matrix_path = alignment_directory / "inverse_matrix.npy"

    source_bgr = cv2.imread(str(source_png_path), cv2.IMREAD_COLOR)
    aligned_source_bgr = cv2.imread(str(aligned_png_path), cv2.IMREAD_COLOR)

    if source_bgr is None:
        raise FileNotFoundError(f"Could not read source PNG: {source_png_path}")
    if aligned_source_bgr is None:
        raise FileNotFoundError(f"Could not read aligned PNG: {aligned_png_path}")
    if not inverse_matrix_path.exists():
        raise FileNotFoundError(f"Missing inverse matrix: {inverse_matrix_path}")

    canonical_reference_bgr = read_geotiff_bgr(canonical_tif_path)
    inverse_matrix = np.load(inverse_matrix_path)

    masks = {
        "contact": read_mask(target_directory / "contact_mask.png"),
        "fault": read_mask(target_directory / "fault_mask.png"),
        "road": read_mask(target_directory / "road_mask.png"),
        "river": read_mask(target_directory / "river_mask.png"),
        "lake": read_mask(target_directory / "lake_mask.png"),
        "strike_dip": read_mask(target_directory / "strike_dip_mask.png"),
    }

    canonical_shape = canonical_reference_bgr.shape[:2]

    for name, mask in masks.items():
        if mask.shape != canonical_shape:
            raise ValueError(
                f"Mask shape mismatch for {name}: {mask.shape} vs {canonical_shape}"
            )

    if aligned_source_bgr.shape[:2] != canonical_shape:
        raise ValueError("aligned.png does not match canonical GeoTIFF dimensions.")

    known_feature_union = build_known_feature_union(masks)

    occlusion_mask, difference = detect_layout_occlusions(
        aligned_source_bgr,
        canonical_reference_bgr,
        known_feature_union,
    )

    canonical_visible = build_canonical_visible_mask(
        canonical_shape,
        occlusion_mask,
    )

    clipped_masks = {
        name: cv2.bitwise_and(mask, canonical_visible) for name, mask in masks.items()
    }

    source_height, source_width = source_bgr.shape[:2]

    warped_masks = {
        name: warp_mask_to_source(
            mask,
            inverse_matrix,
            source_width,
            source_height,
        )
        for name, mask in clipped_masks.items()
    }

    source_visible = warp_mask_to_source(
        canonical_visible,
        inverse_matrix,
        source_width,
        source_height,
    )

    overlay = source_bgr.copy()

    apply_blended_color(overlay, warped_masks["contact"], CONTACT_COLOR, 0.72)
    apply_blended_color(overlay, warped_masks["lake"], LAKE_FILL_COLOR, 0.92)

    lake_outline = cv2.morphologyEx(
        warped_masks["lake"],
        cv2.MORPH_GRADIENT,
        np.ones((3, 3), dtype=np.uint8),
    )
    apply_solid_color(overlay, lake_outline, LAKE_OUTLINE_COLOR)

    apply_blended_color(overlay, warped_masks["river"], RIVER_COLOR, 0.78)
    apply_blended_color(overlay, warped_masks["road"], ROAD_COLOR, 0.72)
    apply_blended_color(overlay, warped_masks["fault"], FAULT_COLOR, 0.80)
    apply_blended_color(overlay, warped_masks["strike_dip"], STRIKE_DIP_COLOR, 0.85)

    boundaries = np.full_like(source_bgr, 255)

    apply_solid_color(boundaries, warped_masks["contact"], (0, 0, 0))
    apply_solid_color(boundaries, warped_masks["lake"], LAKE_FILL_COLOR)
    apply_solid_color(boundaries, lake_outline, LAKE_OUTLINE_COLOR)
    apply_solid_color(boundaries, warped_masks["river"], RIVER_COLOR)
    apply_solid_color(boundaries, warped_masks["road"], ROAD_COLOR)
    apply_solid_color(boundaries, warped_masks["fault"], FAULT_COLOR)
    apply_solid_color(boundaries, warped_masks["strike_dip"], (0, 0, 0))

    difference_preview = cv2.normalize(
        difference,
        None,
        0,
        255,
        cv2.NORM_MINMAX,
    ).astype(np.uint8)

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    output_paths = {
        "overlay": OUTPUT_ROOT / f"{MAP_ID}_final_overlay.png",
        "boundaries": OUTPUT_ROOT / f"{MAP_ID}_final_boundaries.png",
        "canonical_visible": OUTPUT_ROOT / f"{MAP_ID}_canonical_visible.png",
        "canonical_occlusions": OUTPUT_ROOT / f"{MAP_ID}_canonical_occlusions.png",
        "source_visible": OUTPUT_ROOT / f"{MAP_ID}_source_visible.png",
        "difference": OUTPUT_ROOT / f"{MAP_ID}_difference.png",
    }

    cv2.imwrite(str(output_paths["overlay"]), overlay)
    cv2.imwrite(str(output_paths["boundaries"]), boundaries)
    cv2.imwrite(str(output_paths["canonical_visible"]), canonical_visible)
    cv2.imwrite(str(output_paths["canonical_occlusions"]), occlusion_mask)
    cv2.imwrite(str(output_paths["source_visible"]), source_visible)
    cv2.imwrite(str(output_paths["difference"]), difference_preview)

    print(
        "Canonical visible ratio:",
        f"{np.mean(canonical_visible > 0):.3%}",
    )

    for path in output_paths.values():
        print("Saved:", path)


if __name__ == "__main__":
    main()
