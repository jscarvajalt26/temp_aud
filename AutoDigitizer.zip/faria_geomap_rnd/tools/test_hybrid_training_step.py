﻿from __future__ import annotations

from pathlib import Path

import torch
import torch.nn.functional as F

from faria_geomap_rnd.models.hybrid.hybrid_geomap_net import HybridGeoMapNetV1

BASE_DIR = Path(__file__).resolve().parents[1]


def count_parameters(model: torch.nn.Module) -> int:
    return sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )


def main() -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("Device:", device)

    model = HybridGeoMapNetV1(
        in_channels=3,
        num_classes=4,
        base_channels=32,
    ).to(device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=1e-4,
        weight_decay=1e-4,
    )

    images = torch.randn(
        1,
        3,
        512,
        512,
        device=device,
    )

    targets = torch.randint(
        low=0,
        high=4,
        size=(1, 512, 512),
        device=device,
        dtype=torch.long,
    )

    model.train()

    optimizer.zero_grad(set_to_none=True)

    logits = model(images)

    loss = F.cross_entropy(
        logits,
        targets,
    )

    loss.backward()

    gradient_count = 0
    invalid_gradient_count = 0

    for parameter in model.parameters():
        if parameter.grad is None:
            continue

        gradient_count += 1

        if not torch.isfinite(parameter.grad).all():
            invalid_gradient_count += 1

    optimizer.step()

    print("Logits:", tuple(logits.shape))
    print("Loss:", float(loss.detach().cpu()))
    print(
        "Trainable parameters:",
        f"{count_parameters(model):,}",
    )
    print(
        "Parameters with gradients:",
        gradient_count,
    )
    print(
        "Invalid gradients:",
        invalid_gradient_count,
    )

    if invalid_gradient_count > 0:
        raise RuntimeError("Hybrid model produced invalid gradients.")

    print("Hybrid training step passed.")


if __name__ == "__main__":
    main()
