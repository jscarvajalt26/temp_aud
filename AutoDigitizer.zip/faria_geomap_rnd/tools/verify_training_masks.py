from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

BASE_DIR = Path(__file__).resolve().parents[1]
VERIFIED_ROOT = BASE_DIR / "data" / "verified_training"

CLASS_NAMES = {
    0: "background / other",
    1: "geological contact",
    2: "structure / fault / vein",
    3: "cartographic clutter",
}

# BGR preview colours.
CLASS_COLORS = {
    0: (0, 0, 0),
    1: (255, 255, 255),
    2: (0, 0, 255),
    3: (255, 0, 0),
}

WINDOW_NAME = "GeoMap Verified Mask Editor"

HEADER_HEIGHT = 46
MAX_DISPLAY_WIDTH = 1550
MAX_DISPLAY_HEIGHT = 900

DEFAULT_BRUSH_RADIUS = 5
MIN_BRUSH_RADIUS = 1
MAX_BRUSH_RADIUS = 80


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=("Interactive correction tool for verified geological-map masks.")
    )

    parser.add_argument(
        "--split",
        choices=["train", "val"],
        default="train",
        help="Which verified split to edit.",
    )

    parser.add_argument(
        "--start",
        default=None,
        help=("Optional filename or filename substring to start from."),
    )

    parser.add_argument(
        "--brush",
        type=int,
        default=DEFAULT_BRUSH_RADIUS,
        help="Initial brush radius in pixels.",
    )

    return parser.parse_args()


def list_images(split: str) -> list[Path]:
    image_dir = VERIFIED_ROOT / split / "images"

    if not image_dir.exists():
        raise FileNotFoundError(f"Missing verified image directory: {image_dir}")

    images = sorted(
        p
        for p in image_dir.iterdir()
        if p.is_file()
        and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".tif", ".tiff"}
    )

    if not images:
        raise RuntimeError(f"No images found in {image_dir}")

    return images


def find_start_index(
    image_paths: list[Path],
    start: str | None,
) -> int:
    if not start:
        return 0

    start_lower = start.lower()

    for index, path in enumerate(image_paths):
        if start_lower in path.name.lower():
            return index

    raise ValueError(f"Could not find a tile matching --start {start!r}")


def read_image(path: Path) -> np.ndarray:
    image = cv2.imread(
        str(path),
        cv2.IMREAD_COLOR,
    )

    if image is None:
        raise RuntimeError(f"Could not read image: {path}")

    return image


def read_mask(
    verified_path: Path,
    proposal_path: Path,
    expected_shape: tuple[int, int],
) -> tuple[np.ndarray, str]:
    if verified_path.exists():
        mask = cv2.imread(
            str(verified_path),
            cv2.IMREAD_GRAYSCALE,
        )
        source = "VERIFIED MASK"
    else:
        mask = cv2.imread(
            str(proposal_path),
            cv2.IMREAD_GRAYSCALE,
        )
        source = "HEURISTIC PROPOSAL"

    if mask is None:
        raise RuntimeError(
            "Could not read verified mask or proposal:\n"
            f"  verified: {verified_path}\n"
            f"  proposal: {proposal_path}"
        )

    if mask.shape != expected_shape:
        mask = cv2.resize(
            mask,
            (
                expected_shape[1],
                expected_shape[0],
            ),
            interpolation=cv2.INTER_NEAREST,
        )

    mask = np.clip(
        mask,
        0,
        3,
    ).astype(np.uint8)

    return mask, source


def colourize_mask(mask: np.ndarray) -> np.ndarray:
    preview = np.zeros(
        (
            mask.shape[0],
            mask.shape[1],
            3,
        ),
        dtype=np.uint8,
    )

    for class_id, colour in CLASS_COLORS.items():
        preview[mask == class_id] = colour

    return preview


def make_overlay(
    image_bgr: np.ndarray,
    mask: np.ndarray,
) -> np.ndarray:
    colour_mask = colourize_mask(mask)

    result = image_bgr.copy()

    foreground = mask != 0

    if np.any(foreground):
        blended = cv2.addWeighted(
            image_bgr,
            0.62,
            colour_mask,
            0.38,
            0.0,
        )

        result[foreground] = blended[foreground]

    return result


def draw_header(
    canvas: np.ndarray,
    text: str,
    x: int,
    width: int,
) -> None:
    cv2.rectangle(
        canvas,
        (x, 0),
        (
            x + width - 1,
            HEADER_HEIGHT - 1,
        ),
        (30, 30, 30),
        thickness=-1,
    )

    cv2.putText(
        canvas,
        text,
        (
            x + 10,
            29,
        ),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )


def compose_canvas(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    filename: str,
    index: int,
    total: int,
    current_class: int,
    brush_radius: int,
    mask_source: str,
    dirty: bool,
    message: str,
) -> np.ndarray:
    mask_preview = colourize_mask(mask)

    overlay = make_overlay(
        image_bgr,
        mask,
    )

    height, width = image_bgr.shape[:2]

    canvas = np.zeros(
        (
            height + HEADER_HEIGHT,
            width * 3,
            3,
        ),
        dtype=np.uint8,
    )

    canvas[
        HEADER_HEIGHT:,
        0:width,
    ] = image_bgr

    canvas[
        HEADER_HEIGHT:,
        width : width * 2,
    ] = mask_preview

    canvas[
        HEADER_HEIGHT:,
        width * 2 : width * 3,
    ] = overlay

    draw_header(
        canvas,
        "ORIGINAL",
        0,
        width,
    )

    draw_header(
        canvas,
        mask_source,
        width,
        width,
    )

    draw_header(
        canvas,
        "OVERLAY",
        width * 2,
        width,
    )

    status_text = (
        f"[{index + 1}/{total}] {filename} | "
        f"class {current_class}: {CLASS_NAMES[current_class]} | "
        f"brush={brush_radius}px"
    )

    if dirty:
        status_text += " | UNSAVED"

    if message:
        status_text += f" | {message}"

    cv2.putText(
        canvas,
        status_text,
        (
            10,
            height + HEADER_HEIGHT - 9,
        ),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.43,
        (0, 255, 255),
        1,
        cv2.LINE_AA,
    )

    return canvas


def compute_display_scale(
    canvas: np.ndarray,
) -> float:
    height, width = canvas.shape[:2]

    width_scale = MAX_DISPLAY_WIDTH / width

    height_scale = MAX_DISPLAY_HEIGHT / height

    return min(
        1.0,
        width_scale,
        height_scale,
    )


def update_manifest_status(
    split: str,
    filename: str,
    status: str,
) -> None:
    manifest_path = VERIFIED_ROOT / "manifest.json"

    if not manifest_path.exists():
        return

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return

    changed = False

    for item in manifest.get(
        "items",
        [],
    ):
        if item.get("split") == split and item.get("filename") == filename:
            item["verification_status"] = status
            changed = True
            break

    if changed:
        manifest_path.write_text(
            json.dumps(
                manifest,
                indent=2,
            ),
            encoding="utf-8",
        )


class MaskEditor:
    def __init__(
        self,
        split: str,
        image_paths: list[Path],
        start_index: int,
        brush_radius: int,
    ) -> None:
        self.split = split
        self.image_paths = image_paths
        self.index = start_index

        self.current_class = 1
        self.brush_radius = int(
            np.clip(
                brush_radius,
                MIN_BRUSH_RADIUS,
                MAX_BRUSH_RADIUS,
            )
        )

        self.image: np.ndarray | None = None
        self.mask: np.ndarray | None = None

        self.mask_source = ""
        self.dirty = False
        self.message = ""

        self.display_scale = 1.0

        self.left_button_down = False
        self.right_button_down = False

        self.load_current()

    @property
    def current_image_path(
        self,
    ) -> Path:
        return self.image_paths[self.index]

    @property
    def proposal_path(
        self,
    ) -> Path:
        return VERIFIED_ROOT / "proposals" / self.split / self.current_image_path.name

    @property
    def verified_path(
        self,
    ) -> Path:
        return VERIFIED_ROOT / self.split / "masks" / self.current_image_path.name

    def load_current(
        self,
    ) -> None:
        self.image = read_image(self.current_image_path)

        self.mask, self.mask_source = read_mask(
            self.verified_path,
            self.proposal_path,
            self.image.shape[:2],
        )

        self.dirty = False
        self.message = ""

    def save(
        self,
    ) -> None:
        assert self.mask is not None

        self.verified_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        success = cv2.imwrite(
            str(self.verified_path),
            self.mask,
        )

        if not success:
            raise RuntimeError(f"Could not save mask: {self.verified_path}")

        update_manifest_status(
            self.split,
            self.current_image_path.name,
            "verified",
        )

        self.mask_source = "VERIFIED MASK"

        self.dirty = False
        self.message = "SAVED"

    def mark_skipped(
        self,
    ) -> None:
        update_manifest_status(
            self.split,
            self.current_image_path.name,
            "skipped_or_uncertain",
        )

        self.message = "MARKED SKIP/UNCERTAIN"

    def reset_to_proposal(
        self,
    ) -> None:
        assert self.image is not None

        proposal = cv2.imread(
            str(self.proposal_path),
            cv2.IMREAD_GRAYSCALE,
        )

        if proposal is None:
            raise RuntimeError(f"Could not read proposal: {self.proposal_path}")

        if proposal.shape != self.image.shape[:2]:
            proposal = cv2.resize(
                proposal,
                (
                    self.image.shape[1],
                    self.image.shape[0],
                ),
                interpolation=cv2.INTER_NEAREST,
            )

        self.mask = np.clip(
            proposal,
            0,
            3,
        ).astype(np.uint8)

        self.mask_source = "HEURISTIC PROPOSAL"

        self.dirty = True
        self.message = "RESET TO PROPOSAL"

    def move(
        self,
        step: int,
    ) -> None:
        if self.dirty:
            self.message = "UNSAVED - press S before moving"
            return

        new_index = self.index + step

        new_index = max(
            0,
            min(
                len(self.image_paths) - 1,
                new_index,
            ),
        )

        if new_index == self.index:
            return

        self.index = new_index
        self.load_current()

    def paint_at_display_position(
        self,
        display_x: int,
        display_y: int,
        class_id: int,
    ) -> None:
        assert self.image is not None
        assert self.mask is not None

        x = int(display_x / self.display_scale)

        y = int(display_y / self.display_scale)

        if y < HEADER_HEIGHT:
            return

        y -= HEADER_HEIGHT

        height, width = self.image.shape[:2]

        if y < 0 or y >= height:
            return

        panel_index = x // width

        if panel_index not in (
            0,
            1,
            2,
        ):
            return

        local_x = x % width

        if local_x < 0 or local_x >= width:
            return

        cv2.circle(
            self.mask,
            (
                local_x,
                y,
            ),
            self.brush_radius,
            int(class_id),
            thickness=-1,
            lineType=cv2.LINE_8,
        )

        self.dirty = True
        self.message = ""

    def mouse_callback(
        self,
        event: int,
        x: int,
        y: int,
        flags: int,
        param,
    ) -> None:
        if event == cv2.EVENT_LBUTTONDOWN:
            self.left_button_down = True
            self.paint_at_display_position(
                x,
                y,
                self.current_class,
            )

        elif event == cv2.EVENT_LBUTTONUP:
            self.left_button_down = False

        elif event == cv2.EVENT_RBUTTONDOWN:
            self.right_button_down = True
            self.paint_at_display_position(
                x,
                y,
                0,
            )

        elif event == cv2.EVENT_RBUTTONUP:
            self.right_button_down = False

        elif event == cv2.EVENT_MOUSEMOVE:
            if self.left_button_down:
                self.paint_at_display_position(
                    x,
                    y,
                    self.current_class,
                )

            elif self.right_button_down:
                self.paint_at_display_position(
                    x,
                    y,
                    0,
                )

    def render(
        self,
    ) -> np.ndarray:
        assert self.image is not None
        assert self.mask is not None

        canvas = compose_canvas(
            image_bgr=self.image,
            mask=self.mask,
            filename=self.current_image_path.name,
            index=self.index,
            total=len(self.image_paths),
            current_class=self.current_class,
            brush_radius=self.brush_radius,
            mask_source=self.mask_source,
            dirty=self.dirty,
            message=self.message,
        )

        self.display_scale = compute_display_scale(canvas)

        if self.display_scale < 1.0:
            canvas = cv2.resize(
                canvas,
                (
                    int(canvas.shape[1] * self.display_scale),
                    int(canvas.shape[0] * self.display_scale),
                ),
                interpolation=cv2.INTER_AREA,
            )

        return canvas

    def run(
        self,
    ) -> None:
        cv2.namedWindow(
            WINDOW_NAME,
            cv2.WINDOW_NORMAL,
        )

        cv2.setMouseCallback(
            WINDOW_NAME,
            self.mouse_callback,
        )

        print()
        print("Controls")
        print("--------")
        print("1 = geological contact")
        print("2 = structure / fault / vein")
        print("3 = cartographic clutter")
        print("0 = background / erase class")
        print("Left mouse = paint selected class")
        print("Right mouse = erase to background")
        print("[ / - = smaller brush")
        print("] / + = larger brush")
        print("S = save verified mask")
        print("R = reset current tile to heuristic proposal")
        print("K = mark tile skip/uncertain")
        print("A or Left Arrow = previous tile")
        print("D or Right Arrow = next tile")
        print("Q or Esc = quit")
        print()

        while True:
            canvas = self.render()

            cv2.imshow(
                WINDOW_NAME,
                canvas,
            )

            key = cv2.waitKey(20)

            if key < 0:
                continue

            key_code = key & 0xFF

            if key_code in (
                27,
                ord("q"),
                ord("Q"),
            ):
                if self.dirty:
                    print(
                        "Current tile has unsaved changes. "
                        "Press S to save, or Q again to discard and quit."
                    )

                    self.message = "UNSAVED - Q again to discard"

                    second_key = cv2.waitKey(0) & 0xFF

                    if second_key in (
                        ord("s"),
                        ord("S"),
                    ):
                        self.save()
                        break

                    if second_key in (
                        ord("q"),
                        ord("Q"),
                        27,
                    ):
                        break

                    continue

                break

            if key_code in (
                ord("0"),
                ord("1"),
                ord("2"),
                ord("3"),
            ):
                self.current_class = int(chr(key_code))
                self.message = f"CLASS {self.current_class}"

            elif key_code in (
                ord("s"),
                ord("S"),
            ):
                self.save()

            elif key_code in (
                ord("r"),
                ord("R"),
            ):
                self.reset_to_proposal()

            elif key_code in (
                ord("k"),
                ord("K"),
            ):
                self.mark_skipped()

            elif key_code in (
                ord("a"),
                ord("A"),
                81,
            ):
                self.move(-1)

            elif key_code in (
                ord("d"),
                ord("D"),
                83,
            ):
                self.move(1)

            elif key_code in (
                ord("["),
                ord("-"),
            ):
                self.brush_radius = max(
                    MIN_BRUSH_RADIUS,
                    self.brush_radius - 1,
                )

            elif key_code in (
                ord("]"),
                ord("+"),
                ord("="),
            ):
                self.brush_radius = min(
                    MAX_BRUSH_RADIUS,
                    self.brush_radius + 1,
                )

        cv2.destroyAllWindows()


def main() -> None:
    args = parse_args()

    image_paths = list_images(args.split)

    start_index = find_start_index(
        image_paths,
        args.start,
    )

    editor = MaskEditor(
        split=args.split,
        image_paths=image_paths,
        start_index=start_index,
        brush_radius=args.brush,
    )

    editor.run()


if __name__ == "__main__":
    main()
