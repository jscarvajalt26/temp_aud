﻿from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np
import rasterio
import shapefile
from rasterio.features import rasterize
from rasterio.transform import rowcol

from faria_geomap_rnd import config

try:
    from shapely.geometry import GeometryCollection, MultiPolygon, Polygon
    from shapely.geometry import shape as shapely_shape
    from shapely.ops import unary_union

    try:
        from shapely.validation import make_valid
    except ImportError:
        make_valid = None
except ImportError as exc:
    raise SystemExit(
        "Shapely is required. Install it with:\n" "python -m pip install shapely"
    ) from exc


DATASET_ROOT = config.SUPERVISOR150_ROOT
OUTPUT_ROOT = config.SUPERVISOR_TARGET_DIR

MAP_IDS = [
    "map_0000",
    "map_0001",
    "map_0002",
]

BACKGROUND_LABEL = 0
CONTACT_LABEL = 1
FAULT_LABEL = 2
CLUTTER_LABEL = 3

CONTACT_WIDTH = 2
FAULT_WIDTH = 3
CLUTTER_LINE_WIDTH = 3
STRIKE_DIP_RADIUS = 5


def world_to_pixel(
    world_x: float,
    world_y: float,
    transform,
) -> tuple[int, int]:
    row, column = rowcol(
        transform,
        world_x,
        world_y,
    )
    return int(column), int(row)


def split_shape_parts(
    shape: shapefile.Shape,
) -> list[list[tuple[float, float]]]:
    if not shape.points:
        return []

    starts = list(shape.parts) or [0]
    starts.append(len(shape.points))

    return [
        shape.points[starts[index] : starts[index + 1]]
        for index in range(len(starts) - 1)
        if starts[index + 1] > starts[index]
    ]


def convert_points_to_pixels(
    points: list[tuple[float, float]],
    transform,
) -> np.ndarray:
    pixels = [world_to_pixel(x, y, transform) for x, y in points]

    return np.asarray(
        pixels,
        dtype=np.int32,
    ).reshape(-1, 1, 2)


def repair_geometry(geometry):
    if geometry.is_empty:
        return geometry

    if geometry.is_valid:
        return geometry

    if make_valid is not None:
        geometry = make_valid(geometry)
    else:
        geometry = geometry.buffer(0)

    if isinstance(geometry, (Polygon, MultiPolygon)):
        return geometry

    if isinstance(geometry, GeometryCollection):
        polygons = [
            item
            for item in geometry.geoms
            if isinstance(item, (Polygon, MultiPolygon)) and not item.is_empty
        ]

        if polygons:
            return unary_union(polygons)

    return geometry


def read_dissolved_geological_units(
    shapefile_path: Path,
) -> dict[int, object]:
    reader = shapefile.Reader(str(shapefile_path))

    field_names = [field[0] for field in reader.fields if field[0] != "DeletionFlag"]

    if "label_id" not in field_names:
        reader.close()
        raise KeyError(f"'label_id' was not found in {shapefile_path}")

    label_index = field_names.index("label_id")
    grouped: dict[int, list[object]] = defaultdict(list)

    for shape_record in reader.iterShapeRecords():
        label_id = int(shape_record.record[label_index])

        geometry = repair_geometry(shapely_shape(shape_record.shape.__geo_interface__))

        if geometry.is_empty:
            continue

        grouped[label_id].append(geometry)

    reader.close()

    dissolved: dict[int, object] = {}

    for label_id, geometries in grouped.items():
        merged = repair_geometry(unary_union(geometries))

        if not merged.is_empty:
            dissolved[label_id] = merged

    if not dissolved:
        raise RuntimeError(f"No usable geological polygons found in {shapefile_path}")

    return dissolved


def rasterize_unit_labels(
    dissolved_units: dict[int, object],
    transform,
    height: int,
    width: int,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Large geological bodies are drawn first and smaller bodies last.
    Real geometry area is used rather than bounding-box area.
    """

    ordered = sorted(
        dissolved_units.items(),
        key=lambda item: item[1].area,
        reverse=True,
    )

    unit_labels = rasterize(
        shapes=[
            (geometry.__geo_interface__, int(label_id))
            for label_id, geometry in ordered
        ],
        out_shape=(height, width),
        transform=transform,
        fill=-1,
        dtype=np.int32,
        all_touched=False,
    )

    footprint = rasterize(
        shapes=[
            (
                unary_union(list(dissolved_units.values())).__geo_interface__,
                1,
            )
        ],
        out_shape=(height, width),
        transform=transform,
        fill=0,
        dtype=np.uint8,
        all_touched=False,
    )

    return unit_labels, footprint


def derive_contact_mask(
    unit_labels: np.ndarray,
    footprint: np.ndarray,
    thickness: int = 2,
) -> np.ndarray:
    """
    Contacts are created only where two different valid geological
    labels meet. This preserves nested units while excluding the
    outside map footprint.
    """

    valid = (unit_labels >= 0) & (footprint > 0)

    contact = np.zeros(
        unit_labels.shape,
        dtype=np.uint8,
    )

    horizontal = (
        valid[:, :-1] & valid[:, 1:] & (unit_labels[:, :-1] != unit_labels[:, 1:])
    )

    contact[:, :-1][horizontal] = 1
    contact[:, 1:][horizontal] = 1

    vertical = (
        valid[:-1, :] & valid[1:, :] & (unit_labels[:-1, :] != unit_labels[1:, :])
    )

    contact[:-1, :][vertical] = 1
    contact[1:, :][vertical] = 1

    # Never let the outer footprint become a geological contact.
    footprint_boundary = cv2.morphologyEx(
        footprint,
        cv2.MORPH_GRADIENT,
        np.ones((3, 3), dtype=np.uint8),
    )

    contact[footprint_boundary > 0] = 0

    if thickness > 1:
        kernel_size = 2 * (thickness // 2) + 1

        contact = cv2.dilate(
            contact,
            np.ones(
                (kernel_size, kernel_size),
                dtype=np.uint8,
            ),
            iterations=1,
        )

        contact[footprint_boundary > 0] = 0

    return contact


def draw_polyline_mask(
    shape: tuple[int, int],
    shapefile_path: Path,
    transform,
    thickness: int,
) -> tuple[np.ndarray, int]:
    mask = np.zeros(
        shape,
        dtype=np.uint8,
    )

    if not shapefile_path.exists():
        return mask, 0

    reader = shapefile.Reader(str(shapefile_path))
    count = 0

    for geometry in reader.shapes():
        for part in split_shape_parts(geometry):
            pixels = convert_points_to_pixels(
                part,
                transform,
            )

            if len(pixels) >= 2:
                cv2.polylines(
                    mask,
                    [pixels],
                    isClosed=False,
                    color=255,
                    thickness=thickness,
                    lineType=cv2.LINE_8,
                )

        count += 1

    reader.close()
    return mask, count


def draw_polygon_mask(
    shape: tuple[int, int],
    shapefile_path: Path,
    transform,
) -> tuple[np.ndarray, int]:
    mask = np.zeros(
        shape,
        dtype=np.uint8,
    )

    if not shapefile_path.exists():
        return mask, 0

    reader = shapefile.Reader(str(shapefile_path))
    count = 0

    for geometry in reader.shapes():
        polygons = []

        for part in split_shape_parts(geometry):
            pixels = convert_points_to_pixels(
                part,
                transform,
            )

            if len(pixels) >= 3:
                polygons.append(pixels)

        if polygons:
            cv2.fillPoly(
                mask,
                polygons,
                color=255,
                lineType=cv2.LINE_8,
            )

        count += 1

    reader.close()
    return mask, count


def draw_point_mask(
    shape: tuple[int, int],
    shapefile_path: Path,
    transform,
    radius: int,
) -> tuple[np.ndarray, int]:
    mask = np.zeros(
        shape,
        dtype=np.uint8,
    )

    if not shapefile_path.exists():
        return mask, 0

    reader = shapefile.Reader(str(shapefile_path))
    count = 0

    for geometry in reader.shapes():
        for world_x, world_y in geometry.points:
            pixel_x, pixel_y = world_to_pixel(
                world_x,
                world_y,
                transform,
            )

            cv2.circle(
                mask,
                (pixel_x, pixel_y),
                radius,
                255,
                thickness=-1,
                lineType=cv2.LINE_8,
            )

        count += 1

    reader.close()
    return mask, count


def create_overlay(
    image_bgr: np.ndarray,
    contact_mask: np.ndarray,
    fault_mask: np.ndarray,
    clutter_mask: np.ndarray,
) -> np.ndarray:
    """
    Independent masks are rendered without collapsing their ground truth.
    Blue = clutter, green = contacts, red = faults.
    """

    overlay = image_bgr.copy()

    layers = (
        (clutter_mask, (255, 0, 0)),
        (contact_mask, (0, 255, 0)),
        (fault_mask, (0, 0, 255)),
    )

    for mask, color in layers:
        selected = mask > 0

        if not np.any(selected):
            continue

        color_image = np.zeros_like(overlay)
        color_image[:] = color

        overlay[selected] = cv2.addWeighted(
            overlay[selected],
            0.35,
            color_image[selected],
            0.65,
            0.0,
        )

    # Overlap markers help diagnose real intersections.
    contact_fault = (contact_mask > 0) & (fault_mask > 0)

    overlay[contact_fault] = (0, 255, 255)

    return overlay


def make_unit_preview(
    unit_labels: np.ndarray,
) -> np.ndarray:
    height, width = unit_labels.shape

    preview = np.full(
        (height, width, 3),
        255,
        dtype=np.uint8,
    )

    rng = np.random.default_rng(42)

    for label_id in sorted(
        int(value) for value in np.unique(unit_labels) if value >= 0
    ):
        color = rng.integers(
            40,
            230,
            size=3,
            dtype=np.uint8,
        )

        preview[unit_labels == label_id] = color

    return preview


def process_map(
    map_id: str,
) -> None:
    map_directory = DATASET_ROOT / map_id
    geotiff_path = map_directory / f"{map_id}_color.tif"

    with rasterio.open(geotiff_path) as dataset:
        image_rgb = dataset.read([1, 2, 3])
        image_rgb = np.transpose(
            image_rgb,
            (1, 2, 0),
        )

        transform = dataset.transform
        height = dataset.height
        width = dataset.width

    if image_rgb.dtype != np.uint8:
        image_rgb = cv2.normalize(
            image_rgb,
            None,
            0,
            255,
            cv2.NORM_MINMAX,
        ).astype(np.uint8)

    image_bgr = cv2.cvtColor(
        image_rgb,
        cv2.COLOR_RGB2BGR,
    )

    polygon_path = map_directory / f"{map_id}_polygons.shp"

    dissolved_units = read_dissolved_geological_units(polygon_path)

    unit_labels, footprint = rasterize_unit_labels(
        dissolved_units,
        transform,
        height,
        width,
    )

    contact_mask = (
        derive_contact_mask(
            unit_labels,
            footprint,
            thickness=CONTACT_WIDTH,
        )
        * 255
    ).astype(np.uint8)

    fault_mask, fault_count = draw_polyline_mask(
        (height, width),
        map_directory / f"{map_id}_faults.shp",
        transform,
        FAULT_WIDTH,
    )

    road_mask, road_count = draw_polyline_mask(
        (height, width),
        map_directory / f"{map_id}_roads.shp",
        transform,
        CLUTTER_LINE_WIDTH,
    )

    river_mask, river_count = draw_polyline_mask(
        (height, width),
        map_directory / f"{map_id}_rivers.shp",
        transform,
        CLUTTER_LINE_WIDTH,
    )

    lake_mask, lake_count = draw_polygon_mask(
        (height, width),
        map_directory / f"{map_id}_lakes.shp",
        transform,
    )

    strike_dip_mask, strike_dip_count = draw_point_mask(
        (height, width),
        map_directory / f"{map_id}_strike_dip.shp",
        transform,
        STRIKE_DIP_RADIUS,
    )

    clutter_mask = cv2.bitwise_or(
        road_mask,
        river_mask,
    )

    clutter_mask = cv2.bitwise_or(
        clutter_mask,
        lake_mask,
    )

    clutter_mask = cv2.bitwise_or(
        clutter_mask,
        strike_dip_mask,
    )

    # A combined label image is retained only for compatibility.
    # Separate masks are the authoritative targets because classes overlap.
    structural_labels = np.zeros(
        (height, width),
        dtype=np.uint8,
    )

    structural_labels[clutter_mask > 0] = CLUTTER_LABEL

    structural_labels[contact_mask > 0] = CONTACT_LABEL

    structural_labels[fault_mask > 0] = FAULT_LABEL

    output_directory = OUTPUT_ROOT / map_id

    output_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    overlay = create_overlay(
        image_bgr,
        contact_mask,
        fault_mask,
        clutter_mask,
    )

    cv2.imwrite(
        str(output_directory / "structural_labels.png"),
        structural_labels,
    )

    cv2.imwrite(
        str(output_directory / "structural_overlay.png"),
        overlay,
    )

    cv2.imwrite(
        str(output_directory / "contact_mask.png"),
        contact_mask,
    )

    cv2.imwrite(
        str(output_directory / "fault_mask.png"),
        fault_mask,
    )

    cv2.imwrite(
        str(output_directory / "clutter_mask.png"),
        clutter_mask,
    )

    cv2.imwrite(
        str(output_directory / "geology_footprint.png"),
        footprint * 255,
    )

    cv2.imwrite(
        str(output_directory / "unit_labels_preview.png"),
        make_unit_preview(unit_labels),
    )

    np.save(
        output_directory / "unit_labels.npy",
        unit_labels,
    )

    polygon_count = sum(1 for _ in shapefile.Reader(str(polygon_path)).iterShapes())

    print()
    print("=" * 60)
    print("Processed:", map_id)
    print("Image shape:", image_bgr.shape)
    print("Geological labels:", sorted(dissolved_units))
    print("Polygon features:", polygon_count)
    print("Fault features:", fault_count)
    print("Road features:", road_count)
    print("River features:", river_count)
    print("Lake features:", lake_count)
    print("Strike/dip features:", strike_dip_count)
    print(
        "Contact pixels:",
        int(np.count_nonzero(contact_mask)),
    )
    print(
        "Fault pixels:",
        int(np.count_nonzero(fault_mask)),
    )
    print(
        "Clutter pixels:",
        int(np.count_nonzero(clutter_mask)),
    )
    print("Saved:", output_directory)


def main() -> None:
    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    completed = 0
    failed = 0

    print("Rasterizing corrected Supervisor150 targets")
    print("Maps:", MAP_IDS)

    for map_id in MAP_IDS:
        try:
            process_map(map_id)
            completed += 1
        except Exception as error:
            failed += 1
            print()
            print("=" * 60)
            print("FAILED:", map_id)
            print(
                type(error).__name__ + ":",
                error,
            )

    print()
    print("=" * 60)
    print("Completed:", completed)
    print("Failed:", failed)

    if failed:
        raise RuntimeError(f"{failed} map(s) failed target generation.")


if __name__ == "__main__":
    main()
