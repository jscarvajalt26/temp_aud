﻿from __future__ import annotations

import json
import random

from faria_geomap_rnd import config

# ============================================================
# SETTINGS
# ============================================================

DATASET_ROOT = config.SUPERVISOR150_ROOT
OUTPUT_DIR = config.SUPERVISOR_SPLIT_DIR

RANDOM_SEED = 42

TRAIN_COUNT = 104
VALIDATION_COUNT = 22
TEST_COUNT = 23


# ============================================================
# MAIN
# ============================================================


def main() -> None:
    map_ids = sorted(
        folder.name for folder in DATASET_ROOT.glob("map_*") if folder.is_dir()
    )

    expected_total = TRAIN_COUNT + VALIDATION_COUNT + TEST_COUNT

    if len(map_ids) != expected_total:
        raise RuntimeError(
            f"Expected {expected_total} maps, " f"but found {len(map_ids)}."
        )

    random_generator = random.Random(RANDOM_SEED)

    random_generator.shuffle(map_ids)

    train_ids = map_ids[:TRAIN_COUNT]

    validation_ids = map_ids[TRAIN_COUNT : TRAIN_COUNT + VALIDATION_COUNT]

    test_ids = map_ids[TRAIN_COUNT + VALIDATION_COUNT :]

    split = {
        "seed": RANDOM_SEED,
        "train_count": len(train_ids),
        "validation_count": len(validation_ids),
        "test_count": len(test_ids),
        "train": train_ids,
        "validation": validation_ids,
        "test": test_ids,
    }

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_path = OUTPUT_DIR / "supervisor150_split.json"

    with output_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            split,
            file,
            indent=2,
        )

    print("Train:", len(train_ids))
    print("Validation:", len(validation_ids))
    print("Test:", len(test_ids))
    print()
    print("Saved:")
    print(output_path)


if __name__ == "__main__":
    main()
