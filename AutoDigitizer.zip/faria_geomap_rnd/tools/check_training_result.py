from pathlib import Path

import torch

BASE_DIR = Path(__file__).resolve().parents[1]

CHECKPOINT_DIR = BASE_DIR / "outputs" / "checkpoints_v2"

CHECKPOINT_PATHS = [
    CHECKPOINT_DIR / "se_unet_v2_best.pth",
    CHECKPOINT_DIR / "se_unet_v2_last.pth",
]


for checkpoint_path in CHECKPOINT_PATHS:
    print("\n" + "=" * 60)
    print("Checkpoint:", checkpoint_path.name)

    if not checkpoint_path.exists():
        print("NOT FOUND")
        continue

    checkpoint = torch.load(
        checkpoint_path,
        map_location="cpu",
        weights_only=False,
    )

    print("Epoch:", checkpoint.get("epoch", "not saved"))
    print(
        "Validation loss:",
        checkpoint.get("validation_loss", "not saved"),
    )
    print(
        "Validation mean IoU:",
        checkpoint.get("validation_mean_iou", "not saved"),
    )
    print(
        "Validation mean Dice:",
        checkpoint.get("validation_mean_dice", "not saved"),
    )
    print(
        "Validation pixel accuracy:",
        checkpoint.get("validation_pixel_accuracy", "not saved"),
    )
    print(
        "Number of classes:",
        checkpoint.get("num_classes", "not saved"),
    )
    print(
        "Image size:",
        checkpoint.get("image_size", "not saved"),
    )
    print(
        "Base channels:",
        checkpoint.get("base_channels", "not saved"),
    )
