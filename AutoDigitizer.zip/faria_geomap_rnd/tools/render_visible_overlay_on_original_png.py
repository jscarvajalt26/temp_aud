﻿from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

from faria_geomap_rnd import config

MAP_ID = "map_0000"

DATASET_ROOT = config.SUPERVISOR150_ROOT
TARGET_ROOT = config.SUPERVISOR_MULTILAYER_TARGET_DIR
ALIGNMENT_ROOT = config.ALIGNMENT_DEBUG_DIR
OUTPUT_ROOT = config.OUTPUT_DIR / "original_png_overlays"

# BGR colors
CONTACT_COLOR = (0, 255, 0)
FAULT_COLOR = (0, 0, 255)
ROAD_COLOR = (128, 128, 128)
RIVER_COLOR = (255, 100, 0)
LAKE_FILL_COLOR = (255, 0, 0)
LAKE_OUTLINE_COLOR = (180, 70, 0)
STRIKE_DIP_COLOR = (0, 255, 255)

DARK_THRESHOLD = 80
MIN_HORIZONTAL_FRACTION = 0.45
MIN_VERTICAL_FRACTION = 0.45
FRAME_MARGIN = 2


def read_mask(path: Path) -> np.ndarray:
    image = cv2.imread(
        str(path),
        cv2.IMREAD_GRAYSCALE,
    )

    if image is None:
        raise FileNotFoundError(f"Could not read mask: {path}")

    return image


def warp_mask_to_source(
    canonical_mask: np.ndarray,
    inverse_matrix: np.ndarray,
    source_width: int,
    source_height: int,
) -> np.ndarray:
    return cv2.warpPerspective(
        canonical_mask,
        inverse_matrix,
        dsize=(
            source_width,
            source_height,
        ),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )


def longest_true_run(values: np.ndarray) -> int:
    longest = 0
    current = 0

    for value in values:
        if value:
            current += 1
            longest = max(longest, current)
        else:
            current = 0

    return longest


def detect_map_frame(
    source_bgr: np.ndarray,
) -> tuple[int, int, int, int]:
    """
    Detect the black rectangular map frame in the decorated PNG.

    Returns:
        left, top, right, bottom
    """

    gray = cv2.cvtColor(
        source_bgr,
        cv2.COLOR_BGR2GRAY,
    )

    dark = gray < DARK_THRESHOLD
    height, width = gray.shape

    horizontal_scores = np.asarray(
        [longest_true_run(dark[row, :]) for row in range(height)],
        dtype=np.int32,
    )

    vertical_scores = np.asarray(
        [longest_true_run(dark[:, column]) for column in range(width)],
        dtype=np.int32,
    )

    horizontal_candidates = np.flatnonzero(
        horizontal_scores >= int(width * MIN_HORIZONTAL_FRACTION)
    )

    vertical_candidates = np.flatnonzero(
        vertical_scores >= int(height * MIN_VERTICAL_FRACTION)
    )

    if horizontal_candidates.size < 2 or vertical_candidates.size < 2:
        raise RuntimeError("Could not automatically detect the map frame.")

    # Collapse nearby detections from the same thick line.
    def group_centers(indices: np.ndarray) -> list[int]:
        groups: list[list[int]] = []
        current: list[int] = []

        for value in indices.tolist():
            if not current or value <= current[-1] + 2:
                current.append(value)
            else:
                groups.append(current)
                current = [value]

        if current:
            groups.append(current)

        return [int(round(float(np.mean(group)))) for group in groups]

    horizontal_lines = group_centers(horizontal_candidates)

    vertical_lines = group_centers(vertical_candidates)

    # Prefer the largest plausible rectangle that is inset from the page.
    best = None
    best_area = -1

    for top in horizontal_lines:
        for bottom in horizontal_lines:
            if bottom <= top:
                continue

            rectangle_height = bottom - top

            if rectangle_height < height * 0.45:
                continue

            for left in vertical_lines:
                for right in vertical_lines:
                    if right <= left:
                        continue

                    rectangle_width = right - left

                    if rectangle_width < width * 0.45:
                        continue

                    area = rectangle_width * rectangle_height

                    if area > best_area:
                        best_area = area
                        best = (
                            left,
                            top,
                            right,
                            bottom,
                        )

    if best is None:
        raise RuntimeError("No plausible map-frame rectangle was found.")

    return best


def make_visible_panel_mask(
    shape: tuple[int, int],
    frame: tuple[int, int, int, int],
) -> np.ndarray:
    height, width = shape
    left, top, right, bottom = frame

    visible = np.zeros(
        (height, width),
        dtype=np.uint8,
    )

    x1 = max(left + FRAME_MARGIN, 0)
    y1 = max(top + FRAME_MARGIN, 0)
    x2 = min(right - FRAME_MARGIN, width - 1)
    y2 = min(bottom - FRAME_MARGIN, height - 1)

    cv2.rectangle(
        visible,
        (x1, y1),
        (x2, y2),
        255,
        thickness=-1,
    )

    return visible


def clip_mask(
    mask: np.ndarray,
    visible_panel_mask: np.ndarray,
) -> np.ndarray:
    return cv2.bitwise_and(
        mask,
        visible_panel_mask,
    )


def apply_solid_color(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    color_bgr: tuple[int, int, int],
) -> None:
    image_bgr[mask > 0] = color_bgr


def apply_blended_color(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    color_bgr: tuple[int, int, int],
    alpha: float = 0.72,
) -> None:
    selected = mask > 0

    if not np.any(selected):
        return

    color_image = np.empty_like(image_bgr)

    color_image[:] = color_bgr

    image_bgr[selected] = cv2.addWeighted(
        image_bgr[selected],
        1.0 - alpha,
        color_image[selected],
        alpha,
        0.0,
    )


def main() -> None:
    source_path = DATASET_ROOT / MAP_ID / f"{MAP_ID}_color.png"

    target_directory = TARGET_ROOT / MAP_ID

    inverse_matrix_path = ALIGNMENT_ROOT / MAP_ID / "inverse_matrix.npy"

    source_bgr = cv2.imread(
        str(source_path),
        cv2.IMREAD_COLOR,
    )

    if source_bgr is None:
        raise FileNotFoundError(f"Could not read source PNG: {source_path}")

    inverse_matrix = np.load(inverse_matrix_path)

    canonical_masks = {
        "contact": read_mask(target_directory / "contact_mask.png"),
        "fault": read_mask(target_directory / "fault_mask.png"),
        "road": read_mask(target_directory / "road_mask.png"),
        "river": read_mask(target_directory / "river_mask.png"),
        "lake": read_mask(target_directory / "lake_mask.png"),
        "strike_dip": read_mask(target_directory / "strike_dip_mask.png"),
    }

    source_height, source_width = source_bgr.shape[:2]

    frame = detect_map_frame(source_bgr)

    visible_panel_mask = make_visible_panel_mask(
        (
            source_height,
            source_width,
        ),
        frame,
    )

    warped_masks = {}

    for name, canonical_mask in canonical_masks.items():
        warped = warp_mask_to_source(
            canonical_mask,
            inverse_matrix,
            source_width,
            source_height,
        )

        warped_masks[name] = clip_mask(
            warped,
            visible_panel_mask,
        )

    # Overlay on the original decorated PNG.
    overlay = source_bgr.copy()

    apply_blended_color(
        overlay,
        warped_masks["contact"],
        CONTACT_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["lake"],
        LAKE_FILL_COLOR,
        alpha=0.85,
    )

    lake_outline = cv2.morphologyEx(
        warped_masks["lake"],
        cv2.MORPH_GRADIENT,
        np.ones((3, 3), dtype=np.uint8),
    )

    apply_solid_color(
        overlay,
        lake_outline,
        LAKE_OUTLINE_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["river"],
        RIVER_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["road"],
        ROAD_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["fault"],
        FAULT_COLOR,
    )

    apply_blended_color(
        overlay,
        warped_masks["strike_dip"],
        STRIKE_DIP_COLOR,
    )

    # Standalone visible-boundaries product.
    boundaries = np.full_like(
        source_bgr,
        255,
    )

    # Keep everything outside the actual map panel white.
    apply_solid_color(
        boundaries,
        warped_masks["contact"],
        (0, 0, 0),
    )

    # Lakes are filled blue here so they are not "missing."
    apply_solid_color(
        boundaries,
        warped_masks["lake"],
        LAKE_FILL_COLOR,
    )

    apply_solid_color(
        boundaries,
        lake_outline,
        LAKE_OUTLINE_COLOR,
    )

    apply_solid_color(
        boundaries,
        warped_masks["river"],
        RIVER_COLOR,
    )

    apply_solid_color(
        boundaries,
        warped_masks["road"],
        ROAD_COLOR,
    )

    apply_solid_color(
        boundaries,
        warped_masks["fault"],
        FAULT_COLOR,
    )

    apply_solid_color(
        boundaries,
        warped_masks["strike_dip"],
        (0, 0, 0),
    )

    # Diagnostic frame preview.
    frame_preview = source_bgr.copy()
    left, top, right, bottom = frame

    cv2.rectangle(
        frame_preview,
        (left, top),
        (right, bottom),
        (255, 0, 255),
        thickness=4,
    )

    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    paths = {
        "overlay": (OUTPUT_ROOT / f"{MAP_ID}_visible_overlay.png"),
        "boundaries": (OUTPUT_ROOT / f"{MAP_ID}_visible_boundaries.png"),
        "visible_mask": (OUTPUT_ROOT / f"{MAP_ID}_visible_panel_mask.png"),
        "frame_preview": (OUTPUT_ROOT / f"{MAP_ID}_detected_frame.png"),
    }

    cv2.imwrite(
        str(paths["overlay"]),
        overlay,
    )

    cv2.imwrite(
        str(paths["boundaries"]),
        boundaries,
    )

    cv2.imwrite(
        str(paths["visible_mask"]),
        visible_panel_mask,
    )

    cv2.imwrite(
        str(paths["frame_preview"]),
        frame_preview,
    )

    print("Detected frame:", frame)
    print("Saved:", paths["overlay"])
    print("Saved:", paths["boundaries"])
    print("Saved:", paths["visible_mask"])
    print("Saved:", paths["frame_preview"])


if __name__ == "__main__":
    main()
