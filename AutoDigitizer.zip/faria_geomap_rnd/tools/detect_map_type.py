from pathlib import Path

import cv2
import numpy as np


def detect_map_type(image_path: Path) -> str:
    """
    Detect whether a geological map is mainly coloured or grayscale.

    Returns:
        "color" or "grayscale"
    """

    image_bgr = cv2.imread(str(image_path))

    if image_bgr is None:
        raise FileNotFoundError(f"Could not load image: {image_path}")

    # Resize for faster analysis
    h, w = image_bgr.shape[:2]
    max_width = 1200

    if w > max_width:
        scale = max_width / w
        image_bgr = cv2.resize(
            image_bgr,
            (int(w * scale), int(h * scale)),
            interpolation=cv2.INTER_AREA,
        )

    hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)

    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]

    # Ignore very white background and very dark text
    valid = (value > 40) & (value < 245)

    if np.sum(valid) == 0:
        return "grayscale"

    mean_saturation = float(np.mean(saturation[valid]))
    high_saturation_ratio = float(np.mean(saturation[valid] > 45))

    print("Mean saturation:", mean_saturation)
    print("High saturation ratio:", high_saturation_ratio)

    if mean_saturation > 25 and high_saturation_ratio > 0.08:
        return "color"

    return "grayscale"


if __name__ == "__main__":
    base_dir = Path(__file__).resolve().parents[1]

    test_image = base_dir / "data" / "raw_maps" / "map003.jpg"

    map_type = detect_map_type(test_image)

    print("Detected map type:", map_type)
