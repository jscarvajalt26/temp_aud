﻿from __future__ import annotations

import json

import cv2
import numpy as np

from faria_geomap_rnd import config

MAP_ID = "map_0000"

DATASET_ROOT = config.SUPERVISOR150_ROOT

MAP_DIR = DATASET_ROOT / MAP_ID


def inspect_image(name: str) -> None:
    path = MAP_DIR / f"{MAP_ID}_{name}.png"

    image = cv2.imread(
        str(path),
        cv2.IMREAD_UNCHANGED,
    )

    if image is None:
        print(f"{name}: could not read {path}")
        return

    print(f"\n{name}")
    print("Path:", path)
    print("Shape:", image.shape)
    print("Dtype:", image.dtype)
    print("Minimum:", image.min())
    print("Maximum:", image.max())

    if image.ndim == 2:
        unique_values = np.unique(image)

        print("Unique value count:", len(unique_values))
        print(
            "First unique values:",
            unique_values[:50],
        )

    elif image.ndim == 3:
        pixels = image.reshape(
            -1,
            image.shape[2],
        )

        unique_colors, counts = np.unique(
            pixels,
            axis=0,
            return_counts=True,
        )

        order = np.argsort(counts)[::-1]

        unique_colors = unique_colors[order]
        counts = counts[order]

        print(
            "Unique color count:",
            len(unique_colors),
        )

        print("Most common BGR colors:")

        for color, count in zip(
            unique_colors[:30],
            counts[:30],
        ):
            print(f"  BGR={color.tolist()} " f"pixels={int(count)}")


def inspect_metadata() -> None:
    path = MAP_DIR / f"{MAP_ID}_meta.json"

    with path.open(
        "r",
        encoding="utf-8",
    ) as file:
        metadata = json.load(file)

    print("\nMetadata")
    print("Top-level keys:")

    for key in metadata:
        value = metadata[key]

        if isinstance(value, list):
            print(f"  {key}: list with {len(value)} items")
        elif isinstance(value, dict):
            print(f"  {key}: dictionary with {len(value)} keys")
        else:
            print(f"  {key}: {value}")


def inspect_shapefiles() -> None:
    print("\nShapefile layers")

    layers = [
        "polygons",
        "faults",
        "roads",
        "rivers",
        "lakes",
        "strike_dip",
    ]

    for layer in layers:
        path = MAP_DIR / f"{MAP_ID}_{layer}.shp"
        print(f"  {layer}: {path.exists()}")


def main() -> None:
    for variant in [
        "color",
        "grayscale",
        "bw",
        "aged",
        "mask",
    ]:
        inspect_image(variant)

    inspect_metadata()
    inspect_shapefiles()


if __name__ == "__main__":
    main()
