﻿from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import rasterio
import shapefile
from rasterio.features import rasterize
from rasterio.transform import rowcol

from faria_geomap_rnd import config

# ============================================================
# Configuration
# ============================================================

DATASET_ROOT = config.SUPERVISOR150_ROOT
OUTPUT_ROOT = config.SUPERVISOR_MULTILAYER_TARGET_DIR

# Keep three maps until the results are visually verified.
MAP_IDS = [
    folder.name for folder in sorted(DATASET_ROOT.glob("map_*")) if folder.is_dir()
]

IGNORE_LABEL = 255

CONTACT_WIDTH = 2
FAULT_WIDTH = 3
ROAD_WIDTH = 3
RIVER_WIDTH = 3
LAKE_OUTLINE_WIDTH = 2
STRIKE_DIP_RADIUS = 5

# Maximum Euclidean RGB distance allowed when matching a mask pixel
# to the metadata palette. Flat-color masks should normally match
# exactly; this tolerance protects against small encoding differences.
PALETTE_MATCH_TOLERANCE = 12.0

# Rendering colors in BGR for OpenCV.
CONTACT_COLOR = (0, 0, 0)
FAULT_COLOR = (0, 0, 220)
ROAD_COLOR = (90, 90, 90)
RIVER_COLOR = (220, 120, 20)
LAKE_FILL_COLOR = (220, 170, 80)
LAKE_OUTLINE_COLOR = (170, 90, 20)
STRIKE_DIP_COLOR = (0, 0, 0)

DEBUG_CONTACT_COLOR = (0, 255, 0)
DEBUG_FAULT_COLOR = (0, 0, 255)
DEBUG_ROAD_COLOR = (128, 128, 128)
DEBUG_RIVER_COLOR = (255, 100, 0)
DEBUG_LAKE_COLOR = (255, 0, 255)
DEBUG_STRIKE_DIP_COLOR = (0, 255, 255)


# ============================================================
# Metadata and palette helpers
# ============================================================


def hex_to_rgb(value: str) -> tuple[int, int, int]:
    value = value.strip().lstrip("#")

    if len(value) == 3:
        value = "".join(character * 2 for character in value)

    if len(value) != 6:
        raise ValueError(f"Invalid hex color: {value}")

    return (
        int(value[0:2], 16),
        int(value[2:4], 16),
        int(value[4:6], 16),
    )


def normalize_rgb(value: Any) -> tuple[int, int, int]:
    if isinstance(value, str):
        return hex_to_rgb(value)

    if isinstance(value, (list, tuple)) and len(value) >= 3:
        return (
            int(value[0]),
            int(value[1]),
            int(value[2]),
        )

    if isinstance(value, dict):
        for keys in (
            ("r", "g", "b"),
            ("red", "green", "blue"),
        ):
            if all(key in value for key in keys):
                return tuple(int(value[key]) for key in keys)

    raise ValueError(f"Unsupported color value: {value!r}")


def read_geological_palette(
    metadata_path: Path,
) -> tuple[dict[int, tuple[int, int, int]], dict[int, dict[str, Any]]]:
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))

    units = metadata.get("geological_units")

    if not isinstance(units, list) or not units:
        raise ValueError(f"No geological_units list found in {metadata_path}")

    palette: dict[int, tuple[int, int, int]] = {}
    records: dict[int, dict[str, Any]] = {}

    for unit in units:
        if not isinstance(unit, dict):
            continue

        label_value = None

        for key in (
            "label_id",
            "id",
            "unit_id",
            "class_id",
        ):
            if key in unit:
                label_value = unit[key]
                break

        if label_value is None:
            raise KeyError(
                f"A geological unit is missing a label ID in {metadata_path}: "
                f"{unit}"
            )

        color_value = None

        for key in (
            "color",
            "hex_color",
            "rgb",
            "fill_color",
        ):
            if key in unit:
                color_value = unit[key]
                break

        if color_value is None:
            raise KeyError(f"Unit {label_value} has no color in {metadata_path}")

        label_id = int(label_value)
        palette[label_id] = normalize_rgb(color_value)
        records[label_id] = unit

    return palette, records


def infer_mask_palette_from_polygons(
    mask_rgb: np.ndarray,
    polygon_path: Path,
    transform,
) -> tuple[dict[tuple[int, int, int], int], dict[str, Any]]:
    """
    Infer the mask-color -> geological-label mapping automatically.

    The mask GeoTIFF uses a display palette that does not necessarily match
    the colors stored in metadata. We therefore learn the mapping spatially:
    each polygon votes for the mask colors occurring inside its geometry.

    Each polygon contributes a normalized color distribution, so a very large
    polygon cannot overwhelm all smaller nested geological bodies.
    """

    flat = mask_rgb.reshape(-1, 3)

    unique_colors, inverse = np.unique(
        flat,
        axis=0,
        return_inverse=True,
    )

    color_index = inverse.reshape(mask_rgb.shape[:2])

    reader = shapefile.Reader(str(polygon_path))

    field_names = [field[0] for field in reader.fields if field[0] != "DeletionFlag"]

    if "label_id" not in field_names:
        reader.close()
        raise KeyError(f"'label_id' was not found in {polygon_path}")

    label_index = field_names.index("label_id")

    votes: dict[int, dict[int, float]] = defaultdict(lambda: defaultdict(float))

    polygon_count = 0

    for shape_record in reader.iterShapeRecords():
        geometry = shape_record.shape

        if not geometry.points:
            continue

        label_id = int(shape_record.record[label_index])

        polygon_mask = rasterize(
            shapes=[
                (
                    geometry.__geo_interface__,
                    1,
                )
            ],
            out_shape=mask_rgb.shape[:2],
            transform=transform,
            fill=0,
            dtype=np.uint8,
            all_touched=False,
        )

        selected_indices = color_index[polygon_mask > 0]

        if selected_indices.size == 0:
            continue

        counts = np.bincount(
            selected_indices,
            minlength=len(unique_colors),
        ).astype(np.float64)

        total = counts.sum()

        if total <= 0:
            continue

        proportions = counts / total

        # Every polygon contributes total vote weight 1.0.
        for color_id in np.flatnonzero(proportions > 0.005):
            votes[int(color_id)][label_id] += float(proportions[color_id])

        polygon_count += 1

    reader.close()

    color_to_label: dict[
        tuple[int, int, int],
        int,
    ] = {}

    confidence_report: dict[str, Any] = {}

    for color_id, color in enumerate(unique_colors):
        color_tuple = tuple(int(value) for value in color)

        label_votes = votes.get(
            color_id,
            {},
        )

        if not label_votes:
            continue

        ordered = sorted(
            label_votes.items(),
            key=lambda item: item[1],
            reverse=True,
        )

        best_label, best_vote = ordered[0]
        total_vote = sum(label_votes.values())

        confidence = best_vote / total_vote if total_vote > 0 else 0.0

        color_to_label[color_tuple] = int(best_label)

        confidence_report[str(color_tuple)] = {
            "label_id": int(best_label),
            "confidence": float(confidence),
            "votes": {str(label): float(vote) for label, vote in ordered},
        }

    if not color_to_label:
        raise RuntimeError(f"Could not infer any mask colors from {polygon_path}")

    report = {
        "polygon_count": polygon_count,
        "unique_mask_color_count": int(len(unique_colors)),
        "mapped_color_count": int(len(color_to_label)),
        "mapping": confidence_report,
    }

    return color_to_label, report


def decode_unit_labels_from_spatial_mapping(
    mask_rgb: np.ndarray,
    color_to_label: dict[
        tuple[int, int, int],
        int,
    ],
) -> np.ndarray:
    """
    Decode exact flat mask colors using the inferred spatial mapping.
    """

    unit_labels = np.full(
        mask_rgb.shape[:2],
        -1,
        dtype=np.int32,
    )

    for color_rgb, label_id in color_to_label.items():
        color_array = np.asarray(
            color_rgb,
            dtype=np.uint8,
        )

        matching = np.all(
            mask_rgb == color_array,
            axis=2,
        )

        unit_labels[matching] = int(label_id)

    return unit_labels


# ============================================================
# Raster loading and unit decoding
# ============================================================


def read_rgb_geotiff(
    path: Path,
) -> tuple[np.ndarray, rasterio.Affine, Any]:
    with rasterio.open(path) as dataset:
        if dataset.count < 3:
            band = dataset.read(1)
            image_rgb = np.repeat(
                band[:, :, None],
                3,
                axis=2,
            )
        else:
            image_rgb = np.moveaxis(
                dataset.read([1, 2, 3]),
                0,
                -1,
            )

        transform = dataset.transform
        profile = dataset.profile.copy()

    if image_rgb.dtype != np.uint8:
        image_rgb = cv2.normalize(
            image_rgb,
            None,
            0,
            255,
            cv2.NORM_MINMAX,
        ).astype(np.uint8)

    return image_rgb, transform, profile


def decode_unit_labels(
    mask_rgb: np.ndarray,
    palette: dict[int, tuple[int, int, int]],
    tolerance: float,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Convert a flat-color geological mask to integer label IDs.

    Returns
    -------
    unit_labels:
        int32 array containing geological label IDs and -1 for unmatched pixels.

    color_distance:
        float32 nearest-palette distance for quality auditing.
    """

    if not palette:
        raise ValueError("The geological palette is empty.")

    label_ids = np.asarray(
        sorted(palette),
        dtype=np.int32,
    )

    palette_rgb = np.asarray(
        [palette[int(label)] for label in label_ids],
        dtype=np.float32,
    )

    flat_rgb = mask_rgb.reshape(-1, 3).astype(np.float32)

    nearest_indices = np.empty(
        flat_rgb.shape[0],
        dtype=np.int32,
    )

    nearest_distances = np.empty(
        flat_rgb.shape[0],
        dtype=np.float32,
    )

    # Chunking prevents a large temporary N x K x 3 array.
    chunk_size = 500_000

    for start in range(0, flat_rgb.shape[0], chunk_size):
        end = min(
            start + chunk_size,
            flat_rgb.shape[0],
        )

        differences = flat_rgb[start:end, None, :] - palette_rgb[None, :, :]

        squared_distances = np.sum(
            differences * differences,
            axis=2,
        )

        indices = np.argmin(
            squared_distances,
            axis=1,
        )

        nearest_indices[start:end] = indices
        nearest_distances[start:end] = np.sqrt(
            squared_distances[
                np.arange(end - start),
                indices,
            ]
        )

    decoded = label_ids[nearest_indices].reshape(mask_rgb.shape[:2])

    distances = nearest_distances.reshape(mask_rgb.shape[:2])

    decoded = decoded.astype(np.int32)
    decoded[distances > tolerance] = -1

    return decoded, distances


def derive_contact_mask(
    unit_labels: np.ndarray,
    thickness: int,
) -> np.ndarray:
    """
    Create geological contacts only where adjacent valid unit labels differ.

    The outside of the geological raster is ignored, so the image/page frame
    cannot become a contact.
    """

    valid = unit_labels >= 0

    contact = np.zeros(
        unit_labels.shape,
        dtype=np.uint8,
    )

    horizontal = (
        valid[:, :-1] & valid[:, 1:] & (unit_labels[:, :-1] != unit_labels[:, 1:])
    )

    contact[:, :-1][horizontal] = 255
    contact[:, 1:][horizontal] = 255

    vertical = (
        valid[:-1, :] & valid[1:, :] & (unit_labels[:-1, :] != unit_labels[1:, :])
    )

    contact[:-1, :][vertical] = 255
    contact[1:, :][vertical] = 255

    if thickness > 1:
        size = 2 * (thickness // 2) + 1

        contact = cv2.dilate(
            contact,
            np.ones((size, size), dtype=np.uint8),
            iterations=1,
        )

    return contact


# ============================================================
# Shapefile rasterization
# ============================================================


def read_shape_geometries(
    shapefile_path: Path,
) -> tuple[list[dict[str, Any]], int]:
    if not shapefile_path.exists():
        return [], 0

    reader = shapefile.Reader(str(shapefile_path))

    geometries = [
        geometry.__geo_interface__ for geometry in reader.shapes() if geometry.points
    ]

    count = len(reader)
    reader.close()

    return geometries, count


def rasterize_geometry_mask(
    geometries: list[dict[str, Any]],
    out_shape: tuple[int, int],
    transform,
    line_width: int = 1,
) -> np.ndarray:
    if not geometries:
        return np.zeros(
            out_shape,
            dtype=np.uint8,
        )

    mask = rasterize(
        shapes=[(geometry, 255) for geometry in geometries],
        out_shape=out_shape,
        transform=transform,
        fill=0,
        dtype=np.uint8,
        all_touched=True,
    )

    if line_width > 1:
        size = 2 * (line_width // 2) + 1

        mask = cv2.dilate(
            mask,
            np.ones((size, size), dtype=np.uint8),
            iterations=1,
        )

    return mask


def rasterize_point_mask(
    shapefile_path: Path,
    out_shape: tuple[int, int],
    transform,
    radius: int,
) -> tuple[np.ndarray, int]:
    mask = np.zeros(
        out_shape,
        dtype=np.uint8,
    )

    if not shapefile_path.exists():
        return mask, 0

    reader = shapefile.Reader(str(shapefile_path))

    count = 0

    for geometry in reader.shapes():
        for world_x, world_y in geometry.points:
            row, column = rowcol(
                transform,
                world_x,
                world_y,
            )

            cv2.circle(
                mask,
                center=(int(column), int(row)),
                radius=radius,
                color=255,
                thickness=-1,
                lineType=cv2.LINE_8,
            )

        count += 1

    reader.close()

    return mask, count


# ============================================================
# Rendering
# ============================================================


def colorize_unit_labels(
    unit_labels: np.ndarray,
    palette: dict[int, tuple[int, int, int]],
) -> np.ndarray:
    height, width = unit_labels.shape

    image_rgb = np.full(
        (height, width, 3),
        255,
        dtype=np.uint8,
    )

    for label_id, color_rgb in palette.items():
        image_rgb[unit_labels == label_id] = color_rgb

    return image_rgb


def draw_mask_color(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    color_bgr: tuple[int, int, int],
) -> None:
    image_bgr[mask > 0] = color_bgr


def draw_lake_layer(
    image_bgr: np.ndarray,
    lake_mask: np.ndarray,
) -> None:
    draw_mask_color(
        image_bgr,
        lake_mask,
        LAKE_FILL_COLOR,
    )

    outline = cv2.morphologyEx(
        lake_mask,
        cv2.MORPH_GRADIENT,
        np.ones(
            (
                2 * (LAKE_OUTLINE_WIDTH // 2) + 1,
                2 * (LAKE_OUTLINE_WIDTH // 2) + 1,
            ),
            dtype=np.uint8,
        ),
    )

    draw_mask_color(
        image_bgr,
        outline,
        LAKE_OUTLINE_COLOR,
    )


def build_final_clean_map(
    unit_labels: np.ndarray,
    palette: dict[int, tuple[int, int, int]],
    contact_mask: np.ndarray,
    fault_mask: np.ndarray,
    road_mask: np.ndarray,
    river_mask: np.ndarray,
    lake_mask: np.ndarray,
    strike_dip_mask: np.ndarray,
) -> np.ndarray:
    unit_rgb = colorize_unit_labels(
        unit_labels,
        palette,
    )

    final_bgr = cv2.cvtColor(
        unit_rgb,
        cv2.COLOR_RGB2BGR,
    )

    # Controlled bottom-to-top rendering order.
    draw_mask_color(
        final_bgr,
        contact_mask,
        CONTACT_COLOR,
    )

    # Lakes hide any geological contact below them and receive their own edge.
    draw_lake_layer(
        final_bgr,
        lake_mask,
    )

    draw_mask_color(
        final_bgr,
        river_mask,
        RIVER_COLOR,
    )

    draw_mask_color(
        final_bgr,
        road_mask,
        ROAD_COLOR,
    )

    # Faults remain visible across units and other line layers.
    draw_mask_color(
        final_bgr,
        fault_mask,
        FAULT_COLOR,
    )

    draw_mask_color(
        final_bgr,
        strike_dip_mask,
        STRIKE_DIP_COLOR,
    )

    return final_bgr


def build_final_boundaries(
    shape: tuple[int, int],
    contact_mask: np.ndarray,
    fault_mask: np.ndarray,
    road_mask: np.ndarray,
    river_mask: np.ndarray,
    lake_mask: np.ndarray,
    strike_dip_mask: np.ndarray,
) -> np.ndarray:
    boundaries = np.full(
        (shape[0], shape[1], 3),
        255,
        dtype=np.uint8,
    )

    lake_outline = cv2.morphologyEx(
        lake_mask,
        cv2.MORPH_GRADIENT,
        np.ones((3, 3), dtype=np.uint8),
    )

    # Same visual priority used for the clean map.
    draw_mask_color(
        boundaries,
        contact_mask,
        CONTACT_COLOR,
    )

    draw_mask_color(
        boundaries,
        lake_outline,
        LAKE_OUTLINE_COLOR,
    )

    draw_mask_color(
        boundaries,
        river_mask,
        RIVER_COLOR,
    )

    draw_mask_color(
        boundaries,
        road_mask,
        ROAD_COLOR,
    )

    draw_mask_color(
        boundaries,
        fault_mask,
        FAULT_COLOR,
    )

    draw_mask_color(
        boundaries,
        strike_dip_mask,
        STRIKE_DIP_COLOR,
    )

    return boundaries


def build_debug_overlay(
    image_bgr: np.ndarray,
    contact_mask: np.ndarray,
    fault_mask: np.ndarray,
    road_mask: np.ndarray,
    river_mask: np.ndarray,
    lake_mask: np.ndarray,
    strike_dip_mask: np.ndarray,
) -> np.ndarray:
    overlay = image_bgr.copy()

    layers = (
        (contact_mask, DEBUG_CONTACT_COLOR),
        (lake_mask, DEBUG_LAKE_COLOR),
        (river_mask, DEBUG_RIVER_COLOR),
        (road_mask, DEBUG_ROAD_COLOR),
        (fault_mask, DEBUG_FAULT_COLOR),
        (strike_dip_mask, DEBUG_STRIKE_DIP_COLOR),
    )

    for mask, color in layers:
        selected = mask > 0

        if not np.any(selected):
            continue

        colored = np.empty_like(overlay)
        colored[:] = color

        overlay[selected] = cv2.addWeighted(
            overlay[selected],
            0.35,
            colored[selected],
            0.65,
            0.0,
        )

    return overlay


# ============================================================
# Saving
# ============================================================


def save_geotiff(
    path: Path,
    image_bgr: np.ndarray,
    reference_profile: dict[str, Any],
) -> None:
    image_rgb = cv2.cvtColor(
        image_bgr,
        cv2.COLOR_BGR2RGB,
    )

    profile = reference_profile.copy()

    profile.update(
        driver="GTiff",
        height=image_rgb.shape[0],
        width=image_rgb.shape[1],
        count=3,
        dtype="uint8",
        nodata=None,
        compress="deflate",
    )

    with rasterio.open(
        path,
        "w",
        **profile,
    ) as dataset:
        dataset.write(
            np.moveaxis(
                image_rgb,
                -1,
                0,
            )
        )


# ============================================================
# Map processing
# ============================================================


def process_map(
    map_id: str,
) -> None:
    map_directory = DATASET_ROOT / map_id

    color_path = map_directory / f"{map_id}_color.tif"

    mask_path = map_directory / f"{map_id}_mask.tif"

    metadata_path = map_directory / f"{map_id}_meta.json"

    color_rgb, color_transform, color_profile = read_rgb_geotiff(color_path)

    mask_rgb, mask_transform, _ = read_rgb_geotiff(mask_path)

    if color_rgb.shape[:2] != mask_rgb.shape[:2]:
        raise ValueError(
            f"Color/mask size mismatch for {map_id}: "
            f"{color_rgb.shape[:2]} vs {mask_rgb.shape[:2]}"
        )

    if not np.allclose(
        tuple(color_transform),
        tuple(mask_transform),
        atol=1e-12,
    ):
        raise ValueError(f"Color/mask transforms differ for {map_id}.")

    metadata_palette, unit_records = read_geological_palette(metadata_path)

    polygon_path = map_directory / f"{map_id}_polygons.shp"

    (
        mask_color_to_label,
        spatial_palette_report,
    ) = infer_mask_palette_from_polygons(
        mask_rgb=mask_rgb,
        polygon_path=polygon_path,
        transform=color_transform,
    )

    unit_labels = decode_unit_labels_from_spatial_mapping(
        mask_rgb,
        mask_color_to_label,
    )

    # Reconstruct using the actual mask colors, not metadata colors.
    palette = {}

    for mask_color, label_id in mask_color_to_label.items():
        palette[int(label_id)] = tuple(int(value) for value in mask_color)

    # Kept for report compatibility.
    color_distance = np.zeros(
        unit_labels.shape,
        dtype=np.float32,
    )

    contact_mask = derive_contact_mask(
        unit_labels,
        thickness=CONTACT_WIDTH,
    )

    out_shape = color_rgb.shape[:2]

    fault_geometries, fault_count = read_shape_geometries(
        map_directory / f"{map_id}_faults.shp"
    )

    road_geometries, road_count = read_shape_geometries(
        map_directory / f"{map_id}_roads.shp"
    )

    river_geometries, river_count = read_shape_geometries(
        map_directory / f"{map_id}_rivers.shp"
    )

    lake_geometries, lake_count = read_shape_geometries(
        map_directory / f"{map_id}_lakes.shp"
    )

    fault_mask = rasterize_geometry_mask(
        fault_geometries,
        out_shape,
        color_transform,
        line_width=FAULT_WIDTH,
    )

    road_mask = rasterize_geometry_mask(
        road_geometries,
        out_shape,
        color_transform,
        line_width=ROAD_WIDTH,
    )

    river_mask = rasterize_geometry_mask(
        river_geometries,
        out_shape,
        color_transform,
        line_width=RIVER_WIDTH,
    )

    lake_mask = rasterize_geometry_mask(
        lake_geometries,
        out_shape,
        color_transform,
        line_width=1,
    )

    strike_dip_mask, strike_dip_count = rasterize_point_mask(
        map_directory / f"{map_id}_strike_dip.shp",
        out_shape,
        color_transform,
        radius=STRIKE_DIP_RADIUS,
    )

    clutter_mask = cv2.bitwise_or(
        road_mask,
        river_mask,
    )

    clutter_mask = cv2.bitwise_or(
        clutter_mask,
        lake_mask,
    )

    clutter_mask = cv2.bitwise_or(
        clutter_mask,
        strike_dip_mask,
    )

    color_bgr = cv2.cvtColor(
        color_rgb,
        cv2.COLOR_RGB2BGR,
    )

    final_clean_map = build_final_clean_map(
        unit_labels,
        palette,
        contact_mask,
        fault_mask,
        road_mask,
        river_mask,
        lake_mask,
        strike_dip_mask,
    )

    final_boundaries = build_final_boundaries(
        out_shape,
        contact_mask,
        fault_mask,
        road_mask,
        river_mask,
        lake_mask,
        strike_dip_mask,
    )

    final_debug_overlay = build_debug_overlay(
        color_bgr,
        contact_mask,
        fault_mask,
        road_mask,
        river_mask,
        lake_mask,
        strike_dip_mask,
    )

    output_directory = OUTPUT_ROOT / map_id

    output_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    np.save(
        output_directory / "unit_labels.npy",
        unit_labels,
    )

    np.save(
        output_directory / "palette_match_distance.npy",
        color_distance,
    )

    cv2.imwrite(
        str(output_directory / "unit_labels_preview.png"),
        cv2.cvtColor(
            colorize_unit_labels(
                unit_labels,
                palette,
            ),
            cv2.COLOR_RGB2BGR,
        ),
    )

    cv2.imwrite(
        str(output_directory / "contact_mask.png"),
        contact_mask,
    )

    cv2.imwrite(
        str(output_directory / "fault_mask.png"),
        fault_mask,
    )

    cv2.imwrite(
        str(output_directory / "road_mask.png"),
        road_mask,
    )

    cv2.imwrite(
        str(output_directory / "river_mask.png"),
        river_mask,
    )

    cv2.imwrite(
        str(output_directory / "lake_mask.png"),
        lake_mask,
    )

    cv2.imwrite(
        str(output_directory / "strike_dip_mask.png"),
        strike_dip_mask,
    )

    cv2.imwrite(
        str(output_directory / "clutter_mask.png"),
        clutter_mask,
    )

    cv2.imwrite(
        str(output_directory / "final_clean_map.png"),
        final_clean_map,
    )

    cv2.imwrite(
        str(output_directory / "final_boundaries.png"),
        final_boundaries,
    )

    cv2.imwrite(
        str(output_directory / "final_debug_overlay.png"),
        final_debug_overlay,
    )

    save_geotiff(
        output_directory / "final_clean_map.tif",
        final_clean_map,
        color_profile,
    )

    unmatched = unit_labels < 0

    report = {
        "map_id": map_id,
        "shape": [
            int(out_shape[0]),
            int(out_shape[1]),
        ],
        "palette": {
            str(label_id): {
                "rgb": list(palette[label_id]),
                "metadata": unit_records[label_id],
            }
            for label_id in sorted(palette)
        },
        "unmatched_pixel_count": int(np.count_nonzero(unmatched)),
        "unmatched_pixel_ratio": float(np.mean(unmatched)),
        "maximum_palette_distance": float(np.max(color_distance)),
        "mean_palette_distance": float(np.mean(color_distance)),
        "contact_pixels": int(np.count_nonzero(contact_mask)),
        "fault_pixels": int(np.count_nonzero(fault_mask)),
        "road_pixels": int(np.count_nonzero(road_mask)),
        "river_pixels": int(np.count_nonzero(river_mask)),
        "lake_pixels": int(np.count_nonzero(lake_mask)),
        "strike_dip_pixels": int(np.count_nonzero(strike_dip_mask)),
        "feature_counts": {
            "faults": fault_count,
            "roads": road_count,
            "rivers": river_count,
            "lakes": lake_count,
            "strike_dip": strike_dip_count,
        },
        "spatial_palette_inference": spatial_palette_report,
    }

    (output_directory / "target_report.json").write_text(
        json.dumps(
            report,
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    print()
    print("=" * 68)
    print("Processed:", map_id)
    print("Shape:", out_shape)
    print("Unit labels:", sorted(palette))
    print(
        "Unmatched mask pixels:",
        report["unmatched_pixel_count"],
        f"({report['unmatched_pixel_ratio']:.6%})",
    )
    print("Fault features:", fault_count)
    print("Road features:", road_count)
    print("River features:", river_count)
    print("Lake features:", lake_count)
    print("Strike/dip features:", strike_dip_count)
    print("Saved:", output_directory)


def main() -> None:
    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    print("Building Supervisor150 multilayer targets")
    print("Maps:", MAP_IDS)

    completed = 0
    failed = 0

    for map_id in MAP_IDS:
        try:
            process_map(map_id)
            completed += 1

        except Exception as error:
            failed += 1

            print()
            print("=" * 68)
            print("FAILED:", map_id)
            print(
                type(error).__name__ + ":",
                error,
            )

    print()
    print("=" * 68)
    print("Completed:", completed)
    print("Failed:", failed)

    if failed:
        raise RuntimeError(f"{failed} map(s) failed multilayer target generation.")


if __name__ == "__main__":
    main()
