﻿from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

from faria_geomap_rnd import config

# ============================================================
# Configuration
# ============================================================

MAP_ID = "map_0000"

DATASET_ROOT = config.SUPERVISOR150_ROOT
TARGET_ROOT = config.SUPERVISOR_MULTILAYER_TARGET_DIR
ALIGNMENT_ROOT = config.ALIGNMENT_DEBUG_DIR
OUTPUT_ROOT = config.OUTPUT_DIR / "original_png_overlays"

# BGR debug colors.
CONTACT_COLOR = (0, 255, 0)
FAULT_COLOR = (0, 0, 255)
ROAD_COLOR = (128, 128, 128)
RIVER_COLOR = (255, 100, 0)
LAKE_COLOR = (255, 0, 0)  # Blue in OpenCV BGR
STRIKE_DIP_COLOR = (0, 255, 255)


def read_mask(path: Path) -> np.ndarray:
    mask = cv2.imread(
        str(path),
        cv2.IMREAD_GRAYSCALE,
    )

    if mask is None:
        raise FileNotFoundError(f"Could not read mask: {path}")

    return mask


def warp_mask_to_source(
    canonical_mask: np.ndarray,
    inverse_matrix: np.ndarray,
    source_width: int,
    source_height: int,
) -> np.ndarray:
    """
    Warp a canonical GeoTIFF-grid mask back onto the original PNG page.

    Nearest-neighbour interpolation is essential for categorical masks.
    """

    warped = cv2.warpPerspective(
        canonical_mask,
        inverse_matrix,
        dsize=(
            source_width,
            source_height,
        ),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )

    return warped


def color_overlay(
    base_bgr: np.ndarray,
    mask: np.ndarray,
    color_bgr: tuple[int, int, int],
    alpha: float = 0.70,
) -> None:
    selected = mask > 0

    if not np.any(selected):
        return

    color_image = np.empty_like(base_bgr)

    color_image[:] = color_bgr

    base_bgr[selected] = cv2.addWeighted(
        base_bgr[selected],
        1.0 - alpha,
        color_image[selected],
        alpha,
        0.0,
    )


def build_source_map_footprint(
    canonical_shape: tuple[int, int],
    inverse_matrix: np.ndarray,
    source_width: int,
    source_height: int,
) -> np.ndarray:
    """
    The canonical GeoTIFF grid itself is the valid map panel.

    Warping a full-white canonical footprint back to the PNG gives the exact
    polygonal region on the decorated page where map overlays are allowed.
    """

    canonical_footprint = np.full(
        canonical_shape,
        255,
        dtype=np.uint8,
    )

    source_footprint = warp_mask_to_source(
        canonical_footprint,
        inverse_matrix,
        source_width,
        source_height,
    )

    # Remove tiny interpolation/fringe artifacts at the map edge.
    source_footprint = cv2.morphologyEx(
        source_footprint,
        cv2.MORPH_ERODE,
        np.ones((3, 3), dtype=np.uint8),
        iterations=1,
    )

    return source_footprint


def clip_to_footprint(
    mask: np.ndarray,
    footprint: np.ndarray,
) -> np.ndarray:
    return cv2.bitwise_and(
        mask,
        footprint,
    )


def main() -> None:
    source_png_path = DATASET_ROOT / MAP_ID / f"{MAP_ID}_color.png"

    target_directory = TARGET_ROOT / MAP_ID

    inverse_matrix_path = ALIGNMENT_ROOT / MAP_ID / "inverse_matrix.npy"

    source_bgr = cv2.imread(
        str(source_png_path),
        cv2.IMREAD_COLOR,
    )

    if source_bgr is None:
        raise FileNotFoundError(f"Could not read source PNG: {source_png_path}")

    if not inverse_matrix_path.exists():
        raise FileNotFoundError(
            f"Missing inverse alignment matrix: {inverse_matrix_path}"
        )

    inverse_matrix = np.load(inverse_matrix_path)

    masks = {
        "contact": read_mask(target_directory / "contact_mask.png"),
        "fault": read_mask(target_directory / "fault_mask.png"),
        "road": read_mask(target_directory / "road_mask.png"),
        "river": read_mask(target_directory / "river_mask.png"),
        "lake": read_mask(target_directory / "lake_mask.png"),
        "strike_dip": read_mask(target_directory / "strike_dip_mask.png"),
    }

    canonical_shape = masks["contact"].shape

    for name, mask in masks.items():
        if mask.shape != canonical_shape:
            raise ValueError(
                f"Mask shape mismatch for {name}: "
                f"{mask.shape} versus {canonical_shape}"
            )

    source_height, source_width = source_bgr.shape[:2]

    source_footprint = build_source_map_footprint(
        canonical_shape,
        inverse_matrix,
        source_width,
        source_height,
    )

    warped_masks = {}

    for name, canonical_mask in masks.items():
        warped = warp_mask_to_source(
            canonical_mask,
            inverse_matrix,
            source_width,
            source_height,
        )

        warped_masks[name] = clip_to_footprint(
            warped,
            source_footprint,
        )

    overlay = source_bgr.copy()

    # Bottom-to-top debug rendering order.
    color_overlay(
        overlay,
        warped_masks["contact"],
        CONTACT_COLOR,
    )

    color_overlay(
        overlay,
        warped_masks["lake"],
        LAKE_COLOR,
    )

    color_overlay(
        overlay,
        warped_masks["river"],
        RIVER_COLOR,
    )

    color_overlay(
        overlay,
        warped_masks["road"],
        ROAD_COLOR,
    )

    color_overlay(
        overlay,
        warped_masks["fault"],
        FAULT_COLOR,
    )

    color_overlay(
        overlay,
        warped_masks["strike_dip"],
        STRIKE_DIP_COLOR,
    )

    # Transparent-style RGBA overlay for later GUI use.
    rgba = np.zeros(
        (
            source_height,
            source_width,
            4,
        ),
        dtype=np.uint8,
    )

    layer_specs = (
        ("contact", CONTACT_COLOR),
        ("lake", LAKE_COLOR),
        ("river", RIVER_COLOR),
        ("road", ROAD_COLOR),
        ("fault", FAULT_COLOR),
        ("strike_dip", STRIKE_DIP_COLOR),
    )

    for name, bgr in layer_specs:
        selected = warped_masks[name] > 0

        rgba[selected, 0] = bgr[0]
        rgba[selected, 1] = bgr[1]
        rgba[selected, 2] = bgr[2]
        rgba[selected, 3] = 220

    OUTPUT_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    overlay_path = OUTPUT_ROOT / f"{MAP_ID}_overlay_on_original_png.png"

    footprint_path = OUTPUT_ROOT / f"{MAP_ID}_source_map_footprint.png"

    rgba_path = OUTPUT_ROOT / f"{MAP_ID}_overlay_transparent.png"

    cv2.imwrite(
        str(overlay_path),
        overlay,
    )

    cv2.imwrite(
        str(footprint_path),
        source_footprint,
    )

    cv2.imwrite(
        str(rgba_path),
        rgba,
    )

    print("Saved:", overlay_path)
    print("Saved:", footprint_path)
    print("Saved:", rgba_path)


if __name__ == "__main__":
    main()
