from __future__ import annotations

import cv2
import numpy as np
import pyogrio
import pytest
from faria_geomap_rnd.gis_export import vectorize
from faria_geomap_rnd.gis_export.layers import LAYER_FIELDS
from faria_geomap_rnd.run_map import absorb_small_regions, run_map


def synthetic_map(h: int = 600, w: int = 800) -> np.ndarray:
    """Three coloured units, a black straight line and a red line."""
    image = np.full((h, w, 3), 255, dtype=np.uint8)
    image[50:550, 50:350] = (120, 200, 120)  # green unit (BGR)
    image[50:550, 350:750] = (200, 150, 90)  # blue unit
    image[300:550, 350:750] = (90, 200, 230)  # yellow unit
    cv2.line(image, (60, 80), (740, 520), (20, 20, 20), 3)
    cv2.line(image, (100, 500), (300, 120), (0, 0, 255), 3)
    return image


@pytest.fixture()
def map_png(tmp_path):
    path = tmp_path / "synthetic.png"
    cv2.imwrite(str(path), synthetic_map())
    return path


def test_run_map_writes_separate_layers(map_png, tmp_path):
    out = tmp_path / "out"
    report = run_map(map_png, out, k=3, min_region_area=200)

    assert report["status"] == "ok"
    gpkg = out / "synthetic" / "synthetic.gpkg"
    layers = {name for name, _ in pyogrio.list_layers(gpkg)}
    assert layers - {"layer_styles"} == set(LAYER_FIELDS)

    for name in LAYER_FIELDS:
        assert (out / "synthetic" / "geojson" / f"{name}.geojson").exists()

    units = pyogrio.read_dataframe(gpkg, layer="units")
    assert len(units) >= 3
    assert units.geometry.is_valid.all()
    assert {"unit_id", "legend_color", "map_id", "source"} <= set(units.columns)

    contacts = pyogrio.read_dataframe(gpkg, layer="contacts")
    assert len(contacts) > 0
    assert (contacts.left_unit <= contacts.right_unit).all()


def test_no_crs_is_invented_for_plain_images(map_png, tmp_path):
    report = run_map(map_png, tmp_path / "out", k=3, min_region_area=200)

    assert report["georeference"]["georeferenced"] is False
    gpkg = tmp_path / "out" / "synthetic" / "synthetic.gpkg"
    info = pyogrio.read_info(gpkg, layer="units")
    assert info["crs"] is None

    # Pixel space, y flipped so the map is upright in QGIS.
    xmin, ymin, xmax, ymax = info["total_bounds"]
    assert 0 <= xmin < xmax <= 800
    assert -600 <= ymin < ymax <= 0


def test_geotiff_crs_is_kept(tmp_path):
    rasterio = pytest.importorskip("rasterio")
    from rasterio.transform import from_origin

    image = synthetic_map()
    path = tmp_path / "geo.tif"
    transform = from_origin(500000.0, 5100000.0, 2.0, 2.0)
    with rasterio.open(
        path,
        "w",
        driver="GTiff",
        height=image.shape[0],
        width=image.shape[1],
        count=3,
        dtype="uint8",
        crs="EPSG:32617",
        transform=transform,
    ) as dst:
        dst.write(np.moveaxis(image[:, :, ::-1], -1, 0))

    report = run_map(path, tmp_path / "out", k=3, min_region_area=200)

    assert report["georeference"]["georeferenced"] is True
    info = pyogrio.read_info(tmp_path / "out" / "geo" / "geo.gpkg", layer="units")
    assert "32617" in info["crs"]
    xmin, ymin, xmax, ymax = info["total_bounds"]
    assert 500000 <= xmin < xmax <= 501600
    assert 5098800 <= ymin < ymax <= 5100000


def test_absorb_small_regions_leaves_no_tiny_polygons():
    labels = np.zeros((50, 50), dtype=np.int16)
    labels[:, 25:] = 1
    labels[10:12, 10:12] = 1  # 4-pixel island
    labels[40:, :] = -1  # outside the map

    out, absorbed = absorb_small_regions(labels, min_area=10)

    assert absorbed == 1
    assert (out[10:12, 10:12] == 0).all()
    assert (out[40:, :] == -1).all()


def test_line_rules():
    red = {"hue": 2.0, "saturation": 200.0, "value": 200.0}
    dark = {"hue": 0.0, "saturation": 10.0, "value": 30.0}

    assert vectorize.classify_line(red, 50, 0.5, 0.0, 1000)[0] == "veins"
    assert vectorize.classify_line(dark, 200, 0.95, 0.0, 1000)[0] == "faults"
    assert vectorize.classify_line(dark, 20, 0.3, 0.0, 1000)[0] == "other_lines"
    assert vectorize.classify_line(dark, 200, 0.95, 0.9, 1000)[0] == "drop_contact"


def test_qgis_default_styles_are_stored(map_png, tmp_path):
    import sqlite3
    import xml.etree.ElementTree as ET

    run_map(map_png, tmp_path / "out", k=3, min_region_area=200)
    map_dir = tmp_path / "out" / "synthetic"

    con = sqlite3.connect(map_dir / "synthetic.gpkg")
    rows = con.execute(
        "SELECT f_table_name, styleQML, useAsDefault FROM layer_styles"
    ).fetchall()
    con.close()

    assert {r[0] for r in rows} == set(LAYER_FIELDS)
    for _, qml, default in rows:
        assert default == 1
        ET.fromstring(qml.split(">", 1)[1])  # well-formed after the DOCTYPE

    for name in LAYER_FIELDS:
        assert (map_dir / "geojson" / f"{name}.qml").exists()

    # The GeoPackage still opens normally with the extra table.
    assert {n for n, _ in pyogrio.list_layers(map_dir / "synthetic.gpkg")} >= set(
        LAYER_FIELDS
    )


def test_printed_outline_splits_same_colour_area():
    from faria_geomap_rnd.run_map import extract_region_labels

    image = np.full((400, 500, 3), 255, dtype=np.uint8)
    image[50:350, 50:450] = (120, 200, 120)
    cv2.line(image, (250, 50), (250, 349), (0, 0, 0), 3)  # drawn boundary

    labels, faces, _ = extract_region_labels(image, k=3, min_region_area=200)

    left, right = faces[200, 150], faces[200, 350]
    assert left >= 0 and right >= 0 and left != right
    assert labels[200, 150] == labels[200, 350]


def test_white_ground_inside_map_is_kept():
    from faria_geomap_rnd.run_map import extract_region_labels

    image = np.full((400, 500, 3), 255, dtype=np.uint8)
    image[50:350, 50:450] = (120, 200, 120)
    image[150:250, 200:300] = 255  # white patch inside the coloured area

    labels, _, _ = extract_region_labels(image, k=3, min_region_area=200)

    assert labels[200, 250] >= 0
    assert labels[200, 250] != labels[100, 100]


TINY_MASK2FORMER = dict(
    embed_dim=24,
    depths=[1, 1, 1, 1],
    num_heads=[1, 2, 3, 6],
    num_queries=8,
    hidden_dim=32,
    mask_feature_size=32,
    feature_size=32,
    encoder_layers=1,
    decoder_layers=2,
    dim_feedforward=64,
    num_attention_heads=2,
)


def _save_stand_in_checkpoints(models_dir):
    """Randomly initialised checkpoints in the training scripts' format."""
    torch = pytest.importorskip("torch")
    pytest.importorskip("transformers")
    from faria_geomap_rnd.models import mask2former_regions as m2f
    from faria_geomap_rnd.models.hybrid.georegion_affinity_net import (
        GeoRegionAffinityNet,
    )
    from faria_geomap_rnd.models.hybrid.line_models import (
        CHECKPOINT_STEMS,
        build_line_model,
    )
    from faria_geomap_rnd.models.se_unet import SEUNet

    torch.manual_seed(0)
    models_dir.mkdir()
    for architecture, stem in CHECKPOINT_STEMS.items():
        torch.save(
            {
                "model_state_dict": build_line_model(architecture, 8).state_dict(),
                "architecture": architecture,
                "base_channels": 8,
                "crop_size": 128,
            },
            models_dir / f"{stem}_best.pth",
        )
    torch.save(
        {
            "model_state_dict": GeoRegionAffinityNet(base_channels=8).state_dict(),
            "base_channels": 8,
            "crop_size": 128,
        },
        models_dir / "georegion_affinity_best.pth",
    )
    torch.save(
        {
            "model_state_dict": SEUNet(num_classes=4, base_channels=8).state_dict(),
            "base_channels": 8,
            "num_classes": 4,
        },
        models_dir / "se_unet_v2_best.pth",
    )
    m2f_config = m2f.small_config(**TINY_MASK2FORMER)
    torch.save(
        {
            "model_state_dict": m2f.build_region_model(m2f_config).state_dict(),
            "hf_config": m2f_config.to_dict(),
            "crop_size": 128,
        },
        models_dir / m2f.CHECKPOINT_NAME,
    )


ALL_TRAINED = {
    "supervisor_multihead",
    "transunet",
    "rs3mamba",
    "se_unet",
    "georegion_affinity",
    "mask2former",
}


def test_runner_uses_every_trained_model_when_checkpoints_exist(
    map_png, tmp_path, monkeypatch
):
    from faria_geomap_rnd.gis_export import experts

    models_dir = tmp_path / "models"
    _save_stand_in_checkpoints(models_dir)
    # Random stand-in weights fire everywhere; accept them for this test.
    monkeypatch.setattr(experts, "MAX_PLAUSIBLE_COVERAGE", 1.01)

    report = run_map(
        map_png,
        tmp_path / "out",
        k=3,
        min_region_area=200,
        models_dir=models_dir,
        device="cpu",
    )

    assert report["status"] == "ok"
    assert set(report["models"]["used"]) == ALL_TRAINED
    assert report["models"]["errors"] == {}
    assert report["models"]["roles"]["mask2former"] == ["area_boundary"]
    fault_method = report["steps"]["lines"]["model_layers"]["fault"]
    assert {"transunet", "rs3mamba", "se_unet"} <= set(fault_method.split("+"))


def test_implausible_model_output_is_ignored(tmp_path):
    from faria_geomap_rnd.gis_export.experts import run_experts

    models_dir = tmp_path / "models"
    _save_stand_in_checkpoints(models_dir)

    out = run_experts(synthetic_map(300, 400), models_dir, device="cpu")

    assert out.errors == {}
    assert out.ignored  # random weights mark lines or boundaries everywhere
    assert not set(out.ignored) & set(out.used)
    for name in out.ignored:
        assert name not in out.line and name not in out.area


def test_line_architectures_train_and_load(tmp_path):
    torch = pytest.importorskip("torch")
    from faria_geomap_rnd.models.hybrid.line_models import build_line_model
    from faria_geomap_rnd.models.hybrid.rs3mamba_geomap import (
        selective_scan_reference,
    )
    from faria_geomap_rnd.pipelines.infer_supervisor_multihead import load_model

    # The chunked scan equals the step-by-step recurrence.
    torch.manual_seed(0)
    u, delta = torch.randn(1, 3, 70), torch.rand(1, 3, 70) * 0.5
    A, D = -torch.rand(3, 4) * 2, torch.randn(3)
    B, C = torch.randn(1, 4, 70), torch.randn(1, 4, 70)
    h, ys = torch.zeros(1, 3, 4), []
    for t in range(70):
        h = torch.exp(delta[:, :, t, None] * A) * h
        h = h + delta[:, :, t, None] * B[:, None, :, t] * u[:, :, t, None]
        ys.append((h * C[:, None, :, t]).sum(-1))
    expected = torch.stack(ys, 2) + u * D[None, :, None]
    got = selective_scan_reference(u, delta, A, B, C, D, chunk=16)
    assert torch.allclose(got, expected, atol=1e-4)

    for architecture in ("transunet", "rs3mamba"):
        model = build_line_model(architecture, base_channels=8)
        outputs = model(torch.rand(2, 3, 64, 96))
        assert outputs["fault"].shape == (2, 1, 64, 96)
        sum(o.mean() for o in outputs.values()).backward()

        path = tmp_path / f"{architecture}.pth"
        torch.save(
            {
                "model_state_dict": model.state_dict(),
                "architecture": architecture,
                "base_channels": 8,
            },
            path,
        )
        loaded, _ = load_model(path, torch.device("cpu"))
        assert type(loaded) is type(model)


def test_mask2former_area_targets_and_loss():
    torch = pytest.importorskip("torch")
    pytest.importorskip("transformers")
    from faria_geomap_rnd.models import mask2former_regions as m2f

    units = np.full((64, 64), -1, dtype=np.int64)
    units[4:60, 4:32] = 0
    units[4:60, 32:60] = 1
    units[20:30, 10:20] = 1  # a second, separate area of unit 1
    masks, classes = m2f.area_targets(units)
    assert masks.shape == (3, 64, 64) and (classes == 0).all()

    model = m2f.build_region_model(m2f.small_config(**TINY_MASK2FORMER))
    outputs = model(
        pixel_values=torch.rand(1, 3, 64, 64),
        mask_labels=[masks],
        class_labels=[classes],
    )
    assert torch.isfinite(outputs.loss)

    # Two clean areas give a boundary only where they meet.
    membership = torch.zeros(2, 8, 8)
    membership[0, :, :4] = 1
    membership[1, :, 4:] = 1
    boundary = m2f.membership_boundary(membership)
    assert boundary[:, 3:5].min() == 1 and boundary[:, :3].max() == 0


def test_sam2_refines_uncertain_area_boundaries(tmp_path):
    torch = pytest.importorskip("torch")
    pytest.importorskip("sam2")
    from faria_geomap_rnd.gis_export import experts
    from sam2.build_sam import build_sam2

    path = tmp_path / "sam2.1_hiera_tiny.pt"
    model = build_sam2("configs/sam2.1/sam2.1_hiera_t.yaml", None, device="cpu")
    torch.save({"model": model.state_dict()}, path)
    assert experts.sam2_config_for(path).endswith("sam2.1_hiera_t.yaml")

    image = synthetic_map(300, 400)
    boundary = np.zeros(image.shape[:2], dtype=np.float32)
    boundary[100:200, 150:250] = 0.5  # one uncertain patch

    refined, info = experts._refine_with_sam2(
        image, path, torch.device("cpu"), boundary, max_boxes=1
    )

    assert info["boxes"] == 1
    assert info["pixels_raised"] + info["pixels_lowered"] == 100 * 100
    patch = refined[100:200, 150:250]
    assert np.isclose(patch, 0.2).sum() + np.isclose(patch, 0.8).sum() == patch.size
    assert (refined[boundary == 0] == 0).all()


def test_runner_falls_back_without_checkpoints(map_png, tmp_path):
    report = run_map(
        map_png,
        tmp_path / "out",
        k=3,
        min_region_area=200,
        models_dir=tmp_path / "empty",
    )

    assert report["status"] == "ok"
    assert report["models"]["used"] == {}
    assert any("No trained model" in w for w in report["warnings"])
