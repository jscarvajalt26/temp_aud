﻿from __future__ import annotations

import torch
from faria_geomap_rnd import config
from faria_geomap_rnd.models.hybrid.georegion_affinity_net import GeoRegionAffinityNet
from faria_geomap_rnd.models.hybrid.hybrid_geomap_net import HybridGeoMapNetV1
from faria_geomap_rnd.models.hybrid.multihead_geomap_net import (
    HEAD_NAMES,
    MultiHeadGeoMapNet,
)
from faria_geomap_rnd.models.refinement import mapsam2_refiner
from faria_geomap_rnd.models.se_unet import SEUNet


def test_config_base_dir_exists() -> None:
    assert config.BASE_DIR.exists()
    assert config.BASE_DIR.name == "faria_geomap_rnd"


def test_sam2_module_imports_without_dependency() -> None:
    assert isinstance(mapsam2_refiner.SAM2_AVAILABLE, bool)


def test_se_unet_forward_shape() -> None:
    model = SEUNet(
        in_channels=3,
        num_classes=4,
        base_channels=32,
    )
    model.eval()

    x = torch.randn(1, 3, 64, 64)

    with torch.no_grad():
        output = model(x)

    assert output.shape == (1, 4, 64, 64)


def test_hybrid_model_forward_shape() -> None:
    model = HybridGeoMapNetV1(
        in_channels=3,
        num_classes=4,
        base_channels=32,
    )
    model.eval()

    x = torch.randn(1, 3, 64, 64)

    with torch.no_grad():
        output = model(x)

    assert output.shape == (1, 4, 64, 64)


def test_georegion_affinity_forward_shapes() -> None:
    model = GeoRegionAffinityNet(
        in_channels=3,
        base_channels=16,
    )
    model.eval()

    x = torch.randn(1, 3, 64, 64)

    with torch.no_grad():
        output = model(x)

    assert set(output) == {
        "affinity_h",
        "affinity_v",
        "boundary",
    }

    for value in output.values():
        assert value.shape == (1, 1, 64, 64)


def test_multihead_forward_shapes() -> None:
    model = MultiHeadGeoMapNet(
        in_channels=3,
        base_channels=32,
    )
    model.eval()

    x = torch.randn(1, 3, 64, 64)

    with torch.no_grad():
        output = model(x)

    assert set(output) == set(HEAD_NAMES)

    for value in output.values():
        assert value.shape == (1, 1, 64, 64)
