from pathlib import Path

import plotly.express as px
import plotly.graph_objects as go
from nicegui import ui

from digitalize import *

IMAGES_FOLDER = Path("digitalize/tests/images")
RNG_SEED = 469273

img_cv2 = cv2.imread(
    (
        IMAGES_FOLDER
        / "222_Western_Pacific_Minerals_Phillipines_Project_Lampaki_geology_map_2.JPG"
    ).as_posix(),
    cv2.IMREAD_COLOR_BGR,
)
sample_size = 0.05
pallet_size = 20


def show_img(img) -> Tuple[go.Figure, ui.plotly]:
    img = reorder_channels(img)
    fig = px.imshow(img)
    fig.update_layout(margin=dict(l=0, r=0, t=0, b=0))
    return fig, ui.plotly(fig).classes("w-full")


def broadcast_pallet(pallet):
    pallet = np.array((np.vstack(np.array([(p,) * 50 for p in pallet])),) * 50)
    return pallet


def pltly(data, centroid, matches):
    fig = go.Figure()
    fig.add_trace(
        go.Scatter3d(
            x=data[:, 0],
            y=data[:, 1],
            z=data[:, 2],
            name="Pixels",
            mode="markers",
            marker={
                "color": ["rgb({},{},{})".format(*c) for c in data],
                "size": 4,
                "opacity": 0.8,
                "symbol": "cross",
            },
        )
    )
    fig.add_trace(
        go.Scatter3d(
            x=centroid[:, 0],
            y=centroid[:, 1],
            z=centroid[:, 2],
            name="Centroids",
            mode="markers",
            marker={
                "color": ["rgb({},{},{})".format(*c) for c in centroid],
                "size": 6,
                "symbol": "diamond",
                "line": {"color": "rgb(0,0,0)", "width": 1},
            },
        )
    )
    matches = [centroid[idx] for idx in matches]
    zipped = list(
        map(
            lambda x: list(zip(*x)),
            zip(zip(*data), zip(*matches), zip(*np.full(data.shape, np.nan))),
        )
    )
    fig.add_trace(
        go.Scatter3d(
            x=list(sum(zipped[0], ())),
            y=list(sum(zipped[1], ())),
            z=list(sum(zipped[2], ())),
            mode="lines",
            line={"color": "#aaaaff", "width": 1},
            showlegend=False,
            opacity=0.5,
            hoverinfo="skip",
        )
    )
    fig.update_layout(
        scene=dict(
            xaxis=dict(title=dict(text="Red")),
            yaxis=dict(title=dict(text="Green")),
            zaxis=dict(title=dict(text="Blue")),
        ),
        # width=700,
        # height=700,
        margin=dict(b=0, t=0),
    )

    ui.plotly(fig).classes("w-full")


def display_tabs(**kwargs):
    tab_dict = {}
    with ui.header(elevated=True):
        with ui.tabs().classes("w-full") as tabs:
            for k in kwargs.keys():
                tab_dict[k] = ui.tab(k)
    with ui.tab_panels(tabs, value=list(tab_dict.keys())[0]).classes("w-full"):
        for k, v in kwargs.items():
            f, *args = v
            with ui.tab_panel(tab_dict[k]):
                f(*args)


def display_palletized(img: npt.NDArray, pallet: npt.NDArray):
    img_flat = img.reshape((-1, 3))
    img_clustered, _ = assign_clusters(img_flat, pallet)

    toggels = []

    fig: go.Figure = None
    plotly: ui.plotly = None
    bg_colour_sel: ui.color_input = None

    def update_img():
        nonlocal fig, plotly, bg_colour_sel, toggels
        if bg_colour_sel is not None:
            bg_colour = bg_colour_sel.value
            # ui.label(str(type(bg_colour)))
            # ui.label(
            #     tuple(int(bg_colour.lstrip("#")[i : i + 2], 16) for i in (0, 2, 4))
            # )
            bg_colour = np.array(
                tuple(int(bg_colour.lstrip("#")[i : i + 2], 16) for i in (4, 2, 0))
            ).astype("uint8")
        else:
            bg_colour = np.array([0, 0, 0]).astype("uint8")

        enabled = []
        for idx, toggle in enumerate(toggels):
            if toggle.value:
                enabled.append(idx)
        img_to_show = np.array(
            [(pallet[idx] if idx in enabled else bg_colour) for idx in img_clustered]
        )
        img_to_show = img_to_show.reshape(img.shape)
        if not plotly:
            fig, plotly = show_img(img_to_show)
        else:
            img_to_show = reorder_channels(img_to_show)
            fig = px.imshow(img_to_show)
            fig.update_layout(margin=dict(l=0, r=0, t=0, b=0))
            # fig.update_traces(img_to_show)
            # plotly.update()
            plotly.update_figure(fig)
            # plotly.update()

    with ui.row():
        bg_colour_sel = ui.color_input(
            label="Background color",
            value="#000000",
            on_change=update_img,
        )
        pallet_rgb = reorder_channels(pallet)
        colour: npt.NDArray
        for colour in pallet_rgb:
            rgb = f"{colour[0]},{colour[1]},{colour[2]}"
            toggels.append(
                ui.switch(rgb, value=False, on_change=update_img).style(
                    f"background-color: rgb({rgb})"
                ),
            )
        update_img()


@ui.page("/")
def main():
    tab_collector = {}

    tab_collector["img_cv2"] = (show_img, img_cv2)

    img_smooth = cv2.bilateralFilter(img_cv2, 0, 35, 20)
    tab_collector["img_smooth"] = (show_img, img_smooth)

    colours_distinct = sort_pixel_frequency(img_smooth)
    colours_sample = sample_pixels(colours_distinct, sample_size)

    pallet, _ = get_clusters(colours_sample, pallet_size)
    tab_collector["pallet"] = (show_img, np.array([pallet]))

    labels, _ = assign_clusters(colours_sample, pallet)
    tab_collector["clustering"] = (
        pltly,
        reorder_channels(colours_sample),
        reorder_channels(pallet),
        labels,
    )

    # img_flat = img_smooth.reshape((-1, 3))
    # img_clustered, _ = assign_clusters(img_flat, pallet)
    # img_clustered = np.array(
    #     [
    #         (
    #             pallet[idx]
    #             if idx in [0, 6, 7, 9, 15, 16]
    #             else np.array([0, 0, 0]).astype("uint8")
    #         )
    #         for idx in img_clustered
    #     ]
    # )
    tab_collector["palletized"] = (display_palletized, img_smooth, pallet)

    display_tabs(**tab_collector)


if __name__ in {"__main__", "__mp_main__"}:
    ui.run()
