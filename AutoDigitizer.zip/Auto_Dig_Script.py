import os
import datetime
import cv2
import numpy as np
import rasterio
from rasterio.transform import from_origin
from rasterio.enums import Resampling
from qgis.core import (
    QgsFeature,  # this function represents a feature in a vector layer
    QgsGeometry,  # this represents the geometry of a feature
    QgsRasterLayer,  # this represents a raster layer
    QgsVectorLayer,  # this represents a vector layer
    QgsField,  # this represents a single attribute table's field
    QgsFields,  # this represents multiple attribute table's fields
    QgsPoint,  # this represents a point in 2d (x,y coordinates)
    QgsVectorFileWriter,  # this is used to write vector data to a file
    QgsProject,  # this manages the layers in the current qgis project
)
from PyQt5.QtCore import QVariant, QTimer  # used for data storage in QGIS vector layers
from PyQt5.QtWidgets import (
    QFileDialog,  # dialog window for selecting files
    QInputDialog,  # dialog window for inputs
    QMessageBox,  # used to display warnings and errors
    QWidget,  # class for user interface objects
    QProgressBar,  # progress bar widget function
    QApplication,  # this one helps to manage application resources and settings
    QDialog,  # class for creating dialogs
    QVBoxLayout,  # layout manager for arranging widgets vertically
    QPushButton,  # button function for UI interaction
    QComboBox,  # dropdown list for inputs
    QSpinBox,  # used to select an integer within a range
    QLabel,  # display text labels
    QGridLayout,  # this helps to adjust the input window
)

# log file variables are set globally
log_directory = None
log_file = None


def setup_progress_bar(max_value):
    """This sets up the progress bar"""
    progress_widget = QWidget()
    progress_widget.setWindowTitle("Processing Progress")
    progress_widget.resize(300, 100)

    progress_bar = QProgressBar(progress_widget)
    progress_bar.setGeometry(50, 30, 200, 30)
    progress_bar.setMaximum(max_value)
    progress_bar.setValue(0)

    progress_widget.show()
    QApplication.processEvents()

    return progress_widget, progress_bar


def update_progress_bar(progress_bar, value):
    """This function updates the progres bar after each event takes place"""
    progress_bar.setValue(value)
    QApplication.processEvents()


def initialize_log(raster_path):
    """This function sets the log path and log file and creates them if needed"""
    global log_directory, log_file
    if raster_path is None or not os.path.isfile(raster_path):
        raise ValueError("Invalid or null raster path provided")
    log_directory = os.path.dirname(raster_path)
    log_directory = os.path.join(log_directory, "Log Files")
    if not os.path.exists(log_directory):
        os.makedirs(log_directory)
    log_file = os.path.join(log_directory, "Autodigitizing_Script_Log.txt")
    with open(log_file, "a") as log_file_handle:
        log_file_handle.write(f"\nProcess Log - {datetime.datetime.now()}\n")
        log_file_handle.write("-" * 50 + "\n")
    return log_file


def write_log(log_file, message):
    """This function takes care of writing the log"""
    if log_file:
        if os.path.exists(log_file):
            with open(log_file, "r") as log_file_handle:
                existing_log = log_file_handle.read()
        else:
            existing_log = ""

        with open(log_file, "a") as log_file_handle:
            log_file_handle.write(message + "\n")
    else:
        print("Log file path is invalid")


# class for the input dialog window to set the inputs for all the parameters needed
class InputDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Input Parameters")
        self.setGeometry(100, 100, 400, 300)

        layout = QVBoxLayout()

        self.raster_path_label = QLabel("Select Raster File:")
        self.raster_path_button = QPushButton("Browse")
        self.raster_path_button.clicked.connect(self.browse_raster_file)
        layout.addWidget(self.raster_path_label)
        layout.addWidget(self.raster_path_button)

        self.output_folder_label = QLabel("Select Output Folder:")
        self.output_folder_button = QPushButton("Browse")
        self.output_folder_button.clicked.connect(self.browse_output_folder)
        layout.addWidget(self.output_folder_label)
        layout.addWidget(self.output_folder_button)

        self.operation_label = QLabel("Select Operation (Erosion, Dilation, or None):")
        self.operation_combo = QComboBox()
        self.operation_combo.addItems(["None", "Dilation", "Erosion"])
        self.operation_combo.currentIndexChanged.connect(self.update_operation_inputs)
        layout.addWidget(self.operation_label)
        layout.addWidget(self.operation_combo)

        self.kernel_size_label = QLabel("Kernel Size (1-10):")
        self.kernel_size_spin = QSpinBox()
        self.kernel_size_spin.setRange(1, 10)
        self.kernel_size_spin.setValue(3)
        layout.addWidget(self.kernel_size_label)
        layout.addWidget(self.kernel_size_spin)
        self.kernel_size_label.setVisible(False)
        self.kernel_size_spin.setVisible(False)

        self.iterations_label = QLabel("Iterations (1-5):")
        self.iterations_spin = QSpinBox()
        self.iterations_spin.setRange(1, 5)
        self.iterations_spin.setValue(1)
        layout.addWidget(self.iterations_label)
        layout.addWidget(self.iterations_spin)
        self.iterations_label.setVisible(False)
        self.iterations_spin.setVisible(False)

        self.num_thresholds_label = QLabel("Number of Thresholds (1-10):")
        self.num_thresholds_spin = QSpinBox()
        self.num_thresholds_spin.setRange(1, 10)
        self.num_thresholds_spin.setValue(1)
        self.num_thresholds_spin.valueChanged.connect(self.update_threshold_inputs)
        layout.addWidget(self.num_thresholds_label)
        layout.addWidget(self.num_thresholds_spin)

        self.threshold_inputs_layout = QGridLayout()
        self.threshold_inputs_widget = QWidget()
        self.threshold_inputs_widget.setLayout(self.threshold_inputs_layout)
        layout.addWidget(self.threshold_inputs_widget)

        self.submit_button = QPushButton("Submit")
        self.submit_button.clicked.connect(self.submit_inputs)
        layout.addWidget(self.submit_button)

        self.setLayout(layout)
        self.result = None
        self.update_threshold_inputs()
        self.update_operation_inputs()

    def browse_raster_file(self):
        file_types = (
            "GeoTIFF Files (*.tif *.tiff);;JPEG Files (*.jpg *.jpeg);;PNG Files (*.png)"
        )
        raster_path, _ = QFileDialog.getOpenFileName(
            None, "Select Raster File", "", file_types
        )
        self.raster_path_label.setText(raster_path)

    def browse_output_folder(self):
        output_folder = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        self.output_folder_label.setText(output_folder)

    # function to generate the threshold input fields according to user parameters
    def update_threshold_inputs(self):
        num_thresholds = self.num_thresholds_spin.value()
        for i in reversed(range(self.threshold_inputs_layout.count())):
            widget = self.threshold_inputs_layout.itemAt(i).widget()
            if widget is not None:
                widget.deleteLater()

        self.threshold_inputs = []
        num_columns = 2 if num_thresholds > 5 else 1
        for i in range(num_thresholds):
            threshold_label = QLabel(f"Threshold {i+1}:")
            threshold_spin = QSpinBox()
            threshold_spin.setRange(0, 255)
            threshold_spin.setValue(255 // num_thresholds * (i + 1))

            row = i // num_columns
            col = i % num_columns * 2

            self.threshold_inputs_layout.addWidget(threshold_label, row, col)
            self.threshold_inputs_layout.addWidget(threshold_spin, row, col + 1)

            self.threshold_inputs.append(threshold_spin)

    def update_operation_inputs(self):
        operation = self.operation_combo.currentText()
        if operation in ["Erosion", "Dilation"]:
            self.kernel_size_label.setVisible(True)
            self.kernel_size_spin.setVisible(True)
            self.iterations_label.setVisible(True)
            self.iterations_spin.setVisible(True)
        else:
            self.kernel_size_label.setVisible(False)
            self.kernel_size_spin.setVisible(False)
            self.iterations_label.setVisible(False)
            self.iterations_spin.setVisible(False)

    def submit_inputs(self):
        thresholds = [spin.value() for spin in self.threshold_inputs]
        self.result = {
            "raster_path": self.raster_path_label.text(),
            "operation": self.operation_combo.currentText(),
            "kernel_size": self.kernel_size_spin.value(),
            "iterations": self.iterations_spin.value(),
            "num_thresholds": self.num_thresholds_spin.value(),
            "thresholds": thresholds,
            "output_folder": self.output_folder_label.text(),
        }
        self.accept()


def save_binary_geotiff(binary_image, threshold_value, output_dir, transform, crs):
    output_path = os.path.join(output_dir, f"binary_image_{threshold_value}.tif")
    with rasterio.open(
        output_path,
        "w",
        driver="GTiff",
        height=binary_image.shape[0],
        width=binary_image.shape[1],
        count=1,
        dtype=binary_image.dtype,
        crs=crs,
        transform=transform,
    ) as dst:
        dst.write(binary_image, 1)
    write_log(log_file, f"Binary image saved to {output_path}")
    return output_path


# creates an instance of the InputDialog class to get user input
input_dialog = InputDialog()

# shows the dialog and check if the user accepted the input
if input_dialog.exec_() == QDialog.Accepted:
    inputs = input_dialog.result
    raster_path = inputs["raster_path"]
    operation = inputs["operation"]
    kernel_size = inputs["kernel_size"]
    iterations = inputs["iterations"]
    num_thresholds = inputs["num_thresholds"]
    threshold_values = inputs["thresholds"]
    output_folder = inputs["output_folder"]

    if not raster_path:
        print("File selection canceled.")
        write_log(None, "File selection canceled.")
    else:
        try:
            log_file = initialize_log(raster_path)
            start_time = datetime.datetime.now()
        except ValueError as e:
            print(f"Error: {e}")
            write_log(None, f"Error: {e}")
            exit()

        # reads and loads the input raster as a qgis raster layer
        layer = QgsRasterLayer(raster_path, "Raster Layer", "gdal")
        if not layer.isValid():
            print("Error: Could not load raster layer.")
            write_log(log_file, "Error: Could not load raster layer.")

        # loop through each threshold and apply the selected operation dilation/erosion
        else:
            all_contours = []
            fields = QgsFields()
            fields.append(QgsField("ID", QVariant.Int))
            fields.append(QgsField("Threshold", QVariant.Int))
            fields.append(QgsField("Length_Km", QVariant.Double))
            memory_layer = QgsVectorLayer(
                "LineString?crs=" + layer.crs().authid(),
                "combined_contours",
                "memory",
            )
            memory_layer.dataProvider().addAttributes(fields)
            memory_layer.updateFields()

            # get the raster properties for calculations, including its corners' coordinates
            x_pixel_size = layer.rasterUnitsPerPixelX()
            y_pixel_size = layer.rasterUnitsPerPixelY()
            xmin, ymax = layer.extent().xMinimum(), layer.extent().yMaximum()

            # reads the raster data
            block = layer.dataProvider().block(
                1, layer.extent(), layer.width(), layer.height()
            )
            raster_data = np.frombuffer(block.data(), dtype=np.uint8).reshape(
                (block.height(), block.width())
            )

            transform = from_origin(
                layer.extent().xMinimum(),
                layer.extent().yMaximum(),
                layer.rasterUnitsPerPixelX(),
                layer.rasterUnitsPerPixelY(),
            )
            crs = layer.crs().authid()

            progress_widget, progress_bar = setup_progress_bar(len(threshold_values))

            # a directory is created to save binary images to review the process
            binary_image_dir = os.path.join(log_directory, "Binary Images")
            if not os.path.exists(binary_image_dir):
                os.makedirs(binary_image_dir)

            # this one processes each threshold value
            for idx, threshold_value in enumerate(threshold_values):
                try:
                    # here the input raster is converted to a binary image per each threshold
                    write_log(
                        log_file,
                        f"Applying threshold value {threshold_value}, converting raster to binary image.",
                    )
                    _, binary_image = cv2.threshold(
                        raster_data, threshold_value, 255, cv2.THRESH_BINARY
                    )
                    binary_image = binary_image.astype(np.uint8)
                    write_log(
                        log_file,
                        f"Binary image dtype before operation: {binary_image.dtype}",
                    )
                    write_log(
                        log_file,
                        f"Unique values in binary image before operation: {np.unique(binary_image)}",
                    )

                    # here the threshold binary image is exported
                    output_path = save_binary_geotiff(
                        binary_image, threshold_value, binary_image_dir, transform, crs
                    )
                    write_log(log_file, f"Binary image saved to {output_path}")
                except Exception as e:
                    write_log(
                        log_file,
                        f"error during binary image conversion for threshold {threshold_value}: {e}",
                    )
                    continue

                # here the erosion/dilation is applied to the binary image
                if operation.lower() != "none":
                    try:
                        write_log(
                            log_file,
                            f"Applying {operation} operation with kernel size {kernel_size} and iterations {iterations}",
                        )
                        kernel = np.ones((kernel_size, kernel_size), np.uint8)
                        write_log(log_file, f"Kernel used: {kernel}")

                        if operation == "Dilation":
                            binary_image = cv2.dilate(
                                binary_image, kernel, iterations=iterations
                            )
                            write_log(log_file, "Dilation operation completed.")
                        elif operation == "Erosion":
                            binary_image = cv2.erode(
                                binary_image, kernel, iterations=iterations
                            )
                            write_log(log_file, "Erosion operation completed.")

                        write_log(
                            log_file,
                            f"Binary image dtype after operation: {binary_image.dtype}",
                        )
                        write_log(
                            log_file,
                            f"Unique values in binary image after operation: {np.unique(binary_image)}",
                        )
                    except Exception as e:
                        write_log(log_file, f"Error during {operation} operation: {e}")
                        continue

                    try:
                        output_path = save_binary_geotiff(
                            binary_image,
                            threshold_value,
                            binary_image_dir,
                            transform,
                            crs,
                        )
                        write_log(log_file, f"Binary image saved to {output_path}")
                    except Exception as e:
                        write_log(
                            log_file,
                            f"Error saving binary image for threshold {threshold_value}: {e}",
                        )

                    try:
                        update_progress_bar(progress_bar, idx + 1)
                    except RuntimeError as e:
                        write_log(log_file, f"RuntimeError: {e}")
                        break

                # here the contours are extracted from the binary image
                try:
                    contours, _ = cv2.findContours(
                        binary_image, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE
                    )
                    write_log(
                        log_file,
                        f"Found {len(contours)} contours for threshold value {threshold_value}",
                    )
                    all_contours.extend(contours)

                    # add contours as features to the QGIS memory layer
                    for idx, contour in enumerate(contours):
                        feature = QgsFeature()
                        map_coordinates = [
                            (
                                xmin + pt[0][0] * x_pixel_size,
                                ymax - pt[0][1] * y_pixel_size,
                            )
                            for pt in contour
                        ]
                        feature.setGeometry(
                            QgsGeometry.fromPolyline(
                                [QgsPoint(pt[0], pt[1]) for pt in map_coordinates]
                            )
                        )
                        feature.setAttributes(
                            [
                                idx + 1,
                                threshold_value,
                                len(contour) * (x_pixel_size + y_pixel_size) / 2000,
                            ]
                        )

                        memory_layer.dataProvider().addFeature(feature)

                    try:
                        update_progress_bar(progress_bar, idx + 1)
                    except RuntimeError as e:
                        write_log(log_file, f"RuntimeError: {e}")
                        break

                except Exception as e:
                    write_log(
                        log_file,
                        f"Error during contour extraction for threshold {threshold_value}: {e}",
                    )

                # export the output file name and save the vector layer
                input_basename = os.path.splitext(os.path.basename(raster_path))[0]
                threshold_values_str = "_".join(map(str, threshold_values))
                output_name = f"{input_basename}_combined_{threshold_values_str}_{operation}_{kernel_size}_iterations_{iterations}.shp"
                output_folder = inputs["output_folder"]
                if not output_folder:
                    print("Output folder selection canceled.")
                    write_log(log_file, "Output folder selection canceled.")
                else:
                    output_path = os.path.join(output_folder, output_name)
                    QgsVectorFileWriter.writeAsVectorFormat(
                        memory_layer,
                        output_path,
                        "utf-8",
                        layer.crs(),
                        "ESRI Shapefile",
                    )

                if not output_folder:
                    print("Output folder selection canceled.")
                    write_log(log_file, "Output folder selection canceled.")
                else:
                    output_path = os.path.join(output_folder, output_name)
                    QgsVectorFileWriter.writeAsVectorFormat(
                        memory_layer,
                        output_path,
                        "utf-8",
                        layer.crs(),
                        "ESRI Shapefile",
                    )

                    progress_bar.setValue(progress_bar.maximum())
                    progress_widget.close()
                    end_time = datetime.datetime.now()
                    processing_time = end_time - start_time
                    print(f"Contours exported to: {output_path}")
                    write_log(
                        log_file,
                        f"Contours exported to: {output_path} \n Total processing time: {processing_time}",
                    )
            # imports the saved shapefile to qgis
            saved_layer = QgsVectorLayer(output_path, output_name, "ogr")
            if not saved_layer.isValid():
                print(
                    f"Error: Could not load the shapefile {output_name} from {output_path}"
                )
                write_log(
                    log_file,
                    f"Error: Could not load the shapefile {output_name} from {output_path}",
                )
            else:
                QgsProject.instance().addMapLayer(saved_layer)
                print(f"Shapefile {output_name} imported to current project")
                write_log(
                    log_file,
                    f"Shapefile {output_name} from {output_path} imported to the current QGIS project",
                )
